# Phase 3 - Microwave Generation, Transmission and Orbital Distribution

Reserved under the fixed six-phase project structure. Do not create internal steps before the authorized preceding-phase handoff planning point.


=== ALL-PHASE TENTATIVE PLANNING BASELINE ===
Planning basis: 10 km cap for provisional downstream sizing; compare 20 km for shape retention. Retain 100 km and 250 km as documented reference cases. The 0.6% PV design, 1.1% alternative and 0.5%-3.0% coverage range remain in the trade record. Use conditional interfaces and explicit TBDs. Step 4 remains technically open; planning proceeds without representing any failed or unverified gate as passed. Keep pole results independent; aggregation is reporting only. Revisit the coupled design after the all-phase plan.
Transmission: use Phase 2 conditioned output as the input boundary. Size wavelength, transmitter and receiver apertures, pointing, duty cycle, conversion losses, thermal load and installed mass. Return link-budget and pointing envelopes over the nominal and CME trajectories plus shutdown behavior. Keep all transmission efficiencies and delivered power TBD until calculated.

CURRENT OPERATING REFERENCE: By user direction, plan for the loaded collector to remain at a fixed heliocentric location at 0.2 AU after future mass is installed. The outward moving reference and its day-seven power derating are historical studies. Use stationary-reference disturbance rejection for further acceptance work. Static balance is a design target and does not qualify CME stationkeeping, attitude stability or shape retention. Treat future mass reserve as prior to loading, and reconcile once actual hardware mass is known.
