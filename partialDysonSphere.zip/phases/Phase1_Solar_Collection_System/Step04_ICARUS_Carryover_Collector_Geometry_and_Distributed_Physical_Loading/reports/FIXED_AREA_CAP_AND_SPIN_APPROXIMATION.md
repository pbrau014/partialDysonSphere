# Phase 1 Step 4 provisional fixed-area cap and spin approximation

Apply the target independently to each pole. Set curved membrane area A = 0.10 (4 Pi RSun^2), using RSun = 695700000 m. Hold A fixed to first order. The rim restrains the boundary in the trial configuration. Its stiffness, attachments and the unsupported span remain design variables.

For a trial spherical cap with depth h and rim radius a, A = Pi (a^2 + h^2). With k = h/a = 0.1 from the existing initial geometry assumption, a = Sqrt[A/(Pi (1+k^2))], h = k a, and curvature radius Rc = (a^2+h^2)/(2 h). The existing projected area is numerically almost equal to the new curved-area target. At k = 0.1 the new projected area is 6.02188554666e17 m^2, giving 2.04919716616e22 W under uniform face-on irradiance of 34029.16163521439 W/m^2.

Use p = irradiance/c as an ideal perfect-absorption pressure scale. Under uniform normal pressure with equal principal tensions, Tpressure = p Rc/2 = 125482.5 N/m. This is a global unsupported-cap diagnostic. For the existing 0.1 micrometre foil alone this corresponds to 1.255e12 Pa membrane stress, so the trial shape needs a different load path for this foil baseline.

Use the foil-only areal mass sigma = 2705 kg/m^3 times 0.1 micrometre = 0.0002705 kg/m^2. The spin tension scale is Tspin = sigma (2 Pi a / P)^2, with spin period P in seconds. Equal pressure and spin scales give P = 35.478 h. At periods of 24 h and 168 h the spin-to-pressure scale ratios are 2.1852 and 0.04460. These are load-scale comparisons; the coefficient and installed mass depend on the actual load paths and mass distribution. The equality period is a sensitivity reference, not an operating speed.

A fixed-area spherical cap with a fixed circular rim radius has fixed depth. To study flattening in this model, allow the rim radius to respond while it continues to restrain the edge, or model shape redistribution with a more general surface. Determine span from actual restraints and support spacing. Continue with a rim and support reaction model, pole-local distributed loading, and spin cases before selecting a spin rate or changing baseline acceptance results. Values evaluated in native WolframScript.

## Current design correction

Spin does not flatten the sheet. The perimeter does not expand. The earlier flattening model is superseded. Hold the trial cap geometry fixed across spin cases. The trial depth ratio of 0.10 is a geometry input, independent of spin. For symmetric axial spin the per-pole outward force margin remains 7.6728e13 N and the same-geometry uniform added mass margin remains 5.1688e14 kg.

Native WolframScript, with a = 437815680.7345 m and uniform areal mass sigma = 0.0006305 kg/m^2, evaluated the rim-location acceleration a omega^2 and the sheet inertial load per unit area sigma a omega^2. At 24 h, 54.2 h, and 168 h, respectively, acceleration is 2.31539, 0.453991, and 0.0472528 m/s^2. The corresponding load densities are 0.00145945, 0.000286241, and 0.0000297929 N/m^2. These are outward cylindrical loads on the sheet near the rim. Their vector resultant cancels by symmetry, and they are not rim reactions. Actual reactions require a support load path. Apply the values independently to each pole under the same provisional inputs.
