# Native Step 4 structural pressure diagnostic

WolframScript 15.0.1 evaluated the saved v11.142 Pole 1 and Pole 2 checkpoints in separate processes. The trajectory solver was not rerun.

The dynamic screen compares the maximum resultant traction, Norm[F]/A, against a circular membrane transverse deflection pressure limit. F is the combined environmental and ICARUS patch force in the collector body frame. A is the curved patch surface area in square metres. The static screen instead uses Abs[F.n]/A, with n the local unit normal. Both quantities have pressure units. The resultant comparison is conservative for the normal component and does not evaluate in-plane stress.

The limit is Min[C f T, C f Tallow]/R, where C = 4, f = 0.05, T = 0.1 N/m, Tallow = 1.4 N/m, and R = 4.3999931355877507e8 m. The source derives Tallow from allowable stress times effective thickness. The assumed preliminary pretension controls this limit.

| Checkpoint quantity | Pole 1 | Pole 2 |
|---|---:|---:|
| Pretension-based limit (Pa) | 4.5454616368e-11 | 4.5454616368e-11 |
| Strength-based limit (Pa) | 6.3636462915e-10 | 6.3636462915e-10 |
| Peak saved resultant traction (Pa) | 1.3124657571e-4 | 1.3124657571e-4 |
| Peak normal pressure at the saved peak-resultant sample (Pa) | 1.3122368715e-4 | 1.3122368715e-4 |
| Static peak environmental normal pressure (Pa) | 9.3091087419e-5 | 9.3091087419e-5 |

To reproduce in Wolfram Language, load each assessment checkpoint with Get and take its Result association. Read Step4Core/SurfaceMesh/Patches and DynamicResults/PeakCombinedDynamicPatchLoadMap. Compare the ordered Position_m arrays before pairing the lists. They matched for all 1,280 patches in each checkpoint. Pair CombinedPatchForce_N with SurfaceAreaWeight_m2 and Normal, then take the maxima of Norm[F]/A and Abs[F.n]/A. At time 96286.567164 s, patch 64 had a resultant force of 6.2394291155e10 N over 4.7539747852e14 m^2. Its force divided by its area reproduced the saved peak. This sample bounds the trajectory's peak normal pressure from below.

The projected normal pressure at that sample alone exceeds the assumed-pretension limit by 2.887e6 and is above the strength-based limit. Dropping the tangential component would therefore leave both poles failing the screen. The static normal pressure also exceeds the assumed-pretension limit by 2.048e6. This diagnostic found no unit or patch indexing error in the saved peak. It does not validate application of the full-span circular membrane model to local loads on a curved, supported collector. The next structural investigation should examine the physical load path and whether the governing membrane span and pretension are supported by the design.
