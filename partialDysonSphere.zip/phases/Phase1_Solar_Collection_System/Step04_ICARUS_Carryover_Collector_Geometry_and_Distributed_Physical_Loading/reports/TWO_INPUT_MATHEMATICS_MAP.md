# Polar Collector mathematics from distance and irradiance

Independent checkpoint reads for Pole 1 and Pole 2 both give r = 29,919,574,140 m and S = 34,029.16163521439 W/m^2. The active source computes S as L/(4 Pi r^2), using L = 3.828e26 W. The separate rounded 1 AU reference of 1361 W/m^2 gives 34,025 W/m^2 at 0.2 AU. The active irradiance is a model reference-point flux, not a measurement or a patch-averaged incident flux.

## Reproducible Wolfram Language calculation

```wl
r = 29919574140;
s = 3828*10^23/(4 Pi r^2);
N[{4 Pi r^2, 4 Pi r^2 s, s/299792458, 2 s/299792458}, 12]
```

The first two quantities are spherical area and isotropic-equivalent luminosity. The luminosity reconstructs the source input by design. The final two use the SI speed of light and give ideal normal-incidence absorption and specular reflection pressures, not actual collector pressures.

## Dependency sequence

| Calculation | Additional information needed |
|---|---|
| Patch irradiance: S (r/rPatch)^2 Max[0,n.sunDirection] for an unshadowed illuminated face | Patch position, normal, and shadowing |
| Intercepted power: sum of patch incident irradiance times patch surface area | Curved sheet area and patch weights |
| Radiation force and torque: incident minus outgoing photon momentum, summed with each moment arm | Optical coefficients and reflection law, speed of light, geometry and center of mass |
| Solar gravity and gradient: -mu x/Norm[x]^3 and its spatial derivative | Solar gravitational parameter, positions, mass and inertia for force and torque |
| Wind and CME loads | Particle density, velocity, incidence and event history |
| Natural balance and ICARUS loads | All local force and torque terms, station geometry and actuator constraints |
| Dynamics, stability, saturation and recovery | Mass and inertia, initial state, controls, disturbance and numerical settings |
| Membrane stresses and deflections | Load paths, support spans and boundary conditions, material properties, thickness and pretension |
| Thermal and PV production | Optical absorption and emissivity, thermal paths, PV performance, area and temperature |
| Electrical conditioning, microwave links and grid | Hardware, topology, conversion efficiencies, link geometry and receiver data |

Two sheets at the same r and S can have different areas and therefore different intercepted power even under identical normal illumination. This already prevents a unique rebuild of sheet forces and every dependent project result. Independent inputs need to be measured, specified, or carried as parameters. Previous assessment outputs remain baseline evidence.
