# Phase 1 recalculation closure review

Decision: Phase 1 remains open. Retain the 0.5% to 3.0% PV trade range for each pole. The updated evidence is a fixed-cap trade study and does not establish a coupled operating configuration.

| Roadmap step | Evidence for the updated design | Remaining work |
|---|---|---|
| 1 Inputs | Curved area target, fixed cap and rim, uniform assembly mass and coverage range recorded | Establish installed support, electrical and heat transport inputs before freezing a configuration |
| 2 Natural equilibrium | Pole-local face-on radial force, added mass and gravity-gradient torque screens | Calculate the full force and torque balance at the intended attitude and trajectory with installed hardware |
| 3 ICARUS | Closed by explicit user authorization; technical completion was not asserted | Carry unfinished wrench, allocation and recovery work under Step 4 |
| 4 Geometry and distributed loading | Fixed-cap geometry, local traction and reduced rim load screens | Verify installed load maps, attachments and the carried-forward dynamics |
| 5 Structure | Trial radial/hoop stiffness sweep and rim load magnitudes | Resolve node forces, stress, deflection, allowable loads and structural mass |
| 6 Optics and thermal | Radiative temperature, heat rejection duty, radiator area and mass screens | Model coupled heat transport, view, optical effects and temperature with an installed geometry |
| 7 PV and buses | Gross and conditional electrical power across the trade range | Resolve cell layout, bus resistance, voltage drop and wiring mass and heat |
| 8 Integrated operation | Updated inertia and spin trial loads | Run independent integrated attitude, disturbance, saturation and recovery cases |
| 9 Optimization | Coverage and radiator mass sensitivities | Optimize conditional output with mechanical, thermal and electrical feasibility in the same design |
| 10 Verification and handoff | Independent baseline, chained sweep and radiator export for each pole | Verify the integrated model independently per pole and document the Phase 2 interface |

The roadmap keeps Step 4 incomplete and unaccepted. Step 5 remains preliminary, and the thermal and electrical screens in this review are exploratory sensitivities. They do not advance the formal roadmap sequence.

Per pole, the 28 coverage variants have no passing isolated thermal screen. The radiator screening explores 168 cases and reports 36 passing the radial mass screen for each pole. The largest remaining radial force among those cases is 7.1623e13 N at 0.5% PV. The highest sampled coverage passing the radial mass screen is 1.7%, conditional on bare-foil radiator mass and full effective view. Neither screen verifies a heat transport path or the forces on an installed radiator. No variant has documented coupled acceptance.

The first coupled closure case should establish how the cell heat reaches the emitting area, include its hardware and optical effects in the pole-local force budget, and determine whether sufficient mass margin remains for structure and buses. The coverage range remains in force for that work.

Evidence: Pole1 and Pole2 PV_Coverage_Baseline, PV_Three_Pass_Phase1 and PV_Radiator_Closure CSVs. The earlier native Step 4 assessment files apply to the older configuration.


## Provisional recalculation closeout

The architecture trade recalculations are complete for the current model scope. Retain 0.5% to 3.0% PV coverage per pole as the trade baseline. Carry the 0.6% distributed reference (100 kV, 1 km route, full effective radiator view, 1.0 g/m^2 cooling mass target) and the 1.1% higher-power alternative (0.2705 g/m^2 cooling target). The independent architecture exports contain 224 rows per pole. The reference has 2.85e14 kg remaining radial mass allowance and 3.39e18 W conditional electrical output per pole.

Formal Phase 1 acceptance remains open. The integrated cooling hardware, structural connections, electrical insulation and collection hardware, and independent native ICARUS dynamics have not been verified for the selected architecture. The trade closeout does not change the Step 4 acceptance decision.
