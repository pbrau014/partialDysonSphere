# Native Step 4 Baseline

**Run date:** 2026-11-22  
**Environment:** Wolfram Mathematica / WolframScript 15.0.1 for Microsoft Windows (64-bit)  
**Source revision:** v11.142  
**Source SHA-256:** `ef6d48795d2fac15db099e5da148cc142de4bad5040f5345d8aebb8382acbb2e`

## Execution method

The exact active source was loaded by the local WolframScript executable. Readiness, software self-tests, and pole-independence audit ran in one fresh process. Pole 1 and Pole 2 full Step 4 assessments then ran in separate fresh WolframScript processes. Each process loaded the exact same source revision and saved a distinct result checkpoint.

No engineering source code was changed during this baseline. No combined mechanical-equilibrium calculation was created.

## Smoke baseline

| Check | Result |
|---|---:|
| Source revision loaded | 11.142 |
| Input readiness | Passed; zero missing required inputs |
| Software self-tests | Passed, 49/49; no failed checks |
| Pole-independence audit | Passed |
| Native baseline checkpoint | `results/00_Native_Baseline.wl` |

## Per-pole assessment results

Both assessments returned structured associations, were not `Failure` results, and did not time out. Both report `Step4ScopeComplete -> False`; Step 4 remains **incomplete and not accepted**.

The aggregate acceptance checklist reported these four false conditions for each pole:

- `FiniteForceTargetAppliedWithoutSaturation`
- `GravityGradientReferenceTransverseStabilityPass`
- `DynamicMembraneTractionWithinStructuralScreen`
- `DynamicRecoveryWithinConfiguredLimit`

The corresponding force and dynamic subchecks also report station-force saturation, demand above the derived target, a failed dynamic structural-load screen, and recovery outside the configured limit. The raw dynamic result additionally reports radial-deviation and structural-screen checks as false. Hardware qualification remains explicitly unclaimed; those false qualification flags are not being treated as software or model execution failures.

| Pole-local output | Pole 1 | Pole 2 |
|---|---:|---:|
| Maximum required station force | 0.5166248963 N | 0.5166248963 N |
| Per-station force capacity | 0.4984669094 N | 0.4984669094 N |
| Saturation occurred | Yes | Yes |
| Maximum dynamic patch traction | 1.312465757 × 10⁻⁴ Pa | 1.312465757 × 10⁻⁴ Pa |
| Configured structural pressure limit | 4.545461637 × 10⁻¹¹ Pa | 4.545461637 × 10⁻¹¹ Pa |
| Recovery time | Infinity | Infinity |
| Reference transverse stability | Failed | Failed |

These values were obtained from separate pole executions. Their numerical equality is recorded as observed; pole results were not merged, and no shared mechanical equilibrium was calculated.

## Numerical diagnostics and interpretation

During each assessment, Mathematica emitted `General::munfl` underflow warnings for intermediate values around 10⁻²⁹⁸ and 10⁻²⁹⁹. The process continued and returned structured results with no timeout. The warnings are numerical diagnostics requiring review; they are not a pass and were not returned as a model-level `Failure`.

The false force-capacity, stability, structural-load, and recovery checks are actual modeled assessment results and must be investigated before Step 4 acceptance. This baseline does not identify or authorize a source correction by itself. Preserve the exact v11.142 source and diagnose each failed result and its inputs before making a focused change.

## Saved evidence

- `results/00_Native_Baseline.wl` - readiness, self-test, and pole-independence associations.
- `results/01_Pole1_Step4_Assessment.wl` - Pole 1 result and checkpoint metadata.
- `results/02_Pole2_Step4_Assessment.wl` - Pole 2 result and checkpoint metadata.
- `results/03_Native_Step4_Baseline_Summary.wl` - reporting-only summary retaining pole-separated results and the source hash.

