# Step 4 - Complete ICARUS Carryover, Collector Geometry, and Distributed Physical Loading

**Roadmap status:** Resumed, incomplete, and not accepted.  
**Active source baseline:** v11.142.

Run Pole 1 and Pole 2 assessments independently. Keep source, inputs, scripts, reports, tests, and generated results in the matching folders. See the project status note and the engineering verification report before continuing.

## PV coverage design baseline

Carry 0.5% through 3.0% of curved sheet area as the active PV design trade space for each pole. A coverage value is not selected. The fixed-cap reference sweep uses 0.1 percentage-point increments and includes the exact half-outward-margin and zero-radial-force cases. Run scripts/Run_PV_Coverage_Baseline.wl in a fresh WolframScript process for each pole, setting POLAR_COVERAGE_POLE to Pole1 or Pole2. The two result CSVs in results/ retain all 28 variants per pole.

The sweep uses the current 0.2 AU reference, fixed cap, uniformly distributed sheet assembly mass, and existing optical and PV reference inputs. The signed mass margin represents the radial force budget under fixed geometry and optics. The gross PV estimate uses linear irradiance scaling and excludes thermal derating and downstream losses. Rim loads use the equal-stiffness trial load path. Dynamic stability, thermal performance, hardware strength, attachment qualification and cell count are open. Keep inward-force cases for trade studies and revisit their balance when inputs change.

## Current recalculation plan

Use source/Phase1_Reference_Architecture.wl for the static native reference inputs. Complete reaction/load transfer and independent acceptance trajectories before closing the step.

Step 4 is closed by explicit user direction. Technical acceptance is not asserted. Phase 1 remains open. The earlier incomplete status records describe engineering evidence prior to this administrative closeout. This decision does not establish a technical pass or waive any later acceptance gate.

CURRENT DECISION: Step 4 is reopened by user direction. The administrative closeout is superseded. Technical acceptance remains incomplete, and Phase 1 remains open. Continue engineering verification before closure.


=== ALL-PHASE TENTATIVE PLANNING BASELINE ===
Planning basis: 10 km cap for provisional downstream sizing; compare 20 km for shape retention. Retain 100 km and 250 km as documented reference cases. The 0.6% PV design, 1.1% alternative and 0.5%-3.0% coverage range remain in the trade record. Use conditional interfaces and explicit TBDs. Step 4 remains technically open; planning proceeds without representing any failed or unverified gate as passed. Keep pole results independent; aggregation is reporting only. Revisit the coupled design after the all-phase plan.
Collector: 10 km, zero spin, active attitude control and CME ride-through. Screen radial reflector steering using 0.74 to 0.64 degree ideal rim angles. The ideal CME bypass leaves 2.76e11 kg per pole for remaining reinforcement and load relief, not for double allocation. Four units are reduced tracking evidence; 55 is a distinct radial thrust sizing case. Recompute installed loads, controls, power and trajectory.

CURRENT OPERATING REFERENCE: By user direction, plan for the loaded collector to remain at a fixed heliocentric location at 0.2 AU after future mass is installed. The outward moving reference and its day-seven power derating are historical studies. Use stationary-reference disturbance rejection for further acceptance work. Static balance is a design target and does not qualify CME stationkeeping, attitude stability or shape retention. Treat future mass reserve as prior to loading, and reconcile once actual hardware mass is known.

Provisional downstream planning sensitivity: charge trial optics, rim, 0.50 m ribs and junctions, and interface contingency before preserving a separate 10% future mass reserve. 0.823% PV and 4.64 EW per pole under the inherited optical/thermal/electrical assumptions. This is the current fully charged design trial, distinct from earlier optimistic output, and not an installed qualification or accepted mass ledger. See Step 4 checkpoint 83. The fixed 0.2 AU loaded reference remains.
