<|"SourceRevision" -> "11.142", "KernelVersion" -> 
  "15.0.1 for Microsoft Windows (64-bit) (July 2, 2026)", 
 "RunAt" -> "2026-11-22T22:53:12", "InputReadiness" -> 
  <|"Ready" -> True, "MissingRequiredInputKeys" -> {}, 
   "MissingRequiredInputCount" -> 0, "SharedInputCount" -> 112, 
   "PoleOperatingInputCountPerPole" -> 27, "PoleStatuses" -> 
    <|"Pole1" -> <|"Pole" -> "Pole1", "Ready" -> True, 
       "MissingRequiredInputKeys" -> {}, "InputCount" -> 139, 
       "MissingRequiredInputCount" -> 0|>, 
     "Pole2" -> <|"Pole" -> "Pole2", "Ready" -> True, 
       "MissingRequiredInputKeys" -> {}, "InputCount" -> 139, 
       "MissingRequiredInputCount" -> 0|>|>, "ApprovedAssumptionCount" -> 
    148, "ApprovedAssumptionsUsed" -> True, "EngineeringAcceptance" -> "NotEs\
tablishedByInputReadiness; evaluate each pole's calculations, constraints and \
qualification evidence separately.", "InputReadinessScope" -> "All registered \
calculation inputs are populated by user-approved assumptions, \
reference/software definitions or per-pole derived values. This does not \
imply feasibility, stability, actuator capacity or engineering acceptance.", 
   "UnresolvedEngineeringAndQualificationItems" -> 
    {<|"Item" -> "ICARUS mission-specific actuator redesign feasibility", 
      "Status" -> "User-approved conditional design assumption", 
      "Value" -> True, "Reason" -> "The user approves the premise that modest \
mission-specific reengineering can provide the required capability. This is a \
future design premise, not evidence that the present actuators are capable."|>\
, <|"Item" -> "ICARUS current hardware ratings and complete actuator law", 
      "Status" -> 
       "Unresolved; conditional redesign force target can be calculated", 
      "Value" -> Automatic, "Reason" -> "Present force rating remains \
unknown. Local actuator torque, stroke, slew rate, bandwidth, duty cycle, \
power draw, thermal limits, lifetime and qualification are not specified. The \
10% force reserve does not replace these checks."|>, 
     <|"Item" -> "External support/tether/anchor forces", 
      "Status" -> "Not modelled; no support force assumed in the free-hover \
calculation scope", "Value" -> Missing["NotModelled"], 
      "Reason" -> "Any real external support mechanism must be specified and \
added as its own physical force/torque contribution."|>, 
     <|"Item" -> 
       "Ultrathin aluminum-film process and structural qualification", 
      "Status" -> "Unqualified screening properties", 
      "Value" -> Missing["QualificationEvidenceRequired"], 
      "Reason" -> "Actual film thickness uniformity, grain/defect population, \
residual stress, yield and tensile response, fatigue, seams/joints, thermal \
cycling, radiation exposure, surface condition and manufacturing process must \
be characterized. Bulk 1060-O handbook values are not thin-film allowables."|>\
, <|"Item" -> "Near-Sun PV/reflector durability", 
      "Status" -> "Unqualified stress assumptions", 
      "Value" -> Missing["QualificationEvidenceRequired"], 
      "Reason" -> "Exact-device radiation, UV, thermal-vacuum and lifetime \
degradation data are not established by these screening assumptions."|>}|>, 
 "SoftwareSelfTests" -> <|"TestCount" -> 49, "PassedCount" -> 49, 
   "FailedChecks" -> <||>, "Passed" -> True, "TestScope" -> "Pure \
software/math-path tests only; these are not engineering feasibility tests."|>\
, "PoleIndependenceAudit" -> <|"Rule" -> "Two physically distinct systems, \
one at each pole; design/material definitions shared, all operation \
independent.", "Checks" -> <|"ExactlyTwoPoleSystems" -> True, 
     "SharedRegisterContainsNoPoleOperatingKeys" -> True, 
     "FlareAndCMEProfilesArePoleSpecific" -> True, 
     "ControllerGainsArePoleSpecific" -> True, 
     "HeliocentricReferenceMotionModeIsPoleSpecific" -> True, 
     "EachPoleHasItsOwnCompleteOperatingInputMap" -> True, 
     "PoleOperatingInputMapsSeparate" -> True, 
     "UpdatingPole1ChangesOnlyRequestedPole1Field" -> True, 
     "UpdatingPole1DoesNotChangePole2OperatingInputs" -> True, 
     "UpdatingPole1DoesNotChangePole2CachedState" -> True, 
     "UpdatingPole1InvalidatesOnlyPole1Cache" -> True, 
     "UpdatingPole2ChangesOnlyRequestedPole2Field" -> True, 
     "UpdatingPole2DoesNotChangePole1OperatingInputs" -> True, 
     "UpdatingPole2DoesNotChangePole1CachedState" -> True, 
     "UpdatingPole2InvalidatesOnlyPole2Cache" -> True, 
     "UpdatingPole1DoesNotChangeSharedDesignMaterialInputs" -> True, 
     "PoleContextsContainOnlyTheirOwnOperatingInputsAndState" -> True, 
     "Pole1ToPole2InputReadBlocked" -> True, 
     "Pole1ToPole2StateReadBlocked" -> True, 
     "Pole2ToPole1InputReadBlocked" -> True, 
     "Pole2ToPole1StateReadBlocked" -> True, 
     "SharedInputSnapshotIdenticalForBothContexts" -> True, 
     "AggregateCalculationDoesNotMutatePoleStateOrInputs" -> True, 
     "AggregateMassAndPowerAreArithmeticSums" -> True, 
     "AggregateDoesNotMultiplyByPoleCount" -> True, 
     "PerPoleContextsDoNotReceiveAggregateState" -> True, 
     "NoSharedOperationalStateOrCrossPoleFeedback" -> True|>, 
   "Passed" -> True, "PoleOperatingInputCountPerPole" -> 27, 
   "PoleIDs" -> {"Pole1", "Pole2"}, "Note" -> "The sentinel test ran inside a \
temporary state copy. No live input, pole state, cache or result was \
modified."|>, "SmokePass" -> True|>
