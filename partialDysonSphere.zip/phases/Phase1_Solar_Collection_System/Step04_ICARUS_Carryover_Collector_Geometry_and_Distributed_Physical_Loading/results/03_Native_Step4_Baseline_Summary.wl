<|"SourceRevision" -> "11.142", "SourceSHA256" -> 
  "ef6d48795d2fac15db099e5da148cc142de4bad5040f5345d8aebb8382acbb2e", 
 "KernelVersion" -> "15.0.1 for Microsoft Windows (64-bit) (July 2, 2026)", 
 "RunAt" -> "2026-11-22T23:46:45", 
 "Pole1" -> <|"ReturnedAssociation" -> True, "ModelFailure" -> False, 
   "TimedOut" -> False, "Step4ScopeComplete" -> False, 
   "Status" -> "Step 4 remains incomplete; one or more modeled checks are \
false or unavailable.", "FalseAcceptanceChecks" -> 
    {"FiniteForceTargetAppliedWithoutSaturation", 
     "GravityGradientReferenceTransverseStabilityPass", 
     "DynamicMembraneTractionWithinStructuralScreen", 
     "DynamicRecoveryWithinConfiguredLimit"}, "FalseICARUSChecks" -> 
    {"NoStationForceSaturation", "ForceDemandWithinDerivedTarget", 
     "DynamicStructuralLoadScreenPass", "RecoveryWithinConfiguredLimit"}, 
   "FalseDynamicChecks" -> {"DynamicStructuralLoadScreenPass", 
     "RadialDeviationWithinLimit", "RecoveryWithinLimit", 
     "StructuralScreenPass"}, "SaturationOccurred" -> True, 
   "MaxStationForceDemand_N" -> 0.5166248962887682, 
   "CapacityPerStation_N" -> 0.4984669094296332, "MaxDynamicTraction_Pa" -> 
    0.00013124657570620188, "DynamicTractionLimit_Pa" -> 
    4.545461636800577*^-11, "RecoveryTime_s" -> Infinity, 
   "RecoveryWithinLimit" -> False, 
   "GravityGradientReferenceTransverseStabilityPass" -> False|>, 
 "Pole2" -> <|"ReturnedAssociation" -> True, "ModelFailure" -> False, 
   "TimedOut" -> False, "Step4ScopeComplete" -> False, 
   "Status" -> "Step 4 remains incomplete; one or more modeled checks are \
false or unavailable.", "FalseAcceptanceChecks" -> 
    {"FiniteForceTargetAppliedWithoutSaturation", 
     "GravityGradientReferenceTransverseStabilityPass", 
     "DynamicMembraneTractionWithinStructuralScreen", 
     "DynamicRecoveryWithinConfiguredLimit"}, "FalseICARUSChecks" -> 
    {"NoStationForceSaturation", "ForceDemandWithinDerivedTarget", 
     "DynamicStructuralLoadScreenPass", "RecoveryWithinConfiguredLimit"}, 
   "FalseDynamicChecks" -> {"DynamicStructuralLoadScreenPass", 
     "RadialDeviationWithinLimit", "RecoveryWithinLimit", 
     "StructuralScreenPass"}, "SaturationOccurred" -> True, 
   "MaxStationForceDemand_N" -> 0.5166248962887682, 
   "CapacityPerStation_N" -> 0.4984669094296332, "MaxDynamicTraction_Pa" -> 
    0.00013124657570620188, "DynamicTractionLimit_Pa" -> 
    4.545461636800577*^-11, "RecoveryTime_s" -> Infinity, 
   "RecoveryWithinLimit" -> False, 
   "GravityGradientReferenceTransverseStabilityPass" -> False|>, 
 "BothPolesReturnedStructuredResults" -> True, 
 "BothPolesStep4ScopeComplete" -> False, 
 "NoCombinedMechanicalEquilibriumCreated" -> True|>
