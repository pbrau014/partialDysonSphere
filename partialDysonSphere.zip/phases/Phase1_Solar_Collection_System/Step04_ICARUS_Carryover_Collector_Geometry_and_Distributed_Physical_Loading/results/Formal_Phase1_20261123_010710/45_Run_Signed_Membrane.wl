(* Phase 1 Step 4: signed axisymmetric incremental membrane loads, tension positive. *)
p=Environment["POLAR_ACCEPT_POLE"];
z=Get["40_"<>p<>"_Membrane_Cut.wl"]; pressure=z["CMEPressureAtOnset_Pa"];
area=N[4 Pi 695700000^2/10];
run[h_]:=Module[{rc,q0,mean,rows,ns,nt,vm},
 rc=area/(2 Pi h); q0=1-h/rc; mean=(1+q0)/2;
 ns[q_]:=-pressure rc (q-q0)/(2(1+q));
 nt[q_]:=-pressure rc q (q-mean)-ns[q];
 vm[q_]:=Sqrt[ns[q]^2+nt[q]^2-ns[q] nt[q]];
 rows=Table[{u,ns[q0+(1-q0) u],nt[q0+(1-q0) u],vm[q0+(1-q0) u]},
  {u,Subdivide[0.,1.,1024]}];
 <|"Depth_km"->h/1000,"Apex_N_m"->Last[rows][[2;;3]],"Rim_N_m"->First[rows][[2;;3]],
 "PeakEquivalentIncrement_N_m"->Max[rows[[All,4]]],
 "FoilAllowable_N_m"->1.4,"IncrementOnlyStrengthScreenPass"->(Max[rows[[All,4]]]<=1.4),
 "Columns"->{"AreaCoordinateFromRim","Meridional_N_m","Hoop_N_m","VonMisesIncrement_N_m"},
 "Profile"->rows|>];
o=<|"Pole"->p,"Cases"->(run /@ {100000.,250000.}),
 "Scope"->"Incremental axisymmetric CME, freely translating fixed shape, uniform mass, no bending. No installed laminate, combined environmental baseline, buckling, bonding or thermal pass."|>;
Put[o,"45_"<>p<>"_Signed_Membrane.wl"];Print[{p,KeyDrop[#,"Profile"]& /@ o["Cases"]}];
