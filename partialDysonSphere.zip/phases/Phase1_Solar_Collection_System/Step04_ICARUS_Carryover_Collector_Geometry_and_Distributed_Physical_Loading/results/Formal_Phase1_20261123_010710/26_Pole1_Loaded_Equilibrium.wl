<|"Pole" -> "Pole1", "BaseNaturalRadial_N" -> 1.827272515782408*^13, 
 "BaseMass_kg" -> 7.779537658222802*^14, "LoadedForce_N" -> -1.296875, 
 "LoadedMass_kg" -> 9.012279991326266*^14, "AddedUniformMass_kg" -> 
  1.2327423331034638*^14, "LoadedOtherInstalledArealMass_kg_m2" -> 
  0.0005308900203667971, "ExactNaturalEquilibrium" -> True, 
 "OutwardRadialBiasPass" -> False, "RemainingGrowthReserve_kg" -> 
  -1.3588122690993729*^11, "LoadedSharedInputs" -> 
  <|"PerPoleProjectedArea_m2" -> 6.021885546663576*^17, 
   "CapDepthToPlanformRadius" -> 0.1, "PVFraction" -> 0.006, 
   "OtherInstalledArealMass_kg_m2" -> 0.0005308900203667971|>, 
 "LoadedPoleInputs" -> <|"Distance_m" -> 2.991957414*^10|>|>
