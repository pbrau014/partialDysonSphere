(* Phase 1 Step 4: moving-reference envelope and native wrench authority. *)
p=Environment["POLAR_ACCEPT_POLE"];
a=Get["29_"<>p<>"_Moving_Reference.wl"];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
d=Get["21_Step4_Candidate_Inputs.wl"];
w=c["ICARUSWrenchMatrix"]; radius=c["Geometry"]["PlanformEquivalentRadius_m"];
scale=DiagonalMatrix[Join[ConstantArray[1.,3],ConstantArray[1./radius,3]]];
wrench={1.,0.,0.,0.,0.,0.}; f=Partition[PseudoInverse[scale.w].(scale.wrench),3];
residual=Norm[scale.(w.Flatten[f]-wrench)];
If[residual>10^-10,Exit[1]];
(* Reserve the attitude-only confirmation demand on every station conservatively. *)
att=First[Get["20_"<>p<>"_Saturation.wl"]["Cases"]]["PeakDemand_N"];
cap=d["TrialStationCap_N"];
authority=(cap-att)/Max[Norm /@ f];
mass=a["Mass_kg"]; acceleration=authority/mass;
rows=a["DailyTrajectory"]; au=149597870700.;
tube=.01 radius; minFlux=34029.16163521439 (.2/(Max[rows[[All,2]]]+tube/au))^2;
o=<|"Pole"->p,"NominalDistanceRange_AU"->MinMax[rows[[All,2]]],
 "ProvisionalRadialTubeHalfWidth_m"->tube,
 "RequiredDistanceRangeWithTube_AU"->{Min[rows[[All,2]]]-tube/au,Max[rows[[All,2]]]+tube/au},
 "MinimumIrradianceWithTube_W_m2"->minFlux,"AttitudeReservePerStation_N"->att,
 "UnitRadialWrenchResidual"->residual,"AdditionalRadialWrenchAuthority_N"->authority,
 "Ideal24hVelocityCorrection_m_s"->86400 acceleration,
 "Ideal24hRestToRestPositionCorrection_m"->acceleration 86400^2/4,
 "Scope"->"Instantaneous allocation and isolated ideal double-integrator scales; station capacity, simultaneous support loads and achieved recovery remain unverified."|>;
Put[o,"30_"<>p<>"_Moving_Envelope.wl"];Print[o];
