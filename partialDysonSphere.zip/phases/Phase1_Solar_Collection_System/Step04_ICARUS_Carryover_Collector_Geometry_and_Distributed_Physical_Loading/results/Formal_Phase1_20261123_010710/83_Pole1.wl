<|"Pole" -> "Pole1", "PV_pct" -> 0.8228837603025585, 
 "ConditionalPower_W" -> 4.642799126832437*^18, 
 "NominalReflectivity" -> 0.98, "TrialBay_m" -> 0.5, 
 "FixedArchitectureCharge_kg" -> 1.0574723185880588*^14, 
 "OpticsAllocation_kg" -> 2.068593265953714*^13, 
 "RimStrengthOnly_kg" -> 2.9378736427257523*^13, 
 "RibsAndJunctions_kg" -> 4.640213564334267*^13, 
 "TrialInterfaceContingency_kg" -> 9.280427128668535*^12, 
 "PreLoadMass_kg" -> 8.269429099986738*^14, "PreLoadReserveRatio" -> 
  0.10000541427313599, "PreLoadReservePass" -> True, 
 "PreLoadOutwardBiasPass" -> True, "LaterUniformHardwareMassToBalance_kg" -> 
  8.284944420792858*^13, "LoadedMass_kg" -> 9.097923542066022*^14, 
 "LoadedRadialResidual_N" -> -0.328125, "ExactNaturalEquilibrium" -> True, 
 "Scope" -> "Native static planning ledger: collector optics, strength-only \
rim, trial grid with 1 micron minimum webs and 1 mg junctions plus 20 percent \
grid contingency are charged before future reserve. These are unverified \
trial masses. No coupled performance or power qualification."|>
