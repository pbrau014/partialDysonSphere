# Polar Collector

This is the dedicated working project directory.

- Workspace root: `C:\Users\boo_t\OneDrive\Documents\ChatGPT\dysonSpherePub`
- Project root: `C:\Users\boo_t\OneDrive\Documents\ChatGPT\dysonSpherePub\PolarCollector`
- Governing plan: [`governing/roadmap/Polar_Collector_Project_Roadmap_2026-11-22.txt`](governing/roadmap/Polar_Collector_Project_Roadmap_2026-11-22.txt)
- Current folder map: [`docs/architecture/Project_Layout.md`](docs/architecture/Project_Layout.md)
- Current source and status notes: [`docs/status/Current_Status_and_Location.md`](docs/status/Current_Status_and_Location.md)

## Current working position

The active design reference is 0.6% PV at 0.2 AU with a fixed curved sheet and perimeter, uniform sheet assembly mass, and distributed 100 kV collection over 1 km one-way routes. Keep the 1.1% higher-power alternative and the 0.5%-3.0% per-pole sweep. Reference conditioned power is 3.39e18 W per pole conditional on cooling, with 2.85e14 kg radial allowance after modeled cooling and copper. Phase 1 and Step 4 acceptance remain open. See the Phase 1 roadmap, Step 4 source/Phase1_Reference_Architecture.wl, architecture CSVs, and formal acceptance records.

The original extracted handoff and ZIP are preserved under `archives/handoffs/`. Active working files are separate copies so future project work does not alter the archived package or its checksum manifest.

