# Step 4 direction-specific compression bypass

Checkpoint 52 integrates the positive compression magnitude in each membrane direction independently from each pole's signed CME profiles. It credits zero residual foil compression, a trial 0.5 GPa compression allowable and density 1600 kg/m3, with no web, joints, buckling, thermal strain or coupling penalty. This is a stress-only idealized mass estimate for this load path. It is not a bound on all possible architectures.

At 100 km the ideal bypass needs 1.3611e12 kg versus 3.8795e11 kg after hoop fibers (3.51 times). At 250 km it needs 3.4028e12 kg versus 1.1977e11 kg (28.41 times). For the same material and load path, compression demand averaged over area must drop by 71.5% or 96.5%, respectively, to fit before other costs. Under shallow-cap linear scaling and if the whole 4.1203e11 kg budget were devoted to this bypass, about 30 km depth is a rough ceiling for the CME increment alone. This is an exploratory geometry sensitivity, not a change to the 100/250 km candidates or a shape-retention pass.

Task 51 did not leave a Pole2 output. The task 52 trials read the original 45 signed profiles independently rather than using task 51 results. Step 4 remains open.
