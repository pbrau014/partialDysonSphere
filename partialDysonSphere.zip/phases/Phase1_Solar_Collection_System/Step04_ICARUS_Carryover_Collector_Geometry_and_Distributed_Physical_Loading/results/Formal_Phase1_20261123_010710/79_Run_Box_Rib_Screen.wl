(* Phase 1 Step 4: local box rib screening with shared edges. *)
p=Environment["POLAR_ACCEPT_POLE"]; If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
r=Get["78_"<>p<>".wl"]; rho=1600.; ec=100.*^9; ew=30.*^9; nu=.3;
k=5.34 Pi^2 ew/(12 (1-nu^2)); sf=2.;
(* Ideal simply supported segment; equal loads from two neighboring bays.
   Cap bending and two isotropic-equivalent web shear buckling only. *)
screen[row_]:=Module[{l,delta,q,v,ei,fun,opt,h,t,cap,web},
 l=row[[1]];delta=.1 row[[3,1]];q=2 row[[5]]; v=sf q l/2;
 ei=5 q l^4/(384 delta);
 fun[d_?NumericQ]:=rho (4 ei/(ec d^2)+2 d (v d/(2 k))^(1./3.));
 opt=First@MinimalBy[Table[{d,fun[d]},{d,Exp@Subdivide[Log[.0005],Log[.05],1200]}],Last];
 h=First[opt];t=(v h/(2 k))^(1./3.);cap=4 ei/(ec h^2);web=2 h t;
 <|"Bay_m"->l,"AssumedEdgeMotionLimit_m"->delta,"RequiredEI_Nm2"->ei,
 "CapSeparation_m"->h,"TwoCapArea_m2"->cap,"EachWebThickness_m"->t,
 "TrialRibLinearMass_kg_m"->rho(cap+web),"AvailableLinearMassIfAllSpent_kg_m"->row[[4]],
 "MassFraction"->rho(cap+web)/row[[4]],"TwoFaceSlopeAmplification_mrad"->2000 row[[3,2]]|>];
out=<|"Pole"->p,"Rows"->(screen /@ Take[r["Rows"],4]),
 "Scope"->"Ideal equivalent material assumptions, service deflection and web shear-buckling screen. No bonded load transfer, cap local buckling, joint rigidity, minimum ply or film gauge, mass of sensors, whole-rim compatibility, transient rib dynamics. No installed pass."|>;
Put[out,"79_"<>p<>".wl"];Print[out];
