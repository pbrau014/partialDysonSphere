<|"Pole" -> "Pole2", "Cases" -> {<|"CoolingDensity_g_m2" -> 0.2705, 
    "ReserveFraction" -> 0., "PV_pct" -> 1.3285604139977651, 
    "ConditionalPower_W" -> 7.495881469072888*^18, 
    "RadialForce_N" -> -1.015625, "MassBeforeLaterLoading_kg" -> 
     9.24992423279015*^14, "ModelReportedMassReserve_kg" -> 
     -1.3724003910610345*^11, "StaticBalancePass" -> True, 
    "InterpolationResidual" -> -1.015625|>, 
   <|"CoolingDensity_g_m2" -> 0.2705, "ReserveFraction" -> 0.1, 
    "PV_pct" -> 1.1217393576998493, "ConditionalPower_W" -> 
     6.328974712719515*^18, "RadialForce_N" -> 1.2497832401396969*^13, 
    "MassBeforeLaterLoading_kg" -> 8.416398346401082*^14, 
    "ModelReportedMassReserve_kg" -> 8.416398346400578*^13, 
    "StaticBalancePass" -> False, "InterpolationResidual" -> -5.046875|>}, 
 "Scope" -> "Native static force at 10 km cap and 0.2 AU. Earlier linear PV \
and cooling laws with both modeled copper routes shortened from 1 km to 0.5 \
km at fixed voltage and loss. Ideal copper mass scales as route length \
squared. Extra distribution nodes and hardware uncounted. Installed hardware, \
radiator optical forces and CME stationkeeping unverified."|>
