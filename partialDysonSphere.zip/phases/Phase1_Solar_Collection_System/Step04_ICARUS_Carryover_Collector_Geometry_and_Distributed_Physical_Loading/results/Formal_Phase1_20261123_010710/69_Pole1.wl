<|"Pole" -> "Pole1", "OpticalAddedMassAllocation_kg" -> 
  2.068593265953714*^13, "MassAllocationParts_kg" -> 
  <|"ActiveOptics" -> 1.034296632976857*^13, "DriveAndSensing" -> 
    6.205779797861142*^12, "WiringAndMounts" -> 4.137186531907428*^12|>, 
 "OpticalArealMassCeiling_kg_m2" -> 0.00003438339534108583, 
 "OtherLaterHardwareAllocation_kg" -> 6.205779797861142*^13, 
 "Columns" -> {"WindMultiplier", "ForceEquivalentReturn", 
   "IdealSunwardBeamDeflection_deg", "ReflectedLight_W", 
   "OpticalAbsorptionHeat_W"}, 
 "Rows" -> {{1., 0.9806602951407333, 15.786341663659165, 
    2.045234375850606*^22, 2.047281657508114*^19}, 
   {1260., 0.7931059880197766, 54.069832891389325, 2.045234375850606*^22, 
    2.047281657508114*^19}, {2270., 0.6426613228914853, 73.40478972404418, 
    2.045234375850606*^22, 2.047281657508114*^19}}, 
 "UncompensatedCMEOnsetApexCompression_N_m" -> 0.10490058933694991, 
 "UncompensatedCMEOnsetRimHoop_N_m" -> 0.20980117867389983, 
 "Scope" -> "Ideal split nonabsorptive optical steering. Normal incidence \
energy screen, conditional absorptance. Static incremental shell loads only; \
no coupled transient shape or manufactured properties."|>
