<|"Pole" -> "Pole2", "AlignedNominalTorque_Nm" -> 0., 
 "ConfiguredCapacity_N" -> Automatic, 
 "Cases" -> {<|"Tilt_deg" -> 0., "Torque_Nm" -> 0., 
    "StationForces_N" -> {0., 0., 0., 0.}, "PeakStationForce_N" -> 0., 
    "ForceClosure_N" -> 0., "RelativeScaledResidual" -> 0.|>, 
   <|"Tilt_deg" -> 0.25, "Torque_Nm" -> 1.3940002725791554*^19, 
    "StationForces_N" -> {1.4931134279782133*^10, 5.523020510058751*^9, 
      1.4931134279782133*^10, 5.523020510058752*^9}, 
    "PeakStationForce_N" -> 1.4931134279782133*^10, 
    "ForceClosure_N" -> 2.566918070218477*^-6, "RelativeScaledResidual" -> 
     1.2193401078901627*^-16|>, <|"Tilt_deg" -> 0.5, 
    "Torque_Nm" -> 2.78804677281433*^19, "StationForces_N" -> 
     {2.986219608658378*^10, 1.1046613570611946*^10, 2.986219608658378*^10, 
      1.1046613570611948*^10}, "PeakStationForce_N" -> 2.986219608658378*^10, 
    "ForceClosure_N" -> 5.13411730365876*^-6, "RelativeScaledResidual" -> 
     1.221925739621709*^-16|>, <|"Tilt_deg" -> 1., 
    "Torque_Nm" -> 5.576463332169833*^19, "StationForces_N" -> 
     {5.972381239175338*^10, 2.209780673383477*^10, 5.972381239175338*^10, 
      2.2097806733834774*^10}, "PeakStationForce_N" -> 5.972381239175338*^10, 
    "ForceClosure_N" -> 0.000014952707937379124, "RelativeScaledResidual" -> 
     2.0810446680532483*^-16|>}|>
