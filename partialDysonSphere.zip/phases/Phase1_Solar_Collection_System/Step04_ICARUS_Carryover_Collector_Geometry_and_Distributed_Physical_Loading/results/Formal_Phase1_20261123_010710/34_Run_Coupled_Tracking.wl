(* Phase 1 Step 4: reduced radial and attitude tracking with shared station caps. *)
p=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
ref=Get["32_"<>p<>"_CME_RideThrough.wl"];
d=Get["21_Step4_Candidate_Inputs.wl"];
n=Get["29_"<>p<>"_Moving_Reference.wl"];
h=604800.; on=86400./h; off=235200./h; m=n["Mass_kg"];
grid=n["ForceGrid_N"]; r0=grid[[1,1]];
fit=Interpolation[({#[[1]]/r0,#[[2]] (#[[1]]/r0)^2}& /@ grid),InterpolationOrder->3];
j0=c["DynamicInitialConditions"]["InertiaTensor_kg_m2"]; is=Max[Diagonal[j0]];
(* Uniform additional mass uses a proportional inertia approximation. *)
is=is m/c["NaturalEquilibrium"]["CurrentPoleMass_kg"]; j=j0/Max[Diagonal[j0]];
wm=c["ICARUSWrenchMatrix"]; rad=c["Geometry"]["PlanformEquivalentRadius_m"];
sc=DiagonalMatrix[Join[{1.,1.,1.},ConstantArray[1./rad,3]]];
alloc=PseudoInverse[sc.wm].sc;
cap=d["TrialStationCap_N"]; omega=2. Pi; axis={1.,0.,0.};
kp=d["AttitudeKp_per_s2"] h^2; kd=d["AttitudeKd_per_s"] h;
wind=1259*2.0144675601821415*^10;
sun[q_]:=With[{z=Normalize[q]},{1-2(z[[3]]^2+z[[4]]^2),
 2(z[[2]] z[[3]]-z[[1]] z[[4]]),2(z[[2]] z[[4]]+z[[1]] z[[3]])}];
command[y_]:=Module[{q=y[[3;;6]],v=y[[7;;9]],u,b,t,fr},
 u=sun[q]; b=Cross[u,axis];
 t=-is/h^2 j.(kp If[Norm[b]==0.,b,ArcTan[u.axis,Norm[b]] Normalize[b]]+kd (v-omega u));
 fr=-m/h^2 (112.^2 y[[1]]+224. y[[2]]);
 Partition[alloc.Join[fr u,t],3]];
phase[lo_,hi_,ic_,ix_,delta_]:=Module[{y,t,rhs,s,extra},
 s=ref["Segments"][[ix]]; extra=If[ix==2,wind,0.];
 rhs[tt_?NumericQ,z_?VectorQ]/;VectorQ[z,NumericQ]:=Module[{u,q,v,f,wr,x,a,gg},
  q=z[[3;;6]]; v=z[[7;;9]]; u=sun[q];
  f=If[Norm[#]>cap,cap Normalize[#],#]& /@ command[z];
  wr=wm.Flatten[f]; x=s[tt]+z[[1]]/r0;
  a=h^2/m (-(fit[s[tt]]+extra) (z[[1]]/r0) (x+s[tt])/(x^2 s[tt]^2)+extra delta/x^2+
    Take[wr,3].u);
  gg=3. 1.3271244*^20 h^2/(r0 x)^3;
  Join[{z[[2]],a},Join[{-Rest[q].v},q[[1]] v+Cross[Rest[q],v]]/2+8 (1-q.q) q,
   LinearSolve[j,gg Cross[u,j.u]-Cross[v,j.v]+Take[wr,-3] h^2/is]]];
 NDSolveValue[{y'[t]==rhs[t,y[t]],y[lo]==ic},y,{t,lo,hi},
 AccuracyGoal->10,PrecisionGoal->11,MaxStepSize->1/4096,MaxSteps->Infinity]];
run[delta_]:=Module[{a,b,c2,ic,times,states,dem,good,post,bad,idx,err},
 ic=N[{0,0,Cos[Degree/8],0,Sin[Degree/8],0,omega,0,0}];
 a=phase[0.,on,ic,1,delta]; b=phase[on,off,a[on],2,delta];
 c2=phase[off,1.,b[off],3,delta];
 If[!AllTrue[{a,b,c2},MatchQ[#,_InterpolatingFunction]&],Return[Failure["Integration",<||>]]];
 times=Sort@DeleteDuplicates@Join[Subdivide[0.,1.,4032],{on,off}];
 states=(If[#<on,a[#],If[#<off,b[#],c2[#]]]& /@ times);
 dem=(Max[Norm /@ command[#]]& /@ states);
 err=({Abs[#[[1]]],Abs[#[[2]]]/h,ArcCos[Clip[First[sun[#[[3;;6]]]],{-1.,1.}]],
 Norm[#[[7;;9]]-omega sun[#[[3;;6]]]]/h}& /@ states);
 good=(And@@Thread[#<={.01 rad,10^-4,.0174533,10^-7}]& /@ err);
 post=Flatten@Position[(#>=off& /@ times),True]; bad=Select[post,!good[[#]]&];
 idx=If[bad==={},First[post],Last[bad]+1];
 <|"CMEExcessFractionError"->delta,"ExitErrors"->err[[First[post]]],
 "PeakDemand_N"->Max[dem],"SampledSaturation"->(Max[dem]>cap),
 "Recovery_s"->If[idx>Length[times],Infinity,h (times[[idx]]-off)],
 "QuatNormError"->Max[Abs[(Norm[#[[3;;6]]]& /@ states)-1]],
 "FinalErrors"->Last[err]|>];
out=<|"Pole"->p,"ErrorColumns"->{"RadialPosition_m","RadialVelocity_m_s","Tilt_rad","SpinRelativeRate_rad_s"},
 "Scope"->"Radial residual and nonlinear rigid attitude only. Relative radial force scales with inverse square using the nominal force coefficient. No lateral dynamics, pressure asymmetry or shape model.",
 "Cases"->(run /@ {0.,.0001})|>;
Put[out,"34_"<>p<>"_Coupled_Tracking.wl"];Print[out];

