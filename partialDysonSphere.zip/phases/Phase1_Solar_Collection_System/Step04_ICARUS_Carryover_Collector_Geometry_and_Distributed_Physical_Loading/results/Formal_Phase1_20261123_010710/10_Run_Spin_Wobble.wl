(* Phase 1 Step 4: native nonlinear axial-spin wobble, spin-relative diagnostics. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"];
days=ToExpression[Environment["POLAR_SPIN_DURATION_DAYS"]];
design=Get["01_Reference_Architecture.wl"];
spin=N[2 Pi/604800]; tilt=N[Degree/4];
updates=Join[design["PoleOperatingInputs"],<|"InitialAngularVelocity_rad_s"->{spin,0.,0.},
 "InitialAttitudeSmallAngles_rad"->{0.,tilt,0.},"DynamicCheckDuration_s"->N[86400 days]|>];
shared=Join[design["SharedNativeInputs"],<|
 "DynamicSampleCount"->(201 days/7),"DynamicAccuracyGoal"->If[days==7,8,10],
 "DynamicPrecisionGoal"->If[days==7,8,10]|>];
errors=Select[{Phase1SetInputs[shared],Phase1SetPoleOperatingInputs[pole,updates]},FailureQ];If[errors=!={},Print[errors];Exit[1]];
w=Phase1RunPoleTask[pole,"Wobble"];
If[!AssociationQ[w]||!TrueQ[w["TrajectoryIntegrityPass"]],Print[w];Exit[2]];
states=w["SampleStates"];
rot[q_]:=With[{v=Normalize[q]},1-2 (v[[3]]^2+v[[4]]^2)];
angles=ArcCos[Clip[rot[#],{-1.,1.}]]& /@ states[[All,1]];
rates=Norm[Rest[#]]& /@ states[[All,2]];
summary=<|"Pole"->pole,"DurationDays"->days,"PeakSunRelativeTilt_deg"->Max[angles]/Degree,
 "PeakTransverseBodyRate_rad_s"->Max[rates],"TiltWithinProjectTolerance"->(Max[angles]<=.0174533),
 "TransverseRateWithinProjectRecoveryTolerance"->(Max[rates]<=1.*^-7),
 "NativeNonspinningLinearReferenceGate"->w["AlignedReferenceTransverseStabilityPass"],
 "MaxQuaternionNormError"->w["MaximumQuaternionNormalizationError"]|>;
Put[<|"Summary"->summary,"Inputs"->Join[shared,updates],"SourceHash"->FileHash[src,"SHA256","HexString"],
 "NativeResult"->w|>,"10_"<>pole<>"_"<>ToString[days]<>"d.wl"];
Print[summary];

