(* Phase 1 Step 4: best membrane force achievable by arbitrary uniform axial acceleration. *)
p=Environment["POLAR_ACCEPT_POLE"];
a=Get["40_"<>p<>"_Membrane_Cut.wl"];
q=(1-.1^2)/(1+.1^2);
(* Meridional resultant on a cut at cosine u is p Rc ((1+u)/2-c)/(1+u),
   with c an arbitrary translating-frame acceleration offset. The minimum
   maximum absolute value occurs when apex and rim values are opposite. *)
h=4 a["ApexMeridionalIncrementMagnitude_N_m"]/a["CMEPressureAtOnset_Pa"];
bound=a["CMEPressureAtOnset_Pa"] h/(2 (3+q));
out=<|"Pole"->p,"BestPeakCMEMembraneIncrement_N_m"->bound,
 "FoilAllowable_N_m"->a["LegacyAllowablePretension_N_m"],
 "Ratio"->bound/a["LegacyAllowablePretension_N_m"],
 "Scope"->"Axisymmetric unchanged cap, uniform sheet mass, membrane-only incremental response. Arbitrary net axial thrust at perimeter. No reinforced or bending shell model."|>;
Put[out,"41_"<>p<>"_Rim_Thrust_Limit.wl"];Print[out];
