(* Phase 1 Step 4: spin-relative attitude control and station allocation screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
w=c["ICARUSWrenchMatrix"]; j=c["DynamicInitialConditions"]["InertiaTensor_kg_m2"];
radius=c["Geometry"]["PlanformEquivalentRadius_m"];
s=DiagonalMatrix[Join[ConstantArray[1.,3],ConstantArray[1./radius,3]]];
allocator=PseudoInverse[s.w].s;
axis={1.,0.,0.}; omega=2. Pi/604800;
kp=2.9533720891532804*^-11; kd=7.685534580174993*^-6;
tracking[u_,rate_]:=Module[{b,err},
 b=Cross[u,axis];
 err=If[Norm[b]==0.,0. b,ArcTan[Dot[u,axis],Norm[b]] Normalize[b]];
 -j.(kp err+kd (rate-omega u))];
(* Apply the initial peak attitude demand of the 16x case. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
design=Get["01_Reference_Architecture.wl"];
in=Join[Phase1GetInputs[],design["SharedNativeInputs"],design["PoleOperatingInputs"]];
mapper=ToExpression[First[Names["*`Private`phase1LoadMap"]]];
u=N[{Cos[1.25 Degree],0,Sin[1.25 Degree]}];
forces=Partition[allocator.Join[{0.,0.,0.},16 tracking[u,omega axis]],3];
m=mapper[in,c["Geometry"],c["SurfaceMesh"],c["DynamicInitialConditions"],forces];
If[!AssociationQ[m],Print[m];Exit[1]];
patch=m["Patches"];
areas=Lookup[c["SurfaceMesh"]["Patches"],"SurfaceAreaWeight_m2"];
normals=Lookup[c["SurfaceMesh"]["Patches"],"Normal"];
traction=MapThread[#1/#2&,{Lookup[patch,"EstimatedLocalLoadVector_N"],areas}];
normal=Max[Abs[MapThread[Dot,{traction,normals}]]];
s0=Get["06_"<>p<>"_Structural_Preflight.wl"]["AppliedPeakLocalNormalEnvironmentalPressureIncludingGravity_Pa"];
summary=Join[KeyTake[m,{"ForceAndMomentConservationPass","AllIndividualStationTransfersConserved","ForceConservationResidual_N","MomentConservationResidual_Nm"}],
 <|"PeakStationForce_N"->Max[Norm /@ forces],"PeakMappedTraction_Pa"->Max[Norm /@ traction],
 "PeakMappedNormal_Pa"->normal,"StaticPlusStationNormalEnvelope_Pa"->s0+normal,
 "Trial300mRequiredPretension_N_m"->300 (s0+normal)/.2,
 "MaxHalfSpanAtPointOnePretension_m"->.02/(s0+normal)|>];
Put[<|"Pole"->p,"Summary"->summary,"Map"->m|>,"16_"<>p<>"_Peak_Load_Transfer.wl"];Print[{p,summary}];
