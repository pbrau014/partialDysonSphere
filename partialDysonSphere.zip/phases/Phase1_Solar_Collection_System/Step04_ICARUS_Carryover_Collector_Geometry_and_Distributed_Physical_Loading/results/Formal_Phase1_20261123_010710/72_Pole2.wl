<|"Pole" -> "Pole2", "Cases" -> {<|"CMEExcessFractionError" -> 0., 
    "ModalRefinement" -> {<|"RadialModesPerHarmonic" -> 3, 
       "MaxAzimuthalOrder" -> 2, "PeakSampledDeflection_m" -> 
        325702.192788861, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 325702.192788861, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>, <|"RadialModesPerHarmonic" -> 6, 
       "MaxAzimuthalOrder" -> 4, "PeakSampledDeflection_m" -> 
        3.613623483645065*^6, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 3.613623483645065*^6, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>}|>, <|"CMEExcessFractionError" -> 0.0001, 
    "ModalRefinement" -> {<|"RadialModesPerHarmonic" -> 3, 
       "MaxAzimuthalOrder" -> 2, "PeakSampledDeflection_m" -> 
        531456.6178434271, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 531456.6178434271, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>, <|"RadialModesPerHarmonic" -> 6, 
       "MaxAzimuthalOrder" -> 4, "PeakSampledDeflection_m" -> 
        3.888562786428323*^6, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 3.888562786428323*^6, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>}|>}, "Scope" -> "Linear tensioned \
flat-equivalent membrane, ideal fixed rigid rim, native coarse station map, \
axisymmetric incremental CME load. Zero initial deflection/velocity and no \
damping. Excludes rim flexibility, wrinkles, local attachment stress, lateral \
pressure distribution, material imperfections, optical-structural feedback \
and static shape. Incremental deflection only."|>
