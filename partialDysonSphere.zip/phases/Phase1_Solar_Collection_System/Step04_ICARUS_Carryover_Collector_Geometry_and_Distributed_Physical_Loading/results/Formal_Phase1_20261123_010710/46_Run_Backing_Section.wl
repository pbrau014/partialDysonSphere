(* Phase 1 Step 4: explicit trial orthogonal hat backing; ideal section screens. *)
p=Environment["POLAR_ACCEPT_POLE"];
s=Get["45_"<>p<>"_Signed_Membrane.wl"];
area=N[4 Pi 695700000^2/10]; pitch=1.; depth=.01; width=.001;
(* Symmetric axial carbon cap pair per rib, two orthogonal families; optimistic
   pinned Euler screen assumes perfectly effective web and perfect cap sharing.
   Trial laminate properties are assumptions, not bare-fiber allowables. *)
e=100.*^9; rho=1600.; allow=1.*^9; sf=2.; overlap=.05;
rows=Map[Function[c,Module[{profile,compression,tension,section,meanForce},
 profile=c["Profile"][[All,2;;3]];
 compression=Max[0.,-Min[profile]] pitch;
 tension=Max[profile] pitch;
 section=Max[sf tension/allow,sf compression pitch^2/(Pi^2 e (depth/2)^2)];
 meanForce=Max[compression,tension];
 <|"Depth_km"->c["Depth_km"],"CompressionPerRib_N"->compression,
 "TensionPerRib_N"->tension,"RequiredCapAreaTotal_m2"->section,
 "ThicknessEachCap_m"->section/(2 width),"CapOnlyMass_kg"->area 2 rho section/pitch,
 "IllustrativeAverageLapShear_Pa"->meanForce/(width overlap)|>
 ]],s["Cases"]];
out=<|"Pole"->p,"Cases"->rows,"Pitch_m"->pitch,"CapCenterSeparation_m"->depth,
 "CapWidth_m"->width,"Layup"->"Each cap symmetric axial [0] plies in its rib direction; orthogonal rib families; trial plus-minus 45 degree webs required, not sized.",
 "Bond"->"Continuous 1 mm footprint at lower cap, with 50 mm trial load transfer length; adhesive thickness trial 25 micrometres. Average lap shear is a demand only.",
 "Scope"->"Peak-sized uniform cap-only estimate; excludes web, adhesive, junctions, imperfection reductions, local buckling, peel and thermal stresses. No acceptance."|>;
Put[out,"46_"<>p<>"_Backing_Section.wl"];Print[out];
