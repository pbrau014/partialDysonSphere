<|"Pole" -> "Pole1", "NominalDistanceRange_AU" -> 
  {0.19999999999999998, 0.21773447346244817}, 
 "ProvisionalRadialTubeHalfWidth_m" -> 4.3781568073451845*^6, 
 "RequiredDistanceRangeWithTube_AU" -> {0.19997073382938632, 
   0.21776373963306184}, "MinimumIrradianceWithTube_W_m2" -> 
  28703.84716580937, "AttitudeReservePerStation_N" -> 4.479253316868296*^11, 
 "UnitRadialWrenchResidual" -> 3.429248365163705*^-17, 
 "AdditionalRadialWrenchAuthority_N" -> 2.0829867325268164*^11, 
 "Ideal24hVelocityCorrection_m_s" -> 21.981219911566395, 
 "Ideal24hRestToRestPositionCorrection_m" -> 474794.35008983413, 
 "Scope" -> "Instantaneous allocation and isolated ideal double-integrator \
scales; station capacity, simultaneous support loads and achieved recovery \
remain unverified."|>
