(* Phase 1 Step 4: backside reinforcement candidate, for screening only. *)
<|"BaselineICARUSPerPole"->55,"BackingPlacement"->"Antisunward behind continuous aluminum reflector",
 "Candidate"->"Toray T1100G carbon fiber reinforced backing",
 "FiberDensity_kg_m3"->1790.,"FiberUltimateTensile_Pa"->7.*^9,
 "IllustrativeTensileDesignFactor"->2.,
 "ModelStatus"->"No installed laminate allowable or compression capacity established. No installed mass committed.",
 "ManufacturerData"->"https://www.toraycma.com/wp-content/uploads/Torayca-Technical-Manual_4-28-2020.pdf"|>
