# Step 4 integrated spin candidate

The candidate source adds opt-in tracking of Sun-relative tilt and angular velocity relative to the intended seven-day spin. The default fixed-attitude mode remains available. Recovery uses the same position, velocity, angle and angular-rate limits with spin-relative attitude and rate in the new mode. The governing v11.142 source and acceptance gates remain intact.

The initial 60-second wiring check was rejected by the existing recovery-duration validator. The corrected diagnostic uses the full seven-day window at 6 by 16 mesh resolution and 16 configured samples, and imposes a 150-second runtime bound per pole. Its resolution is for development, not technical acceptance.

The ideal four-station pure-axial aluminum mass screen at 500 GN per station and 14 MPa requires 3.8643e8 kg for each metre of common path length. Spending one quarter of the 0.6% reference radial mass allowance on those paths yields an ideal equal-length ceiling of 184 km per station. This excludes joints, stress concentrations, buckling, reinforcement and actuator mass. It is a sizing constraint, not a verified path length.

Step 4 remains open pending resolved load paths and full independent integrated verification.

Both 23 coarse native seven-day runs returned successfully with no sampled saturation at the 500 GN trial cap. Peak demand was 173.683 GN per station, quaternion norm error 6.069e-9, recovery Infinity, and the structural screen failed. The 24 candidate adds off-manifold quaternion-norm correction (zero on the exact physical state manifold) and reports each final recovery error independently. Neither coarse trajectory is sufficient for acceptance.
