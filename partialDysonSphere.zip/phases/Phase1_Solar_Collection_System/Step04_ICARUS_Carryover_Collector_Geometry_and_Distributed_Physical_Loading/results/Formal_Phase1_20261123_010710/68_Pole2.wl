<|"Pole" -> "Pole2", "Cases" -> 
  {<|"OpticalLag_s" -> 1., "Recovery_s" -> 40620.00000000002, 
    "PeakUnclippedRadialDemand_N" -> 9.465715163203737*^9, 
    "SampledSaturation" -> False, "PeakRadialExcursion_m" -> 
     56.004087077380674|>, <|"OpticalLag_s" -> 10., 
    "Recovery_s" -> 54900.00000000003, "PeakUnclippedRadialDemand_N" -> 
     9.332821854897617*^10, "SampledSaturation" -> False, 
    "PeakRadialExcursion_m" -> 560.0389692364741|>, 
   <|"OpticalLag_s" -> 60., "Recovery_s" -> 71220., 
    "PeakUnclippedRadialDemand_N" -> 5.564222646771133*^11, 
    "SampledSaturation" -> True, "PeakRadialExcursion_m" -> 
     6160.461554433977|>, <|"OpticalLag_s" -> 300., 
    "Recovery_s" -> 164880.00000000003, "PeakUnclippedRadialDemand_N" -> 
     5.201836390162439*^12, "SampledSaturation" -> True, 
    "PeakRadialExcursion_m" -> 153569.24183840494|>}, 
 "Scope" -> "Ideal area-integrated optical feedforward plus clipped radial \
correction. No attitude, local shape or implemented device. Exact forcing \
assumed apart from first-order lag; existing Gaussian flare amplitude and \
timing."|>
