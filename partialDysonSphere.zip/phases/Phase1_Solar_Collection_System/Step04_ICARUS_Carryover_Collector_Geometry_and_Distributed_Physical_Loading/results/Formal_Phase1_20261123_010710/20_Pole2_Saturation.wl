<|"Pole" -> "Pole2", "Cases" -> {<|"Cap_N" -> 5.*^11, "GainFactor" -> 6., 
    "RelativeDamping" -> 1., "SolverSucceeded" -> True, 
    "Recovery_s" -> 75000., "PeakDemand_N" -> 4.479253316868296*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00009281276957829899, 
    "QuaternionNormError" -> 3.885780586188048*^-15|>}|>
