<|"Pole" -> "Pole2", "Columns" -> {"Depth_km", "CMEPeakIncrement_N_m", 
   "GradedTensileEquivalentFiberMass_kg", 
   "FractionOfPreAllocationMassAllowance", "RimRadius_m"}, 
 "Rows" -> {{43781.56807345185, 459.271229300089, 7.123167459765355*^13, 
    1.7288035027798943, 4.3781568073451835*^8}, {10000., 104.90058933694992, 
    1.588522473699698*^13, 0.38553680399745716, 4.3988566241695124*^8}, 
   {1000., 10.490058933694993, 1.2250823381856487*^12, 0.029732933409358585, 
    4.399981772689519*^8}, {250., 2.622514733423748, 8.863377061281204*^10, 
    0.0021511550018377176, 4.399992426129845*^8}, 
   {100., 1.0490058933694992, 0., 0., 4.3999930227217406*^8}}, 
 "Scope" -> "Same onset pressure and area; incremental axisymmetric \
membrane-only screen. Fiber mass uses magnitude of load as tensile \
equivalent, not compression capacity. Excludes matrix, bonding, reinforcement \
mass feedback, all other loads and buckling."|>
