<|"Pole" -> "Pole1", "Cases" -> {<|"CMEExcessFractionError" -> 0., 
    "ZoneScreens" -> {<|"RequestedZones" -> 128, "OccupiedZones" -> 128, 
       "TargetModeCount" -> 15, "ConstraintOperatorResidual" -> 
        9.589141616282111*^-15, "PeakPressureAdjustment_Pa" -> 
        4.953836505713232*^-7, "RelativeWrenchResidual" -> 
        1.0481342542013952*^-14, "PeakDeflectionFromZoneQuantization_m" -> 
        221028.4372718701|>, <|"RequestedZones" -> 384, 
       "OccupiedZones" -> 384, "TargetModeCount" -> 15, 
       "ConstraintOperatorResidual" -> 3.9098627084114955*^-15, 
       "PeakPressureAdjustment_Pa" -> 5.014018650197785*^-7, 
       "RelativeWrenchResidual" -> 7.529140934618589*^-15, 
       "PeakDeflectionFromZoneQuantization_m" -> 248479.41576676993|>}|>, 
   <|"CMEExcessFractionError" -> 0.0001, "ZoneScreens" -> 
     {<|"RequestedZones" -> 128, "OccupiedZones" -> 128, 
       "TargetModeCount" -> 15, "ConstraintOperatorResidual" -> 
        9.589141616282111*^-15, "PeakPressureAdjustment_Pa" -> 
        4.953836505713232*^-7, "RelativeWrenchResidual" -> 
        1.0481391527025635*^-14, "PeakDeflectionFromZoneQuantization_m" -> 
        221028.436839619|>, <|"RequestedZones" -> 384, 
       "OccupiedZones" -> 384, "TargetModeCount" -> 15, 
       "ConstraintOperatorResidual" -> 3.9098627084114955*^-15, 
       "PeakPressureAdjustment_Pa" -> 5.014018650197785*^-7, 
       "RelativeWrenchResidual" -> 7.535120703376626*^-15, 
       "PeakDeflectionFromZoneQuantization_m" -> 248479.41528084857|>}|>}, 
 "Scope" -> "One-way replay, finite-zone pressure with modal allocation and \
held-out higher modes only. Previous station histories are targets. Neither \
thermal recoil, residual ICARUS, real zone lag, feedback, nor rim compliance \
is included."|>
