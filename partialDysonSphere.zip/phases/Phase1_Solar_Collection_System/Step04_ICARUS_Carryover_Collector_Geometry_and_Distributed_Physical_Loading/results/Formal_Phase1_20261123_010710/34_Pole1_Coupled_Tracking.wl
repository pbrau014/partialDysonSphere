<|"Pole" -> "Pole1", "ErrorColumns" -> {"RadialPosition_m", 
   "RadialVelocity_m_s", "Tilt_rad", "SpinRelativeRate_rad_s"}, 
 "Scope" -> "Radial residual and nonlinear rigid attitude only. Relative \
radial force scales with inverse square using the nominal force coefficient. \
No lateral dynamics, pressure asymmetry or shape model.", 
 "Cases" -> {<|"CMEExcessFractionError" -> 0., 
    "ExitErrors" -> {1.647840840117815*^-14, 5.630247039446806*^-19, 
      0.0010847537785521387, 7.475978684830298*^-9}, 
    "PeakDemand_N" -> 9.428415631266415*^10, "SampledSaturation" -> False, 
    "Recovery_s" -> -3.3573144264664734*^-11, "QuatNormError" -> 
     8.489620118012908*^-11, "FinalErrors" -> {4.060330280425696*^-16, 
      3.3162444474556646*^-19, 0.00008291186595184504, 
      5.821276957919246*^-10}|>, <|"CMEExcessFractionError" -> 0.0001, 
    "ExitErrors" -> {86.4279520706329, 0.00004239073556029636, 
      0.0010847537758910922, 7.47597866865563*^-9}, 
    "PeakDemand_N" -> 9.428415631266415*^10, "SampledSaturation" -> False, 
    "Recovery_s" -> 37949.99999999996, "QuatNormError" -> 
     7.69406760525726*^-12, "FinalErrors" -> {9.419384555696628*^-16, 
      5.2173007927130943*^-20, 0.00008291186595184504, 
      5.821276931172598*^-10}|>}|>
