(* Phase 1 Step 4: high precision nonlinear gravity-gradient spin diagnostic. *)
p=Environment["POLAR_ACCEPT_POLE"];
w=Get["08_"<>p<>"_Wobble.wl"]["Result"];
j=Rationalize[w["GravityGradientLinearization"]["InertiaTensor_kg_m2"],0];
j=j/Max[Diagonal[j]];
k=3 (13271244 10^13) 604800^2/29919574140^3;
q={a[t],b[t],c[t],d[t]}; v={u[t],v2[t],v3[t]};
r={1-2(q[[3]]^2+q[[4]]^2),2(q[[2]]q[[3]]-q[[1]]q[[4]]),2(q[[2]]q[[4]]+q[[1]]q[[3]])}/(q.q)
  +{1-1/(q.q),0,0};
qdot=Join[{-Rest[q].v},q[[1]]v+Cross[Rest[q],v]]/2;
eq=Join[Thread[D[q,t]==qdot],Thread[j.D[v,t]==k Cross[r,j.r]-Cross[v,j.v]]];
run[angle_,days_,prec_]:=Module[{sol,ic,res,qv,ang,rate,err},
 ic=Join[Thread[(q/.t->0)=={Cos[angle/2],0,Sin[angle/2],0}],
 Thread[(v/.t->0)=={2 Pi,0,0}]];
 sol=NDSolveValue[Join[eq,ic],{a,b,c,d,u,v2,v3},{t,0,days/7},
 WorkingPrecision->prec,AccuracyGoal->prec-12,PrecisionGoal->prec-12,MaxSteps->Infinity];
 res=Through[sol[#]]& /@ Subdivide[0,days/7,days 144];
 qv=res[[All,1;;4]];
 err=Max[Abs[(Norm /@ qv)-1]];
 ang=Max[ArcCos[Clip[1-2 Total[Normalize[#][[3;;4]]^2],{-1,1}]]& /@ qv];
 rate=Max[Norm /@ res[[All,6;;7]]]/604800;
 <|"Days"->days,"StartTilt_deg"->angle/Degree,"Precision"->prec,
 "PeakTilt_deg"->N[ang/Degree,12],"PeakTransverseRate_rad_s"->N[rate,12],
 "NormError"->N[err,12],"Pass"->TrueQ[ang<=.0174533&&rate<=10^-7&&err<=10^-10]|>];
out={run[Degree/4,7,32],run[Degree/4,28,38],run[Degree/2,28,38]};
Put[<|"Pole"->p,"Results"->out|>,"11_"<>p<>"_Precision_Spin.wl"]; Print[{p,out}];
