# Step 4 spin comparison, 10 km planning cap

Zero commanded spin is already the planning reference. The new structural screen compares zero spin, seven-day spin, 24-hour spin and an approximately 32.67-day spin chosen to balance the average transverse cut at 0.2 AU. The 24-hour period is a trial definition of fast spin. Sign convention: positive cut resultant is outward/tensile demand and negative is inward/compression demand.

| Case | Initial gravity/centrifugal cut N/m | Day-seven cut N/m | Initial isolated aluminum ring stress |
|---|---:|---:|---:|
| Held at zero spin | -430.37 | -280.20 | -2.594 GPa (compression) |
| Seven days | 8945.55 | 9095.71 | 53.93 GPa (tension) |
| 24 hours | 458989.30 | 459139.46 | 2766.92 GPa (tension) |
| Fixed 32.67 days | approximately 0 | 150.17 | 0.338 MPa (tension) |

These are transverse gravity and centrifugal contributions only. Ring self-stress is for a hypothetical isolated circumferential load path with solar gravity and without transfer from the sheet. The foil and ring in a coupled structure can redistribute load, and the ideal ring result is not a combined structure prediction. Neither seven-day nor daily spin looks viable for the baseline aluminum ring. The 10 km incremental CME bypass budget is unchanged in this screening model; spin-dependent deformation was not solved.

The ideal cut-balanced spin schedule lengthens from 32.67 to 40.49 days along the earlier ride-through trajectory. It removes the integrated gravity/centrifugal cut term in the ideal axisymmetric screen, not all local loads. The independent axial feedforward budget at Pole1 is approximately 7.85e19 Nm, or 44.8 GN peak at a station using the earlier four-station wrench map. Hardware capacity and sharing with the other five wrench channels are unverified. Keep zero spin as the planning baseline, reject fast spin for the baseline ring, and retain variable slow spin as a load-relief candidate. A coupled distributed force and flexible shell calculation, actuator qualification and installed mass remain open. Step 4 is not accepted.

Tracking checkpoint 59 uses a uniform 10 km cap inertia, the older reference trajectory and station matrix, and the earlier 0.01 percent CME force mismatch case. It is a reduced rigid-body comparison, not a rerun of every prior solver or a geometry-specific structural acceptance run. See completed per-pole files.
