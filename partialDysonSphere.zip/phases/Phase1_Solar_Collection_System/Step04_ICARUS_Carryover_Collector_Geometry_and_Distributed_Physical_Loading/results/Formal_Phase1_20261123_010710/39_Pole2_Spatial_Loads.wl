<|"Pole" -> "Pole2", "Cases" -> {<|"CMEExcessFractionError" -> 0., 
    "SampleCount" -> 1009, "PeakNormalTangentialResultant_Pa" -> 
     {0.000051164076933571764, 4.742957765005059*^-6, 
      0.0000513834449684436}|>, <|"CMEExcessFractionError" -> 0.0001, 
    "SampleCount" -> 1009, "PeakNormalTangentialResultant_Pa" -> 
     {0.000051164076933571764, 4.742957765005059*^-6, 
      0.0000513834449684436}|>}, "Scope" -> "Coarse nominal incidence CME \
plus station force in uniform-mass translating frame. Excludes lateral CME \
pressure distribution, base radiation/gravity, angular inertia, elastic \
response."|>
