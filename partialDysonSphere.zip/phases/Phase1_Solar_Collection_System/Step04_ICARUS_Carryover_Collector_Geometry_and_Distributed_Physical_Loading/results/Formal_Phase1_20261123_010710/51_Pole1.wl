<|"Pole" -> "Pole1", "AvailableMassBeforeReinforcement_kg" -> 
  4.1202874984412*^11, "Cases" -> 
  {<|"Depth_km" -> 100., "MinimumUniformPretension_N_m" -> 
     1.0490058936162203, "LocalBiasMean_N_m" -> 0.5245029558388282, 
    "PeakFoilEquivalentWithUniformBias_N_m" -> 2.7754085135519757, 
    "PeakFoilEquivalentWithLocalBias_N_m" -> 2.0980115704950095, 
    "UniformStressOnlyBypassMass_kg" -> 4.0833045525912007*^12, 
    "LocalStressOnlyBypassMass_kg" -> 2.041652311448093*^12|>, 
   <|"Depth_km" -> 250., "MinimumUniformPretension_N_m" -> 
     2.6225147333641354, "LocalBiasMean_N_m" -> 1.3112575077870543, 
    "PeakFoilEquivalentWithUniformBias_N_m" -> 6.938518594121607, 
    "PeakFoilEquivalentWithLocalBias_N_m" -> 5.245026080205911, 
    "UniformStressOnlyBypassMass_kg" -> 1.0208261378845023*^13, 
    "LocalStressOnlyBypassMass_kg" -> 5.104131238680278*^12|>}, 
 "Scope" -> "CME increment only. Zero minimum tension margin. Ideal \
independent orthogonal compression members with trial 1600 kg/m3 and 0.5 GPa \
compression allowable. Excludes buckling, connectors, compatibility, thermal \
effects and baseline loads."|>
