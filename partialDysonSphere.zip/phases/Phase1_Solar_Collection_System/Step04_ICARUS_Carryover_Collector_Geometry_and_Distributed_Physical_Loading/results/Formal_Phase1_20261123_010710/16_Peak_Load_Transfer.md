# Step 4 peak station load transfer

Separate native runs reproduce the 16x controller's initial peak station force of 1.19447e12 N in the 1.25-degree trial. The native Gaussian moment-corrected load map passed aggregate and individual force and moment conservation for both poles. The mapped peak normal component is 0.00175226 Pa; adding the static peak separately produces a conservative normal-load envelope of 0.00178901 Pa for these two inputs only.

The 300 m trial half-span requires 2.68352 N/m under the local circular-membrane formula. This exceeds both the configured 0.1 N/m and the legacy 1.4 N/m strength screen. The corresponding half-span scales are 11.18 m and 156.51 m, respectively. These are sensitivity bounds for this snapshot, not verified support spacings. The native map spreads loads across coarse patches and cannot resolve actual local attachments. The complete transient load envelope, resolved support geometry, and actuator hardware remain open. Step 4 remains open.
