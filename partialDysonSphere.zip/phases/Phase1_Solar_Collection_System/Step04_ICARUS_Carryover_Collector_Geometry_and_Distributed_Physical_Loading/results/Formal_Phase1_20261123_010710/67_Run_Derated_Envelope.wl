(* Phase 1 Step 4: ideal patchwise optical thrust authority in loaded hover. *)
p=Environment["POLAR_ACCEPT_POLE"]; loaded=Get["66_"<>p<>".wl"];
r=29919574140.; mu=1.3271244*^20; h=10000.;
area=N[4 Pi 695700000^2/10]; a=Sqrt[area/Pi-h^2]; rc=area/(2 Pi h);
sig=loaded["LoadedMass_kg"]/area; f=loaded["PV_pct"]/100;
light=34029.16163521439/299792458.;
wind=5.*^6 1.67262192595*^-27 (4.*^5)^2/.2^2;
(* Ideal transparent/reflective variable optical backing. PV is smeared on
   each patch. The variable return is force-equivalent, not a device rating. *)
patch[x_,k_]:=Module[{q,z,sz,uv,inc,normal,gravity,pv,ram,target,dir,req},
 q=Sqrt[1-(x/rc)^2]; z=r-h+x^2/(rc (1+q));
 sz=Sqrt[z^2+x^2]; uv={z,x}/sz; normal={q,-x/rc}; inc=uv.normal;
 gravity=sig mu {z,x}/sz^3;
 pv=f light (r/sz)^2 inc (.9 uv+2*.05 inc normal);
 ram=k wind q {1.,0.};
 target=gravity-pv-ram; dir=Normalize[target];
 req=Norm[target]/((1-f) 2 light (r/sz)^2 (uv.dir)^2);
 {x,req,ArcTan[dir[[1]],dir[[2]]]/Degree,Norm[target]}];
run[k_]:=Module[{rows=patch[#,k]& /@ Subdivide[0.,a,512]},
 <|"WindMultiplier"->k,"RequiredReflectivityRange"->MinMax[rows[[All,2]]],
 "InertialFacetTiltRange_deg"->MinMax[rows[[All,3]]],"Profile"->rows|>];
out=<|"Pole"->p,"Cases"->(run /@ {1.,1260.,2270.}),
 "Scope"->"Ideal axisymmetric patch optical authority. Instantaneous full local force matching with uniform mass, final loaded geometry, on-axis wind. Excludes realizable optics, facet area conversion, optics mass, dynamic errors and structural verification."|>;
Put[out,"67_"<>p<>".wl"];Print[{p,KeyDrop[#,"Profile"]& /@ out["Cases"]}];

