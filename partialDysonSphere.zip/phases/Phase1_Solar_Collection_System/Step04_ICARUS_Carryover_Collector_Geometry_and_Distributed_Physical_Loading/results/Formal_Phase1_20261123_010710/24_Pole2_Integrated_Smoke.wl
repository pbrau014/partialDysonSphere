<|"Pole" -> "Pole2", "Summary" -> <|"SolverSucceeded" -> True, 
   "Duration_s" -> 604800., "SpinTrackingEnabled" -> True, 
   "ICARUSSaturationOccurred" -> False, "MaximumRequiredStationForce_N" -> 
    1.7368299040684607*^11, "MaximumQuaternionNormalizationError" -> 
    1.2213680067318933*^-9, "RecoveryWithinLimit" -> False, 
   "RecoveryTime_s" -> Infinity, "StructuralScreenPass" -> False, 
   "FinalRecoveryErrors" -> <|"RadialPosition_m" -> 6.110079957026987*^9, 
     "LateralPosition_m" -> 4.356154075305425*^6, "RadialVelocity_m_s" -> 
      17184.184560650425, "LateralVelocity_m_s" -> 46.070847797336064, 
     "Tilt_rad" -> 0.000679077363004908, "Rate_rad_s" -> 
      3.0191908991880086*^-9|>, "RadialDeviationWithinLimit" -> False, 
   "LateralDeviationWithinLimit" -> False, "AttitudeWithinLimit" -> True|>, 
 "SourceHash" -> 
  "bcf3818abef363417a94f97a8a39c3dfd5544a163f4f7a2bf6289422e8741aad"|>
