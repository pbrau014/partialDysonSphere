# Step 4 discrete stiffener feasibility

A one-metre discrete grid is screened out for unprestressed 0.1 micrometre foil. The ideal simply supported flat strip estimate at the peak modeled CME compression gives 15.583 micrometres allowable bay width at 100 km and 9.856 micrometres at 250 km. This is a flat, uniaxial, perfect-geometry buckling screen. It does not model a curved prestressed cap or prove the admissible spacing for a different load path.

After ideal hoop fiber mass, 3.8795e11 and 1.1977e11 kg are left. At 1 m pitch an ideal pinned twin-cap rib would need about 0.207 and 0.588 m cap centroid separation, respectively, even if the whole remainder went to the caps alone. Webs, joints and imperfection reductions make the trial harder. A continuous 1 mm by 25 micrometre adhesive footprint at 1 m pitch alone is 3.6493e13 kg; the available remainder corresponds to 1.06% and 0.328% footprint duty before stiffener mass. Bond shear/peel transfer for discrete connections is unverified.

Neither tested concept demonstrates a wrinkle-free installed layout. The useful next design direction is to carry the compressive demand in an independent load path while keeping the reflective foil in tension. The 100 km cap remains the primary candidate. Both pole calculations printed matching results but their long-named Wolfram outputs could not open; the saved runner uses shorter checkpoint names for future runs.

