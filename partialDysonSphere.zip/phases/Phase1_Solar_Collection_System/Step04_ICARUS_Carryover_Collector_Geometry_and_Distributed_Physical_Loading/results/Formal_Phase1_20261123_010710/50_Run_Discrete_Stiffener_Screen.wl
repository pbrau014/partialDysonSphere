(* Phase 1 Step 4: ideal discrete rib and bare flat foil bay screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
s=Get["45_"<>p<>"_Signed_Membrane.wl"];
b=Get["48_"<>p<>"_Unstiffened_Area.wl"]["RemainingReservePreservingMass_kg"];
hoop=Get["49_"<>p<>"_Hoop_Mass_Floor.wl"]["Rows"];
a=N[4 Pi 695700000^2/10];
bending=69.*^9 (10^-7)^3/(12 (1-.33^2));
rows=MapThread[Function[{c,g},Module[{load,left,area,sep,adh},
 load=Abs[First[c["Apex_N_m"]]];left=b-g[[2]];
 (* One metre pitch, two families, compression-only caps, no web or joints. *)
 area=left/(2 1600. a);
 sep=2 Sqrt[2 load/(Pi^2 100.*^9 area)];
 adh=2 a .001 25.*^-6 1200.;
 <|"Depth_km"->c["Depth_km"],"RemainingAfterHoop_kg"->left,
 "FlatStripBayWidthAtPeakCompression_m"->Sqrt[4 Pi^2 bending/load],
 "MinOneMetreRibCapSeparationIfAllRemainingMassUsed_m"->sep,
 "ContinuousOneMetrePitchBondMass_kg"->adh,
 "MaximumBondFootprintDutyIfAllRemainingMassUsed"->left/adh|>]],{s["Cases"],hoop}];
o=<|"Pole"->p,"Cases"->rows,"Scope"->"Peak CME increment only. Bare simply supported long flat strip, uniaxial compression, no prestress or curvature. Ideal pinned rib with two efficient caps, 2x buckling load. Budget bounds exclude other components."|>;
Put[o,"50_"<>p<>"_Rib_Screen.wl"];Print[o];

