(* Phase 1 Step 4: pole-local face-on nominal radial moving reference. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
d=Get["01_Reference_Architecture.wl"]; sh=d["SharedNativeInputs"];
reserve=Get["27_"<>pole<>"_Reserve_Trade.wl"];
check=Get["28_"<>pole<>"_Reserve_Check.wl"];
area=N[4 Pi 695700000^2/10];
key="OtherInstalledArealMass_kg_m2";
set=Phase1SetInputs[Join[sh,<|key->(sh[key]+.99 reserve["MaximumAddedMassPreservingReserve_kg"]/area)|>]];
If[FailureQ[set],Print[set];Exit[2]];
r0=d["PoleOperatingInputs"]["Distance_m"]; au=r0/.2;
forceAt[rr_]:=Module[{op,n},
 op=Phase1SetPoleOperatingInputs[pole,Join[d["PoleOperatingInputs"],<|"Distance_m"->rr|>]];
 If[FailureQ[op],Print[op];Exit[2]];
 n=Phase1RunPoleTask[pole,"NaturalEquilibrium"];
 If[!AssociationQ[n],Print[n];Exit[2]];
 n=Lookup[n,"Result",n]; n=Lookup[n,"NaturalEquilibrium",n];
 If[!NumberQ[n["NetNaturalRadialForce_N"]],Print[Keys[n]];Exit[2]];
 n["NetNaturalRadialForce_N"]];
grid=N[Range[.2,.3,.01] au];
forces=forceAt /@ grid;
Put[Transpose[{grid,forces}],"29_"<>pole<>"_Native_Force_Grid.wl"];
If[Abs[First[forces]/check["NetNaturalRadialForce_N"]-1]>10^-8,Exit[4]];
m=check["CurrentPoleMass_kg"];
(* Interpolate r^2 F, which is nearly constant under inverse-square scaling. *)
fit=Interpolation[Transpose[{grid/r0,forces (grid/r0)^2}],InterpolationOrder->3];
end=604800.;
ref=NDSolveValue[{x''[t]==end^2/(m r0) fit[x[t]]/x[t]^2,x[0]==1.,x'[0]==0.},
 x,{t,0.,1.},AccuracyGoal->10,PrecisionGoal->10];
table=Table[With[{u=ref[i/7.]},{i,r0 u/au,r0 ref'[i/7.]/end,34029.16163521439/u^2}],{i,0,7}];
If[Max[table[[All,2]]]>Last[grid]/au || Min[table[[All,2]]]<First[grid]/au-10^-12,Exit[5]];
out=<|"Pole"->pole,"Mass_kg"->m,"ForceGrid_N"->Transpose[{grid,forces}],
 "DailyColumns"->{"Day","Distance_AU","RadialSpeed_m_s","ReferenceIrradiance_W_m2"},
 "DailyTrajectory"->table,"OutwardDrift_m"->r0 (ref[1.]-1),
 "EndFluxFraction"->1/ref[1.]^2,
 "MeanFluxFraction"->NIntegrate[1/ref[t]^2,{t,0,1}],
 "Scope"->"Nominal fixed face-on axis, radial motion from rest, no control or disturbances. No mission envelope supplied."|>;
Put[out,"29_"<>pole<>"_Moving_Reference.wl"];Print[{pole,table,out["OutwardDrift_m"],out["MeanFluxFraction"]}];
