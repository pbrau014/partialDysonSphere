(* Phase 1 Step 4: provisional derated optical fixed-hover design targets. *)
<|"Status"->"ProvisionalDesignTargets","CapDepth_m"->10000,
 "AlternateCapDepth_m"->20000,"Distance_AU"->.2,"CommandedAxialSpin_rad_s"->0.,
 "NominalNativeReflectivity"->.98,"NominalNativeTransmissivity"->.019,
 "PVFraction"->.010826495586110485,"PreLoadReserveFraction"->.1,
 "LaterEffectiveHardwareMassTarget_kg"->8.274373063814856*^13,
 "ConditionalElectricalOutput_W"->6.10842584077336*^18,
 "EffectiveSpecularReturnTargets"-><|"Calm"->.980661,"ConfiguredCME"->.793109,"StrongerSensitivity"->.642673|>,
 "OpticalLagTrialTarget_s"->10.,"TrialResidualRadialAuthority_N"->2.0829867325268164*^11,
 "ApplySeparatelyPerPole"->True,"TechnicalAcceptance"->False|>
