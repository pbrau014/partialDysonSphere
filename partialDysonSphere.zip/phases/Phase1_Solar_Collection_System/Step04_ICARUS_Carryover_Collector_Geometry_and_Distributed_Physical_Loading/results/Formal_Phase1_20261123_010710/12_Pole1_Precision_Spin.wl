<|"Pole" -> "Pole1", "Results" -> {<|"Days" -> 7, "StartTilt_deg" -> 1/4, 
    "Precision" -> 44, "PeakTilt_deg" -> 
     0.26922638875137196069843274088151562364`12., 
    "PeakTransverseRate_rad_s" -> 6.70109407032809870712199910337`12.*^-9, 
    "NormError" -> 3.3639028765512161039943348`12.*^-13, "Pass" -> True|>, 
   <|"Days" -> 28, "StartTilt_deg" -> 1/4, "Precision" -> 44, 
    "PeakTilt_deg" -> 0.26922640371970672683217001752423957585`12., 
    "PeakTransverseRate_rad_s" -> 6.70109677542225875087743313269`12.*^-9, 
    "NormError" -> 3.4344023437754334135691161`12.*^-13, "Pass" -> True|>, 
   <|"Days" -> 56, "StartTilt_deg" -> 1/2, "Precision" -> 44, 
    "PeakTilt_deg" -> 0.53845097324527227943044970463618825262`12., 
    "PeakTransverseRate_rad_s" -> 1.34015865404981431127229854053`12.*^-8, 
    "NormError" -> 2.7128978679253458657990287`12.*^-13, "Pass" -> True|>}|>
