<|"Pole" -> "Pole2", "TrialUniformPretension_N_m" -> 0.125, 
 "CMEOnsetApexTensionRemaining_N_m" -> 0.020099410663050085, 
 "PeakHoopWithPretension_N_m" -> 0.3348011786738998, 
 "IdealRimCompression_N" -> 5.499991419027397*^7, 
 "RimAreaAtMaterialAllowable_m2" -> 3.9285652993052835, 
 "StrengthOnlyRimMass_kg" -> 2.9378736427257523*^13, 
 "RemainingAfterOpticsAndStrengthOnlyRim_kg" -> 3.26790615513539*^13, 
 "Scope" -> "Superposed axisymmetric incremental CME plus assumed stress \
field; no equilibrium verification of prestress, rim buckling, shape \
retention or nonaxisymmetric loads. Rim mass is strength-only and ignores \
solar tide, imperfections and section stability."|>
