(* Phase 1 Step 4: flexible fixed-rim membrane response to saved hover commands. *)
p=Environment["POLAR_ACCEPT_POLE"]; If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
src=Environment["POLAR_ACCEPT_SOURCE"];If[Get[src]===$Failed,Exit[3]];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
d=Get["01_Reference_Architecture.wl"]; h=Get["70_"<>p<>".wl"];
b=Get["71_"<>p<>".wl"]; loaded=Get["66_"<>p<>".wl"];
area=N[4 Pi 695700000^2/10]; radius=Sqrt[area/Pi-10000.^2];
sigma=loaded["LoadedMass_kg"]/area; tension=b["CMEOnsetApexTensionRemaining_N_m"];
in=Join[Phase1GetInputs[],d["SharedNativeInputs"],d["PoleOperatingInputs"]];
mapper=ToExpression[First[Names["*`Private`phase1LoadMap"]]];
patch=c["SurfaceMesh"]["Patches"];
areas=Lookup[patch,"SurfaceAreaWeight_m2"]; frac=areas/Total[areas];
pos=Lookup[patch,"Position_m"][[All,2;;3]];
oldR=c["Geometry"]["PlanformEquivalentRadius_m"];
rr=(Norm /@ pos)/oldR;
phi=ArcTan@@@pos; rigid=Transpose[Join[{ConstantArray[1.,Length[frac]]},Transpose[pos/oldR]]]; weighted=MapThread[Times,{frac,rigid}]; gram=Transpose[rigid].weighted; removeRigid[v_]:=v-weighted.LinearSolve[gram,Transpose[rigid].v];
(* Use native load transfer on old normalized geometry and keep only axial
   force. Remove uniform translation; the rim boundary stays fixed in model. *)
cols=Table[Module[{g,v},g=mapper[in,c["Geometry"],c["SurfaceMesh"],c["DynamicInitialConditions"],Partition[N[UnitVector[12,i]],3]];
 If[!AssociationQ[g]||!TrueQ[g["AllIndividualStationTransfersConserved"]],Print[g];Exit[4]];
 v=Lookup[g["Patches"],"EstimatedLocalLoadVector_N"][[All,1]];removeRigid[v]],{i,12}];
(* Axisymmetric CME incidence, uniform mass, onset and delayed rebound.
   Cancellation of the excess is assumed spatially proportional. *)
cos= Sqrt[1.-(2. 10000. rr/radius)^2];
wind=removeRigid[2.561576803528925*^13 frac (cos-frac.cos)/(frac.cos)];
lag[t_]:=Which[t<86400.,0.,t<235200.,Exp[-(t-86400.)/10.],
 True,-(1.-Exp[-148320./10.]) Exp[-(t-235200.)/10.]];
basis[orders_,r_,ang_]:=Map[Function[v,BesselJ[v[[1]],v[[3]] r]
 If[v[[2]]==0,Cos[v[[1]] ang],Sin[v[[1]] ang]]],orders];
solve[case_,nr_,na_,stationScale_]:=Module[{orders,mat,mm,proj,wp,tt,ff,peak,when,shape,modal,
  prev,u,v,omega,dt,half,a0,a1,u1,v1,ss,cc,evalGrid,wm,vInt,uInt,mid},
 orders=Flatten[Table[{l,j,N[BesselJZero[l,k]]},{l,0,na},{j,0,If[l==0,0,1]},{k,nr}],2];
 mat=basis[orders,#1,#2]&@@@Transpose[{rr,phi}];
 mm=loaded["LoadedMass_kg"] ((BesselJ[#[[1]]+1,#[[3]]]^2 If[#[[1]]==0,1.,.5])& /@ orders);
 proj=(cols.mat);wp=wind.mat;tt=case["LoadTimes_s"];
 ff=(Flatten[#].proj& /@ case["AppliedStationForces_N"]);
 ff=(stationScale #/mm& /@ ff);wp=wp/mm;
 (* Piecewise linear force, exact oscillator propagator, with series for
    small arguments so the nearly free response does not lose precision. *)
 omega=Sqrt[tension/sigma] orders[[All,3]]/radius;
 u=0. mm;v=u;peak=0.;when=0.;
 evalGrid=Join[mat,Table[basis[orders,x,th],{x,{0.,.1,.25,.5,.75,.9,1.}},{th,0.,2 Pi-Pi/8,Pi/8}]~Flatten~1];
 Do[dt=tt[[i+1]]-tt[[i]]; If[dt<=0.,Continue[]];
 half=omega dt;ss=Sin[half];cc=Cos[half];a0=ff[[i]];a1=ff[[i+1]]-a0;
 u1=cc u+dt Sinc[half] v+dt^2
  ((.5-half^2/24+half^4/720) a0+(1./6-half^2/120+half^4/5040) a1);
 v1=-omega ss u+cc v+dt
  (Sinc[half] a0+(.5-half^2/24+half^4/720) a1);
 mid=(tt[[i]]+tt[[i+1]])/2; wm=Which[mid<86400.,0.,mid<235200.,Exp[-Max[0.,tt[[i]]-86400.]/10.],True,-Exp[-Max[0.,tt[[i]]-235200.]/10.]]; vInt=10. (1.-Exp[-dt/10.]); uInt=10. (dt-vInt); u=u1+wm uInt wp; v=v1+wm vInt wp;shape=Max[Abs[evalGrid.u]];
 If[shape>peak,peak=shape;when=tt[[i+1]]],
 {i,Length[tt]-1}];
 <|"NonRigidStationLoadScale"->stationScale,"RadialModesPerHarmonic"->nr,"MaxAzimuthalOrder"->na,
 "PeakSampledDeflection_m"->peak,"PeakTime_s"->when,
 "FinalPeakSampledDeflection_m"->Max[Abs[evalGrid.u]],
 "PeakGridPoints"->Length[evalGrid],"MinTensionAssumed_N_m"->tension|>];
out=<|"Pole"->p,"Cases"->Table[
 <|"CMEExcessFractionError"->case["CMEExcessFractionError"],
 "ModalRefinement"->{solve[case,3,2,1.],solve[case,6,4,1.],solve[case,6,4,0.],solve[case,6,4,.00001]}|>,{case,h["Cases"]}],
 "Scope"->"Linear tensioned flat-equivalent membrane, ideal fixed rigid rim, native coarse station map projected off rigid axial translation and two rotation shapes, axisymmetric incremental CME load. The scaled nonrigid load is a hypothetical sensitivity, not an actuator design. Zero initial deflection/velocity and no damping. Excludes rim flexibility, wrinkles, local attachment stress, lateral pressure distribution, material imperfections, optical-structural feedback and static shape. Incremental deflection only."|>;
Put[out,"73_"<>p<>".wl"];Print[out];


