(* Phase 1 Step 4: reflective optical assembly, momentum, heat and mass screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
d=Get["66_"<>p<>".wl"]; e=Get["67_"<>p<>".wl"];
area=N[4 Pi 695700000^2/10]; f=d["PV_pct"]/100; ar=area (1-f);
irr=34029.16163521439; absorb=.001; refl=1-absorb;
(* 25 percent of the later loading target is an optical subsystem allocation,
   not a measured mass. Component allocations include all incremental items. *)
opt=.25 d["LaterUniformHardwareMassToBalance_kg"];
parts=AssociationThread[{"ActiveOptics","DriveAndSensing","WiringAndMounts"},{.5,.3,.2} opt];
(* Inertial projected axial screen: outgoing beam pair with equal/opposite
   transverse momenta, incident beam along the principal axis. *)
rows=Map[Function[c,With[{ret=Mean[c["RequiredReflectivityRange"]]},
 {c["WindMultiplier"],ret,ArcCos[(2 ret-1)/refl]/Degree,
  ar irr refl,ar irr absorb}]],e["Cases"]];
g=Get["40_"<>p<>"_Membrane_Cut.wl"]["CMEPressureAtOnset_Pa"];
peak=g 10000/4;
o=<|"Pole"->p,"OpticalAddedMassAllocation_kg"->opt,"MassAllocationParts_kg"->parts,
 "OpticalArealMassCeiling_kg_m2"->opt/ar,
 "OtherLaterHardwareAllocation_kg"->d["LaterUniformHardwareMassToBalance_kg"]-opt,
 "Columns"->{"WindMultiplier","ForceEquivalentReturn","IdealSunwardBeamDeflection_deg","ReflectedLight_W","OpticalAbsorptionHeat_W"},
 "Rows"->rows,"UncompensatedCMEOnsetApexCompression_N_m"->peak,
 "UncompensatedCMEOnsetRimHoop_N_m"->2 peak,
 "Scope"->"Ideal split nonabsorptive optical steering. Normal incidence energy screen, conditional absorptance. Static incremental shell loads only; no coupled transient shape or manufactured properties."|>;
Put[o,"69_"<>p<>".wl"];Print[o];
