<|"Pole" -> "Pole1", "Summary" -> Failure["Step4CoreInputValidationFailed", 
   <|"Pole" -> "Pole1", "Checks" -> <|"RequiredInputsPresent" -> True, 
      "MissingRequiredInputKeys" -> {}, "PositivePhysicalConstants" -> True, 
      "PositiveDistance" -> True, "PositiveGeometryAndPoleInputs" -> True, 
      "ICARUSStationCountScopeSupported" -> True, 
      "CoverageWithinUnitInterval" -> True, 
      "OpticalFractionsPhysicallyValid" -> True, 
      "MembraneSubstrateMaterialNamePresent" -> True, 
      "MembraneSubstrateMaterialClassSupported" -> True, 
      "AluminumBaseMaterialInputsValid" -> True, 
      "ContinuousAluminumSubstratePolicy" -> True, "MassInputsNonnegative" -> 
       True, "PVSpecificPowerReferenceIrradiancePositive" -> True, 
      "PerimeterHardwareLinearMassValid" -> True, 
      "DeferredEquipmentMassExcludedFromPhase1MassDistribution" -> True, 
      "StationCountMatchesRegisteredStationPositions" -> True, 
      "StationCoordinatesWithinPlanform" -> True, 
      "MassDistributionInputsValid" -> True, 
      "ICARUSRedesignAssumptionInputsValid" -> True, 
      "ICARUSValidationInputsValid" -> True, "DisturbanceInputsValid" -> 
       True, "ControllerAndWobbleInputsValid" -> True, 
      "PVScenarioOptionsValid" -> True, "PVScenarioRecognized" -> True, 
      "PVLayoutModelSupported" -> True, "GeometryProfileModelSupported" -> 
       True, "MassDistributionModelSupported" -> True, 
      "FutureAddedMassTargetFractionValid" -> True, 
      "FlareTemporalProfileSupported" -> True, 
      "CMETemporalProfileSupported" -> True, 
      "ICARUSLoadTransferModelSupported" -> True, 
      "MembraneStructuralModelSupported" -> True, 
      "WobbleRestoringModelSupported" -> True, 
      "PVCellArrayMassPolicyValid" -> True, "ReflectionModelSupported" -> 
       True, "ThermalAndStructuralInputsPositive" -> True, 
      "Step5StructuralScreeningFractionsValid" -> True, 
      "ThermalInputsValid" -> True, "SolarWindInputsValid" -> True, 
      "DegradationInputsValid" -> True, 
      "EfficiencyAndElectricalInputsValid" -> True, 
      "RecoveryCriteriaValid" -> False, "AcceptanceTolerancesValid" -> True, 
      "ModelCoefficientInputsValid" -> True, "DynamicAndMeshCountsValid" -> 
       True, "SearchBoundsValid" -> True, "VectorInitialConditionsValid" -> 
       True, "HeliocentricReferenceMotionModeSupported" -> True, 
      "HeliocentricStaticHoverVelocityValid" -> True, 
      "NumericalSolverSettingsValid" -> True|>|>], 
 "SourceHash" -> 
  "b0793e6bce7fdc6ef42469ecf596e194c34de85a7fc20e9042b25a2cbcd1a59d"|>
