<|"Pole" -> "Pole1", "OpenLoopGrowth_per_s" -> 3.842767290087496*^-6, 
 "IdealGyroCriticalPeriod_h" -> 452.6853288526458, 
 "ReducedControlledCases" -> {<|"StiffnessFactor" -> 1.25, 
    "Kp_per_s2" -> 1.8458575557208004*^-11, "Kd_per_s" -> 
     3.842767290087497*^-6, "TransversePoles_per_s" -> 
     {-1.9213836450437486*^-6, -1.9213836450437486*^-6}, 
    "StaticControlTorqueAt1deg_Nm" -> 1.2090116018753331*^19, 
    "IdealCoupleForceAt1deg_N" -> 1.3807312701168995*^10|>, 
   <|"StiffnessFactor" -> 2., "Kp_per_s2" -> 2.9533720891532804*^-11, 
    "Kd_per_s" -> 7.685534580174993*^-6, "TransversePoles_per_s" -> 
     {-3.842767290087496*^-6, -3.842767290087496*^-6}, 
    "StaticControlTorqueAt1deg_Nm" -> 1.9344185630005326*^19, 
    "IdealCoupleForceAt1deg_N" -> 2.2091700321870388*^10|>, 
   <|"StiffnessFactor" -> 4., "Kp_per_s2" -> 5.906744178306561*^-11, 
    "Kd_per_s" -> 0.000013311736376190629, "TransversePoles_per_s" -> 
     {-6.655868188095314*^-6, -6.655868188095314*^-6}, 
    "StaticControlTorqueAt1deg_Nm" -> 3.868837126001065*^19, 
    "IdealCoupleForceAt1deg_N" -> 4.4183400643740776*^10|>}, 
 "Scope" -> "Linear axisymmetric rigid-body screen; ideal PD or ideal \
torque-free axial spin. Station allocation, capacity, nonlinear disturbances \
and structural transfer remain unverified."|>
