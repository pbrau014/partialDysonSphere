(* Phase 1 Step 4: safe-side tension target and rim strength-only allocation. *)
p=Environment["POLAR_ACCEPT_POLE"];
o=Get["69_"<>p<>".wl"]; a=Sqrt[N[4 695700000^2/10-10000^2]];
d=o["UncompensatedCMEOnsetApexCompression_N_m"]; h=o["UncompensatedCMEOnsetRimHoop_N_m"];
base=.125; rho=2705.; allow=14.*^6;
rimForce=base a; section=rimForce/allow; rimMass=2 Pi a rho section;
z=<|"Pole"->p,"TrialUniformPretension_N_m"->base,"CMEOnsetApexTensionRemaining_N_m"->base-d,
 "PeakHoopWithPretension_N_m"->base+h,"IdealRimCompression_N"->rimForce,
 "RimAreaAtMaterialAllowable_m2"->section,"StrengthOnlyRimMass_kg"->rimMass,
 "RemainingAfterOpticsAndStrengthOnlyRim_kg"->o["OtherLaterHardwareAllocation_kg"]-rimMass,
 "Scope"->"Superposed axisymmetric incremental CME plus assumed stress field; no equilibrium verification of prestress, rim buckling, shape retention or nonaxisymmetric loads. Rim mass is strength-only and ignores solar tide, imperfections and section stability."|>;
Put[z,"71_"<>p<>".wl"];Print[z];
