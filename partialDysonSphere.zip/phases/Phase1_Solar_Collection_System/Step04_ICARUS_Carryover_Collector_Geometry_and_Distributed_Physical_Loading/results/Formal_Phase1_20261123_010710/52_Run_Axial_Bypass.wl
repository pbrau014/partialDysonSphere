(* Phase 1 Step 4: direction-specific compression bypass screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
data=Get["45_"<>p<>"_Signed_Membrane.wl"];
b=Get["48_"<>p<>"_Unstiffened_Area.wl"]["RemainingReservePreservingMass_kg"];
hoop=Get["49_"<>p<>"_Hoop_Mass_Floor.wl"]["Rows"];
a=N[4 Pi 695700000^2/10];
rows=MapThread[Function[{c,g},Module[{demand,mean,m,left},
 demand=Total[Max[0.,-#]& /@ #]& /@ c["Profile"][[All,2;;3]];
 mean=(Total[demand]-(First[demand]+Last[demand])/2)/(Length[demand]-1);
 m=a 1600. mean/(.5*^9);left=b-g[[2]];
 {c["Depth_km"],mean,m,left,m/left,1-left/m}
 ]],{data["Cases"],hoop}];
out=<|"Pole"->p,"Columns"->{"Depth_km","MeanSumCompression_N_m","IdealBypassMass_kg","BudgetAfterHoop_kg","MassRatio","RequiredCompressionReductionFraction"},"Rows"->rows,"Scope"->"Independent local axial minima with zero tensile margin. Trial compression allowable 0.5 GPa, density 1600. No buckling, compatibility, thermal stress, or connections."|>;
Put[out,"52_"<>p<>".wl"];Print[out];
