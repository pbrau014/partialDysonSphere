# Step 4 closeout attempt

Status: open. Separate native static checkpoints report the same reference peak environmental normal pressure, 3.67527461425242e-5 Pa per pole. The v11.142 full-radius pretension screen uses 4 * 0.1 * 0.05 / 437815680.7345184 = 4.5681e-11 Pa, roughly 805,000 times smaller. The assumed cap radius is not the unsupported membrane span under the current design. Substituting a span solely to pass would not verify the load path. Inverting the legacy formula at this static pressure gives approximately 544 m as a screening scale only; it does not establish a support spacing or account for dynamic loads.

The full native 0.6% reference assessment was started for Pole 1. The saved runner then schedules Pole 2 in a fresh process. Completion and acceptance remain pending. Results from the reference are surrogate evidence for installed hardware mass; radiator optics, physical attachments and other installed hardware remain outside that surrogate.
