<|"Pole" -> "Pole2", "BestPeakCMEMembraneIncrement_N_m" -> 230.7780803945721, 
 "FoilAllowable_N_m" -> 1.4, "Ratio" -> 164.84148599612294, 
 "Scope" -> "Axisymmetric unchanged cap, uniform sheet mass, membrane-only \
incremental response. Arbitrary net axial thrust at perimeter. No reinforced \
or bending shell model."|>
