<|"Pole" -> "Pole1", "BaselineUnits" -> 55, "IdealRadialDemand_N" -> 
  2.536957074131879*^13, "BaselineAvailableRadialForce_N" -> 
  2.570829867325268*^13, "BaselineHeadroomFraction" -> 0.013351740768014375, 
 "MarginFractionAndTotalUnits" -> {{0, 55}, {0.1, 60}, {0.2, 65}}, 
 "TwentyPercentWithOneRadialOutage" -> 66|>
