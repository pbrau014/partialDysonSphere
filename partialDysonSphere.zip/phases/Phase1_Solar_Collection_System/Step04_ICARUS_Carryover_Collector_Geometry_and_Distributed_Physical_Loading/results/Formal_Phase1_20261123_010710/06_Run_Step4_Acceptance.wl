(* Phase 1 Step 4: full native assessment of the provisional reference. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
design=Get["01_Reference_Architecture.wl"];
shared=Phase1SetInputs[design["SharedNativeInputs"]];
op=Phase1SetPoleOperatingInputs[pole,design["PoleOperatingInputs"]];
If[FailureQ[shared]||FailureQ[op],Print[Select[{shared,op},FailureQ]];Exit[1]];
Print[{pole,"Started",DateString[]}];
result=Phase1RunStep4Assessment[pole];
Put[<|"Pole"->pole,"Scope"->design["AcceptanceScope"],
 "SourceHash"->FileHash[src,"SHA256","HexString"],"Result"->result|>,"06_"<>pole<>"_Assessment.wl"];
summary=If[AssociationQ[result],<|"ScopeComplete"->result["Step4ScopeComplete"],
 "Checks"->result["Checks"]|>,result];
Put[summary,"06_"<>pole<>"_Summary.wl"];
Print[{pole,summary}];
