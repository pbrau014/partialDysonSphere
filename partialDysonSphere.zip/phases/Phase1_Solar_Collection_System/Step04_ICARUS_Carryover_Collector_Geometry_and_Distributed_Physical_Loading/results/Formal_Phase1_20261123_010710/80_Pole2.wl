<|"Pole" -> "Pole2", "Rows" -> 
  {{0.25, {0.00003202245322159232, 0.0004998793850167597}, 
    {0.000032022455556717145, 0.0005006288137488124}, 6.716232448243634*^-6, 
    5.245029466847496*^-6}, {0.35, {0.00006330601289039529, 
     0.0006956548570224652}, {0.0000633060671766257, 0.0006967210451407055}, 
    9.402725427541087*^-6, 7.3430412535864935*^-6}, 
   {0.4, {0.00008211285395648565, 0.000802838232345139}, 
    {0.00008211290500303839, 0.000804209499308909}, 0.000010745971917189814, 
    8.392047146955994*^-6}, {0.5, {0.00012793932760200781, 
     0.0009674336189293961}, {0.00012793936002842126, 0.0009685187772384106}, 
    0.000013432464896487268, 0.000010490058933694992}}, 
 "Columns" -> {"BayWidth_m", "40Modes_PeakDeflection_m_AndEdgeSlope_rad", 
   "80Modes_PeakDeflection_m_AndEdgeSlope_rad", "MaxSupportLinearMass_kg_m", 
   "StaticFullLoadEdgeReactionPerLength_N_m"}, 
 "Scope" -> "Ideal fixed immobile edges, uniform full CME load with 10 s \
exponential relief, existing minimum tension, foregoing control. Entire \
remainder assigned to grid, excluding junction costs. Not an installed mass \
or global shape pass."|>
