(* Phase 1 Step 4: graded backing versus shallower fixed-area spherical caps. *)
p=Environment["POLAR_ACCEPT_POLE"];
z=Get["40_"<>p<>"_Membrane_Cut.wl"]; pressure=z["CMEPressureAtOnset_Pa"];
budget=Get["27_"<>p<>"_Reserve_Trade.wl"]["MaximumAddedMassPreservingReserve_kg"];
area=N[4 Pi 695700000^2/10]; old=4 z["ApexMeridionalIncrementMagnitude_N_m"]/pressure;
(* Depth coordinate u is uniform in curved area. For passive CME ride-through,
   the magnitude of the axisymmetric meridional increment is p h u/(2(1+q)).
   Translate line-resultant magnitudes into tensile-equivalent fiber mass only. *)
run[h_?NumericQ]:=Module[{rc,q,peak,m},
 rc=area/(2 Pi h);
 q[u_]=1-h/rc+(h/rc) u;
 peak=pressure h/4;
 m=area (1790./3.5*^9) NIntegrate[Max[0.,pressure h u/(2(1+q[u]))-1.4],{u,0,1}];
 {h/1000,peak,m,m/budget,Sqrt[area/Pi-h^2]}
 ];
out=<|"Pole"->p,"Columns"->{"Depth_km","CMEPeakIncrement_N_m","GradedTensileEquivalentFiberMass_kg",
 "FractionOfPreAllocationMassAllowance","RimRadius_m"},
 "Rows"->(run /@ {old,10000.*1000,1000.*1000,250.*1000,100.*1000}),
 "Scope"->"Same onset pressure and area; incremental axisymmetric membrane-only screen. Fiber mass uses magnitude of load as tensile equivalent, not compression capacity. Excludes matrix, bonding, reinforcement mass feedback, all other loads and buckling."|>;
Put[out,"44_"<>p<>"_Graded_Trade.wl"];Print[out];
