<|"Pole" -> "Pole1", "Cases" -> {<|"CMEExcessFractionError" -> 0., 
    "ModalRefinement" -> {<|"NonRigidStationLoadScale" -> 1., 
       "RadialModesPerHarmonic" -> 3, "MaxAzimuthalOrder" -> 2, 
       "PeakSampledDeflection_m" -> 4.566536195167308*^6, 
       "PeakTime_s" -> 604800., "FinalPeakSampledDeflection_m" -> 
        4.566536195167308*^6, "PeakGridPoints" -> 1392, 
       "MinTensionAssumed_N_m" -> 0.020099410663050085|>, 
      <|"NonRigidStationLoadScale" -> 1., "RadialModesPerHarmonic" -> 6, 
       "MaxAzimuthalOrder" -> 4, "PeakSampledDeflection_m" -> 
        6.316024862162234*^6, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 6.316024862162234*^6, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>, <|"NonRigidStationLoadScale" -> 0., 
       "RadialModesPerHarmonic" -> 6, "MaxAzimuthalOrder" -> 4, 
       "PeakSampledDeflection_m" -> 0.00002050789849841421, 
       "PeakTime_s" -> 235310., "FinalPeakSampledDeflection_m" -> 
        0.000020503692536537502, "PeakGridPoints" -> 1392, 
       "MinTensionAssumed_N_m" -> 0.020099410663050085|>, 
      <|"NonRigidStationLoadScale" -> 0.00001, "RadialModesPerHarmonic" -> 6, 
       "MaxAzimuthalOrder" -> 4, "PeakSampledDeflection_m" -> 
        63.16024435388637, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 63.16024435388637, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>}|>, <|"CMEExcessFractionError" -> 0.0001, 
    "ModalRefinement" -> {<|"NonRigidStationLoadScale" -> 1., 
       "RadialModesPerHarmonic" -> 3, "MaxAzimuthalOrder" -> 2, 
       "PeakSampledDeflection_m" -> 4.778916707149362*^6, 
       "PeakTime_s" -> 604800., "FinalPeakSampledDeflection_m" -> 
        4.778916707149362*^6, "PeakGridPoints" -> 1392, 
       "MinTensionAssumed_N_m" -> 0.020099410663050085|>, 
      <|"NonRigidStationLoadScale" -> 1., "RadialModesPerHarmonic" -> 6, 
       "MaxAzimuthalOrder" -> 4, "PeakSampledDeflection_m" -> 
        6.823510677467868*^6, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 6.823510677467868*^6, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>, <|"NonRigidStationLoadScale" -> 0., 
       "RadialModesPerHarmonic" -> 6, "MaxAzimuthalOrder" -> 4, 
       "PeakSampledDeflection_m" -> 0.00002050789849841421, 
       "PeakTime_s" -> 235310., "FinalPeakSampledDeflection_m" -> 
        0.000020503692536537502, "PeakGridPoints" -> 1392, 
       "MinTensionAssumed_N_m" -> 0.020099410663050085|>, 
      <|"NonRigidStationLoadScale" -> 0.00001, "RadialModesPerHarmonic" -> 6, 
       "MaxAzimuthalOrder" -> 4, "PeakSampledDeflection_m" -> 
        68.23510250694292, "PeakTime_s" -> 604800., 
       "FinalPeakSampledDeflection_m" -> 68.23510250694292, 
       "PeakGridPoints" -> 1392, "MinTensionAssumed_N_m" -> 
        0.020099410663050085|>}|>}, "Scope" -> "Linear tensioned \
flat-equivalent membrane, ideal fixed rigid rim, native coarse station map \
projected off rigid axial translation and two rotation shapes, axisymmetric \
incremental CME load. The scaled nonrigid load is a hypothetical sensitivity, \
not an actuator design. Zero initial deflection/velocity and no damping. \
Excludes rim flexibility, wrinkles, local attachment stress, lateral pressure \
distribution, material imperfections, optical-structural feedback and static \
shape. Incremental deflection only."|>
