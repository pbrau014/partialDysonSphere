<|"Pole" -> "Pole1", "Cases" -> 
  {<|"Depth_km" -> 100., "CompressionPerRib_N" -> 1.0490058936162203, 
    "TensionPerRib_N" -> 2.0980115704950095, "RequiredCapAreaTotal_m2" -> 
     8.502921503118697*^-8, "ThicknessEachCap_m" -> 0.00004251460751559349, 
    "CapOnlyMass_kg" -> 1.6549010017627478*^14, 
    "IllustrativeAverageLapShear_Pa" -> 41960.23140990019|>, 
   <|"Depth_km" -> 250., "CompressionPerRib_N" -> 2.6225147333641354, 
    "TensionPerRib_N" -> 5.245026080205911, "RequiredCapAreaTotal_m2" -> 
     2.1257303752313926*^-7, "ThicknessEachCap_m" -> 0.00010628651876156962, 
    "CapOnlyMass_kg" -> 4.137252503339763*^14, 
    "IllustrativeAverageLapShear_Pa" -> 104900.52160411823|>}, 
 "Pitch_m" -> 1., "CapCenterSeparation_m" -> 0.01, "CapWidth_m" -> 0.001, 
 "Layup" -> "Each cap symmetric axial [0] plies in its rib direction; \
orthogonal rib families; trial plus-minus 45 degree webs required, not \
sized.", "Bond" -> "Continuous 1 mm footprint at lower cap, with 50 mm trial \
load transfer length; adhesive thickness trial 25 micrometres. Average lap \
shear is a demand only.", "Scope" -> "Peak-sized uniform cap-only estimate; \
excludes web, adhesive, junctions, imperfection reductions, local buckling, \
peel and thermal stresses. No acceptance."|>
