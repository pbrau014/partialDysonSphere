<|"Pole" -> "Pole1", "Cases" -> {<|"CMEExcessFractionError" -> 0., 
    "ZoneScreens" -> {<|"RequestedZones" -> 384, "OccupiedZones" -> 384, 
       "TargetModeCount" -> 54, "ConstraintOperatorResidual" -> 
        9.42255424084347*^-15, "PeakPressureAdjustment_Pa" -> 
        4.942552257779142*^-7, "RelativeWrenchResidual" -> 
        1.0685711014670808*^-14, "PeakDeflectionFromZoneQuantization_m" -> 
        203541.43127990022|>}|>, <|"CMEExcessFractionError" -> 0.0001, 
    "ZoneScreens" -> {<|"RequestedZones" -> 384, "OccupiedZones" -> 384, 
       "TargetModeCount" -> 54, "ConstraintOperatorResidual" -> 
        9.42255424084347*^-15, "PeakPressureAdjustment_Pa" -> 
        4.942552257779142*^-7, "RelativeWrenchResidual" -> 
        1.0685031717865053*^-14, "PeakDeflectionFromZoneQuantization_m" -> 
        203541.4308816719|>}|>}, "Scope" -> "One-way replay, finite-zone \
pressure with modal allocation and held-out higher modes only. Previous \
station histories are targets. Neither thermal recoil, residual ICARUS, real \
zone lag, feedback, nor rim compliance is included."|>
