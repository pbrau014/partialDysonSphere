(* Phase 1 Step 4: 20 km exploration, independent per pole. *)
p=Environment["POLAR_ACCEPT_POLE"];
s=Get["53_"<>p<>".wl"]; t=Get["54_"<>p<>".wl"];
r=Get["32_"<>p<>"_CME_RideThrough.wl"]; c=Get["40_"<>p<>"_Membrane_Cut.wl"];
a=N[4 Pi 695700000^2/10]; h=20000.; q0=1-2 Pi h^2/a;
row=SelectFirst[s["DepthSweep"],#[[1]]==20.&];
g=s["AverageSolarTideCutResultant_N_m"]; k=r["Day7Distance_AU"]/.2;
peak=c["CMEPressureAtOnset_Pa"] h/4;
limit=row[[3]] (.5*^9/1600.)/a;
(* Fixed facet pattern balances the modeled tide at the initial distance.
   Inverse square light versus inverse cube gravity gives outward excess. *)
out=<|"Pole"->p,"Depth_km"->20,"RimRadius_m"->Sqrt[a/Pi-h^2],
 "ApexCMECompressionEachDirection_N_m"->peak,"RimCMEHoopTension_N_m"->2 peak q0,
 "CMEOnlyBypassMass_kg"->row[[2]],"MassRemaining_kg"->row[[3]],
 "OptimisticAreaMeanResidualCompressionBudget_N_m"->limit,
 "IdealRimTilt_deg"->{t["IdealRimFacetAngleStart_deg"],t["IdealRimFacetAngleDay7_deg"]},
 "FixedInitialPatternDay7OutwardAverageCutExcess_N_m"->g (k^-2-k^-3),
 "Scope"->"CME membrane increment plus separate flat-disk radial momentum scale. Budget converts remaining mass to area-mean directional compression resultant using trial axial members only. Fixed-pattern excess is tensile in a free flat disk; it is not a compression comparison or a complete structural solution."|>;
Put[out,"55_"<>p<>".wl"];Print[out];
