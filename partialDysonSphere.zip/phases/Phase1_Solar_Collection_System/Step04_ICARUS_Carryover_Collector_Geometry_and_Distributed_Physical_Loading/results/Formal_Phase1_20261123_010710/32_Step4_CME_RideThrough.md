# Step 4 CME ride-through reference

Independent native Wolfram runs for the 0.6% reserve-preserving case integrate the saved pole-local radial force grid plus inverse-square rectangular CME excess. Position and velocity are continuous at onset and exit. Both poles reach 0.23076024 AU and 12.68498 km/s at seven days, with irradiance 25561.67 W/m^2. The CME exits at 235200 s at 0.2050060 AU and 7.97736 km/s. This extends beyond the previously approved nominal envelope, and no CME excursion allowance is asserted.

Use the four current units for the next tracking study. Do not demand cancellation of the nominal CME impulse. Use the recorded trajectory as feedforward, and apply residual tracking and attitude control under finite capacity. Validate the free-flying rigid-rim and semi-rigid sheet with internal rim-sheet traction and shape retention. The former 20 m supported panel does not verify this concept. No external anchors are assumed. Step 4 remains open.

The runner and independent pole checkpoints share this report's 32_ prefix.
