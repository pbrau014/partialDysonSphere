<|"Pole" -> "Pole1", "ReserveTargetFraction" -> 0.1, 
 "MaximumAddedMassPreservingReserve_kg" -> 4.1202874984412*^13, 
 "MinimumOutwardForcePreservingReserve_N" -> 1.216529467470779*^13, 
 "FourStationIdealRadialCapacity_N" -> 2.*^12, 
 "MinimumForceShortfall_N" -> 1.016529467470779*^13, 
 "MinimumEqualPerStationRadialForce_N" -> 3.0413236686769473*^12, 
 "IdealEqualAxialPathLengthIfAllAddedMassUsed_m" -> 106624.81511677783|>
