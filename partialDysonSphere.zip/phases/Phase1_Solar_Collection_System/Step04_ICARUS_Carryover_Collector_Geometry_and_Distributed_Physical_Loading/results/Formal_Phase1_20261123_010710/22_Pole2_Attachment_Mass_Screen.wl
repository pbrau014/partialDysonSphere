<|"Pole" -> "Pole2", "IdealFourStationAxialMass_kg_per_m" -> 
  3.864285714285714*^8, "EqualPathLengthIfAllMarginUsed_m" -> 
  737523.1053604437, "EqualPathLengthIfQuarterMarginUsed_m" -> 
  184380.77634011093|>
