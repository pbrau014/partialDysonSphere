<|"Pole" -> "Pole1", "Columns" -> {"Depth_km", "CMEBypassMass_kg", 
   "PeakHoop_N_m", "IdealHoopFiberMass_kg", "MassMargin_kg"}, 
 "Rows" -> {{10., 1.3611021665462373*^11, 0.20980117867389983, 0., 
    2.759185331894963*^11}, {20., 2.7222043330924747*^11, 
    0.41960235734779966, 0., 1.3980831653487253*^11}, 
   {30., 4.0833064996387115*^11, 0.6294035360216995, 0., 
    3.6980998802488403*^9}, {50., 6.805510832731187*^11, 1.0490058933694992, 
    0., -2.6852233342899866*^11}, {70., 9.527715165823662*^11, 
    1.4686082507172988, 3.323260087394432*^8, -5.4107509274698566*^11}}, 
 "Scope" -> "Shallow-cap linear approximation; incremental CME-only screen. \
No solar tide, interfaces, buckling, or installed structural mass."|>
