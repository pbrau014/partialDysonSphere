# Step 4 candidate design

The 0.6% reference fails the native nonspinning gravity-gradient gate on both poles. The independent 09 stability calculations use each saved native inertia and unstable growth rate. A 168-hour axial spin is the candidate for a spin-aware nonlinear assessment: it is below the ideal 452.7-hour gyroscopic threshold and gives the lowest centrifugal loads among the three previously studied periods. Gyroscopic stability is bounded oscillation in this conservative model, not demonstrated recovery. The native nonspinning gate was not altered.

For an alternate active stabilization case, use a reduced transverse proportional gain of 2.9534e-11 s^-2 and derivative gain of 7.6855e-6 s^-1, yielding repeated reduced-model poles of -3.8428e-6 s^-1. The ideal diameter-wide force couple is 2.2092e10 N at each end at one degree. This is a demand estimate before station allocation and saturation, with approximate axisymmetry and the zero-spin linearization.

For an initial structural screening case use 300 m unsupported half-span, separate from the cap radius. At the static peak normal pressure the legacy local circular-membrane formula requires 0.05513 N/m pretension, below the provisional 0.1 N/m. This is a panel candidate, with no implied verified connection layout or net structural pass. Test local normal and tangential loading and the fixed rim reactions with explicit support geometry and actuator loads.

Step 4 remains open. These candidate screens do not resolve the nonlinear station-controlled trajectory, force and moment transfer, saturation, or disturbance recovery. Keep the independent verification gates in place.
