# Step 4 backside backing and CME count screen

Keep the continuous aluminum reflector. Add a T1100G carbon-fiber-reinforced antisunward backing candidate to the trade study; this is a fiber reinforcement candidate, not a finished, qualified continuous film. The bare-fiber inputs are 7 GPa ultimate and 1790 kg/m^3. See the 43 Wolfram runner and pole-local outputs. Compared primary data: Toray technical manual, Toyobo Zylon technical data, Kuraray Vectran basic properties and DuPont Kapton HN datasheet.

Uniform backing at the screened peak load, using perfectly aligned tension-only fiber and a factor of two on ultimate: approximately 1.424e14 kg per pole for the passive CME case, 7.135e13 kg with ideal unlimited axial perimeter thrust. The whole pre-loading structural allowance preserving 10% future mass reserve was 4.120e13 kg; most of that was already allocated in the present reserve-preserving trial. These are equivalent fiber masses for this uniform sizing case; they exclude carrier film, bonding and multi-axis reinforcement. The membrane result can require compression; no tensile fiber datasheet establishes compression, buckling resistance or geometry retention. Do not install a uniform layer in the acceptance model at these values.

The 55-unit baseline has 1.335% ideal radial headroom. The 10% and 20% trial margins require 60 and 65 units per pole, respectively; holding the 20% margin after one radial unit outage requires 66. These are ideal radial-only count screens, not installed station allocations or shape acceptance.

The next material model must use a laminate or rib architecture with a verified compression load path, junctions and mass accounting, or a revised geometry. Step 4 remains open.
