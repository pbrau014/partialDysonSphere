(* Phase 1 Step 4: spin-relative attitude control and station allocation screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
w=c["ICARUSWrenchMatrix"]; j=c["DynamicInitialConditions"]["InertiaTensor_kg_m2"];
radius=c["Geometry"]["PlanformEquivalentRadius_m"];
s=DiagonalMatrix[Join[ConstantArray[1.,3],ConstantArray[1./radius,3]]];
allocator=PseudoInverse[s.w].s;
axis={1.,0.,0.}; omega=2. Pi/604800;
kp=2.9533720891532804*^-11; kd=7.685534580174993*^-6;
tracking[u_,rate_]:=Module[{b,err},
 b=Cross[u,axis];
 err=If[Norm[b]==0.,0. b,ArcTan[Dot[u,axis],Norm[b]] Normalize[b]];
 -j.(kp err+kd (rate-omega u))];
rows=Table[Module[{u,t,f,v},
 u={Cos[a Degree],0.,Sin[a Degree]};
 t=tracking[u,omega axis];v=Join[{0.,0.,0.},t];f=Partition[allocator.v,3];
 <|"Tilt_deg"->a,"Torque_Nm"->Norm[t],"StationForces_N"->(Norm /@ f),
 "PeakStationForce_N"->Max[Norm /@ f],"ForceClosure_N"->Norm[Take[w.Flatten[f]-v,3]],
 "RelativeScaledResidual"->(Norm[s.(w.Flatten[f]-v)]/Max[1.,Norm[s.v]])|>],{a,{0.,.25,.5,1.}}];
res=<|"Pole"->p,"AlignedNominalTorque_Nm"->Norm[tracking[axis,omega axis]],
 "ConfiguredCapacity_N"->c["ICARUSCapacityPerStation_N"],"Cases"->rows|>;
Put[res,"13_"<>p<>"_Spin_Allocation.wl"];Print[res];
If[!TrueQ[res["AlignedNominalTorque_Nm"]==0&&Max[Lookup[rows,"RelativeScaledResidual"]]<=10^-7],Exit[1]];
