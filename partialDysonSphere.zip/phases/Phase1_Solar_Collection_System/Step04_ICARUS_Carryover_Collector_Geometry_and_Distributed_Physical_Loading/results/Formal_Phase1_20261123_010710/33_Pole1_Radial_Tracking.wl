<|"Pole" -> "Pole1", "Columns" -> {"ExitVelocityError_m_s", "Recovery_s", 
   "PeakUnclippedDemand_N", "SaturationSampled", "Within24h"}, 
 "Cases" -> {{0.1, 48540., 3.0323874520624004*^10, False, True}, 
   {1., 63120.00000000001, 3.0323874520624005*^11, True, True}, 
   {5., 101400., 1.7960700565396938*^12, True, False}, 
   {10., Infinity, 5.93307312348703*^12, True, False}}|>
