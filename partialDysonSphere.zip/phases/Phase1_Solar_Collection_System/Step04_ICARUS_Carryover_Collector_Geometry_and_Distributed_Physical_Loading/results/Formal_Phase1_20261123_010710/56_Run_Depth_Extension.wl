(* Phase 1 Step 4: exploratory depth extensions to the shallow-cap screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
s=Get["52_"<>p<>".wl"]; c=Get["40_"<>p<>"_Membrane_Cut.wl"];
b=Get["48_"<>p<>"_Unstiffened_Area.wl"]["RemainingReservePreservingMass_kg"];
area=N[4 Pi 695700000^2/10];
rows=Table[With[{axial=First[s["Rows"]][[3]] h/100,
 apex=c["CMEPressureAtOnset_Pa"] (1000 h)/4},
 With[{hoop=area (1790./3.5*^9) Max[0.,2 apex-1.4]^2/(6 apex)},
 {h,axial,2 apex,hoop,b-axial-hoop}]],{h,{10.,20.,30.,50.,70.}}];
out=<|"Pole"->p,"Columns"->{"Depth_km","CMEBypassMass_kg","PeakHoop_N_m","IdealHoopFiberMass_kg","MassMargin_kg"},
 "Rows"->rows,"Scope"->"Shallow-cap linear approximation; incremental CME-only screen. No solar tide, interfaces, buckling, or installed structural mass."|>;
Put[out,"56_"<>p<>".wl"];Print[out];
