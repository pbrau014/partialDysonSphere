<|"Pole" -> "Pole1", "CMERadialForceScreen_N" -> 2.1393156467102965*^13, 
 "CMEImpulseScreen_Ns" -> 3.1730329672007117*^18, 
 "UncontrolledVelocityIncrementScreen_m_s" -> 3875.4856159962096, 
 "TrialRadialAuthority_N" -> 2.0829867325268164*^11, 
 "IdealCorrectiveImpulseThroughEventAnd24h_Ns" -> 4.889186458586943*^16|>
