# Phase 1 - Solar Collection System

This phase retains the roadmap's established Step 1 through Step 10 structure. Step-specific artifacts belong in the numbered step directories. Shared Phase 1 artifacts may use the phase-level folders only when they genuinely apply across steps.

The current working step is Step 4, resumed and incomplete/not accepted. Step 5 has authorized preliminary early-start work only; it is not accepted. See the governing roadmap and project status note.

## Current reference and acceptance

The provisional reference is a fixed shallow cap and fixed rim at 0.2 AU, with curved area equal to 10% of the solar surface per pole, uniform sheet assembly mass, 0.6% PV coverage, and distributed 100 kV collection over 1 km routes. Keep 1.1% as the higher-power alternative and 0.5%-3.0% as the trade range. Conditional reference output is 3.39e18 W per pole with 2.85e14 kg remaining radial mass budget after trial cooling and copper. Formal Phase 1 remains open. Step 3 remains closed by user authorization, with unfinished technical work in Step 4. Later exploratory calculations do not advance the roadmap acceptance gates.

Step 4 is closed by explicit user direction. Technical acceptance is not asserted. Phase 1 remains open. The earlier incomplete status records describe engineering evidence prior to this administrative closeout. This decision does not establish a technical pass or waive any later acceptance gate.

CURRENT DECISION: Step 4 is reopened by user direction. The administrative closeout is superseded. Technical acceptance remains incomplete, and Phase 1 remains open. Continue engineering verification before closure.
