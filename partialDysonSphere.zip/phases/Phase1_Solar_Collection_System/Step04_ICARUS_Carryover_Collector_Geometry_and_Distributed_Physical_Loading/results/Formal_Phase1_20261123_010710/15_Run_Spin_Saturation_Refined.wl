(* Phase 1 Step 4: spin-relative nonlinear attitude control with finite station forces. *)
pole=Environment["POLAR_ACCEPT_POLE"];
core=Get["02_"<>pole<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
j0=core["DynamicInitialConditions"]["InertiaTensor_kg_m2"];
is=Max[Diagonal[j0]]; j=j0/is;
wm=core["ICARUSWrenchMatrix"]; rad=core["Geometry"]["PlanformEquivalentRadius_m"];
scale=DiagonalMatrix[Join[{1.,1.,1.},ConstantArray[1./rad,3]]];
alloc=PseudoInverse[scale.wm].scale;
period=604800.; omega=2. Pi; axis={1.,0.,0.};
gg=3. 1.3271244*^20 period^2/29919574140.^3;
kp=2.9533720891532804*^-11 period^2; kd=7.685534580174993*^-6 period;
sun[q_]:=With[{z=Normalize[q]},
 {1-2(z[[3]]^2+z[[4]]^2),2(z[[2]] z[[3]]-z[[1]] z[[4]]),2(z[[2]] z[[4]]+z[[1]] z[[3]])}];
desired[q_,w_]:=Module[{u=sun[q],e},e=Cross[u,axis];
 -j.(kp If[Norm[e]==0.,e,ArcTan[u.axis,Norm[e]] Normalize[e]]+kd (w-omega u))];
demand[q_,w_]:=Partition[alloc.Join[{0.,0.,0.},is/period^2 desired[q,w]],3];
run[cap_,gain_]:=Module[{rhs,ic,y,sol,samples,tilts,rates,forces,netF,times,good,recovery},
 rhs[x_?VectorQ]/;VectorQ[x,NumericQ]:=Module[{q=Take[x,4],w=Take[x,-3],u,f,t},
   u=sun[q]; f=demand[q,w] gain;
   f=If[Norm[#]>cap,cap Normalize[#],#]& /@ f;
   t=Take[wm.Flatten[f],-3] period^2/is;
   Join[Join[{-Rest[q].w},q[[1]] w+Cross[Rest[q],w]]/2,
     LinearSolve[j,gg Cross[u,j.u]-Cross[w,j.w]+t]]];
 ic=N[Join[{Cos[1.25 Degree/2],0,Sin[1.25 Degree/2],0},{omega,0,0}]];
 sol=Check[NDSolveValue[{y'[t]==rhs[y[t]],y[0]==ic},y,{t,0.,2.},
    AccuracyGoal->14,PrecisionGoal->14,MaxSteps->Infinity],$Failed];
 If[sol===$Failed,Return[<|"Cap_N"->cap,"GainFactor"->gain,"SolverSucceeded"->False|>]];
 times=Subdivide[0.,2.,4032]; samples=sol /@ times;
 tilts=ArcCos[Clip[First[sun[Take[#,4]]],{-1.,1.}]]& /@ samples;
 rates=Norm[Take[#,-3]-omega sun[Take[#,4]]]/period& /@ samples;
 forces=(gain Max[Norm /@ demand[Take[#,4],Take[#,-3]]])& /@ samples;
 netF=Max[Norm[Total[(If[Norm[#]>cap,cap Normalize[#],#]& /@ (gain demand[Take[#,4],Take[#,-3]]))]]& /@ samples];
 good=MapThread[#1<=.0174533&&#2<=1.*^-7&,{tilts,rates}];
 recovery=If[Last[good],If[FreeQ[good,False],0.,period times[[Last[Flatten[Position[good,False]]]+1]]],Infinity];
 <|"Cap_N"->cap,"GainFactor"->gain,"SolverSucceeded"->True,"Recovery_s"->recovery,
 "PeakDemand_N"->Max[forces],"Saturated"->(Max[forces]>cap),
 "PeakTilt_deg"->Max[tilts]/Degree,"PeakNetStationForce_N"->netF,
 "QuaternionNormError"->Max[Abs[(Norm[Take[#,4]]& /@ samples)-1]]|>];
out=run@@@{{6.*^11,6.},{9.*^11,10.},{1.5*^12,16.}};
Put[<|"Pole"->pole,"Cases"->out|>,"15_"<>pole<>"_Saturation.wl"];Print[{pole,out}];

