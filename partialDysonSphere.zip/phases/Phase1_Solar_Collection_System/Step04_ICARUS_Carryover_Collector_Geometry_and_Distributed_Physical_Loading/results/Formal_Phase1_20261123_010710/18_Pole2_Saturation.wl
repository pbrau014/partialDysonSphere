<|"Pole" -> "Pole2", "Cases" -> {<|"Cap_N" -> 2.*^12, "GainFactor" -> 3., 
    "RelativeDamping" -> 0.25, "SolverSucceeded" -> True, 
    "Recovery_s" -> 389699.99999999994, "PeakDemand_N" -> 
     8.284611265686734*^10, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.000032345310168141086, "QuaternionNormError" -> 
     2.844140478686086*^-10|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 3., 
    "RelativeDamping" -> 0.5, "SolverSucceeded" -> True, 
    "Recovery_s" -> 201300., "PeakDemand_N" -> 1.119813329217074*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00003469049140771537, 
    "QuaternionNormError" -> 3.788952485095365*^-10|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 3., "RelativeDamping" -> 0.75, 
    "SolverSucceeded" -> True, "Recovery_s" -> 171600., 
    "PeakDemand_N" -> 1.6797199938256113*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00004113349790808609, "QuaternionNormError" -> 
     1.1868149796256944*^-9|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 3., 
    "RelativeDamping" -> 1., "SolverSucceeded" -> True, 
    "Recovery_s" -> 140700., "PeakDemand_N" -> 2.239626658434148*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00007030297705879004, 
    "QuaternionNormError" -> 1.5495271732390847*^-11|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 4., "RelativeDamping" -> 0.25, 
    "SolverSucceeded" -> True, "Recovery_s" -> 219000., 
    "PeakDemand_N" -> 1.1046148354248978*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00003364215077172339, "QuaternionNormError" -> 
     1.1851585268729536*^-9|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 4., 
    "RelativeDamping" -> 0.5, "SolverSucceeded" -> True, 
    "Recovery_s" -> 177599.99999999997, "PeakDemand_N" -> 
     1.4930844389560986*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00003922658228898041, "QuaternionNormError" -> 
     4.463721614555993*^-10|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 4., 
    "RelativeDamping" -> 0.75, "SolverSucceeded" -> True, 
    "Recovery_s" -> 148200., "PeakDemand_N" -> 2.2396266584341483*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00007098994649967227, 
    "QuaternionNormError" -> 2.5311197582311706*^-11|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 4., "RelativeDamping" -> 1., 
    "SolverSucceeded" -> True, "Recovery_s" -> 113100., 
    "PeakDemand_N" -> 2.986168877912197*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.0000765536778132993, "QuaternionNormError" -> 6.19361784082173*^-10|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 5., "RelativeDamping" -> 0.25, 
    "SolverSucceeded" -> True, "Recovery_s" -> 195299.99999999997, 
    "PeakDemand_N" -> 1.380768544281122*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.000048867801691826326, "QuaternionNormError" -> 
     9.906242492974116*^-11|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 5., 
    "RelativeDamping" -> 0.5, "SolverSucceeded" -> True, 
    "Recovery_s" -> 161400., "PeakDemand_N" -> 1.8663555486951233*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00006589475316467951, 
    "QuaternionNormError" -> 9.006617673890105*^-11|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 5., "RelativeDamping" -> 0.75, 
    "SolverSucceeded" -> True, "Recovery_s" -> 131699.99999999997, 
    "PeakDemand_N" -> 2.7995333230426855*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00007624832330082954, "QuaternionNormError" -> 
     1.0900735869512346*^-10|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 5., 
    "RelativeDamping" -> 1., "SolverSucceeded" -> True, 
    "Recovery_s" -> 92399.99999999999, "PeakDemand_N" -> 
     3.7327110973902466*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00008471336465582069, "QuaternionNormError" -> 
     5.038500727749806*^-10|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 6., 
    "RelativeDamping" -> 0.25, "SolverSucceeded" -> True, 
    "Recovery_s" -> 179400., "PeakDemand_N" -> 1.6569222531373468*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00006443243244151944, 
    "QuaternionNormError" -> 8.916412053139311*^-11|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 6., "RelativeDamping" -> 0.5, 
    "SolverSucceeded" -> True, "Recovery_s" -> 149400., 
    "PeakDemand_N" -> 2.239626658434148*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.0000683022774073583, "QuaternionNormError" -> 
     6.577804967378142*^-11|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 6., 
    "RelativeDamping" -> 0.75, "SolverSucceeded" -> True, 
    "Recovery_s" -> 119100., "PeakDemand_N" -> 3.3594399876512225*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00008175829642047589, 
    "QuaternionNormError" -> 8.209494195554612*^-10|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 6., "RelativeDamping" -> 1., 
    "SolverSucceeded" -> True, "Recovery_s" -> 75000., 
    "PeakDemand_N" -> 4.479253316868296*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00009281276957829899, "QuaternionNormError" -> 
     3.639498702412425*^-10|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 8., 
    "RelativeDamping" -> 0.25, "SolverSucceeded" -> True, 
    "Recovery_s" -> 158099.99999999997, "PeakDemand_N" -> 
     2.2092296708497955*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00006715840859541562, "QuaternionNormError" -> 
     1.6265089275435685*^-10|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 8., 
    "RelativeDamping" -> 0.5, "SolverSucceeded" -> True, 
    "Recovery_s" -> 132600., "PeakDemand_N" -> 2.986168877912197*^11, 
    "Saturated" -> False, "PeakTilt_deg" -> 1.2499999999998945, 
    "PeakNetStationForce_N" -> 0.00007862079540607197, 
    "QuaternionNormError" -> 3.53833740085463*^-10|>, 
   <|"Cap_N" -> 2.*^12, "GainFactor" -> 8., "RelativeDamping" -> 0.75, 
    "SolverSucceeded" -> True, "Recovery_s" -> 101100., 
    "PeakDemand_N" -> 4.4792533168682965*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00009475829024753223, "QuaternionNormError" -> 
     3.880993304505864*^-10|>, <|"Cap_N" -> 2.*^12, "GainFactor" -> 8., 
    "RelativeDamping" -> 1., "SolverSucceeded" -> True, 
    "Recovery_s" -> 58499.99999999999, "PeakDemand_N" -> 
     5.972337755824395*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00015219302674264975, "QuaternionNormError" -> 
     1.7139545338551443*^-10|>}|>
