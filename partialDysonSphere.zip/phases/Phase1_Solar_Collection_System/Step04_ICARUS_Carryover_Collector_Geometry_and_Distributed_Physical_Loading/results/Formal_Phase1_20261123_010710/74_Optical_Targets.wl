(* Phase 1 Step 4: distributed optical wrench candidate; analysis only. *)
<|"Status"->"CandidateForCoupledVerification","Distance_AU"->.2,"CapDepth_m"->10000,
 "NominalSpin_rad_s"->0.,"AxisymmetricPreTensionTrial_N_m"->.125,
 "PrimaryAxialAndPitchYawActuator"->"Smooth distributed optical pressure",
 "AxialPressureBasis"->{"1","y/R","z/R"},
 "ResidualActuatorRole"->"ICARUS transverse force, roll, and off-nominal recovery",
 "OpticalMassCeiling_kg"->2.068593265953714*^13,
 "PriorConditionalPower_W"->6.10842584077336*^18,
 "OtherInputsMustBeReconciled"->{"InstalledMassMap","CoatingAndFacetResponse","ThermalRecoilAndFlux","PVFootprint","RimCompliance","ModalSensingAndDamping","OffNominalLoads"},
 "KeepConfigurationPoleLocal"->True,"TechnicalAcceptance"->False|>
