(* Phase 1 Step 4: unstiffened-area sensitivity and mass limits. *)
p=Environment["POLAR_ACCEPT_POLE"];
s=Get["45_"<>p<>"_Signed_Membrane.wl"];
b=Get["27_"<>p<>"_Reserve_Trade.wl"]["MaximumAddedMassPreservingReserve_kg"];
a=N[4 Pi 695700000^2/10];
rows=Table[With[{peak=Abs[c["Apex_N_m"][[1]]],h=1000 c["Depth_km"]},
 q0=1-2 Pi h^2/a;
 {c["Depth_km"],Table[{limit,100 Clip[limit (1+q0)/(2 peak-limit (1-q0)),{0,1}]},{limit,{0.,.1,.25,.5,1.,1.4}}]}
 ],{c,s["Cases"]}];
o=<|"Pole"->p,"Rows"->rows,"RemainingReservePreservingMass_kg"->.01 b,
 "RemainingAverageArealMass_kg_m2"->.01 b/a,"FullPreAllocationMass_kg"->b,
 "Scope"->"Area below hypothetical effective meridional compression threshold only; not a wrinkling or hoop-strength pass. Remaining budget relative to 99 percent pre-allocation trial."|>;
Put[o,"48_"<>p<>"_Unstiffened_Area.wl"];Print[o];
