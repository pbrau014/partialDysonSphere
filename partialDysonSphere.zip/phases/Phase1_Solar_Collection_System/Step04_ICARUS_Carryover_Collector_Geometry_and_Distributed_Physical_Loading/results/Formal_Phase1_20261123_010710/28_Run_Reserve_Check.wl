(* Phase 1 Step 4: pole-local static balance of a separate loaded operating case. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"];
d=Get["01_Reference_Architecture.wl"]; sh=d["SharedNativeInputs"];
op=Phase1SetPoleOperatingInputs[pole,d["PoleOperatingInputs"]];
If[FailureQ[op],Print[op];Exit[2]];
key="OtherInstalledArealMass_kg_m2"; x0=sh[key];
eval[x_?NumericQ]:=Module[{set,n},
 set=Phase1SetInputs[Join[sh,<|key->x|>]];
 If[FailureQ[set],Print[set];Exit[2]];
 n=Phase1RunPoleTask[pole,"NaturalEquilibrium"];
 If[!AssociationQ[n],Print[n];Exit[2]];
 n=Lookup[n,"Result",n]; If[AssociationQ[Lookup[n,"NaturalEquilibrium",None]],n["NaturalEquilibrium"],n]];
target=Get["27_"<>pole<>"_Reserve_Trade.wl"];
added=.99 target["MaximumAddedMassPreservingReserve_kg"];
area=N[4 Pi 695700000^2/10];
n=eval[x0+added/area];
out=KeyTake[n,{"CurrentPoleMass_kg","NetNaturalRadialForce_N",
 "OutwardRadialBiasPass","FutureMassGrowthTargetPass","TransverseForceBalancePass",
 "FutureAddedMassCapacityToCurrentMassRatio","ExactNaturalEquilibrium"}];
Put[out,"28_"<>pole<>"_Reserve_Check.wl"];Print[{pole,out}];
If[!TrueQ[out["FutureMassGrowthTargetPass"]&&out["OutwardRadialBiasPass"]],Exit[1]];
