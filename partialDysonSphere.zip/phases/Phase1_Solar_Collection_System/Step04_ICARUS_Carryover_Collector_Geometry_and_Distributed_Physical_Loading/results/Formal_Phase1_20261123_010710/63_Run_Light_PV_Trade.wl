(* Phase 1 Step 4: fixed 0.2 AU PV optimization under modeled mass. *)
src=Environment["POLAR_ACCEPT_SOURCE"]; If[Get[src]===$Failed,Exit[3]];
p=Environment["POLAR_ACCEPT_POLE"]; d=Get["01_Reference_Architecture.wl"];
fixed=Get["61_"<>p<>".wl"]; sh=fixed["LoadedSharedInputs"]; area=N[4 Pi 695700000^2/10];
op=Phase1SetPoleOperatingInputs[p,d["PoleOperatingInputs"]];If[FailureQ[op],Exit[2]];
power=3.385264858155934*^18/.006;
(* Legacy 0.6 percent architecture: before ballast, linear installed copper and cooling. *)
cool=1.526698109072746*^14; copper=4.694880877436852*^13/4;
eval[f_,k_]:=Module[{u,n},
 u=Phase1SetInputs[Join[sh,<|"PVFraction"->f,"OtherInstalledArealMass_kg_m2"->((cool k+copper) f/(.006 area))|>]];
 If[FailureQ[u],Print[u];Exit[2]];
 n=Phase1RunPoleTask[p,"NaturalEquilibrium"];If[!AssociationQ[n],Print[n];Exit[2]];
 n=Lookup[n,"Result",n];n=Lookup[n,"NaturalEquilibrium",n];
 {n["NetNaturalRadialForce_N"],n["CurrentPoleMass_kg"],n["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"],n["ExactNaturalEquilibrium"]}];
rows=Table[Module[{lo,hi,g,q,root,check},
 lo=eval[.005,k];hi=eval[.03,k];
 g[v_]:=If[reserve==0,First[v],v[[3]]-reserve v[[2]]];
 q=(g[hi]-g[lo])/.025;root=.005-g[lo]/q;
 If[!TrueQ[.005<=root<=.03],Print[{k,reserve,root}];Exit[4]];
 check=eval[root,k];
 <|"CoolingDensity_g_m2"->k,"ReserveFraction"->reserve,"PV_pct"->100 root,
 "ConditionalPower_W"->power root,"RadialForce_N"->check[[1]],"MassBeforeLaterLoading_kg"->check[[2]],
 "ModelReportedMassReserve_kg"->check[[3]],"StaticBalancePass"->check[[4]],
 "InterpolationResidual"->g[check]|>
 ],{k,{.2705}},{reserve,{0.,.1}}];
out=<|"Pole"->p,"Cases"->Flatten[rows],"Scope"->"Native static force at 10 km cap and 0.2 AU. Earlier linear PV and cooling laws with both modeled copper routes shortened from 1 km to 0.5 km at fixed voltage and loss. Ideal copper mass scales as route length squared. Extra distribution nodes and hardware uncounted. Installed hardware, radiator optical forces and CME stationkeeping unverified."|>;
Put[out,"63_"<>p<>".wl"];Print[out];

