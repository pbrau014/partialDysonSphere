<|"Pole" -> "Pole2", "Rows" -> 
  {<|"Bay_m" -> 0.25, "AssumedEdgeMotionLimit_m" -> 3.2022455556717147*^-6, 
    "RequiredEI_Nm2" -> 0.00016661807445189256, "CapSeparation_m" -> 
     0.0025940001946448067, "TwoCapArea_m2" -> 9.904717514114176*^-10, 
    "EachWebThickness_m" -> 2.863998429953187*^-7, 
    "TrialRibLinearMass_kg_m" -> 3.9621027973817845*^-6, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 6.716232448243634*^-6, 
    "MassFraction" -> 0.5899293730397785, "TwoFaceSlopeAmplification_mrad" -> 
     1.0012576274976248|>, <|"Bay_m" -> 0.35, "AssumedEdgeMotionLimit_m" -> 
     6.330606717662571*^-6, "RequiredEI_Nm2" -> 0.0004532852496001804, 
    "CapSeparation_m" -> 0.0032782092470898996, "TwoCapArea_m2" -> 
     1.6871676368174279*^-9, "EachWebThickness_m" -> 3.87507716317852*^-7, 
    "TrialRibLinearMass_kg_m" -> 6.764528631553875*^-6, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 9.402725427541087*^-6, 
    "MassFraction" -> 0.7194221168832824, "TwoFaceSlopeAmplification_mrad" -> 
     1.393442090281411|>, <|"Bay_m" -> 0.4, "AssumedEdgeMotionLimit_m" -> 
     8.211290500303839*^-6, "RequiredEI_Nm2" -> 0.0006813421225036, 
    "CapSeparation_m" -> 0.003608305810416943, "TwoCapArea_m2" -> 
     2.0932377343685386*^-9, "EachWebThickness_m" -> 4.373514208377661*^-7, 
    "TrialRibLinearMass_kg_m" -> 8.399092928599317*^-6, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 0.000010745971917189814, 
    "MassFraction" -> 0.7816038412648083, "TwoFaceSlopeAmplification_mrad" -> 
     1.608418998617818|>, <|"Bay_m" -> 0.5, "AssumedEdgeMotionLimit_m" -> 
     0.000012793936002842126, "RequiredEI_Nm2" -> 0.0013345121958768596, 
    "CapSeparation_m" -> 0.004223151592919845, "TwoCapArea_m2" -> 
     2.9930170883211304*^-9, "EachWebThickness_m" -> 5.348290578003734*^-7, 
    "TrialRibLinearMass_kg_m" -> 0.000012016552740960102, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 0.000013432464896487268, 
    "MassFraction" -> 0.8945902954939087, "TwoFaceSlopeAmplification_mrad" -> 
     1.9370375544768212|>}, "Scope" -> "Ideal equivalent material \
assumptions, service deflection and web shear-buckling screen. No bonded load \
transfer, cap local buckling, joint rigidity, minimum ply or film gauge, mass \
of sensors, whole-rim compatibility, transient rib dynamics. No installed \
pass."|>
