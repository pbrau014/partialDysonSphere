<|"Pole" -> "Pole2", "Summary" -> <|"SolverSucceeded" -> True, 
   "Duration_s" -> 604800., "SpinTrackingEnabled" -> True, 
   "ICARUSSaturationOccurred" -> False, "MaximumRequiredStationForce_N" -> 
    1.736829733597069*^11, "MaximumQuaternionNormalizationError" -> 
    6.0686748959426495*^-9, "RecoveryWithinLimit" -> False, 
   "RecoveryTime_s" -> Infinity, "StructuralScreenPass" -> False|>, 
 "SourceHash" -> 
  "b0793e6bce7fdc6ef42469ecf596e194c34de85a7fc20e9042b25a2cbcd1a59d"|>
