(* Phase 1 Step 4: reduced radial residual tracking after CME exit. *)
p=Environment["POLAR_ACCEPT_POLE"];
a=Get["29_"<>p<>"_Moving_Reference.wl"]; d=Get["32_"<>p<>"_CME_RideThrough.wl"];
b=Get["30_"<>p<>"_Moving_Envelope.wl"];
m=a["Mass_kg"]; cap=b["AdditionalRadialWrenchAuthority_N"];
r0=a["ForceGrid_N"][[1,1]]; rInit=r0 Last[d["Segments"]][235200./604800.];
vInit=d["AtCMEEndSpeed_m_s"]; f0=a["ForceGrid_N"][[1,2]];
dt=86400.; om=16.;
force[z_?NumericQ,u_?NumericQ]:=Clip[-m/dt^2 (om^2 z+2 om u),{-cap,cap}];
ref=NDSolveValue[{r''[t]==(dt^2 f0/m) (r0/r[t])^2,r[0]==rInit,r'[0]==dt vInit},r,{t,0,2}];
acc[t_?NumericQ,z_?NumericQ,u_?NumericQ]:=dt^2/m (f0 ((r0/(ref[t]+z))^2-(r0/ref[t])^2)+force[z,u]);
rows=Table[Module[{sol,ts,good,idx,dem},
 sol=NDSolveValue[{x''[t]==acc[t,x[t],x'[t]],x[0]==0.,x'[0]==dt dv},x,{t,0.,2.}];
 ts=Subdivide[0.,2.,2880];
 good=(Abs[sol[#]]<=b["ProvisionalRadialTubeHalfWidth_m"]&&Abs[sol'[#]/dt]<=.0001)& /@ ts;
 idx=If[Last[good],If[FreeQ[good,False],1,Last[Flatten[Position[good,False]]]+1],0];
 dem=Max[(m/dt^2 Abs[om^2 sol[#]+2 om sol'[#]])& /@ ts];
 {dv,If[idx==0,Infinity,dt ts[[idx]]],dem,dem>cap,TrueQ[idx>0&&ts[[idx]]<=1]}
 ],{dv,{.1,1.,5.,10.}}];
o=<|"Pole"->p,"Columns"->{"ExitVelocityError_m_s","Recovery_s","PeakUnclippedDemand_N","SaturationSampled","Within24h"},"Cases"->rows|>;
Put[o,"33_"<>p<>"_Radial_Tracking.wl"];Print[o];
