(* Phase 1 Step 4: ideal variable spin feedforward command along saved trajectory. *)
p=Environment["POLAR_ACCEPT_POLE"];
d=Get["32_"<>p<>"_CME_RideThrough.wl"]; n=Get["29_"<>p<>"_Moving_Reference.wl"];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
area=N[4 Pi 695700000^2/10]; h=10000.;a=Sqrt[area/Pi-h^2];
j=n["Mass_kg"] (a^2/2+h^2/6); r0=n["ForceGrid_N"][[1,1]];
w=c["ICARUSWrenchMatrix"]; sc=DiagonalMatrix[Join[{1.,1.,1.},ConstantArray[1./a,3]]];
per=Max[Norm /@ Partition[PseudoInverse[sc.w].(sc.{0.,0.,0.,1.,0.,0.}),3]];
segs=d["Segments"]; cuts=d["SegmentBoundaries_s"]/604800.;
tq[i_,t_]:=With[{x=segs[[i]][t],v=r0 Derivative[1][segs[[i]]][t]/604800.},
 (3/2) j Sqrt[1.3271244*^20/(r0 x)^3] Abs[v]/(r0 x)];
peak=Max[Flatten[Table[tq[i,#]& /@ Subdivide[cuts[[i]],cuts[[i+1]],256],{i,3}]]];
o=<|"Pole"->p,"PeakIdealFeedforwardTorque_Nm"->peak,"PeakIdealStationDemand_N"->per peak,
 "Scope"->"Central tide balance law omega=sqrt(mu/r^3). Earlier four-station matrix. Pure axial torque demand only; excludes attitude and tracking simultaneity."|>;
Put[o,"60_"<>p<>".wl"];Print[o];
