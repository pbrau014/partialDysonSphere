(* Phase 1 Step 4: candidate operating and support architecture. *)
<|"AxialSpinPeriod_s"->604800,"TrialStationCap_N"->5.*^11,
 "AttitudeKp_per_s2"->(6*2.9533720891532804*^-11),
 "AttitudeKd_per_s"->(6*7.685534580174993*^-6),
 "StationZoneTrialHalfSpan_m"->20.,"Pretension_N_m"->.1,
 "Status"->"Provisional candidate; actuator hardware, structural load paths and coupled recovery require verification."|>
