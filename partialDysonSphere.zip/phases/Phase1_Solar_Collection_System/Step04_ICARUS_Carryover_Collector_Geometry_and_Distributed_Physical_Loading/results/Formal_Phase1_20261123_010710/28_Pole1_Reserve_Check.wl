<|"CurrentPoleMass_kg" -> 8.187446120568481*^14, 
 "NetNaturalRadialForce_N" -> 1.2226368979538672*^13, 
 "OutwardRadialBiasPass" -> True, "FutureMassGrowthTargetPass" -> True, 
 "TransverseForceBalancePass" -> True, 
 "FutureAddedMassCapacityToCurrentMassRatio" -> 0.1005615764058616, 
 "ExactNaturalEquilibrium" -> False|>
