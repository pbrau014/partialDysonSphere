# Step 4 targeted reinforcement design decision

Retain the 100 km cap as the primary geometry and the 250 km cap as the alternative. Retire the trial full-area bonded grid. Keep the aluminum reflector and T1100G as a candidate for targeted antisunward reinforcement.

Treat the hoop load as a rim-zone sizing problem. Trial a circumferential band with tapered transfer into the foil, and size that transfer from the saved signed hoop profile. The rim band may only be credited for loads it can actually collect. Check local hoop demand in the foil inside the band.

Trial discrete meridional stiffeners with closed or braced sections for compression. Their extent follows the signed meridional profile and a verified local buckling limit, rather than assuming that reinforcement is confined to a small apex patch. In the current spherical-cap screen meridional compression persists through almost the entire interior, dropping to zero at the rim. The peak is near the apex. At the 250 km depth, about 47% of the curved area exceeds 1.4 N/m in meridional compression alone. At 100 km the compressive magnitude remains below that strength value, but the local buckling limit is unknown.

Use discrete connections where load transfer permits. Include the whole assembly mass: band, stiffener caps, webs and bracing, connectors and adhesive. Check local foil wrinkling between load paths, stiffener imperfections and buckling, bond shear and peel, differential thermal strain, and rim-to-foil transfer before accepting either cap. These are candidate load paths; the 45 signed profiles and 46 rejected grid remain the sizing evidence. Step 4 remains open.
