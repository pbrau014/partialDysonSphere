<|"Pole" -> "Pole1", "PeakIdealFeedforwardTorque_Nm" -> 
  7.848351278053843*^19, "PeakIdealStationDemand_N" -> 
  4.4815384780684135*^10, "Scope" -> "Central tide balance law \
omega=sqrt(mu/r^3). Earlier four-station matrix. Pure axial torque demand \
only; excludes attitude and tracking simultaneity."|>
