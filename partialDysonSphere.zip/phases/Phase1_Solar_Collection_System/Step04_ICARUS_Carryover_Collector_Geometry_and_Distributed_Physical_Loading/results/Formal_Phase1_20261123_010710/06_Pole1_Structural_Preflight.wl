<|"AppliedPeakLocalNormalEnvironmentalPressureIncludingGravity_Pa" -> 
  0.0000367527461425242, "PlanformSpan_m" -> 4.378156807345184*^8, 
 "AssumedMembranePretension_N_m" -> 0.1, 
 "AllowablePretensionFromStrength_N_m" -> 1.3999999999999997|>
