(* Phase 1 Step 4: ideal radiation momentum steering to balance transverse tide. *)
p=Environment["POLAR_ACCEPT_POLE"];
n=Get["29_"<>p<>"_Moving_Reference.wl"]; d=Get["32_"<>p<>"_CME_RideThrough.wl"];
a=N[4 Pi 695700000^2/10]; rad=Sqrt[a/Pi]; r=n["ForceGrid_N"][[1,1]];
m=n["Mass_kg"]; base=34029.16163521439/299792458.;
f=(m/a) 1.3271244*^20 rad/(r^2+rad^2)^(3/2);
(* Ideal specular pressure per facet surface area: 2 S/c cos^2(theta).
   Select the low-angle solution for outward transverse momentum. *)
theta=x/.FindRoot[2 base Cos[x]^2 Sin[x]==f,{x,.013}];
factor=d["Day7Distance_AU"]/.2;
theta7=x/.FindRoot[2 base/factor^2 Cos[x]^2 Sin[x]==(m/a) 1.3271244*^20 rad/((factor r)^2+rad^2)^(3/2),{x,.011}];
out=<|"Pole"->p,"RimTransversePressureNeeded_Pa"->f,"IdealRimFacetAngleStart_deg"->theta/Degree,
 "IdealRimFacetAngleDay7_deg"->theta7/Degree,"IdealLocalAxialSpecularLossStartFraction"->1-Cos[theta]^3,
 "Scope"->"Ideal perfectly reflecting independently adjustable facets per face area. Balances one modeled load component only. Does not establish optical, thermal, manufacturing, mass or structural feasibility."|>;
Put[out,"54_"<>p<>".wl"];Print[out];
