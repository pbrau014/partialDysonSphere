(* Phase 1 Step 4: conditional interface assumptions for all-phase planning. *)
<|"Status"->"PlanningOnly","Step4TechnicalAcceptance"->False,
 "PoleScope"->{"Pole1","Pole2"},"ApplySeparatelyPerPole"->True,
 "CapDepth_m"->10000,"ComparisonDepth_m"->20000,
 "DocumentedReferenceDepths_m"->{100000,250000},
 "PVFraction"->0.006,"PVAlternativeFraction"->0.011,"PVTradeRange"->{0.005,0.03},
 "FutureAddedMassReserveFraction"->0.10,
 "IdealCMEBypassMass_kg"->1.3611021665462373*^11,
 "ResidualReinforcementAllowanceAfterIdealBypass_kg"->2.759185331894963*^11,
 "FacetRimAngleTargets_deg"->{0.7406241613,0.6419199664},
 "IntentionalSpin"->False,"ReducedTrackingEvidenceUnits"->4,
 "SeparateRadialThrustSizingUnits"->55,
 "HistoricalPlanningEndpointInputs"-><|"Distance_AU"->{0.2,0.2307602360},
   "ReferenceIrradiance_W_m2"->{34029.1616352,25561.6740145},
   "ConditionalConditionedPower_W"->{3.385264858155934*^18,(3.385264858155934*^18 25561.6740145/34029.1616352)}|>,
 "InputCaution"->"Trajectory and power were derived from earlier geometry; carry only as planning placeholders and recalculate for 10 km."|>

