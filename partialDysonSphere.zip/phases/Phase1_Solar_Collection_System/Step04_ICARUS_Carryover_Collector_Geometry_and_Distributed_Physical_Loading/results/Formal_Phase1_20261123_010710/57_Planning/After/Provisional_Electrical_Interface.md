# Phase 2 provisional electrical interface

History-based planning inputs per pole. These values came from the earlier 0.6% design, not a validated 10 km collector run. In the architecture selection runner, Pconditioned = Praw (0.99 x 0.95)^2. For the budget only, assign both 0.99 factors to Phase 1 wiring and one 0.95 factor to each side of the Phase 1/2 handoff. Confirm that loss allocation before hardware sizing.

| Boundary | At 0.2 AU | Day seven, CME reference |
|---|---:|---:|
| Raw PV before modeled losses | 3.827 EW | 2.875 EW |
| Input to Phase 2 after provisional Phase 1 losses | 3.563 EW | 2.676 EW |
| Output of Phase 2 to Phase 3 | 3.385 EW | 2.543 EW |
| Phase 2 loss / thermal duty before heat recovery | 0.178 EW | 0.134 EW |

Derive the far-end case by multiplying all near-end figures by 25561.6740145 / 34029.1616352. Raw PV = conditioned /(0.99 x 0.95)^2. Phase 2 input = conditioned / 0.95. Use these values separately for each pole. Allow only reporting-level sums. Define actual bus segmentation, voltage/current envelope, failure isolation, duty, thermal rejection and installed mass before considering the interface verified. Phase 3 receives provisional conditioned output; additional transmitter losses are TBD.
