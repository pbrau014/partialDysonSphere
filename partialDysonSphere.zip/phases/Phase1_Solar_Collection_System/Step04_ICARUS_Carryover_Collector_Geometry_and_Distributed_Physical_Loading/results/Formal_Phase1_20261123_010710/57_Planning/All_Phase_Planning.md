# All-phase planning and redesign handback

The 10 km candidate and 20 km comparison are tentative geometry inputs. The existing power, CME endpoint and reflector-steering estimates are from earlier geometry or separate ideal screens. Do not treat them as a single validated 10 km simulation. Carry the original check results and 100/250 km cases as design evidence.

| Phase | Planning deliverable | Return to the integrated design |
|---|---|---|
| 0 Master parameters | Interface and assumption register with units and source checkpoints | Mass, power and heat budgets with consistent boundaries |
| 1 Collection | Collector, local electrical collection, thermal and disturbance trade study | Raw PV and bus boundary, available power, geometry, installed mass and trajectory |
| 2 Conditioning | Conversion and distribution architecture | Conditioning map, fault limits, losses, heat and mass |
| 3 Transmission | Link options and pointing budget | Apertures, duty and capture efficiency versus trajectory, thermal and mass costs |
| 4 Reception | Receiver, conversion and grid dispatch plan | Delivered power, infrastructure capacity, thermal loads, curtailment and availability |
| 5 Integration | Coupled pole-local system and fault-case assessment | Verified interfaces, acceptance results and unresolved hardware requirements |

The next planning calculation is the Phase 2 electrical interface budget. The 3.39/2.54 EW per-pole figures are already conditional conditioned estimates. For electrical sizing, work upstream to a consistently defined raw DC boundary and forward through explicit losses. No transmission or delivered grid power values are assigned. Close the planning loop by feeding Phases 2-5 installed mass and interface limits into Phase 1 and rerunning the selected design separately for each pole.

Technical closure remains open. No change to source acceptance logic, physical allowables or prior evidence is made.
