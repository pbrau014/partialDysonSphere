(* Phase 1 Step 4: finite-zone force and moment closure / flexible replay. *)
p=Environment["POLAR_ACCEPT_POLE"];
If[Get[Environment["POLAR_ACCEPT_SOURCE"]]===$Failed,Exit[3]];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
track=Get["70_"<>p<>".wl"]; opt=Get["74_"<>p<>".wl"];
loaded=Get["66_"<>p<>".wl"]; s=Get["71_"<>p<>".wl"];
mass=loaded["LoadedMass_kg"]; a=N[4 Pi 695700000^2/10];
r=Sqrt[a/Pi-10000.^2]; aa=(1-loaded["PV_pct"]/100) a;
patch=c["SurfaceMesh"]["Patches"]; xy=Lookup[patch,"Position_m"][[All,2;;3]]/c["Geometry"]["PlanformEquivalentRadius_m"];
wa=Lookup[patch,"SurfaceAreaWeight_m2"]; weights=wa/Total[wa]; rr=Norm /@ xy;
az=(ArcTan@@@xy); rigid=({1.,#[[1]],#[[2]]}& /@ xy);
moment=Transpose[rigid]; fine=MapThread[Times,{weights,rigid}];
gram=moment.fine;
nonRigid[v_]:=v-fine.LinearSolve[gram,moment.v];
w=c["ICARUSWrenchMatrix"];
modes=Flatten[Table[{l,j,N[BesselJZero[l,k]]},{l,0,6},{j,0,If[l==0,0,1]},{k,8}],2];
shapes=Table[BesselJ[v[[1]],v[[3]] rr[[i]]] If[v[[2]]==0,Cos[v[[1]] az[[i]]],Sin[v[[1]] az[[i]]]],{i,Length[rr]},{v,modes}];
modalMass=mass ((BesselJ[#[[1]]+1,#[[3]]]^2 If[#[[1]]==0,1.,.5])& /@ modes);
omega=Sqrt[s["CMEOnsetApexTensionRemaining_N_m"]/(mass/a)] modes[[All,3]]/r;
screen[case_,nr_,na_]:=Module[{key,groups,cen,zmap,op,f,pcoef,press,tt,force,u,v,dt,x,du,umax=0.,rmax=0.,membership,zweight,basis,target,use,sys,commands,err},
 key=MapThread[{Min[nr-1,Floor[nr #1^2]],Min[na-1,Floor[na Mod[#2,2 Pi]/(2 Pi)]]}&,{rr,az}];
 groups=GatherBy[Range[Length[key]],key[[#]]&];
 cen=ConstantArray[{0.,0.,0.},Length[key]];
 Do[cen[[g]]=ConstantArray[weights[[g]].rigid[[g]]/Total[weights[[g]]],Length[g]],{g,groups}];
 membership=Transpose[Table[Normal[SparseArray[Thread[g->1.],Length[weights]]],{g,groups}]]; zweight=Total /@ (weights[[#]]& /@ groups); zmap=MapThread[Times,{weights,membership}].DiagonalMatrix[1./Sqrt[zweight]]; use=Flatten[Position[(#[[1]]<=4&&#[[3]]<=N[BesselJZero[#[[1]],6]]+10^-10& /@ modes),True]]; basis=Join[moment,Transpose[shapes[[All,use]]]]; sys=basis.zmap; target=basis.fine.Inverse[gram]; commands=PseudoInverse[sys].target; op=zmap.commands; err=Max[Abs[Flatten[sys.commands-target]]];
 f=(w.Flatten[#]& /@ case["AppliedStationForces_N"]);
 force=({#[[1]],-#[[6]]/r,#[[5]]/r}& /@ f);
 rmax=Max[Norm[(moment.op-IdentityMatrix[3]).#]/Max[1.,Norm[#]]& /@ force];
 pcoef=commands.#& /@ force;
 press=Max[Abs[Flatten[(membership.(#/Sqrt[zweight]))/aa& /@ pcoef]]];
 (* Generalized forces from zone quantization only, with rigid components
    removed. Analytic oscillator update, linear interpolation in time. *)
 x=(nonRigid /@ Transpose[op]).shapes; If[!MatrixQ[x,NumberQ]||Dimensions[x]=!={3,Length[modes]},Print["Invalid modal projection"];Exit[4]];
 f=(#/modalMass& /@ (force.x)); tt=case["LoadTimes_s"];u=0. modalMass;v=u;
 Do[dt=tt[[i+1]]-tt[[i]];du=f[[i+1]]-f[[i]];
 With[{q=omega dt,old=u},
 u=Cos[q] u+dt Sinc[q] v+dt^2 ((.5-q^2/24) f[[i]]+(1./6-q^2/120) du);
 v=-omega Sin[q] old+Cos[q] v+dt (Sinc[q] f[[i]]+(.5-q^2/24) du)];
 umax=Max[umax,Max[Abs[shapes.u]]],{i,Length[tt]-1}];
 <|"RequestedZones"->nr na,"OccupiedZones"->Length[groups],"TargetModeCount"->Length[use],"ConstraintOperatorResidual"->err,"PeakPressureAdjustment_Pa"->press,
 "RelativeWrenchResidual"->rmax,"PeakDeflectionFromZoneQuantization_m"->umax|>];
out=<|"Pole"->p,"Cases"->Table[<|"CMEExcessFractionError"->h["CMEExcessFractionError"],
 "ZoneScreens"->(screen[h,Sequence@@#]& /@ {{12,32}})|>,{h,track["Cases"]}],
 "Scope"->"One-way replay, finite-zone pressure with modal allocation and held-out higher modes only. Previous station histories are targets. Neither thermal recoil, residual ICARUS, real zone lag, feedback, nor rim compliance is included."|>;
Put[out,"77_"<>p<>".wl"];Print[out];




