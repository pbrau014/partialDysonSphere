<|"Pole" -> "Pole2", "Cases" -> 
  {<|"BayWidth_m" -> 0.25, "WebGauge_um" -> 0.25, "Junction_mg" -> 0.5, 
    "RibsAndSharedJunctions_kg" -> 2.4144070616936273*^13, 
    "BudgetFraction" -> 0.7388238667439939|>, <|"BayWidth_m" -> 0.35, 
    "WebGauge_um" -> 0.25, "Junction_mg" -> 1., 
    "RibsAndSharedJunctions_kg" -> 2.847501218970496*^13, 
    "BudgetFraction" -> 0.8713534244230839|>, <|"BayWidth_m" -> 0.4, 
    "WebGauge_um" -> 0.25, "Junction_mg" -> 2., 
    "RibsAndSharedJunctions_kg" -> 3.314468364030879*^13, 
    "BudgetFraction" -> 1.0142483310979777|>, <|"BayWidth_m" -> 0.4, 
    "WebGauge_um" -> 0.5, "Junction_mg" -> 0.5, 
    "RibsAndSharedJunctions_kg" -> 2.9573484835185582*^13, 
    "BudgetFraction" -> 0.9049673837393394|>, <|"BayWidth_m" -> 0.4, 
    "WebGauge_um" -> 0.5, "Junction_mg" -> 1., "RibsAndSharedJunctions_kg" -> 
     3.147414246085127*^13, "BudgetFraction" -> 0.9631287119855277|>, 
   <|"BayWidth_m" -> 0.5, "WebGauge_um" -> 0.5, "Junction_mg" -> 2., 
    "RibsAndSharedJunctions_kg" -> 3.4100011840778453*^13, 
    "BudgetFraction" -> 1.043481979652065|>, <|"BayWidth_m" -> 0.5, 
    "WebGauge_um" -> 1., "Junction_mg" -> 0.5, "RibsAndSharedJunctions_kg" -> 
     4.5185714762916625*^13, "BudgetFraction" -> 1.3827115167278898|>, 
   <|"BayWidth_m" -> 0.5, "WebGauge_um" -> 1., "Junction_mg" -> 1., 
    "RibsAndSharedJunctions_kg" -> 4.640213564334267*^13, 
    "BudgetFraction" -> 1.4199347668054507|>, <|"BayWidth_m" -> 0.5, 
    "WebGauge_um" -> 1., "Junction_mg" -> 2., "RibsAndSharedJunctions_kg" -> 
     4.883497740419476*^13, "BudgetFraction" -> 1.4943812669605718|>, 
   <|"BayWidth_m" -> 0.5, "WebGauge_um" -> 2., "Junction_mg" -> 0.5, 
    "RibsAndSharedJunctions_kg" -> 7.101338947905738*^13, 
    "BudgetFraction" -> 2.1730547362096835|>, <|"BayWidth_m" -> 0.5, 
    "WebGauge_um" -> 2., "Junction_mg" -> 1., "RibsAndSharedJunctions_kg" -> 
     7.222981035948342*^13, "BudgetFraction" -> 2.2102779862872444|>, 
   <|"BayWidth_m" -> 0.5, "WebGauge_um" -> 2., "Junction_mg" -> 2., 
    "RibsAndSharedJunctions_kg" -> 7.46626521203355*^13, 
    "BudgetFraction" -> 2.2847244864423657|>}, 
 "Scope" -> "Trial minimum gauge and one shared junction per bay. Ribs \
retuned for each case. No bond, optical metrology, thermal margin, cap local \
buckling or global shape verification."|>
