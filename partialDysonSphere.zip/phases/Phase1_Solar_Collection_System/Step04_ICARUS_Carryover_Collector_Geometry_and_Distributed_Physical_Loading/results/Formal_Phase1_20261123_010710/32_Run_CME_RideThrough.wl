(* Phase 1 Step 4: nominal CME ride-through, independently per pole. *)
p=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
n=Get["29_"<>p<>"_Moving_Reference.wl"];
grid=n["ForceGrid_N"]; r0=grid[[1,1]]; m=n["Mass_kg"]; end=604800.;
on=86400./end; off=235200./end;
f=Interpolation[({#[[1]]/r0,#[[2]] (#[[1]]/r0)^2}& /@ grid),InterpolationOrder->3];
wind=1259*2.0144675601821415*^10;
segment[lo_,hi_,x0_,v0_,extra_]:=NDSolveValue[
 {x''[t]==end^2 (f[x[t]]+extra)/(m r0 x[t]^2),x[lo]==x0,x'[lo]==v0},
 x,{t,lo,hi},AccuracyGoal->10,PrecisionGoal->10];
a=segment[0.,on,1.,0.,0.];
b=segment[on,off,a[on],a'[on],wind];
c=segment[off,1.,b[off],b'[off],0.];
If[!AllTrue[{a,b,c},MatchQ[#,_InterpolatingFunction]&],Exit[3]];
If[c[1.]>grid[[-1,1]]/r0,Exit[4]];
out=<|"Pole"->p,"Day7Distance_AU"->.2 c[1.],
 "Day7Speed_m_s"->r0 c'[1.]/end,"Day7Irradiance_W_m2"->34029.16163521439/c[1.]^2,
 "AtCMEEndDistance_AU"->.2 b[off],"AtCMEEndSpeed_m_s"->r0 b'[off]/end,
 "Segments"->{a,b,c},"SegmentBoundaries_s"->{0,86400,235200,604800},
 "Scope"->"Radial face-on nominal reference with configured rectangular CME only. No control or structural dynamics."|>;
Put[out,"32_"<>p<>"_CME_RideThrough.wl"];Print[KeyDrop[out,{"Segments"}]];
