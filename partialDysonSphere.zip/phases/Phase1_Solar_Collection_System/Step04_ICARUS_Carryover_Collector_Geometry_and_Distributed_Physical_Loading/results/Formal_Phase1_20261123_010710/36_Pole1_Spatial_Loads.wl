<|"Pole" -> "Pole1", "Cases" -> {<|"CMEExcessFractionError" -> 0., 
    "SampleCount" -> 1009, "PeakNormalTangentialResultant_Pa" -> 
     {0.0001383208871784154, 0.000012823772751221604, 
      0.00013891406328158033}|>, <|"CMEExcessFractionError" -> 0.0001, 
    "SampleCount" -> 1009, "PeakNormalTangentialResultant_Pa" -> 
     {0.0001383208871784154, 0.000012823772751221604, 
      0.00013891406328158033}|>}, "Scope" -> "Coarse nominal incidence CME \
plus station force in uniform-mass translating frame. Excludes lateral CME \
pressure distribution, base radiation/gravity, angular inertia, elastic \
response."|>
