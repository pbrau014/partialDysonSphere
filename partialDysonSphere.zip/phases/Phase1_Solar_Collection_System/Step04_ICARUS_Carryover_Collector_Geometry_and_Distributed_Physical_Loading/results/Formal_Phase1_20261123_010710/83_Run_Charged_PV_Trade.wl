(* Phase 1 Step 4: derated nominal optical candidate plus two-state mass checks. *)
src=Environment["POLAR_ACCEPT_SOURCE"]; If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"]; If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
d=Get["01_Reference_Architecture.wl"]; sh=Get["61_"<>pole<>".wl"]["LoadedSharedInputs"];
op=Phase1SetPoleOperatingInputs[pole,d["PoleOperatingInputs"]]; If[FailureQ[op],Print[op];Exit[2]];
area=N[4 Pi 695700000^2/10];
rib=SelectFirst[Get["82_"<>pole<>".wl"]["Cases"],Abs[#["WebGauge_um"]-1.]<10^-6&&Abs[#["Junction_mg"]-1.]<10^-6&];
opt=Get["69_"<>pole<>".wl"]["OpticalAddedMassAllocation_kg"];
rim=Get["71_"<>pole<>".wl"]["StrengthOnlyRimMass_kg"];
grid=rib["RibsAndSharedJunctions_kg"];
margin=.20 grid;
fixed=opt+rim+grid+margin;
eval[f_,x_]:=Module[{set,n},
 set=Phase1SetInputs[Join[sh,<|"PVFraction"->f,"ReflectorSolarReflectivity"->.98,
 "ReflectorSolarTransmissivity"->.019,
 "OtherInstalledArealMass_kg_m2"->(((1.526698109072746*^14 .2705+4.694880877436852*^13/4) f/.006+fixed+x)/area)|>]];
 If[FailureQ[set],Print[set];Exit[2]];
 n=Phase1RunPoleTask[pole,"NaturalEquilibrium"]; If[!AssociationQ[n],Print[n];Exit[2]];
 n=Lookup[n,"Result",n]; Lookup[n,"NaturalEquilibrium",n]];
crit[n_]:=n["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"]-.1 n["CurrentPoleMass_kg"];
low=eval[.005,0.];high=eval[.03,0.];
f=.005-.025 crit[low]/(crit[high]-crit[low]); If[!TrueQ[.005<=f<=.03],Exit[4]];
(* Slight numerical margin inside the reserve boundary. *)
f=f-10^-7;b=eval[f,0.]; key="NetNaturalRadialForce_N";
m0=b["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"]; n=eval[f,m0];
mass=m0+m0 n[key]/(b[key]-n[key]); c=eval[f,mass];
out=<|"Pole"->pole,"PV_pct"->100 f,"ConditionalPower_W"->(3.385264858155934*^18 f/.006),
 "NominalReflectivity"->.98,"TrialBay_m"->rib["BayWidth_m"],"FixedArchitectureCharge_kg"->fixed,"OpticsAllocation_kg"->opt,"RimStrengthOnly_kg"->rim,"RibsAndJunctions_kg"->grid,"TrialInterfaceContingency_kg"->margin,"PreLoadMass_kg"->b["CurrentPoleMass_kg"],
 "PreLoadReserveRatio"->b["FutureAddedMassCapacityToCurrentMassRatio"],
 "PreLoadReservePass"->b["FutureMassGrowthTargetPass"],
 "PreLoadOutwardBiasPass"->b["OutwardRadialBiasPass"],
 "LaterUniformHardwareMassToBalance_kg"->mass,"LoadedMass_kg"->c["CurrentPoleMass_kg"],
 "LoadedRadialResidual_N"->c[key],"ExactNaturalEquilibrium"->c["ExactNaturalEquilibrium"],
 "Scope"->"Native static planning ledger: collector optics, strength-only rim, trial grid with 1 micron minimum webs and 1 mg junctions plus 20 percent grid contingency are charged before future reserve. These are unverified trial masses. No coupled performance or power qualification."|>;
Put[out,"83_"<>pole<>".wl"];Print[out];
If[!TrueQ[out["PreLoadReservePass"]&&out["PreLoadOutwardBiasPass"]&&out["ExactNaturalEquilibrium"]],Exit[1]];

