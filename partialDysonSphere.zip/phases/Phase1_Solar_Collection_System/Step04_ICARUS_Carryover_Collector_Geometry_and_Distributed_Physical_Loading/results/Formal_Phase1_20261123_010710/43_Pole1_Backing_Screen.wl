<|"Pole" -> "Pole1", "Scope" -> "Uniform backing; perfectly aligned tension \
and full load transfer; illustrative factor two on ultimate. No load sharing, \
compression, bonding, radiation, thermal or shell qualification.", 
 "ReservePreservingAddedMassCeiling_kg" -> 4.1202874984412*^13, 
 "Rows" -> {{"Toray T1100G carbon fiber", 3.9106145251396643*^6, 
    1.3082035122859686*^-7, 1.424236831031248*^14, 7.134947326316594*^13}, 
   {"Toyobo Zylon AS PBO fiber", 3.7662337662337665*^6, 
    1.5788663079313415*^-7, 1.4788357771640203*^14, 7.408469676140714*^13}, 
   {"Kuraray Vectran HT yarn", 2.43*^6, 2.691776774250964*^-7, 
    2.292033431551311*^14, 1.1482316317037075*^14}, 
   {"DuPont Kapton HN film at 23 C", 162676.05633802817, 
    3.964253067533238*^-6, 3.4237621467146985*^15, 1.715189639981304*^15}}, 
 "Columns" -> {"Material", "UltimateSpecificStrength_m2_s2", 
   "PassiveEquivalentThickness_m", "PassiveUniformBackingMass_kg", 
   "IdealTrimUniformBackingMass_kg"}|>
