<|"Pole" -> "Pole1", "RingRadius_m" -> 4.378156807345184*^8, 
 "RimSpeed_m_s" -> 4548.407824808127, "MinAllowableSpecificStrength_m2_s2" -> 
  2.0688013740775798*^7, "AluminumAllowableSpecificStrength_m2_s2" -> 
  5175.600739371534, "IdealAluminumRingSelfStress_Pa" -> 
  5.596107716879853*^10, "IdealMinimumAluminumRingPeriod_days" -> 
  442.5649896803799, "Scope" -> "Uniform self-supporting tension-only ring in \
free spin; excludes all sheet forces, gravity, propulsion and alternate load \
paths."|>
