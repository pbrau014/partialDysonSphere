(* Phase 1 Step 4: independent checkpoint of the native wobble acceptance gate. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
p=Environment["POLAR_ACCEPT_POLE"];
d=Get["01_Reference_Architecture.wl"];
If[AnyTrue[{Phase1SetInputs[d["SharedNativeInputs"]],
 Phase1SetPoleOperatingInputs[p,d["PoleOperatingInputs"]]},FailureQ],Exit[1]];
w=Phase1RunPoleTask[p,"Wobble"];
Put[<|"Pole"->p,"SourceHash"->FileHash[src,"SHA256","HexString"],"Result"->w|>,
 "08_"<>p<>"_Wobble.wl"];
Print[{p,If[AssociationQ[w],KeyTake[w,{"SolverSucceeded","TrajectoryIntegrityPass",
 "AlignedReferenceTransverseStabilityPass","AttitudeWithinTolerance","AngularRateWithinTolerance"}],w]}];
If[!AssociationQ[w],Exit[1]];
