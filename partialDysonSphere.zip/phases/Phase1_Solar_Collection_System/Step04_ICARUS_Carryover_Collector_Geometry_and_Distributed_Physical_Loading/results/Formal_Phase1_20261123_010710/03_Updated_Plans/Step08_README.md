# Step 8 - Complete Integrated Rotation, Control, Disturbance, and Operating Behavior

**Roadmap position:** Not started; sequencing remains governed by the roadmap and prior-step acceptance.

Keep step-specific inputs, source, scripts, reports, tests, and results in the corresponding folders. Do not use this folder structure as authorization to begin a blocked step.

## Current recalculation plan

Update control allocation, saturation, disturbances and recovery using the integrated installed design in separate pole runs.
