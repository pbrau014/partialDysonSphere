# Step 7 - Complete Photovoltaic Collection and Electrical Production

**Roadmap position:** Not started; sequencing remains governed by the roadmap and prior-step acceptance.

Keep step-specific inputs, source, scripts, reports, tests, and results in the corresponding folders. Do not use this folder structure as authorization to begin a blocked step.

## Current recalculation plan

Use 0.6% coverage and the distributed 100 kV, 1 km reference. Resolve cell layout, insulation, switching, wiring losses and installed mass. Retain the 1.1% alternative.
