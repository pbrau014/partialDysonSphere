# Step 6 - Complete Optical and Thermal Behavior

**Roadmap position:** Not started; sequencing remains governed by the roadmap and prior-step acceptance.

Keep step-specific inputs, source, scripts, reports, tests, and results in the corresponding folders. Do not use this folder structure as authorization to begin a blocked step.

## Current recalculation plan

Verify heat transport, radiator view, thermal equilibrium and optical momentum for the selected architecture after the Step 5 gate.
