# Step 9 - Perform Comprehensive Coupled Optimization

**Roadmap position:** Not started; sequencing remains governed by the roadmap and prior-step acceptance.

Keep step-specific inputs, source, scripts, reports, tests, and results in the corresponding folders. Do not use this folder structure as authorization to begin a blocked step.

## Current recalculation plan

Keep all 28 coverage variants per pole in the trade baseline. Optimize usable power within the coupled mass, thermal, structural and control limits.
