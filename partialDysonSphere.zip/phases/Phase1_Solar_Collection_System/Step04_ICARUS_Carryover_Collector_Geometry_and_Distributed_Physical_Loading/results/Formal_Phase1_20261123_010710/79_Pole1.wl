<|"Pole" -> "Pole1", "Rows" -> 
  {<|"Bay_m" -> 0.5, "AssumedEdgeMotionLimit_m" -> 0.000012793936002842126, 
    "RequiredEI_Nm2" -> 0.0013345121958768596, "CapSeparation_m" -> 
     0.004223151592919845, "TwoCapArea_m2" -> 2.9930170883211304*^-9, 
    "EachWebThickness_m" -> 5.348290578003734*^-7, 
    "TrialRibLinearMass_kg_m" -> 0.000012016552740960102, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 0.000013432464896487268, 
    "MassFraction" -> 0.8945902954939087, "TwoFaceSlopeAmplification_mrad" -> 
     1.9370375544768212|>, <|"Bay_m" -> 1., "AssumedEdgeMotionLimit_m" -> 
     0.000051464979484022814, "RequiredEI_Nm2" -> 0.010616097424066065, 
    "CapSeparation_m" -> 0.006849149896074852, "TwoCapArea_m2" -> 
     9.05214589052113*^-9, "EachWebThickness_m" -> 9.974741708977743*^-7, 
    "TrialRibLinearMass_kg_m" -> 0.000036345353789447694, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 0.000026864929792974536, 
    "MassFraction" -> 1.352892193262027, "TwoFaceSlopeAmplification_mrad" -> 
     4.075667677902126|>, <|"Bay_m" -> 5., "AssumedEdgeMotionLimit_m" -> 
     0.0012218904362693943, "RequiredEI_Nm2" -> 1.3973154320766425, 
    "CapSeparation_m" -> 0.02141098617245877, "TwoCapArea_m2" -> 
     1.2192172673207923*^-7, "EachWebThickness_m" -> 4.2646329839650624*^-6, 
    "TrialRibLinearMass_kg_m" -> 0.0004872667558922469, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 0.00013432464896487265, 
    "MassFraction" -> 3.627530461811759, "TwoFaceSlopeAmplification_mrad" -> 
     19.31221686398191|>, <|"Bay_m" -> 10., "AssumedEdgeMotionLimit_m" -> 
     0.004598285304434519, "RequiredEI_Nm2" -> 11.88176026404992, 
    "CapSeparation_m" -> 0.0353972892192069, "TwoCapArea_m2" -> 
     3.793156558456556*^-7, "EachWebThickness_m" -> 8.004719224587664*^-6, 
    "TrialRibLinearMass_kg_m" -> 0.0015136102061891294, 
    "AvailableLinearMassIfAllSpent_kg_m" -> 0.0002686492979297453, 
    "MassFraction" -> 5.634149122492607, "TwoFaceSlopeAmplification_mrad" -> 
     36.4550726941923|>}, "Scope" -> "Ideal equivalent material assumptions, \
service deflection and web shear-buckling screen. No bonded load transfer, \
cap local buckling, joint rigidity, minimum ply or film gauge, mass of \
sensors, whole-rim compatibility, transient rib dynamics. No installed pass."\
|>
