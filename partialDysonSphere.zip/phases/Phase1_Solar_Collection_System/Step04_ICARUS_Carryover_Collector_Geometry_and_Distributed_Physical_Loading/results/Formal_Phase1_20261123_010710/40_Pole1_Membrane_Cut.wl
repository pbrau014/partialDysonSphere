<|"Pole" -> "Pole1", "CMEPressureAtOnset_Pa" -> 0.00004196023573477997, 
 "ApexMeridionalIncrementMagnitude_N_m" -> 459.271229300089, 
 "LegacyAllowablePretension_N_m" -> 1.4, 
 "EquivalentSectionThicknessAt14MPa_m" -> 0.00003280508780714921, 
 "Scope" -> "Axisymmetric, unchanged cap, uniform surface mass, momentum load \
from CME only, membrane-only force balance. No bending/edge flexibility or \
combined stress. This diagnostic does not describe a reinforced shell."|>
