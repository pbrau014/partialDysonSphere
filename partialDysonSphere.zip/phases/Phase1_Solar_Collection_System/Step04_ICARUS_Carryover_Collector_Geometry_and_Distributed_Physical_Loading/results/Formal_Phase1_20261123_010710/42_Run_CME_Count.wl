(* Phase 1 Step 4: ideal radial CME station-count sizing. *)
p=Environment["POLAR_ACCEPT_POLE"];
e=Get["30_"<>p<>"_Moving_Envelope.wl"];
d=Get["21_Step4_Candidate_Inputs.wl"];
f=1259 2.0144675601821415*^10 (.2/First[e["RequiredDistanceRangeWithTube_AU"]])^2;
cap=d["TrialStationCap_N"]; a=e["AdditionalRadialWrenchAuthority_N"];
counts=Table[{margin,4+Ceiling[((1+margin) f-a)/cap]},{margin,{0,.1,.2}}];
o=<|"Pole"->p,"BaselineUnits"->55,"IdealRadialDemand_N"->f,
 "BaselineAvailableRadialForce_N"->51 cap+a,"BaselineHeadroomFraction"->(51 cap+a)/f-1,
 "MarginFractionAndTotalUnits"->counts,"TwentyPercentWithOneRadialOutage"->Last[Last[counts]]+1|>;
Put[o,"42_"<>p<>"_CME_Count.wl"];Print[o];
