<|"Pole" -> "Pole2", "Columns" -> {"Depth_km", "MeanSumCompression_N_m", 
   "IdealBypassMass_kg", "BudgetAfterHoop_kg", "MassRatio", 
   "RequiredCompressionReductionFraction"}, 
 "Rows" -> {{100., 0.6993375958767255, 1.3611021665462373*^12, 
    3.879498896329099*^11, 3.5084483922244547, 0.7149737182350366}, 
   {250., 1.7483439891593602, 3.402755415329293*^12, 1.1976890481556378*^11, 
    28.41100885550646, 0.9648023762519019}}, "Scope" -> "Independent local \
axial minima with zero tensile margin. Trial compression allowable 0.5 GPa, \
density 1600. No buckling, compatibility, thermal stress, or connections."|>
