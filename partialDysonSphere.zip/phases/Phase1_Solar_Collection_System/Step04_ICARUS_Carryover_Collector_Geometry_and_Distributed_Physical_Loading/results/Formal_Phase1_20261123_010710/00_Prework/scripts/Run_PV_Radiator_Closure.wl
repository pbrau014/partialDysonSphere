(* Phase 1 Steps 5-9: radiator sizing and mass feedback screening. *)
pole=Environment["POLAR_COVERAGE_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
dir=FileNameJoin[{DirectoryName[DirectoryName[$InputFileName]],"results"}];
data=Import[FileNameJoin[{dir,pole<>"_PV_Three_Pass_Phase1.csv"}],"CSV"];
base=AssociationThread[First[data],#]& /@ Rest[data];
a=4 Pi 695700000^2/10;
flux=.85 5.670374419*^-8 343.15^4;
g=.14844541395623445;
cases=Flatten[Table[Module[{area,dm,margin,ratio},
 area=row["RequiredAdditionalCooling_W"]/(flux view);
 dm=area density;
 margin=row["Signed_Added_Mass_Margin_kg"];
 ratio=1+dm/row["Assembly_Mass_kg"];
 {pole,row["PV_Coverage_pct"],view,density,area,area/a,dm,margin/area,
  g (margin-dm),ratio row["Spin_Inertia_kg_m2"],
  ratio row["Rim_24h_N_m"],ratio row["Rim_54p2h_N_m"],ratio row["Rim_168h_N_m"],
  margin>=dm,row["ConditionalConditionedPower_W"]}
 ],{row,base},{view,{.5,1.}},{density,{.0002705,.001,.01}}],2];
If[Length[cases]!=168 || Min[cases[[All,5]]]<=0,Exit[1]];
Export[FileNameJoin[{dir,pole<>"_PV_Radiator_Closure.csv"}],Prepend[cases,
 {"Pole","PV_pct","Effective_View_Fraction","Trial_kg_Per_Emitting_m2",
 "Required_Emitting_Area_m2","Emitting_Area_to_Sheet_Area","Added_Radiator_kg",
 "Max_Radiator_kg_Per_Emitting_m2","Remaining_Radial_Force_N","Updated_Spin_Inertia_kg_m2",
 "Rim_24h_N_m","Rim_54p2h_N_m","Rim_168h_N_m","Radial_Mass_Screen_Pass",
 "Conditional_Conditioned_Power_W"}],"CSV"];
Print[{pole,Length[cases],Count[cases[[All,14]],True],
 TakeLargestBy[Select[cases,TrueQ[#[[14]]]&],Last,1],
 First[cases]}];
