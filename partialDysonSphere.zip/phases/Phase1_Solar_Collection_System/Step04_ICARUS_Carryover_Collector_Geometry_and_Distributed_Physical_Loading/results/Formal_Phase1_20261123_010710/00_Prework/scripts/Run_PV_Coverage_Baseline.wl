(* Phase 1 Step 4: fixed-cap PV coverage baseline. Run once per pole. *)
pole = Environment["POLAR_COVERAGE_POLE"];
If[!MemberQ[{"Pole1", "Pole2"}, pole], Exit[2]];
area = N[4 Pi 695700000^2/10];
irradiance = 34029.16163521439;
gravity = 0.14844541395623445;
wind = 2.0144675601821796*^10;
cosRim = (1 - .1^2)/(1 + .1^2);
pvArea[f_] := area f;
pvMass[f_] := .052 pvArea[f];
mass[f_] := .0003705 area + pvMass[f];
radiation[f_] := irradiance area/299792458 (
  (.001 + .899 f) (1 + cosRim)/2 +
  2 (.999 - .949 f) (1 + cosRim + cosRim^2 + cosRim^3)/4);
net[f_] := radiation[f] + wind - gravity mass[f];
grossPower[f_] := 730 pvMass[f] irradiance/(1000*1.01);
balance = f /. First[Solve[net[f] == 0, f]];
halfMargin = f /. First[Solve[net[f] == net[.005]/2, f]];
coverages = Sort[Join[N[Range[5, 30]/1000], {halfMargin, balance}]];
rows = Table[With[{scale = mass[f]/mass[.005]},
  Join[{pole, 100 f, pvArea[f], pvMass[f], mass[f], radiation[f], wind,
    gravity mass[f], net[f], net[f]/gravity, irradiance pvArea[f]/1.01,
    grossPower[f], scale 3.687540774076244*^31},
    scale {161770.3704401983, 31597.130840631717, 3152.6341342535487}]],
  {f, coverages}];
checks = {Length[rows] == 28, First[coverages] == .005, Last[coverages] == .03,
  And @@ Thread[Differences[net /@ coverages] < 0],
  And @@ Thread[Differences[grossPower /@ coverages] > 0],
  Abs[net[balance]] < 1, Abs[net[halfMargin] - net[.005]/2] < 1,
  Abs[net[.005]/(7.672784558563338*^13) - 1] < 10^-12};
If[!And @@ checks, Print[checks]; Exit[1]];
path = FileNameJoin[{DirectoryName[DirectoryName[$InputFileName]], "results",
  pole <> "_PV_Coverage_Baseline.csv"}];
Export[path, Prepend[rows, {"Pole", "PV_Coverage_pct", "PV_Curved_Area_m2",
  "PV_Mass_kg", "Assembly_Mass_kg", "Radiation_N", "Wind_N", "Gravity_Inward_N",
  "Net_Outward_N", "Signed_Added_Mass_Margin_kg", "PV_Incident_W", "PV_Gross_Reference_W",
  "Spin_Inertia_kg_m2", "Rim_24h_N_m", "Rim_54p2h_N_m", "Rim_168h_N_m"}], "CSV"];
Print[{pole, checks, rows[[{1, 7, 10, 28}]], 100 halfMargin, 100 balance}];

