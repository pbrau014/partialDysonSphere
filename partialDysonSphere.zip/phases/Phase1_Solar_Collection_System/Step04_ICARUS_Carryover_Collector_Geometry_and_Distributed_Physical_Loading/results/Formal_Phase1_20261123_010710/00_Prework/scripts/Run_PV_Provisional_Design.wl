(* Phase 1: provisional installed design requirements, independently per pole. *)
pole=Environment["POLAR_COVERAGE_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
dir=FileNameJoin[{DirectoryName[DirectoryName[$InputFileName]],"results"}];
data=Import[FileNameJoin[{dir,pole<>"_PV_Three_Pass_Phase1.csv"}],"CSV"];
base=AssociationThread[First[data],#]& /@ Rest[data];
radius=437815680.73451835;
emit=.85 5.670374419*^-8 343.15^4;
(* Trials: shaded radiator view 0.5 or 1; installed density includes panels,
   mounts and heat transport as a mass target, not a qualified design.
   Copper two-wire local branch, one-way length L, 1% resistive loss.
   Uniform added mass for rim load scaling. *)
rows=Flatten[Table[Module[{m0,allow,q,p,mr,mw,incr,radial,force,torque},
 m0=row["Assembly_Mass_kg"]; allow=row["Signed_Added_Mass_Margin_kg"];
 q=row["RequiredAdditionalCooling_W"]; p=row["PVGrossIfHeldAtLimit_W"];
 mr=q density/(emit view);
 mw=8960 1.72*^-8 (2 length)^2 p/(.01 voltage^2);
 incr=mr+mw;
 radial=allow-incr;
 force=1000 row["Rim_54p2h_N_m"] (1+incr/m0);
 torque=row["TorqueMagnitudeAt1deg_Nm"];
 {pole,row["PV_Coverage_pct"],view,density,length,voltage,mr,mw,radial,
  TrueQ[allow>0 && radial>=allow/2],force,force/(14*^6),torque/(2 radius),
  .99 row["ConditionalConditionedPower_W"]}
 ],{row,base},{view,{.5,1.}},{density,{.0002705,.001,.01}},
   {length,{1000,10000}},{voltage,{10000,100000}}],4];
If[Dimensions[rows]=!={672,14},Print[Dimensions[rows]];Exit[1]];
Export[FileNameJoin[{dir,pole<>"_PV_Provisional_Design.csv"}],Prepend[rows,
 {"Pole","PV_pct","RadiatorView","TrialInstalledCoolingDensity_kg_m2",
  "BranchLength_m","BusVoltage_V","CoolingMass_kg","BranchCopperMass_kg",
  "RemainingRadialMass_kg","RetainsHalfPreCoolingMargin","RadialLoadPer1kmRim_N",
  "IdealAluminumAttachmentSectionAt14MPa_m2","OneDegreeCoupleForceEachSide_N",
  "ConditionalElectricalOutput_W"}],"CSV"];
pass=Select[rows,TrueQ[#[[10]]]&];
Print[{pole,Length[rows],Length[pass],If[pass==={},{},First@TakeLargestBy[pass,Last,1]],
 Count[Select[rows,#[[9]]>=0&][[All,9]],_?NumericQ]}];
