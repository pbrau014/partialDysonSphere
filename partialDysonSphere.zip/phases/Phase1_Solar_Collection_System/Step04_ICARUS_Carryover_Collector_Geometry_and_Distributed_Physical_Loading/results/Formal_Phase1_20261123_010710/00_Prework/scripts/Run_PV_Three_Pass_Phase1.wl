(* Phase 1, Steps 1-10: chained screens on the fixed-cap PV coverage baseline. *)
pole = Environment["POLAR_COVERAGE_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
dir = FileNameJoin[{DirectoryName[DirectoryName[$InputFileName]],"results"}];
source = Import[FileNameJoin[{dir,pole<>"_PV_Coverage_Baseline.csv"}],"CSV"];
baseline = AssociationThread[First[source],#]& /@ Rest[source];
radius = 437815680.73451835; depth = radius/10;
distance = 29919574140; mu = 1.3271244*^20;
sigmaSB = 5.670374419*^-8;
periods = 3600 {24,54.2,168};

(* Pass 1: rigid trial cap, gravity-gradient torque scale and axial momentum. *)
mechanical = Map[Function[row,Module[{m,iz,ix},
  m=row["Assembly_Mass_kg"]; iz=row["Spin_Inertia_kg_m2"];
  ix=iz/2+m depth^2/12;
  Join[row,<|"TransverseInertia_kg_m2"->ix,
    "NetAcceleration_m_s2"->row["Net_Outward_N"]/m,
    "TorqueSlopeMagnitude_Nm_per_rad"->3 mu Abs[iz-ix]/distance^3,
    "TorqueMagnitudeAt1deg_Nm"->3 mu Abs[iz-ix]/distance^3 Sin[Degree] Cos[Degree],
    "AngularMomentum24h_Nms"->iz 2 Pi/periods[[1]],
    "AngularMomentum54p2h_Nms"->iz 2 Pi/periods[[2]],
    "AngularMomentum168h_Nms"->iz 2 Pi/periods[[3]]|>]
]],baseline];

(* Pass 2: isolated PV radiation screen with one or two emitting faces;
   structural rim attachment load is radial line load times trial pitch. *)
screened = Map[Function[row,Module[{inc,ref,tlim=343.15,eta,heat,t},
  inc=row["PV_Incident_W"]/row["PV_Curved_Area_m2"];
  ref=row["PV_Gross_Reference_W"]/row["PV_Curved_Area_m2"];
  eta=Max[0,1-.004(tlim-298.15)];
  heat=.9 inc-ref eta;
  t=Table[x /. FindRoot[.9 inc-ref Clip[1-.004(x-298.15),{0,1}]
       == faces .85 sigmaSB x^4,{x,750.}],{faces,{1,2}}];
  Join[row,<|"PVOneFaceTemperature_K"->t[[1]],"PVTwoFaceTemperature_K"->t[[2]],
    "PVTemperatureScreenPass"->(Min[t]<=tlim),
    "PVTwoFaceAdditionalCoolingAtLimit_W_m2"->Max[0,heat-2 .85 sigmaSB tlim^4],
    "PVGrossIfHeldAtLimit_W"->eta row["PV_Gross_Reference_W"],
    "Rim54p2hPer1km_N"->1000 row["Rim_54p2h_N_m"],
    "Rim54p2hPer10km_N"->10000 row["Rim_54p2h_N_m"]|>]
]],mechanical];

(* Pass 3: conditional electrical ledger and radial margin versus added cooling mass. *)
closed = Map[Function[row,Module[{cool,margin},
  cool=row["PVTwoFaceAdditionalCoolingAtLimit_W_m2"] row["PV_Curved_Area_m2"];
  margin=row["Signed_Added_Mass_Margin_kg"];
  Join[row,<|"RequiredAdditionalCooling_W"->cool,
    "ConditionalConditionedPower_W"->.95^2 row["PVGrossIfHeldAtLimit_W"],
    "CoolingMassAllowancePerPVArea_kg_m2"->margin/row["PV_Curved_Area_m2"],
    "RequiredCoolingSpecificDuty_W_kg"->If[margin>1,cool/margin,"NoPositiveMassMargin"],
    "CoupledScreenPass"->(TrueQ[row["PVTemperatureScreenPass"]] && margin>=-1)|>]
]],screened];

checks={Length[closed]==28,And@@(FiniteQ /@ Lookup[closed,"PVTwoFaceTemperature_K"]),
 And@@Thread[Lookup[closed,"PVOneFaceTemperature_K"]>Lookup[closed,"PVTwoFaceTemperature_K"]],
 And@@Thread[Differences[Lookup[closed,"RequiredAdditionalCooling_W"]]>0]};
checks=checks /. FiniteQ[x_]:> (NumberQ[x] && Abs[x]<Infinity);
If[!TrueQ[And@@checks],Print[checks];Exit[1]];
out=Export[FileNameJoin[{dir,pole<>"_PV_Three_Pass_Phase1.csv"}],
  Prepend[Values /@ closed,Keys[First[closed]]],"CSV"];
Print[{pole,checks,out}];
Print[Values /@ (KeyTake[#,{"PV_Coverage_pct","PVTwoFaceTemperature_K",
 "RequiredAdditionalCooling_W","ConditionalConditionedPower_W",
 "TorqueMagnitudeAt1deg_Nm","RequiredCoolingSpecificDuty_W_kg"}]& /@
 closed[[{1,10,19,28}]] )];
