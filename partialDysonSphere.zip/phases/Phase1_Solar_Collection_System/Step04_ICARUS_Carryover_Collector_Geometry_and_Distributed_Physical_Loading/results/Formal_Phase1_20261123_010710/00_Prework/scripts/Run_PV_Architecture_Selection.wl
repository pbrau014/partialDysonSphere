(* Phase 1: compare distributed and longer-route electrical architectures. *)
pole=Environment["POLAR_COVERAGE_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
dir=FileNameJoin[{DirectoryName[DirectoryName[$InputFileName]],"results"}];
data=Import[FileNameJoin[{dir,pole<>"_PV_Three_Pass_Phase1.csv"}],"CSV"];
base=AssociationThread[First[data],#]& /@ Rest[data];
emit=.85 5.670374419*^-8 343.15^4;
copper[p_,l_,v_]:=8960 1.72*^-8 (2 l)^2 p/(.01 v^2);
architectures={{"Distributed",1000,100000},{"LongRoute",10000,1000000}};
rows=Flatten[Table[Module[{name,l,v,p,q,mc,mb,margin,left,m0},
 {name,l,v}=arch;p=row["PVGrossIfHeldAtLimit_W"];
 q=row["RequiredAdditionalCooling_W"]+(.01+.99*.01)p;
 mc=q density/(emit view);
 mb=copper[p,1000,100000]+copper[.99 p,l,v];
 margin=row["Signed_Added_Mass_Margin_kg"]; left=margin-mc-mb;
 m0=row["Assembly_Mass_kg"];
 {pole,name,row["PV_Coverage_pct"],view,density,l,v,mc,mb,left,
  TrueQ[margin>0&&left>=margin/2],(.99*.95)^2 p,
  row["Rim_54p2h_N_m"](1+(mc+mb)/m0),
  row["TorqueMagnitudeAt1deg_Nm"](1+(mc+mb)/m0)}
 ],{row,base},{arch,architectures},{view,{.5,1.}},{density,{.0002705,.001}}],3];
If[Dimensions[rows]=!={224,14},Exit[1]];
Export[FileNameJoin[{dir,pole<>"_PV_Architecture_Selection.csv"}],Prepend[rows,
 {"Pole","Architecture","PV_pct","EffectiveView","CoolingDensity_kg_m2","MainRoute_m",
  "MainBus_V","CoolingMass_kg","TotalCopper_kg","RemainingMass_kg","HalfMarginPass",
  "ConditionalOutput_W","Rim54p2h_N_m","GravityGradientTorque1deg_Nm"}],"CSV"];
Do[pass=Select[rows,#[[2]]==arch[[1]]&&TrueQ[#[[11]]]&];
 Print[{Length[pass],If[pass==={},{},First@TakeLargestBy[pass,#[[12]]&,1]]}];
 more=Select[pass,#[[5]]==.001&];
 Print[If[more==={},{},First@TakeLargestBy[more,#[[12]]&,1]]],{arch,architectures}];
