# Step 4 - Complete ICARUS Carryover, Collector Geometry, and Distributed Physical Loading

**Roadmap status:** Resumed, incomplete, and not accepted.  
**Active source baseline:** v11.142.

Run Pole 1 and Pole 2 assessments independently. Keep source, inputs, scripts, reports, tests, and generated results in the matching folders. See the project status note and the engineering verification report before continuing.

## PV coverage design baseline

Carry 0.5% through 3.0% of curved sheet area as the active PV design trade space for each pole. A coverage value is not selected. The fixed-cap reference sweep uses 0.1 percentage-point increments and includes the exact half-outward-margin and zero-radial-force cases. Run scripts/Run_PV_Coverage_Baseline.wl in a fresh WolframScript process for each pole, setting POLAR_COVERAGE_POLE to Pole1 or Pole2. The two result CSVs in results/ retain all 28 variants per pole.

The sweep uses the current 0.2 AU reference, fixed cap, uniformly distributed sheet assembly mass, and existing optical and PV reference inputs. The signed mass margin represents the radial force budget under fixed geometry and optics. The gross PV estimate uses linear irradiance scaling and excludes thermal derating and downstream losses. Rim loads use the equal-stiffness trial load path. Dynamic stability, thermal performance, hardware strength, attachment qualification and cell count are open. Keep inward-force cases for trade studies and revisit their balance when inputs change.
