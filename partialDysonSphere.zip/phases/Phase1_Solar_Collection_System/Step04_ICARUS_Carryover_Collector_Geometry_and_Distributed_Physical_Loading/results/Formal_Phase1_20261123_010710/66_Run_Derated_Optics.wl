(* Phase 1 Step 4: derated nominal optical candidate plus two-state mass checks. *)
src=Environment["POLAR_ACCEPT_SOURCE"]; If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"]; If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
d=Get["01_Reference_Architecture.wl"]; sh=Get["61_"<>pole<>".wl"]["LoadedSharedInputs"];
op=Phase1SetPoleOperatingInputs[pole,d["PoleOperatingInputs"]]; If[FailureQ[op],Print[op];Exit[2]];
area=N[4 Pi 695700000^2/10];
eval[f_,x_]:=Module[{set,n},
 set=Phase1SetInputs[Join[sh,<|"PVFraction"->f,"ReflectorSolarReflectivity"->.98,
 "ReflectorSolarTransmissivity"->.019,
 "OtherInstalledArealMass_kg_m2"->(((1.526698109072746*^14 .2705+4.694880877436852*^13/4) f/.006+x)/area)|>]];
 If[FailureQ[set],Print[set];Exit[2]];
 n=Phase1RunPoleTask[pole,"NaturalEquilibrium"]; If[!AssociationQ[n],Print[n];Exit[2]];
 n=Lookup[n,"Result",n]; Lookup[n,"NaturalEquilibrium",n]];
crit[n_]:=n["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"]-.1 n["CurrentPoleMass_kg"];
low=eval[.005,0.];high=eval[.03,0.];
f=.005-.025 crit[low]/(crit[high]-crit[low]); If[!TrueQ[.005<=f<=.03],Exit[4]];
(* Slight numerical margin inside the reserve boundary. *)
f=f-10^-7;b=eval[f,0.]; key="NetNaturalRadialForce_N";
m0=b["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"]; n=eval[f,m0];
mass=m0+m0 n[key]/(b[key]-n[key]); c=eval[f,mass];
out=<|"Pole"->pole,"PV_pct"->100 f,"ConditionalPower_W"->(3.385264858155934*^18 f/.006),
 "NominalReflectivity"->.98,"PreLoadMass_kg"->b["CurrentPoleMass_kg"],
 "PreLoadReserveRatio"->b["FutureAddedMassCapacityToCurrentMassRatio"],
 "PreLoadReservePass"->b["FutureMassGrowthTargetPass"],
 "PreLoadOutwardBiasPass"->b["OutwardRadialBiasPass"],
 "LaterUniformHardwareMassToBalance_kg"->mass,"LoadedMass_kg"->c["CurrentPoleMass_kg"],
 "LoadedRadialResidual_N"->c[key],"ExactNaturalEquilibrium"->c["ExactNaturalEquilibrium"],
 "Scope"->"Native static optical derating. Power is inherited conditional PV scaling. Optical hardware and allocated future mass are not installed or verified."|>;
Put[out,"66_"<>pole<>".wl"];Print[out];
If[!TrueQ[out["PreLoadReservePass"]&&out["PreLoadOutwardBiasPass"]&&out["ExactNaturalEquilibrium"]],Exit[1]];
