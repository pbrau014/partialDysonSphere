<|"Pole" -> "Pole1", "RimTransversePressureNeeded_Pa" -> 
  2.9339392906725624*^-6, "IdealRimFacetAngleStart_deg" -> 0.74062416130275, 
 "IdealRimFacetAngleDay7_deg" -> 0.6419199663925292, 
 "IdealLocalAxialSpecularLossStartFraction" -> 0.0002506105881190379, 
 "Scope" -> "Ideal perfectly reflecting independently adjustable facets per \
face area. Balances one modeled load component only. Does not establish \
optical, thermal, manufacturing, mass or structural feasibility."|>
