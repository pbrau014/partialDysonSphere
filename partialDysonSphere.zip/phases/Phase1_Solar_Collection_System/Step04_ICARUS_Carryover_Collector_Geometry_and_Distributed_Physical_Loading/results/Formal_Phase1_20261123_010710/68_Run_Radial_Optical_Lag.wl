(* Phase 1 Step 4: fixed-hover radial recovery with delayed optical force. *)
p=Environment["POLAR_ACCEPT_POLE"]; load=Get["66_"<>p<>".wl"];
m=load["LoadedMass_kg"]; cap=Get["30_"<>p<>"_Moving_Envelope.wl"]["AdditionalRadialWrenchAuthority_N"];
cme=2.561576803528925*^13; p0=m .14825208795382003;
h=86400.; ls=10^4; end=7.; on=1.; off=235200./h;
flare[t_]:=.00028 p0 Exp[-4 Log[2] ((h t-43200.)/3600.)^2];
cmd[x_,v_]:=-m ls/h^2 (16.^2 x+32. v);
(* State optical force normalized by peak CME; command spans both sides of calm. *)
run[tau_]:=Module[{phase,a,b,c,samples,ts,good,lastBad,recovery,peak,err,fl,band},
 phase[lo_,hi_,ic_,extra_]:=Module[{x,y,z,t},
 NDSolveValue[{x'[t]==y[t],
 y'[t]==h^2/(m ls) (extra+flare[t]-cme z[t]+Clip[cmd[x[t],y[t]],{-cap,cap}]),
 z'[t]==(h/tau) ((extra+flare[t])/cme-z[t]),
 x[lo]==ic[[1]],y[lo]==ic[[2]],z[lo]==ic[[3]]},{x,y,z},{t,lo,hi},
 AccuracyGoal->10,PrecisionGoal->9,MaxStepSize->1./144,MaxSteps->Infinity]];
 a=phase[0.,on,{0.,0.,0.},0.];
 b=phase[on,off,Through[a[on]],cme];
 c=phase[off,end,Through[b[off]],0.];
 ts=Sort@DeleteDuplicates@Join[Subdivide[0.,end,10080],{on,off},
  Select[Flatten[Table[{on+j tau/h,off+j tau/h},{j,0,24}]],0<=#<=end&]];
 samples=(Which[#<on,Through[a[#]],#<off,Through[b[#]],True,Through[c[#]]]& /@ ts);
 peak=Max[Abs[cmd[#[[1]],#[[2]]]]& /@ samples];
 band=.01 Sqrt[N[4 695700000^2/10-10000^2]];
 good=(Abs[#[[1]] ls]<=band&&Abs[#[[2]] ls/h]<=.0001)& /@ samples;
 lastBad=Select[Range[Length[ts]],ts[[#]]>=off&&!good[[#]]&];
 recovery=If[lastBad==={},0.,If[Last[lastBad]==Length[ts],Infinity,h(ts[[Last[lastBad]+1]]-off)]];
 <|"OpticalLag_s"->tau,"Recovery_s"->recovery,"PeakUnclippedRadialDemand_N"->peak,
 "SampledSaturation"->(peak>cap),"PeakRadialExcursion_m"->ls Max[Abs[samples[[All,1]]]]|>];
out=<|"Pole"->p,"Cases"->(run/@{1.,10.,60.,300.}),
 "Scope"->"Ideal area-integrated optical feedforward plus clipped radial correction. No attitude, local shape or implemented device. Exact forcing assumed apart from first-order lag; existing Gaussian flare amplitude and timing."|>;
Put[out,"68_"<>p<>".wl"];Print[out];
