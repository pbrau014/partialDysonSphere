(* Phase 1 Step 4: locally supported reflector, first-ten-second screen. *)
p=Environment["POLAR_ACCEPT_POLE"]; If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
mass=Get["66_"<>p<>".wl"]["LoadedMass_kg"];
pre=Get["71_"<>p<>".wl"]; wp=Get["40_"<>p<>"_Membrane_Cut.wl"];
area=N[4 Pi 695700000^2/10]; sigma=mass/area;
ten=pre["CMEOnsetApexTensionRemaining_N_m"]; budget=pre["RemainingAfterOpticsAndStrengthOnlyRim_kg"];
press=wp["CMEPressureAtOnset_Pa"]; tau=10.;
(* Fixed-edge, long-strip linear membrane. Uniform full CME increment is
   applied to a bay while support motion is neglected. No shape control is
   credited. Odd sine modes carry the exponential load. *)
run[l_,n_]:=Module[{k,om,fc,disp,sl,td,sd},
 k=Range[1,2 n-1,2] Pi/l;om=k Sqrt[ten/sigma];
 fc=(4 press/(sigma l k))/(om^2+tau^-2);
 disp[t_]:=fc (Exp[-t/tau]-Cos[om t]+Sin[om t]/(tau om));
 sl[t_]:=Total[k disp[t]];
 td=Subdivide[0.,10.,400];sd=Subdivide[0.,l,120];
 {Max[Abs[Flatten[Table[Sin[k x].disp[t],{t,td},{x,sd}]]]],
 Max[Abs[sl /@ td]]}];
rows=Table[{l,run[l,40],run[l,80],budget l/(2 area),press l/2},{l,{.5,1.,5.,10.,50.,100.}}];
o=<|"Pole"->p,"Rows"->rows,"Columns"->{"BayWidth_m","40Modes_PeakDeflection_m_AndEdgeSlope_rad",
 "80Modes_PeakDeflection_m_AndEdgeSlope_rad","MaxSupportLinearMass_kg_m","StaticFullLoadEdgeReactionPerLength_N_m"},
 "Scope"->"Ideal fixed immobile edges, uniform full CME load with 10 s exponential relief, existing minimum tension, foregoing control. Entire remainder assigned to grid, excluding junction costs. Not an installed mass or global shape pass."|>;
Put[o,"78_"<>p<>".wl"];Print[o];
