(* Phase 1 Step 4: optimistic graded hoop reinforcement mass screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
d=Get["45_"<>p<>"_Signed_Membrane.wl"];
area=N[4 Pi 695700000^2/10];
rows=Table[Module[{n,extra},
 n=c["Profile"][[All,3]];
 extra=Max[0.,#-1.4]& /@ n;
 {c["Depth_km"],area (1790./3.5*^9) (Total[extra]-(First[extra]+Last[extra])/2)/(Length[extra]-1),
 100 Count[extra,_?(#>0.&)]/Length[extra]}
 ],{c,d["Cases"]}];
o=<|"Pole"->p,"Columns"->{"CapDepth_km","AlignedHoopFiberOnlyMass_kg","AreaOverHoopFoilAllowable_pct"},
 "Rows"->rows,"Scope"->"Optimistic perfect local axial fiber sharing, full foil hoop credit, no compression or bond mass. Not a rim ring or installed mass."|>;
Put[o,"49_"<>p<>"_Hoop_Mass_Floor.wl"];Print[o];
