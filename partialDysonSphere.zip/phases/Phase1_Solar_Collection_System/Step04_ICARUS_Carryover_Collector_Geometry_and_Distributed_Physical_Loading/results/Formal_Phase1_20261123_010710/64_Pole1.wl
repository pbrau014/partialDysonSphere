<|"Pole" -> "Pole1", "PV_pct" -> 1.1217393576998493, 
 "ConditionalPower_W" -> 6.328974712719515*^18, 
 "LaterUniformHardwareMassToBalance_kg" -> 8.431489703294819*^13, 
 "LoadedMass_kg" -> 9.259547316730564*^14, "LoadedRadialResidual_N" -> 
  0.1875, "ExactNaturalEquilibrium" -> True, "Scope" -> "Uniform effective \
loading, fixed 0.2 AU, 10 km cap. Conditional cooling, short copper routes, \
and future hardware mass target, not an installed design."|>
