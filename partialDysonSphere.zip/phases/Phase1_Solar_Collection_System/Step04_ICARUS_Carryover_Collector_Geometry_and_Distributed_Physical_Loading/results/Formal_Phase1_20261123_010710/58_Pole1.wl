<|"Pole" -> "Pole1", "Columns" -> {"SpinDays", "RimSpeed_m_s", 
   "InitialNetCut_N_m", "Day7NetCut_N_m", "InitialIdealRingHoopStress_Pa"}, 
 "Rows" -> {{Infinity, 0., -430.36643145558656, -280.19892188316146, 
    -2.594034854163319*^9}, {7., 4571.093290164913, 8945.54506941569, 
    9095.712578988112, 5.39266530571285*^10}, {1., 31997.653031154394, 
    458989.29711123684, 459139.46462080925, 2.7669196727991357*^12}, 
   {32.67274288865373, 979.3378272586423, 2.1320676335317627*^-9, 
    150.16750957455722, 337624.4653100554}}, 
 "AdaptiveCutBalancePeriods_days" -> {32.67274288865373, 40.492217387550994}, 
 "CMEOnlyMassScreen" -> {10., 1.3611021665462373*^11, 0.20980117867389983, 
   0., 2.759185331894963*^11}, "Scope" -> "Axisymmetric shallow cap with \
uniform mass. Signed cut resultant from transverse gravity and centrifugal \
inertia only. Ring stress includes ideal rim gravity but no sheet traction. \
Cut balance is not patchwise, and the model excludes photon steering, \
rim/foil interaction, and stability."|>
