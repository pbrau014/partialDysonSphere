<|"Pole" -> "Pole1", "BaseNaturalRadial_N" -> 2.229772899472717*^13, 
 "BaseMass_kg" -> 7.779537658360005*^14, "LoadedForce_N" -> -1.96875, 
 "LoadedMass_kg" -> 9.283823092727991*^14, "AddedUniformMass_kg" -> 
  1.5042854343679862*^14, "LoadedOtherInstalledArealMass_kg_m2" -> 
  0.0005755362617515088, "ExactNaturalEquilibrium" -> True, 
 "OutwardRadialBiasPass" -> False, "RemainingGrowthReserve_kg" -> 
  -1.3724003911253255*^11, "LoadedSharedInputs" -> 
  <|"PerPoleProjectedArea_m2" -> 6.08210439898862*^17, 
   "CapDepthToPlanformRadius" -> 0.000022727308185892524, 
   "PVFraction" -> 0.006, "OtherInstalledArealMass_kg_m2" -> 
    0.0005755362617515088|>, "LoadedPoleInputs" -> 
  <|"Distance_m" -> 2.991957414*^10|>|>
