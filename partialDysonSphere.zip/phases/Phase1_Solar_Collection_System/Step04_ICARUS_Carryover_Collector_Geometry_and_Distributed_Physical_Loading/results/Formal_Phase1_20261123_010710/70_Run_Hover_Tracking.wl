(* Phase 1 Step 4: reduced radial and attitude tracking with shared station caps. *)
p=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
loaded=Get["66_"<>p<>".wl"];
d=Get["21_Step4_Candidate_Inputs.wl"];
n=Get["29_"<>p<>"_Moving_Reference.wl"];
h=604800.; on=86400./h; off=235200./h; m=loaded["LoadedMass_kg"];
grid=n["ForceGrid_N"]; r0=grid[[1,1]];
dep=10000.; a2=N[4 695700000^2/10-dep^2];
ia=m (a2/2+dep^2/6); it=ia/2+m dep^2/12; j0=DiagonalMatrix[{ia,it,it}]; is=ia;
(* Uniform additional mass uses a proportional inertia approximation. *)
j=j0/is;
wm=c["ICARUSWrenchMatrix"]; rad=c["Geometry"]["PlanformEquivalentRadius_m"];
sc=DiagonalMatrix[Join[{1.,1.,1.},ConstantArray[1./rad,3]]];
alloc=PseudoInverse[sc.wm].sc;
cap=d["TrialStationCap_N"]; omega=0.; axis={1.,0.,0.};
kp=d["AttitudeKp_per_s2"] h^2; kd=d["AttitudeKd_per_s"] h;
wind=2.561576803528925*^13; lag=10./h;
sun[q_]:=With[{z=Normalize[q]},{1-2(z[[3]]^2+z[[4]]^2),
 2(z[[2]] z[[3]]-z[[1]] z[[4]]),2(z[[2]] z[[4]]+z[[1]] z[[3]])}];
body[q_,v_]:=With[{a=First[Normalize[q]],b=Rest[Normalize[q]]},(a^2-b.b) v+2 b (b.v)-2 a Cross[b,v]];
command[y_]:=Module[{q=y[[3;;6]],v=y[[7;;9]],u,b,t,fr},
 u=sun[q]; b=Cross[u,axis];
 t=-is/h^2 j.(kp If[Norm[b]==0.,b,ArcTan[u.axis,Norm[b]] Normalize[b]]+kd (v-omega u));
 fr=-m/h^2 (112.^2 y[[1]]+224. y[[2]]);
 Partition[alloc.Join[fr u+body[q,Join[{0.},-m/h^2 (112.^2 y[[10;;11]]+224. y[[12;;13]])]],t],3]];
phase[lo_,hi_,ic_,ix_,delta_]:=Module[{y,t,rhs,s,extra},
 s[_]:=1.; extra=If[ix==2,wind,0.];
 rhs[tt_?NumericQ,z_?VectorQ]/;VectorQ[z,NumericQ]:=Module[{u,q,v,f,wr,x,a,gg,lat,ly,lz,res,flare},
  q=z[[3;;6]]; v=z[[7;;9]]; u=sun[q];
  f=If[Norm[#]>cap,cap Normalize[#],#]& /@ command[z];
  wr=wm.Flatten[f]; x=s[tt]+z[[1]]/r0;
  res=Switch[ix,1,0.,2,wind Exp[-Max[0.,tt-on]/lag],3,-wind (1-Exp[-(off-on)/lag]) Exp[-Max[0.,tt-off]/lag]];
  flare=.00028 m .14825208795382003 Exp[-4 Log[2.] ((h tt-43200.)/3600.)^2];
  a=h^2/m ((res+extra delta+flare)/x^2+Take[wr,3].u);
  gg=3. 1.3271244*^20 h^2/(r0 x)^3;
  ly=body[q,{0.,1.,0.}]; lz=body[q,{0.,0.,1.}]; lat=h^2/m ({ly.Take[wr,3],lz.Take[wr,3]}+{extra delta/x^2,0.});
  Join[{z[[2]],a},Join[{-Rest[q].v},q[[1]] v+Cross[Rest[q],v]]/2+8 (1-q.q) q,
   LinearSolve[j,gg Cross[u,j.u]-Cross[v,j.v]+(Take[wr,-3]+1000. res {0.,0.,1.}) h^2/is],z[[12;;13]],lat]];
 NDSolveValue[{y'[t]==rhs[t,y[t]],y[lo]==ic},y,{t,lo,hi},
 AccuracyGoal->10,PrecisionGoal->11,MaxStepSize->1/4096,MaxSteps->Infinity]];
run[delta_]:=Module[{a,b,c2,ic,times,states,dem,good,post,bad,idx,err,history},
 ic=N[{0,0,Cos[Degree/8],0,Sin[Degree/8],0,omega,0,0,0,0,0,0}];
 a=phase[0.,on,ic,1,delta]; b=phase[on,off,a[on],2,delta];
 c2=phase[off,1.,b[off],3,delta];
 If[!AllTrue[{a,b,c2},MatchQ[#,_InterpolatingFunction]&],Return[Failure["Integration",<||>]]];
 times=Sort@DeleteDuplicates@Join[Subdivide[0.,1.,4032],{on,off},Flatten[Table[{on+i lag,off+i lag},{i,0,24}]]];
 states=(If[#<on,a[#],If[#<off,b[#],c2[#]]]& /@ times);
 history=command /@ states; dem=Max[Norm /@ #]& /@ history;
 err=({Abs[#[[1]]],Abs[#[[2]]]/h,ArcCos[Clip[First[sun[#[[3;;6]]]],{-1.,1.}]],
 Norm[#[[7;;9]]-omega sun[#[[3;;6]]]]/h,Norm[#[[10;;11]]],Norm[#[[12;;13]]]/h}& /@ states);
 good=(And@@Thread[#<={.01 rad,10^-4,.0174533,10^-7,.01 rad,10^-4}]& /@ err);
 post=Flatten@Position[(#>=off& /@ times),True]; bad=Select[post,!good[[#]]&];
 idx=If[bad==={},First[post],Last[bad]+1];
 <|"CMEExcessFractionError"->delta,"ExitErrors"->err[[First[post]]],
 "PeakDemand_N"->Max[dem],"SampledSaturation"->(Max[dem]>cap),
 "Recovery_s"->If[idx>Length[times],Infinity,Max[0.,h (times[[idx]]-off)]],
 "QuatNormError"->Max[Abs[(Norm[#[[3;;6]]]& /@ states)-1]],
 "FinalErrors"->Last[err],"LoadTimes_s"->h times,"AttitudeQuaternions"->states[[All,3;;6]],"AppliedStationForces_N"->Map[If[Norm[#]>cap,cap Normalize[#],#]&,history,{2}]|>];
out=<|"Pole"->p,"ErrorColumns"->{"RadialPosition_m","RadialVelocity_m_s","Tilt_rad","SpinRelativeRate_rad_s","LateralPosition_m","LateralVelocity_m_s"},
 "Scope"->"Fixed-hover rigid-body reduced test; 10 second radial optical feedforward, Gaussian flare uncorrected by optics, trial 1 km onset center-of-pressure offset, shared four station caps. Neglects flexible structure, detailed torque map, and ambient radial gradient.",
 "Cases"->(run /@ {0.,.0001})|>;
Put[out,"70_"<>p<>".wl"];Print[Map[KeyDrop[#,{"LoadTimes_s","AppliedStationForces_N","AttitudeQuaternions"}]&,out["Cases"]]];



