<|"Pole" -> "Pole1", "Columns" -> {"CapDepth_km", 
   "AlignedHoopFiberOnlyMass_kg", "AreaOverHoopFoilAllowable_pct"}, 
 "Rows" -> {{100., 2.407886021121006*^10, 912/41}, 
   {250., 2.922598450285562*^11, 2004/41}}, "Scope" -> "Optimistic perfect \
local axial fiber sharing, full foil hoop credit, no compression or bond \
mass. Not a rim ring or installed mass."|>
