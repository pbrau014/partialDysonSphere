(* Phase 1 Step 4: ideal two-way tension bias and compression bypass screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
s=Get["45_"<>p<>"_Signed_Membrane.wl"];
available=Get["48_"<>p<>"_Unstiffened_Area.wl"]["RemainingReservePreservingMass_kg"];
area=N[4 Pi 695700000^2/10];
rows=Map[Function[c,Module[{n,bias,uniform,vm,mean,limit},
 n=c["Profile"][[All,2;;3]];
 bias=Max[0.,-Min[#]]& /@ n;
 uniform=Max[bias];
 vm[{x_,y_}]:=Sqrt[x^2+y^2-x y];
 mean=(Total[bias]-(First[bias]+Last[bias])/2)/(Length[bias]-1);
 limit=1.*^9/2;
 <|"Depth_km"->c["Depth_km"],"MinimumUniformPretension_N_m"->uniform,
 "LocalBiasMean_N_m"->mean,
 "PeakFoilEquivalentWithUniformBias_N_m"->Max[vm[# + uniform]& /@ n],
 "PeakFoilEquivalentWithLocalBias_N_m"->Max[MapThread[vm[#1+#2]&,{n,bias}]],
 "UniformStressOnlyBypassMass_kg"->area (1600./limit) 2 uniform,
 "LocalStressOnlyBypassMass_kg"->area (1600./limit) 2 mean|>
 ]],s["Cases"]];
out=<|"Pole"->p,"AvailableMassBeforeReinforcement_kg"->available,"Cases"->rows,
 "Scope"->"CME increment only. Zero minimum tension margin. Ideal independent orthogonal compression members with trial 1600 kg/m3 and 0.5 GPa compression allowable. Excludes buckling, connectors, compatibility, thermal effects and baseline loads."|>;
Put[out,"51_"<>p<>".wl"];Print[out];
