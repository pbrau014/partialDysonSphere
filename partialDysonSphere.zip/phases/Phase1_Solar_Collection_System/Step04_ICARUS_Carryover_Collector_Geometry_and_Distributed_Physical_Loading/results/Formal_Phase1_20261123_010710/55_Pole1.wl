<|"Pole" -> "Pole1", "Depth_km" -> 20, "RimRadius_m" -> 
  4.3999931318128216*^8, "ApexCMECompressionEachDirection_N_m" -> 
  0.20980117867389983, "RimCMEHoopTension_N_m" -> 0.4196023556139002, 
 "CMEOnlyBypassMass_kg" -> 2.7222043330924747*^11, 
 "MassRemaining_kg" -> 1.3980831653487253*^11, 
 "OptimisticAreaMeanResidualCompressionBudget_N_m" -> 0.07183385227955892, 
 "IdealRimTilt_deg" -> {0.74062416130275, 0.6419199663925292}, 
 "FixedInitialPatternDay7OutwardAverageCutExcess_N_m" -> 43.101210730003096, 
 "Scope" -> "CME membrane increment plus separate flat-disk radial momentum \
scale. Budget converts remaining mass to area-mean directional compression \
resultant using trial axial members only. Fixed-pattern excess is tensile in \
a free flat disk; it is not a compression comparison or a complete structural \
solution."|>
