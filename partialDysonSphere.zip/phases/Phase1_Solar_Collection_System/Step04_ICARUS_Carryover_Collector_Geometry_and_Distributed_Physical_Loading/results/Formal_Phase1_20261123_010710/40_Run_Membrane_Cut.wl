(* Phase 1 Step 4: membrane-only incremental CME cut-equilibrium screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
n=Get["29_"<>p<>"_Moving_Reference.wl"];
d=Get["32_"<>p<>"_CME_RideThrough.wl"];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
a=c["Geometry"]["PlanformEquivalentRadius_m"]; h=.1 a;
on=d["SegmentBoundaries_s"][[2]];
rel=First[d["Segments"]][on/Last[d["SegmentBoundaries_s"]]];
pressure=1259*5.*^6*1.67262192595*^-27*(4.*^5)^2/(.2 rel)^2;
(* cos(theta) is uniform in curved area on a spherical cap. In the translating
   frame the incremental axial traction is p (cos(theta)-mean cos(theta)).
   A meridional cut balances the integral inside the cap by axial projection
   of its membrane force. The limiting magnitude at the apex is p h/4. *)
apex=pressure h/4;
o=<|"Pole"->p,"CMEPressureAtOnset_Pa"->pressure,
 "ApexMeridionalIncrementMagnitude_N_m"->apex,
 "LegacyAllowablePretension_N_m"->1.4,
 "EquivalentSectionThicknessAt14MPa_m"->apex/(14*^6),
 "Scope"->"Axisymmetric, unchanged cap, uniform surface mass, momentum load from CME only, membrane-only force balance. No bending/edge flexibility or combined stress. This diagnostic does not describe a reinforced shell."|>;
Put[o,"40_"<>p<>"_Membrane_Cut.wl"];Print[o];
