(* Phase 1 Step 4: charged collector architecture trial, not acceptance inputs. *)
<|"Status"->"ProvisionalChargedMassTrade","CapDepth_m"->10000,"Distance_AU"->.2,
 "CommandedSpin_rad_s"->0.,"BaySpacing_m"->.5,"TrialMinimumWebThickness_m"->10^-6,
 "TrialJunctionMass_kg"->10^-6,"GridContingencyFraction"->.2,
 "NominalReflectivity"->.98,"PVFraction"->.008228837603025585,
 "CollectorFixedStructureAndOpticsCharge_kg"->1.0574723185880588*^14,
 "SeparateFutureMassReserveFraction"->.1,
 "LaterUniformLoadForBalance_kg"->8.284944420792858*^13,
 "ConditionalElectricalOutput_W"->4.642799126832437*^18,
 "OpticalRole"->"Distributed bulk force and attitude; ICARUS residual",
 "ApplySeparatelyPerPole"->True,"Step4TechnicalAcceptance"->False|>
