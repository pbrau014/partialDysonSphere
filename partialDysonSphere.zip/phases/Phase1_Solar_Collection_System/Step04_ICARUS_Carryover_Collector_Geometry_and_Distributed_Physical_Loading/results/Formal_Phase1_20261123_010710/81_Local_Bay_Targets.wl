(* Phase 1 Step 4: provisional locally supported optical bay targets. *)
<|"Status"->"UnverifiedCandidate","BaySpacing_m"->.4,
 "LowDeflectionComparisonSpacing_m"->.25,"RibCapSeparation_m"->.00360831,
 "ScreenedEachWebThickness_m"->4.37351*^-7,
 "ScreenedRibLinearMass_kg_m"->8.39909*^-6,
 "RequiredRibBendingRigidity_Nm2"->.000681342,
 "OneJunctionPerBayMassCeilingBeforeOtherCosts_kg"->1.87750*^-6,
 "AssignedLoads"->"Local foil and rib reactions; optical bulk wrench; ICARUS residual",
 "TechnicalAcceptance"->False|>
