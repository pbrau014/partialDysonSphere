(* Phase 1 Step 4: requirements for controlled transverse stability. *)
pole=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
w=Get["08_"<>pole<>"_Wobble.wl"]["Result"];
lin=w["GravityGradientLinearization"];
growth=Max[lin["UnstableGrowthRates_s"]];
moments=Sort[Eigenvalues[lin["InertiaTensor_kg_m2"]]];
it=Mean[Take[moments,2]];
iz=Last[moments];
radius=437815680.7345184;
cases=Table[Module[{kp,kd,roots,torque},
 kp=f growth^2; kd=2 Sqrt[kp-growth^2];
 roots=Sort[{-kd/2,-kd/2}];
 torque=it kp Degree;
 <|"StiffnessFactor"->f,"Kp_per_s2"->kp,"Kd_per_s"->kd,
 "TransversePoles_per_s"->roots,"StaticControlTorqueAt1deg_Nm"->torque,
 "IdealCoupleForceAt1deg_N"->torque/(2 radius)|>],{f,{1.25,2.,4.}}];
result=<|"Pole"->pole,"OpenLoopGrowth_per_s"->growth,
 "IdealGyroCriticalPeriod_h"->2 Pi iz/(2 it growth 3600),
 "ReducedControlledCases"->cases,
 "Scope"->"Linear axisymmetric rigid-body screen; ideal PD or ideal torque-free axial spin. Station allocation, capacity, nonlinear disturbances and structural transfer remain unverified."|>;
Put[result,"09_"<>pole<>"_Stability_Design.wl"];Print[result];
