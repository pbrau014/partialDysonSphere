(* Phase 1 Step 4: provisional architecture inputs and acceptance boundary. *)
Module[{area=N[4 Pi 695700000^2/10], coolingMass=1.526698109072746*^14,
  copperMass=4.694880877436852*^13},
 <|"PVTradeRange"->{.005,.03},"AlternativePVFraction"->.011,
   "SharedNativeInputs"-><|"PerPoleProjectedArea_m2"->area/1.01,
     "CapDepthToPlanformRadius"->.1,"PVFraction"->.006,
     "OtherInstalledArealMass_kg_m2"->(coolingMass+copperMass)/area|>,
   "PoleOperatingInputs"-><|"Distance_m"->29919574140.|>,
   "FixedShape"->True,"FixedPerimeter"->True,"UniformAssemblyMass"->True,
   "BranchAndMainBusVoltage_V"->100000,"OneWayRoute_m"->1000,
   "CoolingMass_kg"->coolingMass,"BranchAndMainCopperMass_kg"->copperMass,
   "AcceptanceScope"->"Static mass surrogate. Installed radiator optics, heat transport, support and electrical qualification are unresolved."|>
]
