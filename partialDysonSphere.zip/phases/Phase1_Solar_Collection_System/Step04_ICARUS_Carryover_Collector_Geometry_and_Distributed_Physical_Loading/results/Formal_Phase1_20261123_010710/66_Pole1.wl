<|"Pole" -> "Pole1", "PV_pct" -> 1.0826495586110485, 
 "ConditionalPower_W" -> 6.10842584077336*^18, "NominalReflectivity" -> 0.98, 
 "PreLoadMass_kg" -> 8.258859457385205*^14, "PreLoadReserveRatio" -> 
  0.1000054212023295, "PreLoadReservePass" -> True, 
 "PreLoadOutwardBiasPass" -> True, "LaterUniformHardwareMassToBalance_kg" -> 
  8.274373063814856*^13, "LoadedMass_kg" -> 9.086296763766692*^14, 
 "LoadedRadialResidual_N" -> -0.84375, "ExactNaturalEquilibrium" -> True, 
 "Scope" -> "Native static optical derating. Power is inherited conditional \
PV scaling. Optical hardware and allocated future mass are not installed or \
verified."|>
