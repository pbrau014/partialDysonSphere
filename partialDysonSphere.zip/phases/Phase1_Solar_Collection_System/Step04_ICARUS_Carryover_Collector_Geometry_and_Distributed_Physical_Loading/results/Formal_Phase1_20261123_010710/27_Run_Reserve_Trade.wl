(* Phase 1 Step 4: reserve-preserving loading and a static-hold feasibility bound. *)
pole=Environment["POLAR_ACCEPT_POLE"];
base=Get["02_"<>pole<>"_Static.wl"]["Results"]["Step4EngineeringCore"]["NaturalEquilibrium"];
loaded=Get["26_"<>pole<>"_Loaded_Equilibrium.wl"];
spec=Get["21_Step4_Candidate_Inputs.wl"];
m=loaded["BaseMass_kg"]; reserve=base["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"];
fraction=base["FutureMassTargetFractionOfCurrentMass"];
dmMax=(reserve-fraction m)/(1+fraction);
gradient=(loaded["BaseNaturalRadial_N"]-loaded["LoadedForce_N"])/loaded["AddedUniformMass_kg"];
forceAtReserve=loaded["BaseNaturalRadial_N"]-gradient dmMax;
cap=spec["TrialStationCap_N"];
out=<|"Pole"->pole,"ReserveTargetFraction"->fraction,
 "MaximumAddedMassPreservingReserve_kg"->dmMax,"MinimumOutwardForcePreservingReserve_N"->forceAtReserve,
 "FourStationIdealRadialCapacity_N"->4 cap,"MinimumForceShortfall_N"->forceAtReserve-4 cap,
 "MinimumEqualPerStationRadialForce_N"->forceAtReserve/4,
 "IdealEqualAxialPathLengthIfAllAddedMassUsed_m"->dmMax/(4 2705 cap/(14*^6))|>;
Put[out,"27_"<>pole<>"_Reserve_Trade.wl"];Print[out];
