# Step 4 acceptance evidence register

| Item | Saved evidence | Status |
|---|---|---|
| Native inputs and prework | 00_Prework, 00_SHA256.csv, 01_Reference_Architecture.wl, 21_Step4_Candidate_Inputs.wl | Traceable |
| Pole-local native nominal force and reserve | 28_Pole*_Reserve_Check.wl | Outward bias, transverse force balance and future mass target passed |
| Moving trajectory and required envelope | 29_Pole* native forces and trajectories; 30_Pole* envelope | Seven-day nominal range 0.19997 to 0.21776 AU with tolerance tube; irradiance minimum 28704 W/m^2. Mission allowance not established in governing roadmap. |
| Spin and finite station control | 12_Pole* precision spin and 20_Pole* saturation | Narrow rigid-body cases passed. Integrated moving-reference recovery remains unexecuted. |
| Fixed reference failure | 24_Pole* integrated smoke | Recovery, native structural screen and quaternion tolerance did not pass. |
| Station-to-sheet loads | 16_Pole* peak map; 19_Pole* envelope; 20_Pole* panel; 21_Pole* support requirements | Mapped force and moment closure passed. 20 m half-span passes a provisional normal load screen. Physical attachment stiffness, material sections, buckling and connection stress/load path unverified. |
| Disturbance severity | 31_Pole* impulse screen and active v11.142 input register | Strong CME radial authority mismatch under current trial settings. |

Native disturbance inputs: Gaussian flare 0.028% peak at 43200 s, 3600 s FWHM and 1% tail cutoff. Rectangular CME multiplier 1260, onset 86400 s and duration 148320 s. Recovery window 86400 s, velocity error tolerance 1e-4 m/s, spin-relative rate target 1e-7 rad/s and tilt about one degree. Collect both pole results independently.

The new impulse scale uses face-on nominal wind at 0.2 AU and inverse-square scaling at the far tube edge. The extra CME force is 21.39 TN, and the event impulse is 3.173e18 N s. The 208.3 GN trial radial authority with attitude reserve supplies at most 4.889e16 N s in the CME plus 24-hour recovery window. The disturbance scale is about 65 times that authority. Even ideal full radial use of all four stations gives only 4.704e17 N s over that window. This is an isolated force/impulse screen on the assumed tube, not a coupled trajectory calculation.

Evidence needed for formal closure: allowable mission distance/flux and operating duration, executable moving-reference controller and stress-case recovery on both poles, supported load-path geometry with stiffness/allowables and installed mass, and verified actuator limits or documented external qualification boundary. Step 4 remains open.
