(* Phase 1 Step 4: minimum web gauge and shared-junction feasibility. *)
p=Environment["POLAR_ACCEPT_POLE"]; If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
b=Get["81_"<>p<>".wl"]; base=Get["71_"<>p<>".wl"];
area=N[4 Pi 695700000^2/10]; budget=base["RemainingAfterOpticsAndStrengthOnlyRim_kg"]/area;
rho=1600.; ec=100.*^9; ew=30.*^9; k=5.34 Pi^2 ew/(12 (1-.3^2));
pressure=Get["40_"<>p<>"_Membrane_Cut.wl"]["CMEPressureAtOnset_Pa"];
hgrid=Exp@Subdivide[Log[.0005],Log[.02],1200];
case[gauge_,node_]:=First@MinimalBy[Table[Module[{l,ei,v,line},
 l=row["Bay_m"];ei=row["RequiredEI_Nm2"]; v=pressure l^2;
 line=Min[(rho (4 ei/(ec #^2)+2 # Max[gauge,(v #/(2 k))^(1./3.)]))& /@ hgrid];
 <|"BayWidth_m"->l,"WebGauge_um"->gauge 10^6,"Junction_mg"->node 10^6,
 "RibsAndSharedJunctions_kg"->area (2 line/l+node/l^2),
 "BudgetFraction"->(2 line/l+node/l^2)/budget|>
 ],{row,b["Rows"]}],#["BudgetFraction"]&];
out=<|"Pole"->p,"Cases"->Flatten[Table[case[g,n],{g,{.25,.5,1.,2.}*10^-6},
 {n,{.5,1.,2.}*10^-6}]],"Scope"->"Trial minimum gauge and one shared junction per bay. Ribs retuned for each case. No bond, optical metrology, thermal margin, cap local buckling or global shape verification."|>;
Put[out,"82_"<>p<>".wl"];Print[out];
