<|"Pole" -> "Pole1", "Rows" -> 
  {{100., {{0., 0.}, {0.1, 9.532834461240855}, {0.25, 23.83208632912594}, 
     {0.5, 47.66417324499791}, {1., 95.32834883697998}, {1.4, 100}}}, 
   {250., {{0., 0.}, {0.1, 3.813132779603575}, {0.25, 9.532832125032696}, 
     {0.5, 19.065664836811287}, {1., 38.13133202060636}, 
     {1.4, 53.383867457471034}}}}, "RemainingReservePreservingMass_kg" -> 
  4.1202874984412*^11, "RemainingAverageArealMass_kg_m2" -> 
  6.77444388655693*^-7, "FullPreAllocationMass_kg" -> 4.1202874984412*^13, 
 "Scope" -> "Area below hypothetical effective meridional compression \
threshold only; not a wrinkling or hoop-strength pass. Remaining budget \
relative to 99 percent pre-allocation trial."|>
