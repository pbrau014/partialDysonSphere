<|"Pole" -> "Pole1", "Results" -> {<|"Days" -> 7, "StartTilt_deg" -> 1/4, 
    "Precision" -> 32, "PeakTilt_deg" -> 
     0.26922638874854539150958681652195502948`12., 
    "PeakTransverseRate_rad_s" -> 6.70109406988370925455519082416`12.*^-9, 
    "NormError" -> 2.6821718476950488141485456421`12.*^-10, 
    "Pass" -> False|>, <|"Days" -> 28, "StartTilt_deg" -> 1/4, 
    "Precision" -> 38, "PeakTilt_deg" -> 
     0.2692264037166032496934137298451906315`12., 
    "PeakTransverseRate_rad_s" -> 6.70109677493443502245327135706`12.*^-9, 
    "NormError" -> 1.069101939510848053917786637`12.*^-11, "Pass" -> True|>, 
   <|"Days" -> 28, "StartTilt_deg" -> 1/2, "Precision" -> 38, 
    "PeakTilt_deg" -> 0.5384509728385139004978425408153125131`12., 
    "PeakTransverseRate_rad_s" -> 1.340158646714803501558731820201`12.*^-8, 
    "NormError" -> 1.342425402607024400852164996`12.*^-11, "Pass" -> True|>}|>
