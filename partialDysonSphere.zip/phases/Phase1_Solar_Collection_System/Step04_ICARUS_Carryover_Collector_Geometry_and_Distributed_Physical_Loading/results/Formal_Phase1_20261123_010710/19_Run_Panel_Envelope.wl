(* Phase 1 Step 4: spin-relative attitude control and station allocation screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
w=c["ICARUSWrenchMatrix"]; j=c["DynamicInitialConditions"]["InertiaTensor_kg_m2"];
radius=c["Geometry"]["PlanformEquivalentRadius_m"];
s=DiagonalMatrix[Join[ConstantArray[1.,3],ConstantArray[1./radius,3]]];
allocator=PseudoInverse[s.w].s;
axis={1.,0.,0.}; omega=2. Pi/604800;
kp=2.9533720891532804*^-11; kd=7.685534580174993*^-6;
tracking[u_,rate_]:=Module[{b,err},
 b=Cross[u,axis];
 err=If[Norm[b]==0.,0. b,ArcTan[Dot[u,axis],Norm[b]] Normalize[b]];
 -j.(kp err+kd (rate-omega u))];
(* Apply the initial peak attitude demand of the 16x case. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
design=Get["01_Reference_Architecture.wl"];
in=Join[Phase1GetInputs[],design["SharedNativeInputs"],design["PoleOperatingInputs"]];
mapper=ToExpression[First[Names["*`Private`phase1LoadMap"]]];
(* Force-to-normal-pressure operator, conservative for any station directions. *)
patch=c["SurfaceMesh"]["Patches"];
areas=Lookup[patch,"SurfaceAreaWeight_m2"];
normals=Lookup[patch,"Normal"];
columns=Table[Module[{m},
 m=mapper[in,c["Geometry"],c["SurfaceMesh"],c["DynamicInitialConditions"],Partition[N[UnitVector[12,i]],3]];
 If[!AssociationQ[m]||!TrueQ[m["AllIndividualStationTransfersConserved"]],Print[m];Exit[1]];
 MapThread[Dot[#1,#2]/#3&,{Lookup[m["Patches"],"EstimatedLocalLoadVector_N"],normals,areas}]
 ],{i,12}];
coeff=Max[Total[Norm /@ Partition[#,3]]& /@ Transpose[columns]];
s0=Get["06_"<>p<>"_Structural_Preflight.wl"]["AppliedPeakLocalNormalEnvironmentalPressureIncludingGravity_Pa"];
out=<|"Pole"->p,"NormalPressureBoundPerStationCap_PaPerN"->coeff,
 "StaticPeak_Pa"->s0,"EnvelopeAt1p5TN_Pa"->s0+1.5*^12 coeff,
 "HalfSpanAt1p5TN_m"->.02/(s0+1.5*^12 coeff)|>;
Put[out,"19_"<>p<>"_Panel_Envelope.wl"];Print[out];
