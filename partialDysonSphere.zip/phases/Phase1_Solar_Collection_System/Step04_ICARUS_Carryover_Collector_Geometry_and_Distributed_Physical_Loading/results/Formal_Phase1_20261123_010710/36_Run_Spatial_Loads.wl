(* Phase 1 Step 4: spatial wind and mapped station traction in a translating frame. *)
p=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
r=Get["32_"<>p<>"_CME_RideThrough.wl"];
d=Get["01_Reference_Architecture.wl"];
track=Get["35_"<>p<>"_Coupled_Tracking.wl"];
in=Join[Phase1GetInputs[],d["SharedNativeInputs"],d["PoleOperatingInputs"]];
mapper=ToExpression[First[Names["*`Private`phase1LoadMap"]]];
patch=c["SurfaceMesh"]["Patches"];
areas=Lookup[patch,"SurfaceAreaWeight_m2"]; normals=Lookup[patch,"Normal"];
weights=areas/Total[areas];
columns=Table[Module[{map},
 map=mapper[in,c["Geometry"],c["SurfaceMesh"],c["DynamicInitialConditions"],
 Partition[N[UnitVector[12,i]],3]];
 If[!AssociationQ[map]||!TrueQ[map["AllIndividualStationTransfersConserved"]],Print[map];Exit[4]];
 Flatten[Lookup[map["Patches"],"EstimatedLocalLoadVector_N"]]
 ],{i,12}];
sun[q_]:=With[{z=Normalize[q]},{1-2(z[[3]]^2+z[[4]]^2),
 2(z[[2]] z[[3]]-z[[1]] z[[4]]),2(z[[2]] z[[4]]+z[[1]] z[[3]])}];
on=r["SegmentBoundaries_s"][[2]]; off=r["SegmentBoundaries_s"][[3]];
end=Last[r["SegmentBoundaries_s"]];
pwind=5. 10^6 1.67262192595*^-27 (4.*^5)^2/.2^2;
amp[t_]:=If[t<on,1,If[t<off,2,3]];
snap[t_,q_,forces_,error_]:=Module[{u,rel,w,fp,tr,pr,tg},
 u=sun[q]; rel=r["Segments"][[amp[t]]][t/end];
 w=If[amp[t]==2,pwind 1259 (1+error)/rel^2,0.];
 fp=Partition[Flatten[forces].columns,3]+Outer[Times,w areas (Clip[#,{0.,1.}]& /@ (normals.u)),u];
 tr=MapThread[(#1-#2 Total[fp])/#3&,{fp,weights,areas}];
 pr=MapThread[Dot,{tr,normals}];
 tg=MapThread[Norm[#1-#2 #3]&,{tr,pr,normals}];
 {Max[Abs[pr]],Max[tg],Max[Norm /@ tr]}];
rows=Table[Module[{t=case["LoadTimes_s"],loads,indices,peaks},
 indices=Union[Range[1,Length[t],4],Flatten@Position[t,_?(Abs[#-on]<1.||Abs[#-off]<1.&)],{Length[t]}];
 loads=MapThread[snap[#1,#2,#3,case["CMEExcessFractionError"]]&,
 {t[[indices]],case["AttitudeQuaternions"][[indices]],case["AppliedStationForces_N"][[indices]]}];
 peaks=Max /@ Transpose[loads];
 <|"CMEExcessFractionError"->case["CMEExcessFractionError"],"SampleCount"->Length[indices],
 "PeakNormalTangentialResultant_Pa"->peaks|>],{case,track["Cases"]}];
out=<|"Pole"->p,"Cases"->rows,"Scope"->"Coarse nominal incidence CME plus station force in uniform-mass translating frame. Excludes lateral CME pressure distribution, base radiation/gravity, angular inertia, elastic response."|>;
Put[out,"36_"<>p<>"_Spatial_Loads.wl"];Print[out];
