(* ========================================================================
   POLAR COLLECTOR — WOLFRAM LANGUAGE PACKAGE
   Revision: v11.142 — cached dynamic environmental RHS evaluation

   GOVERNING PROJECT PHASES — THE ONLY PROJECT-LEVEL PHASE STRUCTURE
     Phase 0 — Master Parameters
     Phase 1 — Solar Collection System
     Phase 2 — RCR Electrical Conditioning
     Phase 3 — Microwave Generation, Transmission and Orbital Distribution
     Phase 4 — Terrestrial Reception and Grid Integration
     Phase 5 — Integrated System Simulation

   CURRENT PROJECT POSITION
     Current phase: Phase 1 — Solar Collection System
     Current step: Step 4 — Complete ICARUS Carryover, Collector Geometry, and Distributed
       Physical Loading [RESUMED UNDER THE USER'S LATEST DIRECTIVE]. Step 4 remains
       incomplete and unaccepted until the two independent pole assessments have been
       executed, failures resolved, and all modeled acceptance checks verified.
       Explicit external actuator, attachment and flexible-structure qualification
       remains separate and must not be claimed from source-model results.
     Step 5 — Complete the Material, Membrane, and Structural Architecture remains
       preliminary early-start work and unaccepted. Step 5 acceptance and Step 6
       commencement remain blocked until Step 4 is completed and accepted.

   GOVERNING PROJECT ROADMAP — SIX HIGHEST-LEVEL PHASES ONLY
     Phase 0 — Master Parameters
     Phase 1 — Solar Collection System
     Phase 2 — RCR Electrical Conditioning
     Phase 3 — Microwave Generation, Transmission and Orbital Distribution
     Phase 4 — Terrestrial Reception and Grid Integration
     Phase 5 — Integrated System Simulation

   PHASE 1 STEP REGISTER — FIXED ORDER
     Step 1 — Establish the Governing Inputs and Assumptions Baseline
     Step 2 — Establish Natural Force and Torque Equilibrium
     Step 3 — ICARUS Redesign Sizing and Dynamic Verification
       Administratively closed; unfinished technical work is carried into Step 4.
     Step 4 — Complete ICARUS Carryover, Collector Geometry, and Distributed
              Physical Loading [CURRENT; RESUMED; USER-AUTHORIZED TESTING]
     Step 5 — Complete the Material, Membrane, and Structural Architecture
              [PRELIMINARY EARLY-START WORK; NOT ACCEPTED]
     Step 6 — Complete Optical and Thermal Behavior
     Step 7 — Complete Photovoltaic Collection and Electrical Production
     Step 8 — Complete Integrated Rotation, Control, Disturbance, and Operating Behavior
     Step 9 — Perform Comprehensive Coupled Optimization
     Step 10 — Complete Integrated Verification, Co-Simulation, and Phase 2 Handoff

   ROADMAP CONTROL
     Do not redefine the six-phase project structure or pre-plan internal steps of
     a later project phase. Later phase steps are defined only at their authorized
     handoffs. The user's latest directive resumes Step 4 and explicitly authorizes
     Mathematica-kernel testing. Execute the readiness gate and both pole assessments;
     diagnose and correct failures before recording modeled completion. Step 4 remains
     unaccepted until all required modeled checks pass. External actuator, attachment
     and flexible-structure qualification remains an explicit external dependency.
     Step 5 remains preliminary and unaccepted; Step 6 cannot begin until Step 4 is
     accepted. Co-simulation remains downstream of a reproducible native baseline.

   PROJECT HIERARCHY RULE
     The six names above are the only project-level phases. Do not use the word
     phase to label any lower-level subsystem, task group, milestone or step.
     Lower-level work is organized only as steps within its governing phase.

   PROJECT-LEVEL SYSTEM OVERLAY — GOVERNED SCOPE

   Phase 0 — Master Parameters
     Establishes the common physical constants, material reference properties,
     design assumptions and interfaces used by the project. The present source
     consumes the Phase 0 governing inputs but does not redefine that phase's plan.

   Phase 1 — Solar Collection System
     Contains two physically separate solar-collector sheets, Pole 1 and Pole 2.
     Each sheet converts incident solar energy into electrical output while its
     optical, mass, structural, force, torque, thermal and attitude behavior is
     evaluated against its own heliocentric operating state. The two systems share
     design definitions and immutable physical references only. Their operating
     states and mechanical equilibrium calculations remain isolated.

   Phase 2 — RCR Electrical Conditioning
     Receives the electrical output interface from the completed collector system
     and governs the named electrical-conditioning subsystem. This source records
     the project-level interface only; internal steps are not defined here.

   Phase 3 — Microwave Generation, Transmission and Orbital Distribution
     Governs conversion of conditioned electrical power into microwave energy,
     transmission, and distribution in orbit. Its internal steps are reserved for
     the authorized Phase 2-to-Phase 3 handoff.

   Phase 4 — Terrestrial Reception and Grid Integration
     Governs terrestrial reception of the transmitted energy and connection to the
     terrestrial grid. Its internal steps are reserved for the authorized Phase 3-
     to-Phase 4 handoff.

   Phase 5 — Integrated System Simulation
     Governs end-to-end integration of the project systems and their coordinated
     system-level simulation. Its internal steps are reserved for the authorized
     Phase 4-to-Phase 5 handoff.

   PHASE 1 — TEN-STEP WORK BREAKDOWN AND DEPENDENCY OVERLAY
     Step 1 — Establish the Governing Inputs and Assumptions Baseline:
       Register constants, base-material properties, design assumptions and
       operating inputs; validate readiness; establish separate Pole 1/Pole 2
       operating registers.
     Step 2 — Establish Natural Force and Torque Equilibrium:
       Calculate patch-integrated radiation pressure, distributed gravity,
       complete mass accounting, natural force and torque behavior, and the
       controlled outward-force/mass-growth objective.
     Step 3 — ICARUS Redesign Sizing and Dynamic Verification:
       Administratively closed by user authorization. Technical completion is
       not asserted. Every unfinished station-sizing, force/torque, membrane-load,
       actuator and attitude-dynamics task is carried into Step 4.
     Step 4 — Complete ICARUS Carryover, Collector Geometry, and Distributed
       Physical Loading [CURRENT]:
       A. Complete per-pole station demands, four-station wrench allocation,
          membrane load transfer, conditional redesign force sizing, quaternion
          and rigid-body response, stability/recovery screening, and an explicit
          list of external actuator qualification requirements.
       B. Establish the three-dimensional curved-sheet patch model, local surface
          normals and incidence angles, patch areas, optical momentum transfer,
          distributed solar gravity, mass-point moments, and the connection from
          station loads into the collector surface and dynamics.
     Step 5 — Complete the Material, Membrane, and Structural Architecture:
       Establish the ultrathin aluminum architecture, structural load paths, wire-
       supported ribs, span-dependent foil thickness, backside thin-film comparison,
       stiffness/strength and complete component mass accounting.
     Step 6 — Complete Optical and Thermal Behavior:
       Resolve material optical properties, absorbed/reflected/transmitted energy,
       radiative/conductive thermal behavior, component temperatures and the effect
       of temperature on material, electrical and structural limits.
     Step 7 — Complete Photovoltaic Collection and Electrical Production:
       Finalize PV layout and nodes, intra-node connections, inter-node buses,
       conductor length/gauge, topology, voltage/current, resistive losses, wiring
       heating, conductor mass, and gross/net output for each pole.
     Step 8 — Complete Integrated Rotation, Control, Disturbance, and Operating
       Behavior:
       Integrate the final geometry, structural, optical, thermal and electrical
       design with quaternion attitude, rotation, disturbances, ICARUS response,
       recovery and independent long-duration pole behavior.
     Step 9 — Perform Comprehensive Coupled Optimization:
       Co-optimize mutable geometry, orbit, PV, electrical, material, thermal and
       control variables against each pole's own force, torque, structural, thermal,
       actuator and operating constraints; report per-pole results and scalar sums.
     Step 10 — Complete Integrated Verification, Co-Simulation, and Phase 2 Handoff:
       First execute and verify the complete Mathematica-native system, then establish
       a reproducible baseline. Only after that baseline may measured workloads be
       profiled and suitable persistent, concurrent, bidirectional co-simulation
       workers be implemented and checked against the native results.

   ACTIVE MODEL INVENTORY — WHAT, WHY AND HOW
     Curved geometry and surface mesh:
       WHAT: A spherical-cap collector surface is represented by annular/azimuthal
       patches with stable identities, local position, unit normal, projected area
       and curved area. WHY: Patch orientation and position determine optical loading,
       gravity-gradient effects, moments and structural load transfer. HOW: The mesh
       samples the cap using its generating-sphere geometry and records an area
       quadrature comparison against the analytic curved area.
     Local incidence and optical response:
       WHAT: Every patch carries its own solar incidence cosine and angle. WHY: A
       single mean cell angle cannot represent a curved collector. HOW: The local
       normal is dotted with the pole's Sun direction; unilluminated patches are
       clipped, and material R/A/T fractions close the incident-energy ledger.
     Photon momentum and absorbed heat:
       WHAT: Each illuminated patch receives absorption and specular-reflection
       momentum transfer and absorbed optical heat. WHY: Radiation force sets the
       outward mass-growth margin; patch moments affect attitude and station demand.
       HOW: Local flux, incidence, area, absorptivity and reflectivity are applied
       patchwise and summed without combining the poles.
     Distributed solar gravity and mass properties:
       WHAT: Sheet patches, perimeter hardware and ICARUS stations form separately
       identified mass points. WHY: Position-dependent gravity creates both resultant
       force and gravity-gradient torque. HOW: Each mass point is placed at its
       current heliocentric location, its inverse-square force is calculated, and
       its centre-of-mass moment is included in the pole's gravity ledger.
     Natural outward-force and future-payload margin:
       WHAT: Radiation-only radial force is compared with inward solar gravity, and
       the remaining force is converted into a maximum additional mass. WHY: Phase 1
       must leave deliberate payload headroom for later structural/hardware additions.
       HOW: The incremental capacity is divided by local solar gravitational
       acceleration; the initial target is 10% of each pole's own current mass.
       Solar-wind pressure is reported but receives no added-mass capacity credit.
     ICARUS force allocation and membrane load transfer:
       WHAT: Four stations provide twelve force components against a six-component
       assembly wrench; station resultants are spread to surface patches. WHY: The
       actuator demand must be connected to membrane load paths and moments. HOW:
       The full-rank wrench matrix maps desired force/torque into station forces, and
       the GaussianMomentCorrected distribution preserves total force and moment.
       Reported r x F values are assembly-COM moment contributions, not actuator
       drive torque.
     Rigid-body and attitude dynamics:
       WHAT: The pole's translation, velocity, quaternion attitude and angular
       velocity evolve under radiation, distributed gravity, solar-wind/CME loads
       and ICARUS control. WHY: Station loads, stability and recovery depend on the
       actual moving orientation and position. HOW: Thirteen scalar dependent
       functions are solved by the Mathematica native ODE model; vector states are
       reconstructed for each numeric right-hand-side evaluation.
     Structural, thermal, PV and electrical interfaces:
       WHAT: Step 4 supplies geometry, load and mass interfaces to later material,
       thermal and electrical work. WHY: Foil/wire spacing, backside reinforcement,
       cell wiring, I^2 R heating and final net power depend on those shared inputs.
       HOW: Those detailed constitutive, thermal and two-tier network calculations
       are assigned to Steps 5, 6 and 7. Their final design or qualification is not
       inferred from the present Step 4 screening model.

   INTERACTIVE CONTROLS
     The package exposes dynamic InputFields, not Manipulate sliders or automatic
     range controls. The shared panel edits only common design/material keys. Its
     Apply button passes changed values through immutable-constant/material checks
     and invalidates both pole caches when a permitted shared value changes; Reload
     discards local edits and restores the current shared register. The per-pole
     panel edits only one pole's operating register. Apply changes that one pole and
     invalidates only its cache; Reload restores that pole's register; Calculate
     this pole invokes that pole's isolated calculation. Pole selection is a view
     convenience and never shares operating state.

   Package interface:
     Context: Phase1PolarCollector`
     Implementation helpers and runtime state live in Phase1PolarCollector`Private`.
     Load with: Get["Phase1_Polar_Collector_v11_27_M08_step3_reviewed_candidate(8)(1).wl"];

   Governing two-pole architecture:
     Exactly two physically separate collector systems, one at each pole. They share
     design/material definitions only. Their operating inputs, environment, disturbances,
     initial conditions, controllers, dynamics, caches, results, optimization, and
     acceptance decisions are independent. Each pole's calculations execute in an
     isolated local state. Aggregate mass/area/power are reporting-only scalar sums and
     never feed either pole's operation. No combined mechanical equilibrium is imposed.

   Governing objective:
     Maximize useful photovoltaic power independently for each pole. The natural-load
     objective is a controlled outward Sun-radial radiation margin (radiation force alone
     exceeds inward solar gravity); solar-wind force is separately reported and included
     in the net-load calculation but cannot substitute for the required radiation surplus.
     Transverse force and natural torque residuals remain controlled within model tolerances. The outward surplus is
     retained as capacity for future added mass; it is NOT mislabeled as zero-net-force
     equilibrium. Thermal, dynamic, actuator, and structural constraints remain separate
     and are evaluated within their assigned Phase 1 steps.

   Input and synthetic-assumption policy (user-approved for this project and chat):
     PoleCount = 2 is fixed by the user-confirmed architecture. Design, material, operating,
     disturbance, model-form and acceptance values may be populated with carefully bounded
     synthetic engineering assumptions when no suitable mathematical approximation or
     reference value exists. Search for a defensible equation or approximation first; then
     use an explicit approved assumption. Check consequences upstream and downstream and
     keep the two pole systems operationally independent. Synthetic changes to existing
     properties must remain slight by default. A 10% change is used here as a provisional
     screening heuristic where a baseline exists, not as a user-specified universal limit;
     larger changes require a specific physical/model rationale and explicit review. Mark every synthetic value and its basis in the assumption register
     and beside the corresponding code. These values are not measurements, supplier
     specifications, material allowables or qualifications. The user specifically approves
     the Phase 1 assumption that ICARUS actuator capability can be achieved by modest
     mission-specific reengineering. The present hardware is not mission-qualified. Phase 1
     may calculate a redesign target but must not claim current hardware already has it.
     Per-pole station coordinates and SEP fluence remain derived from current geometry and
     each pole's independent distance. Numerical settings and published constants are
     separately classified.

   Numerical model limits:
     This is a Phase 1 engineering-screening model, not a qualified flight design.
     Geometry, mass distribution, membrane constitutive response, and station-to-membrane
     load transfer remain explicit reduced-order model choices. Attitude dynamics include
     classical rigid-body gravity-gradient torque and a small-angle mode linearization;
     flexible-body deformation and material damping are not established by that model.
     The model is not CAD-derived geometry, validated finite-element stress analysis, or
     qualified actuator performance unless replaced by the corresponding engineering models.

   PROJECT-WIDE CO-SIMULATION DEVELOPMENT RULE — APPROVED, IMPLEMENTATION DEFERRED
     All future development specifically intended to support Mathematica-driven simulations
     across this project must be designed with concurrent external co-simulation in mind.
     Persistent external executables and/or programs written in suitable compiled or
     interpreted languages may run side-by-side with the Mathematica kernel, perform their
     assigned numerical work concurrently, and exchange state and results bidirectionally
     during a running simulation. This is a project-wide architectural rule for simulation
     development, not authorization to introduce external execution into the current baseline.

     REQUIRED IMPLEMENTATION SEQUENCE:
       1. First complete, load, execute, test, and verify the Phase 1 source in its current
          Mathematica-native state. Establish a functioning and reproducible baseline before
          changing its execution architecture.
       2. Only after that baseline works, examine Phase 1's actual runtime calculations and
          dependencies to determine which workloads benefit from outsourcing while a simulation
          is running. Profile and benchmark before moving calculations.
       3. Introduce external workers incrementally, retaining the verified Mathematica baseline
          and comparing worker outputs against it before any worker becomes authoritative for
          an accepted result. Do not implement co-simulation merely for architectural novelty.

     OWNERSHIP AND INTERFACE RULES FOR FUTURE CO-SIMULATION:
       - Mathematica remains the governing mathematical/engineering authority and simulation
         coordinator unless a later, explicit project decision changes that responsibility.
         It owns governing model definitions, shared inputs, dependency orchestration, simulation
         time coordination, cross-subsystem convergence policy, final validation, and acceptance.
       - External workers may own explicitly partitioned high-volume numerical calculations
         (for example mesh/patch operations, radiation integration, electrical networks, thermal
         submodels, structural numerical work, or parallel candidate evaluations) and may run
         concurrently with Mathematica and with other independent workers. Work partitioning
         must be based on measured computational benefit and a clearly defined mathematical
         responsibility; tightly coupled calculations must not be split in a way that breaks
         their governing equations or convergence.
       - Simulation exchanges must be structured, versioned, unit-explicit, and traceable to a
         simulation time/step, job identifier, model/schema version, and pole identifier where
         applicable. Results must carry completion/error status and numerical-quality information.
       - No stale, partial, mismatched-time, wrong-pole, or failed-worker result may silently
         enter a simulation state. Coupled subsystems must synchronize and iterate to the defined
         convergence criteria before a simulation step advances. Worker failure must cause a
         controlled retry, fallback to a validated Mathematica calculation, or explicit stop.
       - The two pole systems remain physically and operationally independent. Workers must
         receive and return pole-scoped data; no shared operating state, cache, controller,
         dynamics, or mechanical equilibrium may be introduced between the poles. Shared
         design/material definitions may be distributed read-only where appropriate.
       - Critical force, torque, energy, mass, power, and equilibrium results require independent
         checks against Mathematica reference calculations or approved benchmark cases. Numerical
         precision, scaling, conservation, convergence, and reproducibility requirements remain
         in force regardless of the language used by a worker.
       - Prefer native Mathematica execution for symbolic work, exact arithmetic, high-precision
         verification, model orchestration, and workloads where external communication overhead
         outweighs computational savings. Use external programs only where profiling shows a
         justified advantage in throughput, memory use, parallelism, or specialized capability.
       - Phase boundaries must use explicit input/output contracts. Phase 0 supplies versioned
         governing inputs to Phase 1; Phase 1 supplies validated, pole-separated outputs to Phase 2.
         Future external workers must not bypass these phase contracts or mutate another phase's
         state without an explicit interface.

     CURRENT STATUS: No external executable, co-simulation process, WSTP/Socket worker, or
     external numerical engine is implemented or invoked by this rule. Finish and verify the
     current Mathematica-native Phase 1 model first. Co-simulation design and implementation
     are a subsequent, separately reviewed activity after the working baseline is established.

   Recommended Step 4 sequence (Mathematica-kernel execution and testing are now user-authorized):
     Phase1InputRequirements[];
     Phase1InputStatus[];
     Phase1RunSoftwareSelfTests[];
     Phase1PoleIndependenceAudit[];
     Phase1InteractivePanel[];
     Phase1PoleOperatingInputPanel["Pole1"];
     Phase1PoleOperatingInputPanel["Pole2"];
     (* Enter required shared design/material values and separate pole operating values. *)
     Phase1InputStatus[];
     (* After the readiness gate passes, execute the Step 4 assessment independently for both poles. *)
     Phase1RunStep4Assessment[];
     (* Do not invoke the complete electrical/power pipeline here; its network dependency belongs to Step 7. *)
   ======================================================================== *)

BeginPackage["Phase1PolarCollector`"];
Phase1ApplyOptimizationCandidate::usage = "Phase1ApplyOptimizationCandidate is part of the Phase1PolarCollector package API.";
Phase1ComputeAll::usage = "Phase1ComputeAll[] calculates Pole1 and Pole2 independently, then aggregates scalar results for reporting only.";
Phase1ComputePole::usage = "Phase1ComputePole[pole] calculates one pole in an isolated execution context.";
Phase1DistanceThermalFloor::usage = "Phase1DistanceThermalFloor is part of the Phase1PolarCollector package API.";
Phase1DisturbanceScenarios::usage = "Phase1DisturbanceScenarios is part of the Phase1PolarCollector package API.";
Phase1DynamicInitialConditions::usage = "Phase1DynamicInitialConditions is part of the Phase1PolarCollector package API.";
Phase1FreeRotationTrajectory::usage = "Phase1FreeRotationTrajectory is part of the Phase1PolarCollector package API.";
Phase1GetDerived::usage = "Phase1GetDerived is part of the Phase1PolarCollector package API.";
Phase1GetInput::usage = "Phase1GetInput is part of the Phase1PolarCollector package API.";
Phase1GetInputs::usage = "Phase1GetInputs is part of the Phase1PolarCollector package API.";
Phase1GetPoleDerived::usage = "Phase1GetPoleDerived is part of the Phase1PolarCollector package API.";
Phase1GetPoleInputs::usage = "Phase1GetPoleInputs is part of the Phase1PolarCollector package API.";
Phase1GetPoleResult::usage = "Phase1GetPoleResult is part of the Phase1PolarCollector package API.";
Phase1GetPoleResults::usage = "Phase1GetPoleResults is part of the Phase1PolarCollector package API.";
Phase1GetPoleState::usage = "Phase1GetPoleState is part of the Phase1PolarCollector package API.";
Phase1GetResult::usage = "Phase1GetResult is part of the Phase1PolarCollector package API.";
Phase1GetResults::usage = "Phase1GetResults is part of the Phase1PolarCollector package API.";
Phase1GetSharedInputs::usage = "Phase1GetSharedInputs is part of the Phase1PolarCollector package API.";
Phase1GetState::usage = "Phase1GetState is part of the Phase1PolarCollector package API.";
Phase1ICARUSControlLaw::usage = "Phase1ICARUSControlLaw is part of the Phase1PolarCollector package API.";
Phase1ICARUSLoadPropagation::usage = "Phase1ICARUSLoadPropagation is part of the Phase1PolarCollector package API.";
Phase1ICARUSRedesignSizing::usage = "Phase1ICARUSRedesignSizing[pole] derives and tests a conditional mission-specific ICARUS actuator force-capacity target for one independent pole; it is not hardware qualification.";
Phase1InputRequirements::usage = "Phase1InputRequirements[] reports input categories and required values for the shared design/material register and each pole.";
Phase1ApprovedAssumptions::usage = "Phase1ApprovedAssumptions[] reports user-approved assumptions, derived assumption-based values, and unresolved qualification items.";
Phase1MaterialScenarioPresets::usage = "Phase1MaterialScenarioPresets[] reports the continuous aluminum-film baseline and conditional backside-film comparison rule.";
Phase1TaskInputStatus::usage = "Phase1TaskInputStatus[] reports task-specific input readiness for the selected pole; Phase1TaskInputStatus[task] reports one task; Phase1TaskInputStatus[pole,task] reports one explicit pole/task combination, including whether a supported independent setup task has executed with current inputs.";
Phase1InputStatus::usage = "Phase1InputStatus[] reports missing required values.";
Phase1IntegratedSimulation::usage = "Phase1IntegratedSimulation is part of the Phase1PolarCollector package API.";
Phase1InteractivePanel::usage = "Phase1InteractivePanel is part of the Phase1PolarCollector package API.";
Phase1JointOptimization::usage = "Phase1JointOptimization is part of the Phase1PolarCollector package API.";
Phase1LoadState::usage = "Phase1LoadState is part of the Phase1PolarCollector package API.";
Phase1LocalRadiationLoads::usage = "Phase1LocalRadiationLoads is part of the Phase1PolarCollector package API.";
Phase1LocalSurfaceMesh::usage = "Phase1LocalSurfaceMesh is part of the Phase1PolarCollector package API.";
Phase1MassBalance::usage = "Phase1MassBalance is part of the Phase1PolarCollector package API.";
Phase1MissingRequiredInputs::usage = "Phase1MissingRequiredInputs is part of the Phase1PolarCollector package API.";
Phase1Phase2Handoff::usage = "Phase1Phase2Handoff is part of the Phase1PolarCollector package API.";
Phase1PoleIndependenceAudit::usage = "Phase1PoleIndependenceAudit is part of the Phase1PolarCollector package API.";
Phase1PoleOperatingInputPanel::usage = "Phase1PoleOperatingInputPanel is part of the Phase1PolarCollector package API.";
Phase1PowerLedger::usage = "Phase1PowerLedger is part of the Phase1PolarCollector package API.";
Phase1Reset::usage = "Phase1Reset is part of the Phase1PolarCollector package API.";
Phase1RunBothPoleAssessments::usage = "Phase1RunBothPoleAssessments is part of the Phase1PolarCollector package API.";
Phase1RunFullAssessment::usage = "Phase1RunFullAssessment is part of the Phase1PolarCollector package API.";
Phase1RunStep4Assessment::usage = "Phase1RunStep4Assessment[] runs the Step 4 ICARUS carryover, geometry, distributed loading and dynamic assessment independently for both poles; Phase1RunStep4Assessment[pole] runs one pole only.";
Phase1RunStep5StructuralArchitecture::usage = "Phase1RunStep5StructuralArchitecture[pole,step4Assessment,ribSpacing,ribRunSpan,intraNodeConnectorInput,interNodeRibInput] evaluates one pole's Step 5 span-dependent aluminum panel with membrane-pretension stress/deflection coupling, patchwise panel screen, optional supplied intra-node tab/solder connector record with per-item qualification flags and traceable report references, and optional per-run inter-node conductor/anchor record with a separate shared AnchorRecords register. Each actual inter-node run may include supplied TributaryPatchShares entries with PatchIndex and AreaShare to integrate both its allocated Step 4 patch-normal pressure load and patchwise tangential-traction magnitude over the same curved patch areas; every Step 4 patch share must close to one across the complete rib set, and both integrated load categories must independently conserve across the rib set. The cable demand uses a conservative sum of normal and tangential line-load magnitudes because direction-resolved rib projection is not yet available. Each run must separately carry TributaryGeometryMappingEvidencePassed=True and a non-empty TributaryGeometryEvidenceReference identifying the independently established rib/tributary geometry; the source does not derive that geometry from the shares. Without patch shares the peak normal-plus-tangential load envelope is provisional and blocks Step 5 acceptance. The mechanical capacity and axial-rigidity model conservatively credits one physical conductor unless a larger effective load-bearing strand count is supported by a per-run evidence flag and traceable reference; all physical conductors are included in conductor-metal mass; insulation mass is calculated separately from the supplied per-run InsulationLinearMass_kg_per_m input. Each run must provide MinimumOperatingHorizontalTensionAcrossCases_N as a positive lower bound over the complete same-pole operating envelope, HorizontalTensionEvidencePassed=True, and a non-empty HorizontalTensionEvidenceReference. Each run must also provide MaximumEffectiveTransverseAccelerationAcrossCases_m_s2 as a finite nonnegative upper bound on the acceleration component perpendicular to the run axis over the complete same-pole operating envelope, TransverseAccelerationEvidencePassed=True and a non-empty TransverseAccelerationEvidenceReference. The source derives the conductor-plus-insulation linear mass from physical conductor count, per-strand area and density, plus the supplied insulation linear mass; it multiplies this by the supplied effective transverse-acceleration bound and adds the resulting cable self-mass/inertial line load to the integrated surface-load envelope. Both the capacity-design load and the q L^2/(8 H_min) small-sag operating-sag estimate use that combined line load when evidence is complete. Without the acceleration bound and its evidence, only a clearly labelled surface-load partial screen is produced and the run cannot pass. The routine does not independently derive or authenticate the supplied acceleration/tension evidence. The existing MinimumOperatingCableTensionAcrossCases_N tautness record remains separately required. Missing horizontal-tension evidence blocks the structural rib screen; neither tension record is derived or independently authenticated by this routine. Each run may request an EffectiveLoadBearingConductorCount between one and its physical ConductorCountPerRun; more than one conductor is credited for tensile capacity and axial rigidity only when ConductorLoadSharingEvidencePassed=True and a non-empty ConductorLoadSharingEvidenceReference are supplied. Without that evidence the source conservatively credits one conductor for mechanical capacity/EA while retaining all physical conductors in the conductor-metal mass calculation, and records a Step 5 blocker. The tautness flag/reference are user-supplied evidence claims and are not independently verified by this source routine. The intra-node connector screen assumes equal sharing across the supplied tabs per connection and requires per-connection load demands; its evidence flags/references are user-supplied and not independently authenticated. This routine does not choose AWG, calculate current/I2R, execute Step 4, mutate active mass inputs, or invoke tests/simulations.";
Phase1RunPoleAssessment::usage = "Phase1RunPoleAssessment is part of the Phase1PolarCollector package API.";
Phase1RunPoleTask::usage = "Phase1RunPoleTask is part of the Phase1PolarCollector package API.";
Phase1RunReport::usage = "Phase1RunReport is part of the Phase1PolarCollector package API.";
Phase1RunSelfTests::usage = "Phase1RunSelfTests[] runs software-only tests and, when inputs are complete, calculation-integrity tests for each pole.";
Phase1RunSoftwareSelfTests::usage = "Phase1RunSoftwareSelfTests[] runs software-only synthetic tests without requiring project inputs or mutating project state.";
Phase1SaveState::usage = "Phase1SaveState is part of the Phase1PolarCollector package API.";
Phase1SelectPole::usage = "Phase1SelectPole is part of the Phase1PolarCollector package API.";
Phase1SetInputs::usage = "Phase1SetInputs[values] updates shared design/material and model inputs.";
Phase1SetPoleOperatingInputs::usage = "Phase1SetPoleOperatingInputs[pole, values] updates only the selected pole operating register. Pole must be \"Pole1\" or \"Pole2\".";
Phase1SolveExactEquilibrium::usage = "Phase1SolveExactEquilibrium is part of the Phase1PolarCollector package API.";
Phase1StabilityCriteria::usage = "Phase1StabilityCriteria is part of the Phase1PolarCollector package API.";
Phase1ThermalScreen::usage = "Phase1ThermalScreen is part of the Phase1PolarCollector package API.";
Phase1TimeDependentPower::usage = "Phase1TimeDependentPower is part of the Phase1PolarCollector package API.";
Phase1Validate::usage = "Phase1Validate is part of the Phase1PolarCollector package API.";
Phase1WobbleSimulation::usage = "Phase1WobbleSimulation is part of the Phase1PolarCollector package API.";
Begin["`Private`"];

(* Clear only implementation symbols on reload; exported usage messages remain. *)
ClearAll["Phase1PolarCollector`Private`*"];
$Phase1ModelVersion = "11.142";
$Phase1CalculationCoreSchemaVersion = "11.10";

(* ========================================================================
   POLAR COLLECTOR — PHASE 1 WOLFRAM LANGUAGE MODEL
   Revision: v11.136 — Step 4 runtime-verification record and schema compatibility

   Governing objective:
     Maximize useful photovoltaic output independently for each pole while
     maintaining a strictly positive Sun-radial solar-radiation-pressure surplus
     over inward solar gravity. Transverse force and natural torque residuals are
     constrained separately. Exact zero-net-force solutions are diagnostics, not
     the governing target. Thermal, dynamic, actuator and structural limits remain
     independent acceptance constraints.

   IMPORTANT MODEL STATUS:
     This is a Phase 1 engineering-screening model, not a qualified flight design.
     PoleCount = 2 is the user-confirmed architecture. All populated design/material and
     pole-specific operating values from the reviewed 142-input register are user-approved
     assumptions, identified by Phase1ApprovedAssumptions[]. They are not measurements,
     supplier specifications, material allowables, forecasts or qualifications. The approved
     reflector solar reflectivity target is 99.9%; the free-standing PV specific-power
     reference is 730 W/kg. The current substrate screening baseline is continuous 1060-O
     aluminum film with areal mass derived from thickness times density; its ultrathin-film
     properties are not qualified. Numerical execution settings are identified separately
     from physical assumptions. Reference constants and standardized PV test conditions
     remain reference definitions, not collector operating inputs.
     Mathematica calculates all derived values, integrations, solves, optimizations and checks at runtime.

     Get["Phase1_Polar_Collector_v11_27_M08_step3_reviewed_candidate(8)(1).wl"];
     (* Review readiness, approved assumptions and unresolved qualification items. *)
     Phase1InputStatus[];
     Phase1InputRequirements[];
     Phase1ApprovedAssumptions[];
     Phase1MaterialScenarioPresets[];
     Phase1MissingRequiredInputs[];
     Phase1InteractivePanel[];
     Phase1PoleOperatingInputPanel["Pole1"];
     Phase1PoleOperatingInputPanel["Pole2"];
     Phase1PoleIndependenceAudit[];
     (* Review or change assumptions separately in each pole operating register. *)
     Phase1ComputeAll[];
     Phase1Validate[];
     Phase1RunSelfTests[];
     Phase1JointOptimization[];
     Phase1RunFullAssessment[];
     Phase1RunReport[];

   This source implements two operationally independent pole systems. Their design and material assumptions are shared; their operating assumptions, state, controls, disturbances, dynamics, caches and results are separate. PoleCount = 2 is fixed by the user-confirmed architecture. Fundamental constants and intrinsic selected base-material properties are immutable in the input API. The initial per-pole future payload-mass headroom target is 10% of current modeled pole mass and remains a mutable screening assumption. ICARUS force demand is calculated per station; hardware qualification is not claimed.
   ======================================================================== *)

(* ========================================================================
   1. CENTRAL INPUT REGISTER — sole source of model inputs
   Shared design/material inputs are stored here. Each pole has a separate operating
   register. Automatic geometry/fluence entries resolve from the approved assumptions
   when read by calculations; derived values are never written across pole registers.
   ======================================================================== *)

$Phase1DefaultInputs = <|
  (* Widely accepted reference constants. Solar quantities are IAU 2015 nominal
     conversion constants; G, c, mp and sigma are CODATA/SI values. TSI is a
     nominal reference, not a time-invariant solar measurement. *)
  "SolarLuminosity_W" -> 3.828*10^26,
  "SolarGravitationalParameter_m3_s2" -> 1.3271244*10^20,
  "UniversalGravitationalConstant_m3_kg_s2" -> 6.67430*10^-11,
  "SolarIrradianceAt1AU_W_m2" -> 1361.,
  "SpeedOfLight_m_s" -> 299792458.,
  "AstronomicalUnit_m" -> 149597870700.,
  "Year_s" -> 365.25*86400., (* Julian year: exactly 365.25 days by convention. *)
  "StefanBoltzmann_W_m2_K4" -> 5.670374419*10^-8,
  "CentimetersPerMeter" -> 100.,
  "ProtonMass_kg" -> 1.67262192595*10^-27,

  (* Numerical settings below are user-approved calculation settings, not measured
     collector properties. Engineering/model values populated below are user-approved
     assumptions from the 142-input assessment. They are not measurements, qualifications,
     or guaranteed operating performance. *)
  "CircularMembraneDeflectionCoefficient" -> 4.0,
  "MeshAreaRelativeTolerance" -> 1.0*10^-4,
  "AccelerationCrossCheckRelativeTolerance" -> 1.0*10^-6,
  "SolarReferenceConsistencyRelativeTolerance" -> 1.0*10^-3,
  "ThermalResidualRelativeTolerance" -> 1.0*10^-5,
  "QuaternionNormalizationTolerance" -> 1.0*10^-10,
  "OpticalClosureTolerance" -> 1.0*10^-12,
  "PowerLedgerRelativeTolerance" -> 1.0*10^-9,
  "ICARUSLoadMapRelativeTolerance" -> 1.0*10^-6,
  "MeshCoefficientCrossCheckTolerance" -> 1.0*10^-3,
  "OptimizerGridCrossCheckRelativeTolerance" -> 1.0*10^-2,
  "NumericalWorkingPrecision" -> MachinePrecision,
  "OptimizerMaxIterations" -> 1000,
  "PVThermalCouplingMaxIterations" -> 100,
  "OptimizerGridPointCount" -> 41,
  "OptimizerCoverageGridPointCount" -> 41,
  "MeshRadialCount" -> 20,
  "MeshAzimuthCount" -> 64,
  "OptimizerMeshRadialCount" -> 10,
  "OptimizerMeshAzimuthCount" -> 32,
  "DynamicAccuracyGoal" -> 8,
  "DynamicPrecisionGoal" -> 8,
  "DynamicMaxSteps" -> Infinity,
  "DynamicSampleCount" -> 201,
  "DynamicLoadPropagationSampleCount" -> 51,
  (* PoleCount is fixed at the user-confirmed two-system architecture. Other project-specific
     populated values below are user-approved assumptions, not measured specifications. *)
  "PoleCount" -> 2,
  "ICARUSStationCount" -> 4,
  "ICARUSStationCountScope" -> "PerPoleAssembly",
  "ReflectorSolarReflectivity" -> 0.999, (* User-approved 99.9% target assumption; not measured coating performance. *)
  "ProjectTargetEfficiency" -> 0.20,
  "PVSpecificPowerReferenceIrradiance_W_m2" -> 1000., (* PV standard test irradiance, IEC 60904 series. *)
  "PVReferenceTemperature_K" -> 298.15, (* 25 deg C PV standard test temperature. *)
  "PVScenarioOptions" -> {"PVCellArraySpecificPowerLimited","PVCellReferenceEfficiency","ProjectSpecifiedTargetEfficiency"},
  "PVLayoutModel" -> "UniformSurfaceCoverage",
  "GeometryProfileModel" -> "SphericalCapSurrogate",
  "MassDistributionModel" -> "UniformSheetMassWithPerimeterLineMassAndStationPointMasses",
  "FlareTemporalProfile" -> "GaussianFWHM",
  "CMETemporalProfile" -> "RectangularPressureEnvelope",
  "ICARUSLoadTransferModel" -> "GaussianMomentCorrected",
  "MembraneStructuralModel" -> "TensionedCircularMembrane",
  "SpinTrackingEnabled" -> False,
  "WobbleRestoringModel" -> "NonlinearGravityGradientRigidBody",
  "PVSearchRange" -> {0.,1.},
  "ReflectionModel" -> "Specular",
  "DeferredEquipmentMass_kg" -> 0.0,
  (* This 10% per-pole reserve is a synthetic Phase 1 screening target for future
     structural/payload mass. It is a mutable design constraint, not a committed
     downstream payload estimate or a qualified safety factor. *)
  "FutureAddedMassTargetFractionOfCurrentMass" -> 0.10,
  "OtherInstalledArealMass_kg_m2" -> 0.0,
  "PerimeterHardwareLinearMass_kg_m" -> 0.001,
  "InitialPositionLocal_m" -> {0.,0.,0.},
  "InitialVelocityLocal_m_s" -> {0.,0.,0.},
  "InitialVelocityHeliocentric_m_s" -> {0.,0.,0.},
  "HeliocentricReferenceMotionMode" -> "StaticHover",
  "InitialAttitudeSmallAngles_rad" -> {0.,0.,0.},
  "IncidenceAngle_deg" -> 0.0,

  (* Remaining project-specific design/material/operating values are populated from the
     user-approved assumption register below. Values are explicitly labelled as assumptions
     in Phase1ApprovedAssumptions[] and remain subject to validation and replacement. *)
  "Distance_m" -> 29919574140.0,
  "PerPoleProjectedArea_m2" -> 6.0821044*10^17,
  "CapDepthToPlanformRadius" -> 0.10,
  "PVFraction" -> 0.005,
  "ReflectorSolarTransmissivity" -> 0.0,
  "PVSolarReflectivity" -> 0.05,
  "PVSolarTransmissivity" -> 0.05,
  "PVArealMass_kg_m2" -> 0.052,
  "PVCellArraySpecificPower_W_kg" -> 730., (* User-approved free-standing PV reference assumption. *)
  "PrimaryPVScenario" -> "PVCellArraySpecificPowerLimited",
  "PVCellArrayMassPolicy" -> False, (* PV devices sit on the continuous aluminum film; they do not replace it. *)
  "ReflectorArealMass_kg_m2" -> 0.00027,
  (* Current structural base is a continuous ultrathin aluminum film. The 0.1 um
     thickness is a provisional starting assumption only; it is mutable and has
     not been structurally optimized, manufactured, tested or qualified. The PV
     array is mounted on top of this continuous base; PV device mass does not
     replace the supporting aluminum film. *)
  "AluminumFoilThickness_m" -> 1.0*10^-7,
  "AluminumDensity_kg_m3" -> 2705.0,
  "AluminumYoungsModulus_Pa" -> 69.0*10^9,
  "AluminumPoissonRatio" -> 0.33,
  "AluminumYieldStrength_Pa" -> 28.0*10^6,
  "AluminumTensileStrength_Pa" -> 69.0*10^6,
  "AluminumElectricalResistivity_Ohm_m" -> 27.8*10^-9,
  "CopperDensity_kg_m3" -> 8890.0,
  "CopperElectricalResistivity_Ohm_m" -> 1.7241*10^-8,
  "MembraneSubstrateMaterialName" -> "1060-O aluminum foil; provisional ultrathin-film baseline",
  "MembraneSubstrateMaterialClass" -> "AluminumFilm",
  "WiringArealMass_kg_m2" -> 0.0001,
  (* Synthetic mass-budget choice under the user-authorized modest-variation policy: +10%
     The selected 0.55 kg per-station value is a provisional synthetic mass-budget
     assumption, not a separately specified user value or a measured actuator mass. *)
  "ICARUSStationMass_kg" -> 0.55,
  "ICARUSRedesignFeasibilityApproved" -> True,
  "ICARUSRedesignForceReserveFraction" -> 0.10,
  "ICARUSStationPositionsLocal_m" -> Automatic,
  "PVCellReferenceEfficiency" -> 0.047,
  "PVCellArrayEfficiencyReference" -> 0.052,
  "PVEfficiencyTemperatureCoefficient_perK" -> -0.004,
  "TransferEfficiency" -> 0.95,
  "ConditioningEfficiency" -> 0.95,
  "ReflectorIRemissivity" -> 0.255,
  "PVIRemissivity" -> 0.85,
  "BothSidesRadiate" -> True,
  "PVTemperatureLimit_K" -> 343.15,
  "ReflectorTemperatureLimit_K" -> 343.15,
  "ICARUSStationForceCapacity_N" -> Automatic,
  "ControllerTranslationKp_perS2" -> 1.71468*10^-8,
  "ControllerTranslationKd_perS" -> 1.85185*10^-4,
  "ControllerAttitudeKp_perS2" -> 1.71468*10^-8,
  "ControllerAttitudeKd_perS" -> 1.85185*10^-4,
  "MembraneLoadSpreadFractionOfRadius" -> 0.05,
  "InitialAngularVelocity_rad_s" -> {0.,0.,0.},
  "WobbleDampingRatio" -> 0.0,
  (* The structural constitutive model reads density and elastic modulus directly
     from the immutable aluminum material register above. The 1060-O reference
     strength values are bulk wrought-sheet data; applying them to a 0.1 um film is
     an explicit screening approximation, not a thin-film allowable or qualification.
     The initial pretension is a small
     synthetic deployment placeholder, not a specified installed membrane tension. *)
  "MembranePretension_N_m" -> 0.1,
  "StructuralSafetyFactor" -> 2.0,
  "MaximumDeflectionFractionOfRadius" -> 0.05,
  (* Step 5 screening controls. Panel deflection is limited to 1% of the unsupported
     foil span between adjacent wiring ribs; the tensioned-rib sag is limited to 1%
     of its unsupported run span; and elastic extension is limited to 0.1% of run
     length. These are synthetic mutable screening assumptions, not universal
     physical limits or qualified hardware allowables. They must be reconciled with
     resumed/accepted Step 4 loading and the actual Step 7 conductor routing. *)
  "MaximumPanelDeflectionFractionOfRibSpacing" -> 0.01,
  "MaximumStructuralRibSagFractionOfRunSpan" -> 0.01,
  "MaximumStructuralRibElasticExtensionFraction" -> 0.001,
  "FlarePeakFraction" -> 0.00028,
  "FlarePeakTime_s" -> 43200.0,
  "FlareDuration_s" -> 3600.0,
  "FlareTailCutoffFraction" -> 0.01,
  "CMEOnset_s" -> 86400.0,
  "CMEWindPressureMultiplier" -> 1260.0,
  "CMEDuration_s" -> 148320.0,
  "SolarWindProtonDensity_1AU_cm3" -> 5.0,
  "SolarWindSpeed_1AU_m_s" -> 4.0*10^5,
  "SEPDose_protons_cm2" -> Automatic,
  "SEPDoseReference_protons_cm2" -> 7.93*10^10,
  "PVDegradationPerSEPReferenceDoseFraction" -> 0.01,
  "PVAnnualDegradationFraction" -> 0.01,
  "ReflectivityAnnualLossFraction" -> 0.001,
  "ReferenceMissionYears" -> 5.0,
  "DistanceSearchRange_m" -> {0.1*149597870700.,5.0*149597870700.},
  "ExactEquilibriumRelativeTolerance" -> 1.0*10^-8,
  "RadialDeviationToleranceFractionOfRadius" -> 0.01,
  "LateralDeviationToleranceFractionOfRadius" -> 0.01,
  "AttitudeTolerance_rad" -> 0.0174533,
  "RecoveryTimeMaximum_s" -> 86400.0,
  "VelocityRecoveryTolerance_m_s" -> 1.0*10^-4,
  "AngularRateRecoveryTolerance_rad_s" -> 1.0*10^-7,
  "DynamicCheckDuration_s" -> 604800.0
|>;




$Phase1ReferenceAndSoftwareDefaultKeys = {
  "SolarLuminosity_W","SolarGravitationalParameter_m3_s2",
  "UniversalGravitationalConstant_m3_kg_s2","SolarIrradianceAt1AU_W_m2",
  "SpeedOfLight_m_s","AstronomicalUnit_m","Year_s",
  "StefanBoltzmann_W_m2_K4","CentimetersPerMeter","ProtonMass_kg",
  "PVSpecificPowerReferenceIrradiance_W_m2","PVReferenceTemperature_K",
  "PVScenarioOptions","PVSearchRange",
  "NumericalWorkingPrecision","DynamicMaxSteps","WobbleRestoringModel"
};

(* Published physical/reference constants, standardized PV test conditions, supported
   scenario labels, mathematical domains and safe Mathematica execution controls are
   reference/software definitions. User-approved numerical controls are listed separately
   from physical engineering assumptions by Phase1ApprovedAssumptions[]. *)
phase1ProjectInputKeys[] := Select[Keys[$Phase1DefaultInputs],
  !(MemberQ[$Phase1ReferenceAndSoftwareDefaultKeys,#] &&
    SameQ[Lookup[$Phase1State["Inputs"],#,Missing[]],Lookup[$Phase1DefaultInputs,#,Missing[]]])&];

$Phase1State = <|
  "SchemaVersion" -> "11.9",
  "Inputs" -> $Phase1DefaultInputs,
  "Derived" -> <||>,
  "Results" -> <||>,
  "AuditLog" -> {},
  "LastRun" -> Missing["NotRun"]
|>;

phase1StoreResult[name_String,value_] := Module[{updated},
  updated=Join[$Phase1State["Results"],<|name->value|>];
  $Phase1State=Join[$Phase1State,<|"Results"->updated|>];
  phase1Audit["CalculationResultStored",<|"ResultName"->name|>];
  value
];

Phase1GetInputs[] := $Phase1State["Inputs"];
Phase1GetInput[name_String] := Lookup[$Phase1State["Inputs"],name,Missing["UnknownInput",name]];
Phase1MissingRequiredInputs[] := Select[Keys[$Phase1State["Inputs"]], MissingQ[$Phase1State["Inputs"][#]] &];
(* ------------------------------------------------------------------------
   Mutable/immutable inventory and recursive design-space perturbation
   ------------------------------------------------------------------------
   Immutable entries are physical laws/constants, the fixed two-sheet topology,
   and intrinsic properties of the selected aluminum/copper/backside-film base
   materials. Every other model input is mutable. Numerical execution controls
   are inventoried as mutable but are not physical objective variables.
*)
$Phase1PoleIDs = {"Pole1", "Pole2"};
$Phase1PoleOperatingKeys = {
  "Distance_m", "DistanceSearchRange_m",
  "InitialPositionLocal_m", "InitialVelocityLocal_m_s",
  "InitialVelocityHeliocentric_m_s", "HeliocentricReferenceMotionMode", "InitialAttitudeSmallAngles_rad",
  "InitialAngularVelocity_rad_s", "IncidenceAngle_deg",
  "FlarePeakFraction", "FlarePeakTime_s", "FlareDuration_s", "FlareTailCutoffFraction", "FlareTemporalProfile",
  "CMEOnset_s", "CMEWindPressureMultiplier", "CMEDuration_s", "CMETemporalProfile",
  "ControllerTranslationKp_perS2", "ControllerTranslationKd_perS", "ControllerAttitudeKp_perS2", "ControllerAttitudeKd_perS",
  "SolarWindProtonDensity_1AU_cm3", "SolarWindSpeed_1AU_m_s",
  "SEPDose_protons_cm2", "ReferenceMissionYears", "DynamicCheckDuration_s"
};

$Phase1ImmutableInputNamePatterns = {
  (* Fixed topology, fundamental physical constants and conversion definitions, and
     intrinsic properties of the selected base conductors/films. Mission geometry,
     coating areal mass, foil thickness, pretension, reserves and operating limits
     remain mutable design variables. *)
  "PoleCount", "NumberOfPoles", "SheetCount", "SolarLuminosity", "SolarIrradianceAt1AU",
  "SpeedOfLight", "SolarGravitationalParameter", "GravitationalConstant", "StefanBoltzmann",
  "PlanckConstant", "BoltzmannConstant", "AstronomicalUnit", "Year_s",
  "CentimetersPerMeter", "ProtonMass",
  "AluminumDensity", "AluminumYoungsModulus", "AluminumPoissonRatio", "AluminumYieldStrength",
  "AluminumTensileStrength", "AluminumElectricalResistivity",
  "CopperDensity", "CopperElectricalResistivity", "AluminumMeltingPoint",
  "AluminumWireDensity", "AluminumWireResistivity",
  "BacksideFilmDensity", "BacksideFilmYoungsModulus", "BacksideFilmPoissonRatio",
  "StructuralRibYoungsModulus"
};
$Phase1ImmutableInputKeys = Select[Union[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys],
  Function[key, AnyTrue[$Phase1ImmutableInputNamePatterns, StringContainsQ[key,#]&]]];
$Phase1MutableInputKeys = Complement[Union[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys],$Phase1ImmutableInputKeys];
$Phase1MutableRuntimeControlKeys = Select[$Phase1MutableInputKeys,
  Function[key,AnyTrue[{"Tolerance","WorkingPrecision","MaxIterations","MeshRadialCount",
    "MeshAzimuthCount","GridPointCount","Cache","Watchdog","Timeout"},StringContainsQ[key,#]&]]];
$Phase1MutableDesignKeys = Complement[$Phase1MutableInputKeys,$Phase1MutableRuntimeControlKeys];
$Phase1MutableNodeLayoutKeys = {"PVCellsPerNode","PVNodeCellRows","PVNodeCellColumns"};

$Phase1DesignDependencyMap = <|
  "SolarDistance"->{"SolarIrradiance","LocalPVIncidence","CellCurrent","PVPower","RadiationPressure",
    "CellAndBusConductorSections","I2RLoss","WireTemperature","SheetTemperature","OutwardForceMargin"},
  "PVCellArea"->{"CellCount","CellCurrent","NodePitch","NodeCount","TabLength","BusCurrent",
    "WireGauge","SupportRibSpacing","FoilPanelSpan","StructuralRigidity","Mass","PVPower"},
  "PVCellsPerNodeAndNodeLayout"->{"IntraNodeTabCount","NodePitch","NodeVoltage","NodeCurrent",
    "InterNodeSeriesCount","CollectorSectorCount","BusTreeTopology","SupportRibSpacing","Mass","I2RLoss"},
  "BusVoltageAndSectorSize"->{"SeriesStrings","CumulativeSectorCurrent","ConductorAWG","ParallelConductors",
    "BusLength","VoltageDrop","I2RLoss","WireTemperature","InterconnectMass"},
  "AluminumFoilThickness"->{"SubstrateArealMass","SheetMass","CentreOfMass","InertiaTensor",
    "NaturalForceEquilibrium","NaturalTorqueEquilibrium","StationForceDemand","StationTorqueDemand",
    "MembraneLoadTransfer","PanelDeflection","AluminumStress","PVPowerPerMass"},
  "AluminumFoilAndWireSpacing"->{"SupportSpan","PanelDeflection","AluminumStress","FoilMass",
    "BacksideLaminateRequirement","SupportRibMass"},
  "BacksideFilm"->{"CompositeNeutralAxis","CompositeBendingRigidity","FilmStress","LaminateMass",
    "RigidityPerArealMass","PanelPressureLimit"},
  "OpticalPropertiesAndPVFraction"->{"AbsorbedPower","ReflectedMomentum","PVPower","SheetTemperature",
    "RadiationForceVector","OutwardForceMargin"},
  "ThermalCeilingsAndConductorBounds"->{"WireCrossSection","WireTemperature","PVTemperature",
    "ReflectorTemperature","Feasibility"},
  "FutureMassGrowthTarget"->{"FutureAddedMassTargetFractionOfCurrentMass","RequiredOutwardForceSurplus","FutureAddedMassCapacity","PerSheetAcceptance"}
|>;

Phase1MutabilityAudit[] := Module[{keys=Keys[$Phase1DefaultInputs]},
  <|"ImmutableKeys"->$Phase1ImmutableInputKeys,"MutableKeys"->$Phase1MutableInputKeys,
    "MutableDesignKeys"->$Phase1MutableDesignKeys,"MutableRuntimeControlKeys"->$Phase1MutableRuntimeControlKeys,
    "MutableKeyCount"->Length[$Phase1MutableInputKeys],"ImmutableKeyCount"->Length[$Phase1ImmutableInputKeys],
    "UnclassifiedKeys"->Complement[keys,Join[$Phase1ImmutableInputKeys,$Phase1MutableInputKeys]],
    "TwoIndependentSheetsFixed"->True,"PoleIDs"->$Phase1PoleIDs,
    "NoCombinedMechanicalEquilibrium"->True,"DependencyMap"->$Phase1DesignDependencyMap,
    "ClassificationRule"->"Only fixed two-sheet topology, physical constants/laws and intrinsic properties of the chosen base materials are immutable; other registered inputs are mutable. Runtime controls are mutable but are not scored as physical design variables."|>
];

phase1MutablePerturbationValues[key_String,value_] := Which[
  MemberQ[{True,False},value], {Not[value]},
  VectorQ[value,NumericQ] && Length[value]==2 && StringContainsQ[key,"Range"], {0.5 value,0.25 value,1.25 value},
  IntegerQ[value] && MemberQ[$Phase1MutableNodeLayoutKeys,key], {},
  IntegerQ[value] && value>0, DeleteDuplicates[{Max[1,Round[value/2]],Max[1,Round[value/4]],Max[1,Ceiling[1.25 value]]}],
  NumericQ[value] && StringContainsQ[key,"Angle"], DeleteDuplicates[Clip[#,{-90.,90.}]&/@{value-5.,value-2.5,value+5.}],
  NumericQ[value] && AnyTrue[{"Fraction","Efficiency","Reflectivity","Emissivity","Transmissivity","Absorptivity"},StringContainsQ[key,#]&],
    DeleteDuplicates[Clip[#, {0.,1.}]&/@{value/2.,value/4.,1.25 value}],
  NumericQ[value] && value>0., {0.5 value,0.25 value,1.25 value},
  NumericQ[value] && value<0., {0.5 value,0.25 value,1.25 value},
  True, {}
];

Phase1MutablePerturbationCases[input_Association,includeRuntimeControl_:False] := Module[
  {cases={},key,value,values,layout,keys,scenario,factor,overrides,allNumericKeys},
  keys=If[TrueQ[includeRuntimeControl],$Phase1MutableInputKeys,$Phase1MutableDesignKeys];
  (* Simultaneous whole-vector perturbations exercise every positive numeric design value
     together; the individual cases below then resolve competing directions recursively. *)
  allNumericKeys=Select[keys,KeyExistsQ[input,#]&&NumericQ[input[#]]&&
    !MemberQ[$Phase1MutableNodeLayoutKeys,#]&];
  Do[
    overrides=Association@Map[Function[k, k->Which[
      StringContainsQ[k,"Angle"],input[k],
      AnyTrue[{"Fraction","Efficiency","Reflectivity","Emissivity","Transmissivity","Absorptivity"},StringContainsQ[k,#]&],
        Clip[factor input[k],{0.,1.}],
      IntegerQ[input[k]],Max[1,Round[factor input[k]]],
      True,input[k] factor]],allNumericKeys];
    AppendTo[cases,<|"Parameter"->"AllNumericMutableInputsSimultaneous",
      "Baseline"->"Current input vector","PerturbedValue"->factor,
      "Perturbation"->factor,"CandidateInputs"->Join[input,overrides]|>],
    {factor,{0.5,0.25,1.25}}];
  Do[
    If[KeyExistsQ[input,key],value=input[key];values=phase1MutablePerturbationValues[key,value];
      Do[AppendTo[cases,<|"Parameter"->key,"Baseline"->value,"PerturbedValue"->v,
        "Perturbation"->If[NumericQ[value]&&value!=0.,v/value,Missing["NonNumericOrZeroBaseline"]],
        "CandidateInputs"->Join[input,<|key->v|>]|>],{v,values}]
    ],{key,keys}];
  (* The PV node cell count, rows and columns are varied as a consistent discrete layout tuple.
     Skip this branch until all three node-layout inputs exist; never manufacture missing inputs. *)
  If[And@@(KeyExistsQ[input,#]&/@{"PVCellsPerNode","PVNodeCellRows","PVNodeCellColumns"}),
    Do[AppendTo[cases,<|"Parameter"->"PVNodeLayout","Baseline"->{input["PVNodeCellRows"],input["PVNodeCellColumns"]},
        "PerturbedValue"->layout,"Perturbation"->"Discrete layout candidate",
        "CandidateInputs"->Join[input,<|"PVNodeCellRows"->layout[[1]],"PVNodeCellColumns"->layout[[2]],
          "PVCellsPerNode"->Times@@layout|>]|>],
      {layout,{{1,2},{2,2},{2,3},{3,3},{3,4},{4,4},{4,5},{5,5},{5,10},{10,10},{10,20},{20,20},{20,25}}}]
  ];
  (* Select among the explicitly supported cell-array output assumptions. *)
  Do[AppendTo[cases,<|"Parameter"->"PrimaryPVScenario","Baseline"->input["PrimaryPVScenario"],
      "PerturbedValue"->scenario,"Perturbation"->"Discrete PV conversion scenario",
      "CandidateInputs"->Join[input,<|"PrimaryPVScenario"->scenario|>]|>],
    {scenario,{"PVCellArraySpecificPowerLimited","PVCellReferenceEfficiency","ProjectSpecifiedTargetEfficiency"}}];
  cases
];

Phase1RunMutableSensitivitySweep[input_Association,evaluator_Function] := Module[
  {baseline,cases,evaluated,rows},
  baseline=Quiet@Check[evaluator[input],$Failed];
  cases=Phase1MutablePerturbationCases[input,True];
  evaluated=Map[Function[c,With[{r=Quiet@Check[evaluator[c["CandidateInputs"]],$Failed]},
    Join[KeyDrop[c,{"CandidateInputs"}],<|"Evaluation"->r,
      "Feasible"->TrueQ[AssociationQ[r]&&Lookup[r,"Feasible",False]],
      "Objective"->If[AssociationQ[r],Lookup[r,"Objective",-Infinity],-Infinity]|>]]],cases];
  rows=SortBy[evaluated,(-Lookup[#,"Objective",-Infinity])&];
  <|"Baseline"->baseline,"PerturbationCaseCount"->Length[cases],"EvaluatedCaseCount"->Length[evaluated],
    "Results"->rows,"BestFeasibleCase"->If[AnyTrue[rows,TrueQ[Lookup[#,"Feasible",False]]&],
      First@Select[rows,TrueQ[Lookup[#,"Feasible",False]]&],Missing["NoFeasiblePerturbation"]],
    "ProgressiveFactors"->{0.5,0.25,1.25},"ToleranceTighteningDirections"->{0.5,0.25},
    "ToleranceRelaxationDirection"->1.25,"BaselineInputAssociationUnchanged"->True|>
];

Phase1RecursiveMutableDesignSweep[input_Association,evaluator_Function,maxPasses_Integer:2] := Module[
  {current=input,currentResult,bestResult,pass,cases,evaluated,best,improved=False,history={},rows,baselineObjective},
  currentResult=Quiet@Check[evaluator[current],$Failed];
  If[!AssociationQ[currentResult]||!TrueQ[Lookup[currentResult,"Feasible",False]],
    Return[Failure["MutableDesignSweepBaselineInfeasible",<|"BaselineEvaluation"->currentResult|>]]];
  baselineObjective=Lookup[currentResult,"Objective",-Infinity];
  Do[
    cases=Phase1MutablePerturbationCases[current];
    evaluated=Map[Function[c,With[{r=Quiet@Check[evaluator[c["CandidateInputs"]],$Failed]},
      <|"Case"->KeyDrop[c,{"CandidateInputs"}],"CandidateInputs"->c["CandidateInputs"],
        "Evaluation"->r,"Feasible"->TrueQ[AssociationQ[r]&&Lookup[r,"Feasible",False]],
        "Objective"->If[AssociationQ[r],Lookup[r,"Objective",-Infinity],-Infinity]|>]],cases];
    rows=Select[evaluated,TrueQ[Lookup[#,"Feasible",False]]&];
    If[rows==={},AppendTo[history,<|"Pass"->pass,"FeasiblePerturbations"->0,"Improvement"->False|>];Break[]];
    best=First@MaximalBy[rows,Lookup[#,"Objective",-Infinity]&];
    improved=TrueQ[best["Objective"]>Lookup[currentResult,"Objective",-Infinity]];
    AppendTo[history,<|"Pass"->pass,"FeasiblePerturbations"->Length[rows],"BestObjective"->best["Objective"],
      "Improvement"->improved,"BestCase"->best["Case"]|>];
    If[improved,current=best["CandidateInputs"];currentResult=best["Evaluation"],Break[]],
    {pass,1,maxPasses}];
  <|"Status"->"Bounded heuristic coordinate-perturbation pass completed; this is not a proof of global optimality or a substitute for full-source execution.",
    "GlobalOptimalityProven"->False,"FullSourceRuntimeVerified"->False,
    "BaselineObjective"->baselineObjective,"OptimizedObjective"->Lookup[currentResult,"Objective",Missing["NotEvaluated"]],
    "BestInputAssociation"->current,"BestEvaluation"->currentResult,"PassHistory"->history,
    "MutableParameterCount"->Length[$Phase1MutableDesignKeys],"DesignInputsPerturbed"->$Phase1MutableDesignKeys,
    "NodeLayoutsEnumerated"->If[And@@(KeyExistsQ[input,#]&/@{"PVCellsPerNode","PVNodeCellRows","PVNodeCellColumns"}),
      {{1,2},{2,2},{2,3},{3,3},{3,4},{4,4},{4,5},{5,5},{5,10},{10,10},{10,20},{20,20},{20,25}},{}],
    "RecursiveCoordinateCoOptimization"->True,"TwoPoleSeparationPreserved"->True|>
];

(* Pure one-pole candidate evaluator used by the recursive mutable design sweep.
   It accepts a complete isolated pole-input association and never writes project state. *)
phase1EvaluateMutableDesignCandidate[in_Association] := Module[
  {geo,mesh,optics,candidate,thermalBundle,thermal,pv,power,structure,mass,natural,wirePass,feasible},
  geo=phase1Geometry[in];
  mesh=phase1Mesh[in,geo,in["OptimizerMeshRadialCount"],in["OptimizerMeshAzimuthCount"]];
  optics=phase1Optics[in];
  candidate=phase1NaturalCandidateAt[in,geo,mesh,optics,in["PVFraction"],in["Distance_m"]];
  If[FailureQ[candidate],Return[<|"Feasible"->False,"Failure"->candidate,"Objective"->-Infinity|>]];
  thermalBundle=phase1CoupledPVThermal[candidate["Inputs"],geo,candidate["AttitudeMesh"],optics,
    candidate["Radiation"],in["PVFraction"],in["Distance_m"],0.];
  If[FailureQ[thermalBundle],Return[<|"Feasible"->False,"Failure"->thermalBundle,"Objective"->-Infinity|>]];
  thermal=thermalBundle["Thermal"];pv=thermalBundle["PVPerformance"];
  power=phase1Power[candidate["Inputs"],pv];
  structure=phase1Structural[candidate["Inputs"],geo,candidate["Radiation"],in["PVFraction"]];
  mass=candidate["Mass"];natural=candidate["Natural"];
  wirePass=TrueQ[Lookup[mass["ElectricalNetwork"],"WireThermalScreenPass",False]];
  feasible=TrueQ[mass["MassLedgerCloses"]&&natural["FutureMassGrowthTargetPass"]&&natural["ExactTorqueEquilibrium"]&&
    thermal["AllThermalLimitsWithinBounds"]&&thermalBundle["PVThermalCouplingConverged"]&&
    structure["StructuralScreenPass"]&&wirePass&&pv["PVOutputDoesNotExceedAbsorbedPower"]&&
    pv["PVOutputDoesNotExceedSpecificPower"]];
  <|"Feasible"->feasible,"Objective"->power["ConditionedDeliveredPower_W_PerPole"],
    "Distance_m"->in["Distance_m"],"PVFraction"->in["PVFraction"],
    "FutureMassCapacity_kg"->natural["FutureMassCapacityBeforeRadialBalance_kg"],
    "FutureMassTarget_kg"->natural["FutureMassTarget_kg"],
    "MassLedgerCloses"->mass["MassLedgerCloses"],"Thermal"->thermal,"PVPerformance"->pv,
    "PowerLedger"->power,"Structure"->structure,"Natural"->natural,"Mass"->mass,
    "CandidateState"->candidate,"InputAssociation"->in,
    "PerPoleOnly"->True,"OtherPoleStateReadOrModified"->False|>
];

Phase1RecursiveMutableDesignSweep[] := Phase1RecursiveMutableDesignSweep[
  Phase1GetInputs[],phase1EvaluateMutableDesignCandidate,2];

Phase1InputStatus[] := Module[{missing=Phase1MissingRequiredInputs[]},
  <|"Ready"->(missing==={}),
    "MissingRequiredInputKeys"->missing,
    "MissingRequiredInputCount"->Length[missing]|>
];

$Phase1InputCategories = <|
  "NumericalAndConvergenceControls" -> {"MeshAreaRelativeTolerance","AccelerationCrossCheckRelativeTolerance","SolarReferenceConsistencyRelativeTolerance","ThermalResidualRelativeTolerance","QuaternionNormalizationTolerance","OpticalClosureTolerance","PowerLedgerRelativeTolerance","ICARUSLoadMapRelativeTolerance","MeshCoefficientCrossCheckTolerance","OptimizerGridCrossCheckRelativeTolerance","OptimizerMaxIterations","PVThermalCouplingMaxIterations","OptimizerGridPointCount","OptimizerCoverageGridPointCount","MeshRadialCount","MeshAzimuthCount","OptimizerMeshRadialCount","OptimizerMeshAzimuthCount","DynamicAccuracyGoal","DynamicPrecisionGoal","DynamicSampleCount","DynamicLoadPropagationSampleCount"},
  "ArchitectureAndModelChoices" -> {"PoleCount","ICARUSStationCount","ICARUSStationCountScope","PVLayoutModel","GeometryProfileModel","MassDistributionModel","ICARUSLoadTransferModel","MembraneStructuralModel","ReflectionModel"},
  "GeometryAndReferenceState" -> {"PerPoleProjectedArea_m2","CapDepthToPlanformRadius"},
  "OpticalPVAndElectrical" -> {"ReflectorSolarReflectivity","ProjectTargetEfficiency","PVFraction","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","PVArealMass_kg_m2","PVCellArrayMassPolicy","PVCellArraySpecificPower_W_kg","PrimaryPVScenario","PVCellReferenceEfficiency","PVCellArrayEfficiencyReference","PVEfficiencyTemperatureCoefficient_perK","TransferEfficiency","ConditioningEfficiency"},
  "MassMaterialsAndStructure" -> {"CircularMembraneDeflectionCoefficient","DeferredEquipmentMass_kg","OtherInstalledArealMass_kg_m2","PerimeterHardwareLinearMass_kg_m","ReflectorArealMass_kg_m2","AluminumFoilThickness_m","AluminumDensity_kg_m3","AluminumYoungsModulus_Pa","AluminumPoissonRatio","AluminumYieldStrength_Pa","AluminumTensileStrength_Pa","MembraneSubstrateMaterialName","MembraneSubstrateMaterialClass","WiringArealMass_kg_m2","ICARUSStationMass_kg","MembranePretension_N_m","StructuralSafetyFactor","MaximumDeflectionFractionOfRadius","MaximumPanelDeflectionFractionOfRibSpacing","MaximumStructuralRibSagFractionOfRunSpan","MaximumStructuralRibElasticExtensionFraction"},
  "FuturePayloadMassMargin" -> {"FutureAddedMassTargetFractionOfCurrentMass"},
  "ConductorReferenceProperties" -> {"AluminumElectricalResistivity_Ohm_m","CopperDensity_kg_m3","CopperElectricalResistivity_Ohm_m"},
  "ICARUSControlAndLoadTransfer" -> {"ICARUSStationPositionsLocal_m","ICARUSStationForceCapacity_N","ICARUSRedesignFeasibilityApproved","ICARUSRedesignForceReserveFraction","MembraneLoadSpreadFractionOfRadius"},
  "Thermal" -> {"ReflectorIRemissivity","PVIRemissivity","BothSidesRadiate","PVTemperatureLimit_K","ReflectorTemperatureLimit_K"},
  "RotationAndWobble" -> {"WobbleDampingRatio"},
  "RadiationMaterialDegradationProperties" -> {"SEPDoseReference_protons_cm2","PVDegradationPerSEPReferenceDoseFraction","PVAnnualDegradationFraction","ReflectivityAnnualLossFraction"},
  "AcceptanceAndRecoveryCriteria" -> {"ExactEquilibriumRelativeTolerance","RadialDeviationToleranceFractionOfRadius","LateralDeviationToleranceFractionOfRadius","AttitudeTolerance_rad","RecoveryTimeMaximum_s","VelocityRecoveryTolerance_m_s","AngularRateRecoveryTolerance_rad_s"}
|>;
$Phase1PoleOperatingInputCategories = <|
  "PoleSpecificOrbitAndInitialState" -> {"Distance_m","DistanceSearchRange_m","InitialPositionLocal_m","InitialVelocityLocal_m_s","InitialVelocityHeliocentric_m_s","HeliocentricReferenceMotionMode","InitialAttitudeSmallAngles_rad","InitialAngularVelocity_rad_s","IncidenceAngle_deg","DynamicCheckDuration_s"},
  "PoleSpecificEnvironmentAndMission" -> {"FlarePeakFraction","FlarePeakTime_s","FlareDuration_s","FlareTailCutoffFraction","FlareTemporalProfile","CMEOnset_s","CMEWindPressureMultiplier","CMEDuration_s","CMETemporalProfile","SolarWindProtonDensity_1AU_cm3","SolarWindSpeed_1AU_m_s","SEPDose_protons_cm2","ReferenceMissionYears"},
  "PoleSpecificControlSettings" -> {"ControllerTranslationKp_perS2","ControllerTranslationKd_perS","ControllerAttitudeKp_perS2","ControllerAttitudeKd_perS"}
|>;

(* Approved assumption classification. The values in the model's shared and pole-local
   registers remain assumptions unless and until replaced by measured or qualified data. *)
$Phase1ApprovedAssumptionNotes = <|
  "PerPoleProjectedArea_m2" -> "User-approved area assumption equal to 10% of the nominal solar photospheric surface area per pole; not CAD or surveyed geometry.",
  "CapDepthToPlanformRadius" -> "Spherical-cap depth/radius ratio selected as the initial geometry assumption.",
  "ReflectorSolarReflectivity" -> "User-approved 99.9% target. This is a design target assumption, not a measured coating spectrum or qualification result.",
  "PVCellArraySpecificPower_W_kg" -> "User-approved 730 W/kg reference for the free-standing MIT PV case; device-specific space performance remains unqualified.",
  "AluminumFoilThickness_m" -> "Provisional 0.1 um starting thickness for the continuous aluminum-film baseline. It is a mutable screening input, not an optimized minimum or a manufacturing/structural qualification.",
  "AluminumDensity_kg_m3" -> "2705 kg/m^3 reference density for 1060-O aluminum at 20 C; treated as a fixed base-material reference. ASM Handbook, Properties of Wrought Aluminum and Aluminum Alloys, 1060 entry.",
  "AluminumYoungsModulus_Pa" -> "69 GPa reference elastic modulus for 1060-O at 20 C. ASM Handbook, Properties of Wrought Aluminum and Aluminum Alloys, 1060 entry.",
  "AluminumPoissonRatio" -> "0.33 reference Poisson ratio for 1060-O at 20 C. ASM Handbook, Properties of Wrought Aluminum and Aluminum Alloys, 1060 entry.",
  "AluminumYieldStrength_Pa" -> "28 MPa reference yield strength for 1060-O annealed sheet specimens. This bulk-sheet value is not validated for the ultrathin film process.",
  "AluminumTensileStrength_Pa" -> "69 MPa typical tensile strength for 1060-O annealed sheet specimens. This is a reference property, not an ultrathin-film allowable.",
  "AluminumElectricalResistivity_Ohm_m" -> "27.8 nOhm m reference electrical resistivity for 1060-O at 20 C; conductor temperature dependence and thin-film effects remain for Step 7.",
  "CopperDensity_kg_m3" -> "8890 kg/m^3 International Annealed Copper Standard reference density at 20 C.",
  "CopperElectricalResistivity_Ohm_m" -> "1.7241*10^-8 Ohm m International Annealed Copper Standard reference resistivity at 20 C.",
  "MembraneSubstrateMaterialClass" -> "Continuous AluminumFilm is the sole current substrate class. PV devices are mounted over the continuous aluminum base and do not displace its mass.",
  "MembranePretension_N_m" -> "0.1 N/m is a synthetic preliminary deployment placeholder for screening; it is not a validated installed tension.",
  "MaximumPanelDeflectionFractionOfRibSpacing" -> "Synthetic 1% local unsupported-panel-span deflection screen for aluminum foil between adjacent wiring-supported ribs. Mutable; reconcile with accepted Step 4 pressure fields and Step 7 run geometry.",
  "MaximumStructuralRibSagFractionOfRunSpan" -> "Synthetic 1% unsupported-run-span sag limit for the preliminary tensioned-rib cable surrogate. Not a measured installation limit or conductor qualification.",
  "MaximumStructuralRibElasticExtensionFraction" -> "Synthetic 0.1% elastic-extension screen used to derive minimum axial rigidity EA for each structural electrical run. A mutable interface requirement, not a material property.",
  "ICARUSStationMass_kg" -> "0.55 kg per station is a synthetic mass-budget allowance selected under the user-authorized modest-variation policy. The numerical choice is provisional, not a separately user-specified value, measurement or vendor specification.",
  "ICARUSRedesignFeasibilityApproved" -> "User-approved Phase 1 design premise: the current ICARUS actuator concept was not mission-specific, but modest targeted reengineering is considered feasible and likely. This grants permission to calculate a redesign target; it does not assert present hardware capability or qualification.",
  "ICARUSRedesignForceReserveFraction" -> "Provisional synthetic 10% starting reserve above maximum calculated per-station force demand. It is not a separately user-specified percentage, universal upper bound, qualified factor of safety or reliability allowance; the setting remains mutable and requires engineering justification." ,
  "ICARUSStationPositionsLocal_m" -> "Four assumed stations at cardinal perimeter locations; positions are recalculated from the shared planform radius and station count.",
  "PVTemperatureLimit_K" -> "343.15 K (70 C) screening limit assumption; the selected laminate/device continuous-use rating must be verified.",
  "ReflectorTemperatureLimit_K" -> "343.15 K (70 C) screening limit assumption; coating and substrate temperature limits must be verified.",
  "CMEWindPressureMultiplier" -> "1-in-40-year stress-scenario multiplier, not a date-specific forecast; 2270 remains a sensitivity case.",
  "FlarePeakFraction" -> "Historical total-solar-irradiance excursion used as a simplified stress-scenario assumption, not an X-ray-band or near-Sun forecast.",
  "SEPDose_protons_cm2" -> "Derived independently for each pole from the 1 AU reference fluence using an inverse-square screening proxy and that pole's distance.",
  "ExactEquilibriumRelativeTolerance" -> "User-approved numerical screening tolerance; derived absolute force and torque tolerances are calculated separately for each pole.",
  "WobbleDampingRatio" -> "Undamped reference-case assumption until actual membrane/joint damping is measured.",
  "ICARUSStationForceCapacity_N" -> "Present hardware force rating remains Automatic/unknown. Phase1ICARUSRedesignSizing derives a conditional future per-station force target from each pole's own unconstrained dynamic demand plus the approved 10% reserve; this is not a claim that current hardware meets it.",
  "FutureAddedMassTargetFractionOfCurrentMass" -> "A provisional 10% per-pole future payload/structural mass headroom target, expressed as a fraction of that pole's current modeled collector mass. It is a mutable screening design choice, distinct from the ICARUS force reserve and subject to replacement when downstream mass budgets are defined."
|>;

$Phase1ApprovedAssumptionGroups = <|
  "SharedEngineeringAssumptions" -> DeleteDuplicates[Flatten[Values[KeyDrop[$Phase1InputCategories,{"NumericalAndConvergenceControls"}]]]],
  "PoleSpecificOperatingAssumptions" -> DeleteDuplicates[Flatten[Values[$Phase1PoleOperatingInputCategories]]],
  "NumericalExecutionSettings" -> DeleteDuplicates[Flatten[Values[KeyTake[$Phase1InputCategories,{"NumericalAndConvergenceControls"}]]]]
|>;

$Phase1AlternateMaterialScenarioPresets = <|
  "PrimaryAluminumFilmBaseline" -> <|
    "Classification" -> "ProvisionalScreeningBaseline_NotQualified",
    "Inputs" -> <|
      "MembraneSubstrateMaterialName" -> "1060-O aluminum foil; provisional ultrathin-film baseline",
      "MembraneSubstrateMaterialClass" -> "AluminumFilm",
      "AluminumFoilThickness_m" -> 1.0*10^-7,
      "AluminumDensity_kg_m3" -> 2705.0,
      "PVCellArrayMassPolicy" -> False
    |>,
    "Scope" -> "Continuous aluminum structural base; its areal mass is calculated from thickness and density. PV devices are added on top. Detailed span/rib sizing and any optional backside-film comparison belong to Step 5."
  |>,
  "BacksideFilm" -> <|
    "Status" -> "Candidate registered for comparative Step 5 screening only; no backside-film mass is selected or included in the active collector mass model.",
    "Candidate" -> <|
      "MaterialName" -> "DuPont Kapton HN polyimide film, 0.5 mil (12.7 um) reference gauge",
      "Thickness_m" -> 12.7*10^-6,
      "Density_kg_m3" -> 1420.0,
      "YoungsModulus_Pa" -> 2.76*10^9,
      "PoissonRatio" -> 0.34,
      "YieldPointAt3Percent_Pa" -> 69.0*10^6,
      "TensileStrength_Pa" -> 231.0*10^6,
      "PropertyReferenceTemperature_C" -> 23.0,
      "PropertiesClassification" -> "Manufacturer typical room-temperature film properties; not a spacecraft design allowable, radiation qualification, thermal-cycle qualification or bonded-laminate property.",
      "DataSource" -> "https://www.dupont.com/content/dam/electronics/amer/us/en/electronics/public/documents/en/EI-10206-Kapton-HN-Data-Sheet.pdf",
      "InstallationSide" -> "AntiSunward",
      "BondModel" -> "PerfectBondUpperBoundForScreeningOnly",
      "BondingLayerArealMass_kg_m2" -> Missing["NotCharacterized"],
      "BondLayerThickness_m" -> Missing["NotCharacterized"],
      "BondLayerDensity_kg_m3" -> Missing["NotCharacterized"],
      "BondLayerYoungsModulus_Pa" -> Missing["NotCharacterized"],
      "BondLayerAllowableStress_Pa" -> Missing["NotCharacterized"],
      "BondMechanicalPropertiesAvailable" -> False,
      "BondLayerIncludedInBendingSectionModel" -> False,
      "BondQualificationPassed" -> False,
      "BondQualificationEvidence" -> <|
        "LapShearStrengthTestPassed" -> False,
        "PeelResistanceTestPassed" -> False,
        "ThermalVacuumCyclingPassed" -> False,
        "VacuumOutgassingPassed" -> False,
        "RadiationCompatibilityPassed" -> False,
        "LongTermAgingPassed" -> False,
        "ProcessRepeatabilityPassed" -> False,
        "EnvironmentalCompatibilityPassed" -> False
      |> ,
      "BondQualificationEvidenceReferences" -> <||>
    |>,
    "SelectionRule" -> "Select only if the bonded composite exceeds an equal-total-areal-mass aluminum-only alternative in both first-limit strength per mass and bending rigidity, the bonding-layer areal mass and mechanical properties are characterized, the bonded section is explicitly modeled, every required bond qualification test flag is passed and has a non-empty corresponding user-supplied report reference, the overall bond qualification flag is passed, and installation is anti-sunward. Required evidence covers lap shear, peel resistance, thermal-vacuum cycling, vacuum/outgassing, radiation compatibility, long-term ageing, process repeatability and environmental compatibility. References are not authenticated by this source. The perfect-bond comparison is an optimistic upper bound; a candidate failing any gate is rejected without crediting the film.",
    "ComparisonMethod" -> "Compare the anti-sunward bonded aluminum/film laminate with an aluminum-only sheet of equal total areal mass. Use the laminate neutral axis and transformed-section beam-strip bending rigidity, and compare the first reported material-limit axial line capacity per areal mass. Bonding-layer mass is not assumed to be zero for selection; it must be characterized."
  |>
|>;

Phase1InputRequirements[] := Module[
  {inputs = Phase1GetSharedInputs[], sharedGroups, sharedMissing, sharedCategorized,
   poleIDs, poleGroups, poleCategorized, unclassifiedShared, unclassifiedPole, ready},
  sharedGroups = Association @ KeyValueMap[Function[{name, keys},
    With[{missing = Select[keys, MissingQ[Lookup[inputs, #, Missing[]]] &]},
      name -> <|"RequiredKeys" -> keys, "MissingValues" -> missing,
        "MissingValueCount" -> Length[missing]|>
    ]
  ], $Phase1InputCategories];
  sharedMissing = Select[Keys[inputs], MissingQ[Lookup[inputs, #, Missing[]]] &];
  sharedCategorized = DeleteDuplicates[Flatten[Values[$Phase1InputCategories]]];
  poleIDs = If[TrueQ[$Phase1ExecutingPole], {$Phase1CurrentPole}, $Phase1PoleIDs];
  poleGroups = AssociationMap[Function[pole,
    Module[{poleInputs = Phase1GetPoleInputs[pole], groups, missingKeys},
      groups = Association @ KeyValueMap[Function[{name, keys},
        With[{missing = Select[keys, MissingQ[Lookup[poleInputs, #, Missing[]]] &]},
          name -> <|"RequiredKeys" -> keys, "MissingValues" -> missing,
            "MissingValueCount" -> Length[missing]|>
        ]
      ], $Phase1PoleOperatingInputCategories];
      missingKeys = Select[$Phase1PoleOperatingKeys, MissingQ[Lookup[poleInputs, #, Missing[]]] &];
      <|"Groups" -> groups, "MissingRequiredInputKeys" -> missingKeys,
        "MissingRequiredInputCount" -> Length[missingKeys]|>
    ]
  ], poleIDs];
  poleCategorized = DeleteDuplicates[Flatten[Values[$Phase1PoleOperatingInputCategories]]];
  unclassifiedShared = Complement[sharedMissing, sharedCategorized];
  unclassifiedPole = AssociationMap[
    Complement[poleGroups[#]["MissingRequiredInputKeys"], poleCategorized] &, poleIDs];
  ready = sharedMissing === {} &&
    And @@ (poleGroups[#]["MissingRequiredInputKeys"] === {} & /@ poleIDs) &&
    unclassifiedShared === {} && And @@ (unclassifiedPole[#] === {} & /@ poleIDs);
  <|"Ready" -> TrueQ[ready], "RequiredSharedInputCount" -> Length[Keys[inputs]],
    "MissingSharedInputCount" -> Length[sharedMissing], "SharedGroups" -> sharedGroups,
    "PoleOperatingRequirements" -> poleGroups,
    "UnclassifiedSharedRequiredInputs" -> unclassifiedShared,
    "UnclassifiedPoleOperatingInputs" -> unclassifiedPole,
    "SharedDesignMaterialInputCategories" -> $Phase1InputCategories,
    "PoleOperatingInputCategories" -> $Phase1PoleOperatingInputCategories,
    "MissingRequiredInputKeys" -> Join[sharedMissing,
      Flatten[Table[(pole <> "::" <> #) & /@ poleGroups[pole]["MissingRequiredInputKeys"], {pole, poleIDs}]]],
    "MissingValueCount" -> Length[sharedMissing] + Total[poleGroups[#]["MissingRequiredInputCount"] & /@ poleIDs],
    "Groups" -> sharedGroups,
    "UnclassifiedRequiredInputs" -> unclassifiedShared,
    "RequiredProjectAndNumericalInputCount" -> Total[Length /@ Values[$Phase1InputCategories]] +
      Length[poleIDs] Total[Length /@ Values[$Phase1PoleOperatingInputCategories]],
    "Rule" -> "Full model execution requires every registered value to be available. Values populated from the approved register are assumptions, not measured properties; unresolved ICARUS capacity remains demand-only and does not qualify hardware.",
    "RequiredValuesMustBeExplicit" -> False,
    "ApprovedAssumptionCount" -> Phase1ApprovedAssumptions[]["ApprovedAssumptionCount"],
    "ApprovedAssumptions" -> Phase1ApprovedAssumptions[],
    "UnresolvedEngineeringAndQualificationItems" -> Phase1ApprovedAssumptions[]["UnresolvedEngineeringAndQualificationItems"]|>
];
(* Public output accessors always validate the central input snapshot first.
   Raw Phase1GetResults[] is retained for internal state-management code. *)
Phase1GetDerived[name_String] := Module[{computed=phase1EnsureCalculated[]},
  If[FailureQ[computed],computed,Lookup[$Phase1State["Derived"],name,Missing["DerivedValueNotAvailable",name]]]
];
Phase1GetState[] := $Phase1State;
phase1RawResults[] := $Phase1State["Results"];
Phase1GetResults[] := phase1EnsureCalculated[];
Phase1GetResult[name_String] := Module[{computed=phase1EnsureCalculated[]},
  If[FailureQ[computed],computed,Lookup[$Phase1State["Results"],name,Missing["ResultNotAvailable",name]]]
];


phase1DefaultInputAudit[] := Module[
  {projectKeys,referenceConstants,standardPVReferences,softwareDefinitions,assumptions},
  assumptions=Phase1ApprovedAssumptions[];
  projectKeys=Join[Keys@Select[$Phase1DefaultInputs,MissingQ],$Phase1PoleOperatingKeys];
  referenceConstants={"SolarLuminosity_W","SolarGravitationalParameter_m3_s2","UniversalGravitationalConstant_m3_kg_s2",
    "SolarIrradianceAt1AU_W_m2","SpeedOfLight_m_s","AstronomicalUnit_m","Year_s",
    "StefanBoltzmann_W_m2_K4","CentimetersPerMeter","ProtonMass_kg"};
  standardPVReferences={"PVSpecificPowerReferenceIrradiance_W_m2","PVReferenceTemperature_K"};
  softwareDefinitions={"PVScenarioOptions","PVSearchRange","NumericalWorkingPrecision","DynamicMaxSteps","WobbleRestoringModel"};
  <|"FixedUserConfirmedArchitecture"-><|"PoleCount"->2|>,
    "UserApprovedAssumptionDefaultsPresent"->True,
    "ApprovedAssumptionCount"->assumptions["ApprovedAssumptionCount"],
    "ApprovedAssumptionRegister"->assumptions,
    "ProjectSpecificDefaultsAreAssumptionsNotMeasurements"->True,
    "UnapprovedAssistantGeneratedEngineeringDefaultsPresent"->False,
    "PublishedReferenceConstantDefaults"->referenceConstants,
    "SolarIrradianceReferenceClassification"->"IAU nominal solar irradiance conversion constant at 1 au; not an instantaneous operating value.",
    "StandardizedPVReferenceConditionDefaults"->standardPVReferences,
    "MathematicalOrSoftwareDefinitionsNotProjectDefaults"->softwareDefinitions,
    "UnresolvedActuatorCapacity"->"Automatic / unknown; demand-only force/torque calculation. No ICARUS capacity or hardware qualification is inferred.",
    "DerivedPerPoleValues"->{"ICARUSStationPositionsLocal_m","SEPDose_protons_cm2","DerivedNaturalTorqueTolerance_Nm","StableNaturalPeriods_s","UnstableGrowthRates_s"},
    "InitialPositionVelocityAndAttitude"->"User-approved nominal zero-state assumptions are stored separately in each pole register.",
    "GeometryStatus"->"User-approved spherical-cap/area geometry assumptions; replace with CAD-derived geometry or an imported measured mesh when available.",
    "MaterialStatus"->"Approved screening assumptions; material properties and long-duration performance remain unqualified.",
    "NoTwoPoleOperationalCoupling"->True|>
];

phase1Audit[action_String,details_] := Module[{entry},
  entry = <|"Action"->action,"Time"->DateString[{"Year","-","Month","-","Day"," ","Hour",":","Minute",":","Second"}],"Details"->details|>;
  $Phase1State = Join[$Phase1State,<|"AuditLog"->Append[$Phase1State["AuditLog"],entry]|>];
  entry
];



(* Shared state management is defined after the pole-local execution architecture.
   Reset and persistence retain the two independent operating registers and invalidate
   derived caches whenever a shared design/material input changes. *)

(* ========================================================================
   2. PURE MODEL FUNCTIONS — all receive the central input snapshot explicitly
   ======================================================================== *)

phase1InstalledPVArealMass[in_Association] := in["PVArealMass_kg_m2"];

(* WHAT: Resolve the continuous aluminum substrate's areal mass from the active
   foil-thickness input and the selected base aluminum density.
   WHY: Every geometry, natural-load, inertia and ICARUS calculation must see the
   same current substrate mass when foil thickness is changed.
   HOW: Multiply thickness by density; keep PV-device mass separate because the
   cells are mounted on, rather than substituted for, the continuous aluminum film.
   Backside reinforcement and wiring-supported rib stiffness are intentionally not
   credited in this Step 4 calculation; their coupled design belongs to Steps 5 and 7. *)
phase1SubstrateMassTreatment[in_Association] := Module[
  {thickness,density,arealMass,materialClass,materialName},
  thickness=Lookup[in,"AluminumFoilThickness_m",Missing["AluminumFoilThicknessUnavailable"]];
  density=Lookup[in,"AluminumDensity_kg_m3",Missing["AluminumDensityUnavailable"]];
  If[!NumericQ[thickness]||!TrueQ[thickness>0.]||
      !NumericQ[density]||!TrueQ[density>0.],
    Return[Failure["InvalidAluminumSubstrateInputs",<|"Thickness_m"->thickness,"Density_kg_m3"->density|>]]
  ];
  arealMass=thickness density;
  materialClass=Lookup[in,"MembraneSubstrateMaterialClass","AluminumFilm"];
  materialName=Lookup[in,"MembraneSubstrateMaterialName","Aluminum film"];
  If[materialClass=!="AluminumFilm",
    Return[Failure["UnsupportedSubstrateMaterialClass",<|"SelectedClass"->materialClass,"RequiredClass"->"AluminumFilm"|>]]
  ];
  <|"MaterialClass"->materialClass,"MaterialName"->materialName,
    "Thickness_m"->thickness,"Density_kg_m3"->density,
    "EffectiveArealMass_kg_m2"->arealMass,
    "ReductionFactor"->1.,"ReductionApplied"->False,
    "Treatment"->"Continuous aluminum film; areal mass is thickness times aluminum density. No mass reduction is applied and PV device mass is added separately.",
    "MaterialReference"->"ASM Handbook, Properties of Wrought Aluminum and Aluminum Alloys, 1060-O reference data; bulk-sheet properties are not established allowables for the modeled ultrathin film."|>
];

phase1EffectiveSubstrateArealMass[in_Association] := Module[{treatment},
  treatment=phase1SubstrateMassTreatment[in];
  If[FailureQ[treatment],treatment,treatment["EffectiveArealMass_kg_m2"]]
];

(* WHAT: Construct the active pole's spherical-cap surrogate from its projected area
   and cap-depth ratio, then derive curved area, planform radius and perimeter.
   WHY: Curved area sets the distributed mass and optical collection surface; the
   perimeter and radius define mass locations, station geometry and load lever arms.
   HOW: The cap is evaluated independently for the current pole in its local frame.
   The spherical-cap profile is an explicit reduced-order geometry assumption, not
   a flat average-angle model or a measured/CAD surface. *)
phase1Geometry[in_Association] := Module[
  {poleProjectedArea,a,h,sphereRadius,curvedArea,perimeter},
  poleProjectedArea=in["PerPoleProjectedArea_m2"];
  a=Sqrt[poleProjectedArea/Pi];
  h=in["CapDepthToPlanformRadius"] a;
  sphereRadius=(a^2+h^2)/(2. h);
  curvedArea=2. Pi sphereRadius h;
  perimeter=2. Pi a;
  If[in["GeometryProfileModel"] =!= "SphericalCapSurrogate",
    Return[Failure["UnsupportedGeometryProfileModel",<|"SelectedModel"->in["GeometryProfileModel"]|>]]];
  <|
    "TwoPoleCollectorArea_m2"->Missing["AggregateFromIndependentPoleGeometryResults"],
    "GrossProjectedAreaPerPole_m2"->poleProjectedArea,
    "GrossCurvedAreaPerPole_m2"->curvedArea,
    "PlanformEquivalentRadius_m"->a,
    "PlanformPerimeter_m"->perimeter,
    "CapDepth_m"->h,
    "GeneratingSphereRadius_m"->sphereRadius,
    "CurvedToProjectedAreaRatio"->curvedArea/poleProjectedArea,
    "GeometryModel"->in["GeometryProfileModel"],
    "GeometryModelQualification"->"Explicitly selected user-approved spherical-cap geometry assumption in the reduced-order calculation; it is not inferred from CAD or measurement. Replace phase1Geometry/phase1Mesh with a CAD/profile-derived or imported measured surface when available.",
    "CalculationScope"->"All calculations are performed for the active pole alone, in that pole's independent local coordinate frame. The local +x axis is the Sun-radial coordinate convention; no global inter-pole orientation or coupling is assumed."
  |>
];

(* WHAT: Discretize the curved cap into annular/azimuthal surface patches.
   WHY: Solar incidence, momentum transfer, absorbed heat, distributed gravity and
   moments depend on each patch's own orientation and location.
   HOW: Each patch receives a local unit normal, projected-area weight and curved
   surface-area weight. The quadrature/analytic area comparison is the geometric
   resolution gate used by the Step 4 engineering core. *)
phase1Mesh[in_Association,geo_Association,nr_:Automatic,na_:Automatic] := Module[
  {nR,nA,a,sr,area,patches,rho,phi,x,norm,dAproj,dAsurf},
  nR=If[nr===Automatic,in["MeshRadialCount"],nr];
  nA=If[na===Automatic,in["MeshAzimuthCount"],na];
  a=geo["PlanformEquivalentRadius_m"];sr=geo["GeneratingSphereRadius_m"];area=geo["GrossProjectedAreaPerPole_m2"];
  patches=Flatten[Table[
    rho=a Sqrt[(i-0.5)/nR];
    phi=2. Pi (j-1)/nA;
    x=Sqrt[sr^2-rho^2]-(sr-geo["CapDepth_m"]);
    norm=Normalize[{1.,rho Cos[phi]/Sqrt[sr^2-rho^2],rho Sin[phi]/Sqrt[sr^2-rho^2]}];
    dAproj=area/(nR nA);
    dAsurf=dAproj/norm[[1]];
    <|"PatchIndex"->((i-1) nA+j),"Position_m"->{x,rho Cos[phi],rho Sin[phi]},"Normal"->norm,
      "ProjectedAreaWeight_m2"->dAproj,"SurfaceAreaWeight_m2"->dAsurf,
      "RadialIndex"->i,"AzimuthIndex"->j|>,
    {i,nR},{j,nA}],1];
  <|"Patches"->patches,"PatchCount"->Length[patches],
    "ProjectedArea_m2"->Total[Lookup[patches,"ProjectedAreaWeight_m2"]],
    "QuadratureCurvedArea_m2"->Total[Lookup[patches,"SurfaceAreaWeight_m2"]],
    "AnalyticCurvedArea_m2"->geo["GrossCurvedAreaPerPole_m2"],
    "QuadratureAreaRelativeError"->(Total[Lookup[patches,"SurfaceAreaWeight_m2"]]/geo["GrossCurvedAreaPerPole_m2"]-1.),
    "MeshResolution"->{nR,nA},
    "SurfaceFrame"->"Local x is the Sun-radial/canopy-normal axis; y-z span the canopy planform."|>
];

phase1Optics[in_Association] := Module[{rR,tR,aR,rP,tP,aP},
  rR=in["ReflectorSolarReflectivity"];tR=in["ReflectorSolarTransmissivity"];aR=1.-rR-tR;
  rP=in["PVSolarReflectivity"];tP=in["PVSolarTransmissivity"];aP=1.-rP-tP;
  <|"Reflector"-><|"R"->rR,"A"->aR,"T"->tR|>,
    "PV"-><|"R"->rP,"A"->aP,"T"->tP|>,
    "EnergyClosure"-><|"Reflector"->rR+aR+tR,"PV"->rP+aP+tP|>,
    "Status"->"Absorptivity is calculated as 1-R-T; each incident-energy fraction is assigned exactly once."|>
];

phase1SunVector[angleDeg_] := Normalize[{Cos[angleDeg Degree],Sin[angleDeg Degree],0.}];

phase1Illumination[mesh_Association,sun_List] := Module[{patches=mesh["Patches"],cosines},
  cosines=Map[Max[0.,# ["Normal"].sun]&,patches];
  <|"SunDirection"->sun,"PatchIncidenceCosines"->cosines,
    "IlluminationWeightedProjectedArea_m2"->Total[MapThread[#1 #2&,{cosines,Lookup[patches,"SurfaceAreaWeight_m2"]}]],
    "IlluminationModel"->"One-sided illumination using local surface normals; backside illumination is not assumed."|>
];

phase1MaterialMomentumCoefficients[mesh_Association,sun_List,optics_Association] := Module[
  {patches=mesh["Patches"],absVector,reflVector,forceCoefficient},
  absVector=Total[Map[Function[p,Module[{ci=Max[0.,p["Normal"].sun]},ci p["SurfaceAreaWeight_m2"] sun]],patches]]/mesh["ProjectedArea_m2"];
  reflVector=Total[Map[Function[p,Module[{ci=Max[0.,p["Normal"].sun]},2. ci^2 p["SurfaceAreaWeight_m2"] p["Normal"]]],patches]]/mesh["ProjectedArea_m2"];
  forceCoefficient[material_] := optics[material]["A"] absVector+optics[material]["R"] reflVector;
  <|"AbsorptionVectorCoefficient"->absVector,"SpecularReflectionVectorCoefficient"->reflVector,
    "PVVectorCoefficient"->forceCoefficient["PV"],
    "ReflectorVectorCoefficient"->forceCoefficient["Reflector"]|>
];

(* Solar irradiance is evaluated independently from each pole's active heliocentric
   distance and the fixed solar-luminosity reference. The resulting flux is propagated
   into every locally oriented patch calculation. *)
phase1SolarIrradiance[in_Association, distance_?NumericQ] :=
  If[TrueQ[distance > 0.],
    in["SolarLuminosity_W"]/(4. Pi distance^2),
    Failure["InvalidSolarDistance", <|"Distance_m" -> distance|>]
  ];

(* WHAT: Integrate solar photon momentum and absorbed optical energy over the
   current pole's individually oriented surface patches.
   WHY: Radiation force is the outward mass-growth driver, while patch moments and
   absorbed heat feed the natural-load and later thermal models.
   HOW: Local incidence cosine clips unilluminated patches. Absorption transfers
   incident momentum along the Sun direction; the selected specular-reflection model
   contributes its normal momentum term. Optical energy is ledgered as absorbed,
   reflected and transmitted fractions. Diffuse scattering is outside this model. *)
phase1Radiation[in_Association,geo_Association,mesh_Association,optics_Association,f_,r_,angleDeg_,sunOverride_:Automatic] := Module[
  {sun,flux,patches,forces,ci,dA,aEff,rEff,force,heat,pvIncident,pvAbsorbed,refIncident,totalForce,totalMoment,coefficients,coefficientVector,pvReflected,pvTransmitted,refReflected,refTransmitted,totalIncident,totalAbsorbed,totalReflected,totalTransmitted,energyResidual},
  sun=If[sunOverride===Automatic,phase1SunVector[angleDeg],Normalize[sunOverride]];
  flux=phase1SolarIrradiance[in,r]; If[FailureQ[flux],Return[flux]];
  patches=mesh["Patches"];
  aEff=f optics["PV"]["A"]+(1.-f) optics["Reflector"]["A"];
  rEff=f optics["PV"]["R"]+(1.-f) optics["Reflector"]["R"];
  forces=Map[Function[p,
    ci=Max[0.,p["Normal"].sun];dA=p["SurfaceAreaWeight_m2"];
    force=(flux/in["SpeedOfLight_m_s"]) ci dA (aEff sun+2. rEff ci p["Normal"]);
    heat=flux ci dA aEff;
    Join[p,<|"IncidenceCosine"->ci,
      "IncidenceAngle_rad"->ArcCos[Clip[ci,{0.,1.}]],
      "IncidenceAngle_deg"->ArcCos[Clip[ci,{0.,1.}]]/Degree,
      "RadiationForceVector_N"->force,
      (* Patch positions are expressed relative to mesh reference point. In the Step 4
         engineering core the mesh has been shifted to the centre of mass, so this local
         moment is the patch's explicit contribution to the pole's COM radiation moment. *)
      "RadiationMomentAboutReferencePoint_Nm"->Cross[p["Position_m"],force],
      "AbsorbedHeat_W"->heat|>]
  ],patches];
  pvIncident=flux f Total[MapThread[#1 #2&,{Map[Max[0.,# .sun]&,Lookup[patches,"Normal"]],Lookup[patches,"SurfaceAreaWeight_m2"]}]];
  pvAbsorbed=pvIncident optics["PV"]["A"];
  refIncident=flux (1.-f) Total[MapThread[#1 #2&,{Map[Max[0.,# .sun]&,Lookup[patches,"Normal"]],Lookup[patches,"SurfaceAreaWeight_m2"]}]];
  pvReflected=pvIncident optics["PV"]["R"];pvTransmitted=pvIncident optics["PV"]["T"];
  refReflected=refIncident optics["Reflector"]["R"];refTransmitted=refIncident optics["Reflector"]["T"];
  totalIncident=pvIncident+refIncident;
  totalAbsorbed=pvAbsorbed+refIncident optics["Reflector"]["A"];
  totalReflected=pvReflected+refReflected;totalTransmitted=pvTransmitted+refTransmitted;
  energyResidual=totalIncident-totalAbsorbed-totalReflected-totalTransmitted;
  totalForce=Total[Lookup[forces,"RadiationForceVector_N"]];
  (* Aggregate the stored patch contributions rather than reconstructing a second
     moment path; this keeps the reported resultant exactly traceable to patch records. *)
  totalMoment=Total[Lookup[forces,"RadiationMomentAboutReferencePoint_Nm"]];
  coefficients=phase1MaterialMomentumCoefficients[mesh,sun,optics];
  coefficientVector=f coefficients["PVVectorCoefficient"]+(1.-f) coefficients["ReflectorVectorCoefficient"];
  <|"Distance_m"->r,"Irradiance_W_m2"->flux,"SunDirection"->sun,
    "PVIncidentPower_W"->pvIncident,"PVAbsorbedPower_W"->pvAbsorbed,
    "PVReflectedPower_W"->pvReflected,"PVTransmittedPower_W"->pvTransmitted,
    "ReflectorIncidentPower_W"->refIncident,"ReflectorAbsorbedPower_W"->refIncident optics["Reflector"]["A"],
    "ReflectorReflectedPower_W"->refReflected,"ReflectorTransmittedPower_W"->refTransmitted,
    "TotalIncidentOpticalPower_W"->totalIncident,"TotalAbsorbedOpticalPower_W"->totalAbsorbed,
    "TotalReflectedOpticalPower_W"->totalReflected,"TotalTransmittedOpticalPower_W"->totalTransmitted,
    "OpticalEnergyClosureResidual_W"->energyResidual, 
    "TotalAbsorbedHeat_W"->Total[Lookup[forces,"AbsorbedHeat_W"]],
    "NetRadiationForceVector_N"->totalForce,"NetRadiationMoment_Nm"->totalMoment,
    "RadiationPressureVector_Pa"->totalForce/geo["GrossProjectedAreaPerPole_m2"],
    "NumericalMomentumCoefficientVector"->coefficientVector,
    "NumericalMomentumCoefficientRadial"->coefficientVector[[1]],
    "MaterialMomentumCoefficients"->coefficients,
    "PatchLoads"->forces,"PVFraction"->f,"ReflectiveFraction"->1.-f,
    "AssumedReflectionType"->in["ReflectionModel"],
    "Qualification"->"Patch integration uses local normals and area weights. Reflection is assumed specular; diffuse/backscatter terms are deferred."|>
];

phase1Mass[in_Association,geo_Association,rad_Association,f_,r_] := Module[
  {ratio,curvedArea,projectedArea,pvMass,reflectMass,substrateMass,effectiveSubstrateMassOnReflectorArea,substrateTreatment,wireMass,otherMass,deferredMass,perimeterMass,stationMass,sheetMass,totalMass,sigma,flux,mu,gravity,radAcceleration,accVector,sigmaEq,margin,relativeResidual,integratedPVReplacesSubstrate,wind,radialDirection,forceScale,accelerationTolerance,characteristicRadius,torqueTolerance},
  ratio=geo["CurvedToProjectedAreaRatio"];
  curvedArea=geo["GrossCurvedAreaPerPole_m2"];projectedArea=geo["GrossProjectedAreaPerPole_m2"];
  pvMass=f curvedArea phase1InstalledPVArealMass[in];
  reflectMass=(1.-f) curvedArea in["ReflectorArealMass_kg_m2"];
  integratedPVReplacesSubstrate=False;
  substrateTreatment=phase1SubstrateMassTreatment[in];
  If[FailureQ[substrateTreatment],Return[substrateTreatment]];
  (* Continuous aluminum support remains under both reflector and PV regions. *)
  substrateMass=curvedArea substrateTreatment["EffectiveArealMass_kg_m2"];
  effectiveSubstrateMassOnReflectorArea=curvedArea (1.-f) substrateTreatment["EffectiveArealMass_kg_m2"];
  wireMass=curvedArea in["WiringArealMass_kg_m2"];
  otherMass=curvedArea in["OtherInstalledArealMass_kg_m2"];
  deferredMass=in["DeferredEquipmentMass_kg"];
  perimeterMass=geo["PlanformPerimeter_m"] in["PerimeterHardwareLinearMass_kg_m"];
  stationMass=in["ICARUSStationCount"] in["ICARUSStationMass_kg"];
  sheetMass=pvMass+reflectMass+substrateMass+wireMass+otherMass;
  totalMass=sheetMass+perimeterMass+stationMass+deferredMass;
  sigma=totalMass/projectedArea;
  flux=phase1SolarIrradiance[in,r]; If[FailureQ[flux],Return[flux]];
  mu=in["SolarGravitationalParameter_m3_s2"];
  radialDirection={1.,0.,0.};
  gravity=mu/r^2;
  radAcceleration=rad["NetRadiationForceVector_N"]/totalMass;
  wind=phase1SolarWindLoads[in,rad["PatchLoads"],r,radialDirection];
  accVector=radAcceleration+wind["TotalForce_N"]/totalMass-gravity radialDirection;
  forceScale=Max[Norm[rad["NetRadiationForceVector_N"]],Norm[wind["TotalForce_N"]],totalMass gravity,$MinMachineNumber];
  accelerationTolerance=in["ExactEquilibriumRelativeTolerance"] forceScale/totalMass;
  characteristicRadius=Sqrt[projectedArea/Pi];
  torqueTolerance=in["ExactEquilibriumRelativeTolerance"] forceScale characteristicRadius;
  (* The mass-growth limit is governed by solar radiation pressure alone. Solar-wind
     ram pressure is reported separately and contributes to the net environmental load,
     but it is not credited as permanent mass-carrying capacity. Use the actual integrated
     Sun-radial radiation force so the threshold remains consistent with this pole's local
     surface normals, incidence, optical response and attitude-corrected patch loads. *)
  sigmaEq=Dot[rad["NetRadiationForceVector_N"],radialDirection]/(projectedArea gravity);
  margin=sigmaEq-sigma;
  relativeResidual=(sigma-sigmaEq)/sigmaEq;
  <|"Distance_m"->r,"PVMass_kg"->pvMass,"ReflectorCoatingMass_kg"->reflectMass,
    "MembraneSubstrateMaterialName"->in["MembraneSubstrateMaterialName"],
    "MembraneSubstrateMass_kg"->substrateMass,"PerimeterHardwareMass_kg"->perimeterMass,
    "PerimeterHardwareLinearMass_kg_m"->in["PerimeterHardwareLinearMass_kg_m"],
    "PerimeterMassModel"->"User-selected linear mass distributed uniformly around the computed planform perimeter; perimeter point masses are included in centre-of-mass, inertia and distributed-gravity calculations.",
    "PVIntegratedCellArrayReplacesSubstrate"->False,
    "PVArrayMountedOnContinuousAluminumSubstrate"->True,
    "EffectiveSubstrateMassOnReflectorArea_kg"->effectiveSubstrateMassOnReflectorArea,
    "WiringMass_kg"->wireMass,"WiringGridStructuralReinforcementModelled"->False,"OtherInstalledArealMass_kg"->otherMass,"DeferredEquipmentMass_kg"->deferredMass,
    "SheetMass_kg"->sheetMass,"StationMassTotal_kg"->stationMass,
    "MassLedgerComponentSum_kg"->pvMass+reflectMass+substrateMass+wireMass+otherMass+perimeterMass+stationMass+deferredMass,
    "MassLedgerResidual_kg"->totalMass-(pvMass+reflectMass+substrateMass+wireMass+otherMass+perimeterMass+stationMass+deferredMass),
    "MassLedgerCloses"->TrueQ[Abs[totalMass-(pvMass+reflectMass+substrateMass+wireMass+otherMass+perimeterMass+stationMass+deferredMass)]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[totalMass]]],
    "TotalMass_kg"->totalMass,"TotalTwoPoleMass_kg"->Missing["AggregateFromIndependentPoleMassResults"],
    "InstalledPVArealMass_kg_m2"->phase1InstalledPVArealMass[in],
    "MembraneSubstrateMaterialClass"->substrateTreatment["MaterialClass"],
    "MembraneSubstrateReductionFactor"->substrateTreatment["ReductionFactor"],
    "AluminumFilmArealMass_kg_m2"->substrateTreatment["EffectiveArealMass_kg_m2"],
    "SubstrateMassReductionApplied"->False,
    "AluminumFoilThickness_m"->substrateTreatment["Thickness_m"],
    "AluminumFoilDensity_kg_m3"->substrateTreatment["Density_kg_m3"],
    "SubstrateMassTreatment"->substrateTreatment["Treatment"],
    "SubstrateMassDerivedFromCurrentThicknessAndDensity"->True,
    "ReflectorCoatingArealMass_kg_m2"->in["ReflectorArealMass_kg_m2"],
    "StationMassCountedOnce"->TrueQ[Abs[stationMass-in["ICARUSStationCount"] in["ICARUSStationMass_kg"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[stationMass]]],
    "TotalArealMass_kg_m2"->sigma,"EquilibriumArealMass_kg_m2"->sigmaEq,
    "SolarWindForce_N"->wind["TotalForce_N"],"SolarWindTorqueAboutCOM_Nm"->wind["TotalTorqueAboutCOM_Nm"],
    "MassMargin_kg_m2"->margin,
    "MassFeasible"->TrueQ[margin>=-in["ExactEquilibriumRelativeTolerance"] sigmaEq],
    "RelativeEquilibriumResidual"->relativeResidual,
    "NetNaturalAccelerationVector_m_s2"->accVector,
    "NetRadialAcceleration_m_s2"->accVector[[1]],
    "NaturalForceResidualMagnitude_m_s2"->Norm[accVector],
    "ExactVectorEquilibrium"->TrueQ[Norm[accVector]<=accelerationTolerance],
    "DerivedNaturalAccelerationTolerance_m_s2"->accelerationTolerance,
    "DerivedNaturalTorqueTolerance_Nm"->torqueTolerance,
    "ExactMassBalanceWithinTolerance"->TrueQ[Abs[relativeResidual]<=in["ExactEquilibriumRelativeTolerance"]],
    "RadiationAccelerationVector_m_s2"->radAcceleration,
    "SolarGravityAcceleration_m_s2"->gravity,
    "Interpretation"->Which[Norm[accVector]<=accelerationTolerance,"Natural vector equilibrium within numerical tolerance",accVector[[1]]>0.,"Outward/radiation-dominant residual; NOT equilibrium",True,"Inward/gravity-dominant or transverse residual; NOT equilibrium"]|>
];

phase1Thermal[in_Association,geo_Association,rad_Association,r_,limit_,coverage_:Automatic,electricalOutputW_:0.] := Module[
  {sides,pvEps,refEps,f,pvArea,reflectorArea,pvQ,reflectorQ,pvTemp,reflectorTemp,
   pvResidual,reflectorResidual,reflectorLimit,netPVHeatW},
  f=If[coverage===Automatic,in["PVFraction"],coverage];
  sides=If[TrueQ[in["BothSidesRadiate"]],2.,1.];
  pvEps=in["PVIRemissivity"];refEps=in["ReflectorIRemissivity"];
  pvArea=f geo["GrossCurvedAreaPerPole_m2"];
  reflectorArea=(1.-f) geo["GrossCurvedAreaPerPole_m2"];
  netPVHeatW=Max[0.,rad["PVAbsorbedPower_W"]-Max[0.,electricalOutputW]];
  pvQ=If[pvArea>0.,netPVHeatW/pvArea,0.];
  reflectorQ=If[reflectorArea>0.,rad["ReflectorAbsorbedPower_W"]/reflectorArea,0.];
  pvTemp=If[pvQ>0.,(pvQ/(sides pvEps in["StefanBoltzmann_W_m2_K4"]))^(1/4),0.];
  reflectorTemp=If[reflectorQ>0.,(reflectorQ/(sides refEps in["StefanBoltzmann_W_m2_K4"]))^(1/4),0.];
  pvResidual=sides pvEps in["StefanBoltzmann_W_m2_K4"] pvTemp^4-pvQ;
  reflectorResidual=sides refEps in["StefanBoltzmann_W_m2_K4"] reflectorTemp^4-reflectorQ;
  reflectorLimit=in["ReflectorTemperatureLimit_K"];
  <|"Distance_m"->r,"PVActiveArea_m2"->pvArea,"ReflectorActiveArea_m2"->reflectorArea,
    "PVMeanAbsorbedHeatFlux_W_m2"->pvQ,"PVAbsorbedOpticalPower_W"->rad["PVAbsorbedPower_W"],
    "PVElectricalPowerExtracted_W"->Max[0.,electricalOutputW],"PVResidualHeatPower_W"->netPVHeatW,
    "ReflectorMeanAbsorbedHeatFlux_W_m2"->reflectorQ,
    "PVTemperature_K"->pvTemp,"ReflectorTemperature_K"->reflectorTemp,
    "TemperatureLimit_K"->limit,"ReflectorTemperatureLimit_K"->reflectorLimit,
    "PVTemperatureWithinLimit"->TrueQ[pvTemp<=limit || pvQ==0.],
    "ReflectorTemperatureWithinLimit"->TrueQ[reflectorTemp<=reflectorLimit || reflectorQ==0.],
    "AllThermalLimitsWithinBounds"->TrueQ[(pvTemp<=limit || pvQ==0.) && (reflectorTemp<=reflectorLimit || reflectorQ==0.)],
    "ThermalBalanceResidual_W_m2"->pvResidual,
    "PVThermalBalanceResidual_W_m2"->pvResidual,"ReflectorThermalBalanceResidual_W_m2"->reflectorResidual,
    "RadiatingSides"->sides,"PVIRemissivity"->pvEps,"ReflectorIRemissivity"->refEps,
    "CoverageUsed"->f,
    "Model"->"Separate mean steady radiative balances per active PV and reflector area. PV electrical DC output is extracted from absorbed PV optical power before the residual PV heat balance; reflector absorbed optical power remains heat. No conduction, thermal inertia, hot-spot resolution, coating interface resistance or view-factor network."|>
];

(* The hierarchical collector electrical network is intentionally not implemented
   in the current Step 4 source update. Its two-tier node/bus topology, conductor sizing,
   I^2 R losses, thermal interaction and structural-rib coupling belong to Phase 1 Step 7.
   Fail closed so an early full power-pipeline call reports this boundary instead of
   falling through as an unevaluated symbol or producing misleading power output. *)
phase1ElectricalNetwork[___] := Failure["ElectricalNetworkDeferredToStep7",
  <|"CurrentProjectStep"->4,"PlannedProjectStep"->7,
    "Reason"->"Complete the Phase 1 Step 7 two-tier PV interconnect and electrical-network design before full PV/power calculation."|>];

phase1PV[in_Association,geo_Association,rad_Association,thermal_Association,f_,years_] := Module[
  {pvArea,pvMass,installedArealMass,incident,meanIrradiance,specificPowerIrradianceFactor,
   degAnnual,degSEP,degPV,effTemp,cellReferenceEff,projectEffTemp,spCap,grossOutputs,outputs,
   selected,grossSel,sel,capApplicable,capPass,electrical,designOutput,electricalScale,
   scenarioElectricalLosses,selectedElectricalLoss},
  If[in["PVLayoutModel"] =!= "UniformSurfaceCoverage",
    Return[Failure["UnsupportedPVLayoutModel",<|"SelectedModel"->in["PVLayoutModel"]|>]]];
  pvArea=f geo["GrossCurvedAreaPerPole_m2"];
  installedArealMass=phase1InstalledPVArealMass[in];
  pvMass=pvArea installedArealMass;
  incident=rad["PVIncidentPower_W"];
  meanIrradiance=If[pvArea>0.,incident/pvArea,0.];
  specificPowerIrradianceFactor=If[pvArea>0.,meanIrradiance/in["PVSpecificPowerReferenceIrradiance_W_m2"],0.];
  degAnnual=(1.-in["PVAnnualDegradationFraction"])^years;
  degSEP=Clip[1.-in["PVDegradationPerSEPReferenceDoseFraction"] in["SEPDose_protons_cm2"]/in["SEPDoseReference_protons_cm2"],{0.,1.}];
  degPV=degAnnual degSEP;
  effTemp=Clip[in["PVCellReferenceEfficiency"] (1.+in["PVEfficiencyTemperatureCoefficient_perK"] (thermal["PVTemperature_K"]-in["PVReferenceTemperature_K"])),{0.,1.}];
  cellReferenceEff=incident effTemp degPV;
  projectEffTemp=Clip[in["ProjectTargetEfficiency"]*(1.+in["PVEfficiencyTemperatureCoefficient_perK"]*
    (thermal["PVTemperature_K"]-in["PVReferenceTemperature_K"])),{0.,1.}];
  spCap=pvMass in["PVCellArraySpecificPower_W_kg"] specificPowerIrradianceFactor degPV;
  grossOutputs=<|"PVCellArraySpecificPowerLimited"->Min[spCap,cellReferenceEff],
    "PVCellReferenceEfficiency"->cellReferenceEff,
    "ProjectSpecifiedTargetEfficiency"->incident projectEffTemp degPV|>;
  selected=in["PrimaryPVScenario"];
  grossSel=Lookup[grossOutputs,selected,Missing["UnknownPVScenario",selected]];
  electrical=phase1ElectricalNetwork[in,geo,rad,f];
  If[FailureQ[electrical],Return[electrical]];
  designOutput=electrical["ElectricalDesignOutput_W"];
  scenarioElectricalLosses=AssociationMap[Function[power,
    If[NumericQ[power]&&designOutput>0.,electrical["TotalElectricalLoss_W"] (power/designOutput)^2,0.]],grossOutputs];
  outputs=AssociationMap[Function[name,Max[0.,grossOutputs[name]-scenarioElectricalLosses[name]]],Keys[grossOutputs]];
  sel=Lookup[outputs,selected,Missing["UnknownPVScenario",selected]];
  selectedElectricalLoss=Lookup[scenarioElectricalLosses,selected,Missing["UnknownPVScenario",selected]];
  electricalScale=If[NumericQ[grossSel]&&designOutput>0.,grossSel/designOutput,0.];
  capApplicable=TrueQ[selected==="PVCellArraySpecificPowerLimited"];
  capPass=If[capApplicable,TrueQ[NumericQ[grossSel]&&grossSel<=spCap+Sqrt[$MachineEpsilon]],True];
  <|"PVInstalledCurvedArea_m2"->pvArea,"PVDeviceMass_kg"->pvMass,
    "PVCellArrayDeviceMass_kg"->pvMass,"InstalledPVArealMass_kg_m2"->installedArealMass,
    "IncidentPVPower_W"->incident,"MeanIncidentPVIrradiance_W_m2"->meanIrradiance,
    "SpecificPowerReferenceIrradiance_W_m2"->in["PVSpecificPowerReferenceIrradiance_W_m2"],
    "SpecificPowerIrradianceScalingFactor"->specificPowerIrradianceFactor,
    "EffectivePVCellReferenceEfficiency"->effTemp,"EffectiveProjectTargetEfficiency"->projectEffTemp,
    "AnnualPVDegradationFactor"->degAnnual,"SEPDegradationFactor"->degSEP,
    "TotalPVDegradationFactor"->degPV,
    "PVCellArraySpecificPowerCeiling_W"->spCap,
    "ScenarioGrossDCOutputs_W"->grossOutputs,"ScenarioElectricalLosses_W"->scenarioElectricalLosses,
    "ScenarioDCOutputs_W"->outputs,"ElectricalNetwork"->electrical,
    "ElectricalLossAtSelectedOperatingPoint_W"->selectedElectricalLoss,
    "ElectricalDesignOutput_W"->designOutput,"ElectricalDesignPowerScalingFactor"->electricalScale,
    "SelectedScenario"->selected,"SelectedGrossDCOutput_W"->grossSel,"SelectedDCOutput_W"->sel,
    "SpecificPowerCapApplicable"->capApplicable,
    "PVOutputDoesNotExceedAbsorbedPower"->TrueQ[NumericQ[sel]&&sel<=rad["PVAbsorbedPower_W"]+Sqrt[$MachineEpsilon] Max[Sqrt[$MinMachineNumber],Abs[rad["PVAbsorbedPower_W"]]]],
    "PVOutputDoesNotExceedSpecificPower"->capPass,
    "PVOutputIncludesHierarchicalInterconnectLosses"->True,
    "MassPowerReconciliation"->"PV device mass is represented by the cell-array areal mass. Copper tabs/solder, aluminum series jumpers, sector bus conductors and structural ribs are separate bottom-up mass components. Each PV scenario debits I^2 R losses from the hierarchical interconnect network."|>
];

phase1CoupledPVThermal[in_Association, geo_Association, mesh_Association, optics_Association,
    rad_Association, coverage_?NumericQ, distance_?NumericQ, missionYears_?NumericQ] := Module[
  {maxIterations, tolerance, initialThermal, initialState, step, states, finalState,
   thermal, pv, before, after},
  maxIterations = in["PVThermalCouplingMaxIterations"];
  tolerance = in["ThermalResidualRelativeTolerance"];
  initialThermal = phase1Thermal[in, geo, rad, distance,
    in["PVTemperatureLimit_K"], coverage, 0.];
  If[FailureQ[initialThermal], Return[initialThermal]];
  initialState = <|"Thermal" -> initialThermal, "Iteration" -> 0, "Converged" -> False|>;
  step[state_Association] := Module[{pvNow, thermalNow, priorTemperature, newTemperature, electricalOutput},
    If[TrueQ[state["Converged"]], Return[state]];
    priorTemperature = state["Thermal"]["PVTemperature_K"];
    pvNow = phase1PV[in, geo, rad, state["Thermal"], coverage, missionYears];
    If[FailureQ[pvNow], Return[pvNow]];
    electricalOutput = pvNow["SelectedDCOutput_W"];
    If[!NumericQ[electricalOutput],
      Return[Failure["PVOutputNotNumeric", <|"PVResult" -> pvNow|>]]
    ];
    thermalNow = phase1Thermal[in, geo, rad, distance,
      in["PVTemperatureLimit_K"], coverage, electricalOutput];
    If[FailureQ[thermalNow], Return[thermalNow]];
    newTemperature = thermalNow["PVTemperature_K"];
    <|"Thermal" -> thermalNow, "Iteration" -> state["Iteration"] + 1,
      "Converged" -> TrueQ[Abs[newTemperature - priorTemperature] <=
        tolerance Max[Sqrt[$MinMachineNumber], Abs[newTemperature], Abs[priorTemperature]]]|>
  ];
  states = NestWhileList[step, initialState,
    Function[state, AssociationQ[state] && !TrueQ[Lookup[state, "Converged", False]] &&
      IntegerQ[Lookup[state, "Iteration", -1]] && state["Iteration"] < maxIterations]];
  finalState = Last[states];
  If[FailureQ[finalState], Return[finalState]];
  If[!AssociationQ[finalState],
    Return[Failure["PVThermalIterationStateInvalid", <|"State" -> finalState|>]]
  ];
  thermal = finalState["Thermal"];
  pv = phase1PV[in, geo, rad, thermal, coverage, missionYears];
  If[FailureQ[pv], Return[pv]];
  before = If[Length[states] > 1,
    states[[-2]]["Thermal"]["PVTemperature_K"], thermal["PVTemperature_K"]];
  after = thermal["PVTemperature_K"];
  thermal = Join[thermal, <|"PVThermalCouplingConverged" -> TrueQ[finalState["Converged"]],
    "PVThermalCouplingIterations" -> finalState["Iteration"],
    "PVThermalCouplingRelativeTemperatureChange" ->
      Abs[after - before]/Max[Sqrt[$MinMachineNumber], Abs[after]],
    "PVThermalCouplingMethod" ->
      "Bounded fixed-point iteration; subsequent iterations stop immediately after the PV-temperature residual meets the configured tolerance."|>];
  If[!TrueQ[finalState["Converged"]],
    Return[Failure["PVThermalCouplingDidNotConverge",
      <|"Iterations" -> finalState["Iteration"], "Thermal" -> thermal, "PV" -> pv|>]]
  ];
  <|"Thermal" -> thermal, "PVPerformance" -> pv, "Converged" -> True,
    "Iterations" -> finalState["Iteration"]|>
];

phase1Power[in_Association,pv_Association] := Module[{dc,transferred,conditioned},
  dc=pv["SelectedDCOutput_W"];
  transferred=dc in["TransferEfficiency"];
  conditioned=transferred in["ConditioningEfficiency"];
  <|"PoleCount"->in["PoleCount"],
    "PVDirectCurrent_W_PerPole"->dc,"TransferredDC_W_PerPole"->transferred,
    "ConditionedDeliveredPower_W_PerPole"->conditioned,
    "TotalTwoPoleDeliveredPower_W"->Missing["AggregateFromIndependentPolePowerResults"],
    "PVDirectCurrent_W"->dc,"TransferredDC_W"->transferred,
    "ConditionedDeliveredPower_W"->conditioned,
    "TransferEfficiency"->in["TransferEfficiency"],
    "ConditioningEfficiency"->in["ConditioningEfficiency"],
    "ScenarioDCOutputs_W"->pv["ScenarioDCOutputs_W"]|>
];

(* WHAT: Screen the continuous aluminum membrane against the peak patch-normal
   environmental traction, including radiation, solar-wind ram pressure and (when
   supplied) the current pole's distributed sheet-patch solar-gravity loads.
   WHY: Step 4 must connect the geometry-resolved external loads to the sheet's
   membrane response; omitting the sheet's own distributed gravitational body load
   would break consistency between the mass model, natural equilibrium and the load
   path delivered to ICARUS. Perimeter and station point loads remain separately
   identified for their attachment/wrench paths.
   HOW: Map each SheetPatch gravity record to the matching PatchIndex identifier,
   combine its force with radiation and wind force at that patch, then report normal
   pressure and tangential traction. The scalar tensioned-membrane deflection relation
   uses normal pressure only; tangential traction is exposed as a separate load output
   and is not represented as a completed in-plane shear or finite-element solution.
   Wiring-rib stiffness and backside-film reinforcement remain outside this screen. *)
phase1Structural[in_Association,geo_Association,rad_Association,coverage_:Automatic,gravityLoads_:Automatic] := Module[
  {a,pressure,tension,arealMass,density,thickness,stress,strain,allowableStress,deflection,ratio,requiredTension,allowableTension,pass,
   patchPressures,radiationWindPressures,patchTangentialTractions,gravityNormalTractions,gravityTangentialTractions,
   patchTotalForces,f,wind,windForces,gravityPatchIndices,gravityAllForces,gravityAllIDs,gravityKinds,patchIDs,
   gravityIndexMap,gravityPatchForces,gravityApplied,sunDirection,attachmentIndices,attachmentGravityMap,
   attachmentGravityPatchForces,totalGravityPatchForces,gravityPositionsAll,attachmentIDs},
  If[in["MembraneStructuralModel"] =!= "TensionedCircularMembrane",
    Return[Failure["UnsupportedMembraneStructuralModel",<|"SelectedModel"->in["MembraneStructuralModel"]|>]]];
  f=If[coverage===Automatic,in["PVFraction"],coverage];
  a=geo["PlanformEquivalentRadius_m"];
  (* Use the same pole-local Sun direction as the radiation patch integration. The
     ambient solar-wind traction arrives from the Sun and must be projected against
     the same rotated surface normals rather than an unrelated fixed axis. *)
  sunDirection=Lookup[rad,"SunDirection",{1.,0.,0.}];
  wind=phase1SolarWindLoads[in,rad["PatchLoads"],in["Distance_m"],sunDirection];
  windForces=wind["PatchForces_N"];
  gravityPatchForces=ConstantArray[{0.,0.,0.},Length[rad["PatchLoads"]]];
  gravityApplied=False;
  If[gravityLoads=!=Automatic,
    If[!AssociationQ[gravityLoads],Return[Failure["InvalidDistributedGravityLoadRecord",<||>]]];
    gravityAllIDs=Lookup[gravityLoads,"MassPointIdentifiers",{}];
    gravityKinds=Lookup[gravityLoads,"MassPointKinds",{}];
    gravityAllForces=Lookup[gravityLoads,"IndividualGravityForces_N",{}];
    gravityPositionsAll=Lookup[gravityLoads,"MassPointPositionsCOMInertial_m",{}];
    (* Check the complete gravity mass-point register before using its identifiers
       to build the patch lookup. Every physical mass point must have one unique
       identifier, one recognized category, one finite gravity-force vector and one
       finite COM-relative position. This prevents a truncated or reordered register
       from silently routing gravity to the wrong foil patch or attachment. *)
    If[!ListQ[gravityAllIDs]||gravityAllIDs==={}||
        !VectorQ[gravityAllIDs,StringQ]||!DuplicateFreeQ[gravityAllIDs]||
        !VectorQ[gravityKinds,StringQ]||Length[gravityKinds]=!=Length[gravityAllIDs]||
        !And@@(MemberQ[{"SheetPatch","PerimeterHardware","ICARUSStation"},#]&/@gravityKinds)||
        !ListQ[gravityAllForces]||Length[gravityAllForces]=!=Length[gravityAllIDs]||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@gravityAllForces)||
        !ListQ[gravityPositionsAll]||Length[gravityPositionsAll]=!=Length[gravityAllIDs]||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@gravityPositionsAll),
      Return[Failure["DistributedGravityMassPointRegisterInvalid",<|
        "IdentifierCount"->If[ListQ[gravityAllIDs],Length[gravityAllIDs],Missing["NotAList"]],
        "KindCount"->If[ListQ[gravityKinds],Length[gravityKinds],Missing["NotAList"]],
        "ForceVectorCount"->If[ListQ[gravityAllForces],Length[gravityAllForces],Missing["NotAList"]],
        "PositionVectorCount"->If[ListQ[gravityPositionsAll],Length[gravityPositionsAll],Missing["NotAList"]]|>]]
    ];
    patchIDs=("SheetPatch-"<>ToString[#])&/@Lookup[rad["PatchLoads"],"PatchIndex",{}];
    gravityIndexMap=AssociationThread[gravityAllIDs,Range[Length[gravityAllIDs]]];
    (* Stable patch identifiers, not incidental list order, map each surface patch to
       its independently evaluated gravity mass point. This protects the load transfer
       if perimeter/station points or future mesh bookkeeping are reordered. *)
    gravityPatchIndices=Lookup[gravityIndexMap,patchIDs,Missing["SheetPatchMassPointNotFound"]];
    If[Length[gravityPatchIndices]=!=Length[rad["PatchLoads"]]||
        !VectorQ[gravityPatchIndices,IntegerQ]||
        Length[gravityAllForces]=!=Length[gravityAllIDs]||
        Length[gravityKinds]=!=Length[gravityAllIDs]||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@gravityAllForces),
      Return[Failure["DistributedSheetPatchGravityMappingInvalid",<|
        "ExpectedPatchCount"->Length[rad["PatchLoads"]],
        "MappedGravityPatchCount"->Count[gravityPatchIndices,_Integer],
        "AvailableGravityMassPointCount"->Length[gravityAllForces]|>]]
    ];
    If[!And@@((gravityKinds[[#]]==="SheetPatch")&/@gravityPatchIndices),
      Return[Failure["DistributedSheetPatchGravityKindMismatch",<|"PatchIndices"->gravityPatchIndices|>]]
    ];
    gravityPatchForces=gravityAllForces[[gravityPatchIndices]];
    (* Sheet-patch gravity acts directly over the continuous foil. Perimeter and
       station masses instead deliver concentrated reactions through their physical
       attachment points. Transfer those remaining point forces onto the same curved
       patch field, preserving each attachment's force and COM moment. *)
    attachmentIndices=Select[Range[Length[gravityKinds]],
      MemberQ[{"PerimeterHardware","ICARUSStation"},gravityKinds[[#]]]&];
    If[Length[gravityPositionsAll]=!=Length[gravityAllIDs]||attachmentIndices==={}||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@gravityPositionsAll),
      Return[Failure["DistributedAttachmentGravityPositionsInvalid",<|
        "MassPointCount"->Length[gravityAllIDs],"PositionCount"->Length[gravityPositionsAll],
        "AttachmentIndices"->attachmentIndices|>]]
    ];
    attachmentIDs=gravityAllIDs[[attachmentIndices]];
    attachmentGravityMap=phase1ConcentratedGravityLoadMap[in,rad["PatchLoads"],
      gravityPositionsAll[[attachmentIndices]],gravityAllForces[[attachmentIndices]],attachmentIDs];
    If[FailureQ[attachmentGravityMap],Return[attachmentGravityMap]];
    attachmentGravityPatchForces=attachmentGravityMap["PatchForces_N"];
    gravityApplied=True
  ];
  If[gravityLoads===Automatic,attachmentGravityMap=Missing["NotSupplied"];
    attachmentGravityPatchForces=ConstantArray[{0.,0.,0.},Length[rad["PatchLoads"]]]];
  totalGravityPatchForces=MapThread[Plus,{gravityPatchForces,attachmentGravityPatchForces}];
  patchTotalForces=MapThread[#1+#2+#3&,
    {Lookup[rad["PatchLoads"],"RadiationForceVector_N"],windForces,totalGravityPatchForces}];
  radiationWindPressures=MapThread[Function[{p,fw},
    Abs[fw.p["Normal"]]/p["SurfaceAreaWeight_m2"]],
    {rad["PatchLoads"],MapThread[#1+#2&,{Lookup[rad["PatchLoads"],"RadiationForceVector_N"],windForces}]}];
  patchPressures=MapThread[Function[{p,totalLoad},
    Abs[totalLoad.p["Normal"]]/p["SurfaceAreaWeight_m2"]],
    {rad["PatchLoads"],patchTotalForces}];
  patchTangentialTractions=MapThread[Function[{p,totalLoad},
    Norm[totalLoad-(totalLoad.p["Normal"]) p["Normal"]]/p["SurfaceAreaWeight_m2"]],
    {rad["PatchLoads"],patchTotalForces}];
  gravityNormalTractions=MapThread[Function[{p,fg},
    Abs[fg.p["Normal"]]/p["SurfaceAreaWeight_m2"]],
    {rad["PatchLoads"],totalGravityPatchForces}];
  gravityTangentialTractions=MapThread[Function[{p,fg},
    Norm[fg-(fg.p["Normal"]) p["Normal"]]/p["SurfaceAreaWeight_m2"]],
    {rad["PatchLoads"],totalGravityPatchForces}];
  pressure=Max[patchPressures];
  tension=in["MembranePretension_N_m"];
  arealMass=phase1EffectiveSubstrateArealMass[in];
  density=in["AluminumDensity_kg_m3"];
  thickness=arealMass/density;
  stress=If[thickness>0.,tension/thickness,Infinity];
  strain=stress/in["AluminumYoungsModulus_Pa"];
  allowableStress=in["AluminumYieldStrength_Pa"]/in["StructuralSafetyFactor"];
  deflection=If[tension>0.,pressure a^2/(in["CircularMembraneDeflectionCoefficient"] tension),Infinity];
  ratio=deflection/a;
  requiredTension=pressure a/(in["CircularMembraneDeflectionCoefficient"] in["MaximumDeflectionFractionOfRadius"]);
  allowableTension=allowableStress thickness;
  pass=TrueQ[ratio<=in["MaximumDeflectionFractionOfRadius"] && stress<=allowableStress && requiredTension<=allowableTension &&
    !(in["PrimaryPVScenario"]==="PVCellArraySpecificPowerLimited" &&
      TrueQ[in["PVCellArrayMassPolicy"]] && f>0.)];
  <|"AppliedPeakLocalNormalRadiationAndSolarWindPressure_Pa"->Max[radiationWindPressures],
    "AppliedPeakLocalNormalEnvironmentalPressureIncludingGravity_Pa"->pressure,
    "SolarWindIncludedInStaticStructuralLoad"->True,
    "DistributedGravityIncludedInStaticStructuralLoad"->gravityApplied,
    "DistributedGravityPatchForceCount"->If[gravityApplied,Length[gravityPatchForces],0],
    "PerimeterAndStationGravityTransferredToMembrane"->TrueQ[AssociationQ[attachmentGravityMap]&&
      TrueQ[Lookup[attachmentGravityMap,"ForceAndMomentConservationPass",False]]&&
      Length[attachmentGravityPatchForces]===Length[rad["PatchLoads"]]],
    "AttachmentGravityLoadMap"->attachmentGravityMap,
    "DistributedAttachmentGravityPatchForceCount"->Length[attachmentGravityPatchForces],
    "AttachmentGravityTransferFrame"->"Initial-attitude COM-centred inertial frame; patch normals and gravity vectors are expressed in the same frame.",
    "PatchAttachmentGravityNormalTraction_Pa"->MapThread[Function[{p,fg},
      Abs[fg.p["Normal"]]/p["SurfaceAreaWeight_m2"]],{rad["PatchLoads"],attachmentGravityPatchForces}],
    "PatchAttachmentGravityTangentialTraction_Pa"->MapThread[Function[{p,fg},
      Norm[fg-(fg.p["Normal"]) p["Normal"]]/p["SurfaceAreaWeight_m2"]],{rad["PatchLoads"],attachmentGravityPatchForces}],
    "BaselineSolarWindPressure_Pa"->wind["DynamicPressure_Pa"],
    "PatchPressureRange_Pa"->{Min[patchPressures],Max[patchPressures]},
    "PatchNormalPressureContributions_Pa"->patchPressures,
    "PatchTangentialTraction_Pa"->patchTangentialTractions,
    "MaximumPatchTangentialTraction_Pa"->Max[patchTangentialTractions],
    "PatchGravityNormalTraction_Pa"->gravityNormalTractions,
    "PatchGravityTangentialTraction_Pa"->gravityTangentialTractions,
    "GravityLoadTreatment"->If[gravityApplied,
      "Individual solar-gravity forces for SheetPatch mass points are applied at their own distributed patches. Perimeter hardware and ICARUS station gravity forces are transferred from their registered COM-referenced attachment positions through a force- and moment-conserving Gaussian patch footprint. All three categories are included in the patchwise membrane traction screen and the complete gravity record remains in the rigid-body force and torque equations. The transfer is reduced-order and does not constitute a detailed joint, seam or finite-element model.",
      "No distributed gravity record was supplied to this screening call; only local radiation and solar-wind traction are included."],
    "StructuralSubstrateArealMass_kg_m2"->arealMass,
    "WiringArealMass_kg_m2"->in["WiringArealMass_kg_m2"],
    "WiringGridStructuralReinforcementCredited"->False,
    "WiringStructuralTreatment"->"Wiring contributes mass only; no stiffness, strength, joint, or load-transfer reinforcement credit is applied by this substrate-only structural screen.",
    "PlanformSpan_m"->a,"AssumedMembranePretension_N_m"->tension,
    "EquivalentMembraneThickness_m"->thickness,
    "EstimatedMembraneTensileStress_Pa"->stress,"EstimatedMembraneElasticStrain"->strain,
    "AllowableMembraneStress_Pa"->allowableStress,
    "MembraneStrengthBasis"->"Immutable 1060-O aluminum yield-strength reference divided by the mutable structural screening factor. Bulk-sheet reference strength is not a qualified allowable for an ultrathin film.",
    "EstimatedMaximumDeflection_m"->deflection,
    "DeflectionFractionOfRadius"->ratio,
    "MaximumAllowedDeflectionFraction"->in["MaximumDeflectionFractionOfRadius"],
    "RequiredPretensionForDeflectionLimit_N_m"->requiredTension,
    "AllowablePretensionFromStrength_N_m"->allowableTension,
    "DeflectionMargin"->in["MaximumDeflectionFractionOfRadius"]-ratio,
    "TensileStressMargin_Pa"->allowableStress-stress,
    "PretensionCapacityMargin_N_m"->allowableTension-requiredTension,
    "StructuralScreenPass"->pass,
    "IntegratedPVStructuralQualification"->If[in["PrimaryPVScenario"]==="PVCellArraySpecificPowerLimited" && TrueQ[in["PVCellArrayMassPolicy"]] && f>0.,
      "Not qualified: the integrated PV cell array replaces the base membrane substrate under covered area, but a mixed-laminate constitutive model is not supplied.",
      "First-order uniform tensioned-membrane screen only; not nonlinear membrane FEA."],
    "StructuralScreenModel"->in["MembraneStructuralModel"],
    "StructuralScreenQualification"->"Tensioned circular membrane one-span formula w_max≈p a^2/(C T), driven in the Step 4 core by patch-resolved normal radiation, solar-wind, sheet-patch gravity and force-/moment-conserved perimeter/station attachment gravity. Tangential traction is reported separately because this scalar deflection relation does not resolve in-plane shear. The attachment map is a reduced-order interface, not detailed joint or finite-element analysis. The present screen uses a continuous aluminum-film baseline and bulk 1060-O reference properties as provisional inputs; thin-film process, seams, residual stress, anisotropy, defects and deployment behavior are unqualified. Wiring-rib support is not credited until Step 5. This is not nonlinear membrane FEA."|>
];

phase1StructuralDistanceFloor[in_Association,geo_Association,mesh_Association,optics_Association,pvFraction_?NumericQ] := Module[
  {sun,patches,maxCos,maxWindCos,mixA,mixR,pressureCoefficient,windPressureCoefficient,a,thickness,allowableStress,allowableTension,
   pressureLimit,pretensionStress,minimumDistance,rad0,mass0,dyn0,meshAtt},
  sun=phase1SunVector[in["IncidenceAngle_deg"]];
  rad0=phase1Radiation[in,geo,mesh,optics,pvFraction,in["Distance_m"],in["IncidenceAngle_deg"],sun];
  mass0=phase1Mass[in,geo,rad0,pvFraction,in["Distance_m"]];
  dyn0=phase1DynamicsInitial[in,geo,mass0,mesh];
  meshAtt=phase1RotateMeshToCOM[mesh,dyn0["CenterOfMassLocal_m"],dyn0["InitialQuaternion"]];
  patches=meshAtt["Patches"];
  maxCos=Max[Map[Max[0.,# ["Normal"].sun]&,patches]];
  maxWindCos=Max[Map[Max[0.,# ["Normal"].{1.,0.,0.}]&,patches]];
  mixA=pvFraction optics["PV"]["A"]+(1.-pvFraction) optics["Reflector"]["A"];
  mixR=pvFraction optics["PV"]["R"]+(1.-pvFraction) optics["Reflector"]["R"];
  pressureCoefficient=in["SolarLuminosity_W"] maxCos^2 (mixA+2. mixR)/(4. Pi in["SpeedOfLight_m_s"]);
  windPressureCoefficient=in["SolarWindProtonDensity_1AU_cm3"] in["CentimetersPerMeter"]^3 in["ProtonMass_kg"] in["SolarWindSpeed_1AU_m_s"]^2 in["AstronomicalUnit_m"]^2 maxWindCos;
  pressureCoefficient=pressureCoefficient+windPressureCoefficient;
  a=geo["PlanformEquivalentRadius_m"];
  thickness=phase1EffectiveSubstrateArealMass[in]/in["AluminumDensity_kg_m3"];
  allowableStress=in["AluminumYieldStrength_Pa"]/in["StructuralSafetyFactor"];
  allowableTension=allowableStress thickness;
  pretensionStress=in["MembranePretension_N_m"]/thickness;
  pressureLimit=Min[
    in["CircularMembraneDeflectionCoefficient"] in["MembranePretension_N_m"] in["MaximumDeflectionFractionOfRadius"]/a,
    in["CircularMembraneDeflectionCoefficient"] in["MaximumDeflectionFractionOfRadius"] allowableTension/a
  ];
  minimumDistance=If[pretensionStress>allowableStress || pressureLimit<=0. || pressureCoefficient<0. ||
      (in["PrimaryPVScenario"]==="PVCellArraySpecificPowerLimited" &&
       TrueQ[in["PVCellArrayMassPolicy"]] && pvFraction>0.),Infinity,
    Sqrt[pressureCoefficient/pressureLimit]];
  <|"MinimumStructuralDistance_m"->minimumDistance,
    "PeakNormalCosine"->maxCos,"PeakSolarWindNormalCosine"->maxWindCos,
    "CombinedRadiationAndSolarWindPressureCoefficient_Pa_m2"->pressureCoefficient,
    "MaximumPermittedNormalPressure_Pa"->pressureLimit,
    "PretensionStress_Pa"->pretensionStress,"AllowablePretensionStress_Pa"->allowableStress,
    "AllowableTension_N_m"->allowableTension,
    "Feasible"->TrueQ[NumericQ[minimumDistance] && minimumDistance<Infinity],
    "Derivation"->"The structural distance floor is solved from the same membrane deflection and tensile-strength inequalities used by the independent structural screen. Pressure varies as 1/r^2, giving r_min=Sqrt[pressureCoefficient/pressureLimit]."|>
];

(* WHAT: Build the current pole's distributed mass points, centre of mass and
   three-dimensional inertia tensor, including sheet patches, perimeter hardware
   and four independent ICARUS station masses.
   WHY: The control wrench, torque demand, attitude response and membrane load map
   require the actual mass centroid and rotational inertia of this pole.
   HOW: Sheet mass follows curved patch area; perimeter and station masses are
   represented at their configured locations. The resulting mass points are centred
   at the computed COM before the inertia tensor and initial quaternion are formed. *)
phase1DynamicsInitial[in_Association,geo_Association,mass_Association,mesh_Association] := Module[
  {a,stationMass,sheetMass,perimeterMass,nPerimeter,perimeterPositions,perimeterPointMasses,total,stationsAbsolute,patches,patchWeights,patchMasses,positions,masses,massPointKinds,massPointIdentifiers,com,
   centered,inertia,theta,angle,q,omega,vHelio,rHelio,mu,helioSpeed,radialDirection},
  a=geo["PlanformEquivalentRadius_m"];
  If[in["MassDistributionModel"] =!= "UniformSheetMassWithPerimeterLineMassAndStationPointMasses",
    Return[Failure["UnsupportedMassDistributionModel",<|"SelectedModel"->in["MassDistributionModel"]|>]]];
  stationMass=in["ICARUSStationMass_kg"];
  sheetMass=mass["SheetMass_kg"];
  perimeterMass=mass["PerimeterHardwareMass_kg"];
  total=mass["TotalMass_kg"];
  stationsAbsolute=in["ICARUSStationPositionsLocal_m"];
  patches=mesh["Patches"];
  patchWeights=Lookup[patches,"SurfaceAreaWeight_m2"];
  patchMasses=sheetMass patchWeights/Total[patchWeights];
  nPerimeter=Max[Length[DeleteDuplicates[Lookup[patches,"AzimuthIndex"]]],1];
  perimeterPositions=Table[{0.,a Cos[2. Pi (j-1)/nPerimeter],a Sin[2. Pi (j-1)/nPerimeter]},{j,nPerimeter}];
  perimeterPointMasses=ConstantArray[perimeterMass/nPerimeter,nPerimeter];
  positions=Join[Lookup[patches,"Position_m"],perimeterPositions,stationsAbsolute];
  masses=Join[patchMasses,perimeterPointMasses,ConstantArray[stationMass,Length[stationsAbsolute]]];
  massPointKinds=Join[ConstantArray["SheetPatch",Length[patches]],
    ConstantArray["PerimeterHardware",nPerimeter],ConstantArray["ICARUSStation",Length[stationsAbsolute]]];
  massPointIdentifiers=Join[("SheetPatch-"<>ToString[#])&/@Lookup[patches,"PatchIndex"],
    ("PerimeterHardware-"<>ToString[#])&/@Range[nPerimeter],
    ("ICARUSStation-"<>ToString[#])&/@Range[Length[stationsAbsolute]]];
  com=Total[MapThread[#1 #2&,{masses,positions}]]/Total[masses];
  centered=(#-com& /@ positions);
  inertia=Total[MapThread[Function[{m,rr},m*(Norm[rr]^2*IdentityMatrix[3]-Outer[Times,rr,rr])],{masses,centered}]];
  theta=in["InitialAttitudeSmallAngles_rad"];
  angle=Norm[theta];
  q=phase1Quaternion[theta,Sqrt[$MachineEpsilon]];
  omega=in["InitialAngularVelocity_rad_s"];
  vHelio=in["InitialVelocityHeliocentric_m_s"];
  radialDirection={1.,0.,0.};
  rHelio=in["Distance_m"] radialDirection;
  mu=in["SolarGravitationalParameter_m3_s2"];
  helioSpeed=Norm[vHelio];
  <|"TotalMass_kg"->total,"DistributedSheetMass_kg"->sheetMass,
    "PerimeterHardwareMass_kg"->perimeterMass,"PerimeterMassPointCount"->nPerimeter,
    "PerimeterMassPointPositionsLocal_m"->perimeterPositions,"PerimeterMassPointMasses_kg"->perimeterPointMasses,
    "StationMassTotal_kg"->Length[stationsAbsolute] stationMass,
    "CenterOfMassLocal_m"->com,
    "InertiaTensor_kg_m2"->inertia,
    "InitialPositionHeliocentric_m"->rHelio,
    "InitialVelocityHeliocentric_m_s"->vHelio,
    "HeliocentricSpeed_m_s"->helioSpeed,
    "HeliocentricSpecificAngularMomentum_m2_s"->Cross[rHelio,vHelio],
    "HeliocentricSpecificKineticEnergy_J_kg"->helioSpeed^2/2.,
    "HeliocentricCircularSpeedIfGravityOnly_m_s"->Sqrt[mu/in["Distance_m"]],
    "HeliocentricEscapeSpeedIfGravityOnly_m_s"->Sqrt[2. mu/in["Distance_m"]],
    "HeliocentricSpecificMechanicalEnergy_J_kg"->helioSpeed^2/2.-mu/in["Distance_m"],
    "LocalFrameInitialVelocityIsIndependentInput"->True,
    "HeliocentricReferenceMotionMode"->in["HeliocentricReferenceMotionMode"],
    "HeliocentricReferenceDynamics"->"The selected pole-specific reference motion mode is StaticHover. Its heliocentric reference velocity must be zero. The model calculates kinetic energy, specific angular momentum, gravity-only circular speed, escape speed and specific mechanical energy as diagnostics. Local perturbation dynamics use the separate local-frame initial position and velocity. Keplerian/orbital propagation and rotating-frame coupling are not implemented in this Phase 1 model.",
    "InitialPositionLocal_m"->in["InitialPositionLocal_m"],
    "InitialVelocityLocal_m_s"->in["InitialVelocityLocal_m_s"],
    "InitialAttitudeSmallAngles_rad"->theta,"InitialQuaternion"->q,
    "InitialAngularVelocity_rad_s"->omega,
    "StationPositionsAbsoluteLocal_m"->stationsAbsolute,
    "MassPointPositionsLocal_m"->centered,"MassPointMasses_kg"->masses,
    "MassPointKinds"->massPointKinds,"MassPointIdentifiers"->massPointIdentifiers,
    "MassPointCount"->Length[masses],
    "StationPositionsLocal_m"->(#-com& /@ stationsAbsolute),
    "WrenchMatrix"->phase1WrenchMatrix[(#-com& /@ stationsAbsolute)],
    "MassDistributionModel"->in["MassDistributionModel"],
    "InertiaApproximation"->"User-selected uniform sheet mass is distributed over surface patches, perimeter hardware is discretized as equal point masses around the calculated planform perimeter, and stations are point masses at their registered coordinates. Centre of mass and inertia are recalculated from all registered mass points; each component mass is counted once. This is a lumped approximation, not a complete component-level mass distribution.",
    "MassConservationResidual_kg"->(Total[masses]-total),
    "HeliocentricAndLocalFramesSeparated"->True|>
];

phase1WrenchMatrix[stations_List] := Module[{blocks,skew},
  skew[p_] := {{0.,-p[[3]],p[[2]]},{p[[3]],0.,-p[[1]]},{-p[[2]],p[[1]],0.}};
  blocks=Table[Join[IdentityMatrix[3],skew[stations[[i]]]],{i,Length[stations]}];
  ArrayFlatten[{blocks}]
];

(* Apply a station-force capacity without allowing Automatic to enter a numeric
   comparison. Automatic means the hardware rating is unknown: preserve the
   calculated demand for sizing/diagnostics, but explicitly leave qualification
   false. Infinity is a deliberate idealized unbounded-capacity mode, also not
   hardware qualification. Only a finite positive rating can qualify capacity. *)
(* WHAT: Apply the configured per-station force limit to four three-axis force vectors.
   WHY: Every allocation path must preserve demand when capacity is unknown or idealized,
   and must report clipping explicitly when a finite model limit is supplied.
   HOW: Accept a nonempty list of finite-real three-vector station forces. The generic
   capacity helper supports isolated station-count fixtures; the physical project controller
   separately requires the governing four-station 6-by-12 wrench map. Automatic and Infinity
   retain unbounded demand for sizing diagnostics; a finite positive scalar clips each station
   independently without changing force direction. This is not hardware qualification. *)
phase1ApplyStationCapacity[forces_List,capacity_] := Module[
  {applied,saturated,mode,forceCapacitySpecified},
  If[forces==={}||!And@@(phase1FiniteRealVectorQ[#,3]&/@forces),
    Return[Failure["InvalidStationForceVectors",<|"StationCount"->Length[forces],
      "Forces"->forces,"Requirement"->"A nonempty list of finite-real three-vector station forces."|>]]
  ];
  Which[
    capacity===Automatic,
      applied=forces;mode="UnknownCapacity_UnclippedDemand";forceCapacitySpecified=False,
    capacity===Infinity,
      applied=forces;mode="IdealizedUnboundedCapacity";forceCapacitySpecified=False,
    phase1FiniteRealNumberQ[capacity]&&TrueQ[capacity>0.],
      applied=Map[If[Norm[#]>capacity,capacity Normalize[#],#]&,forces];
      mode="ExplicitFinitePerStationLimit";forceCapacitySpecified=True,
    True,
      Return[Failure["InvalidStationForceCapacity",<|"CapacityPerStation_N"->capacity,
        "Requirement"->"Automatic, Infinity for an idealized unbounded run, or a finite positive real force rating."|>]]
  ];
  saturated=MapThread[Norm[#1-#2]>0.&,{forces,applied}];
  <|"AppliedStationForces_N"->applied,"SaturationByStation"->saturated,
    "CapacityPerStation_N"->capacity,"CapacityMode"->mode,
    "ForceCapacitySpecified"->forceCapacitySpecified,
    "HardwareQualified"->False,
    "HardwareQualificationBlockers"->{"No complete actuator torque/stroke/bandwidth/power rating set or qualification evidence is represented by the Phase 1 model."},
    "UnconstrainedDemandPreserved"->(capacity===Automatic||capacity===Infinity)|>
];

(* WHAT: Solve the six-axis assembly wrench with the four registered ICARUS stations.
   WHY: This is the common force-allocation path for static basis checks, dynamic control
   and redesign sizing; malformed geometry or a rank-deficient wrench map must not yield
   a plausible-looking station-force record.
   HOW: Require a finite six-vector demand, exactly four finite-real station locations, and
   a finite full-rank 6-by-12 wrench matrix. Solve the unconstrained least-norm station
   forces, apply only the configured per-station force limit, then report force and moment
   reconstruction residuals separately so unlike physical units are never combined. *)
phase1Controller[dyn_Association,wrench_,capacity_] := Module[
  {in=Phase1GetInputs[],stations,w,raw,blocks,capacityResult,clipped,saturated,achieved,
   forceResidual,momentResidual,forceScale,momentScale,tol,reconstructionPass,
   characteristicLength,wrenchRowScale,scaledWrenchMatrix,scaledDemand},
  If[!phase1FiniteRealVectorQ[wrench,6],
    Return[Failure["InvalidDesiredICARUSWrench",<|"DesiredWrench"->wrench,
      "RequiredShape"->{6},"ComponentOrder"->{"Fx_N","Fy_N","Fz_N","Mx_Nm","My_Nm","Mz_Nm"}|>]]
  ];
  w=Lookup[dyn,"WrenchMatrix",Missing["WrenchMatrixUnavailable"]];
  stations=Lookup[dyn,"StationPositionsLocal_m",Missing["StationPositionsUnavailable"]];
  If[MissingQ[w],
    If[!ListQ[stations]||Length[stations]=!=4||!And@@(phase1FiniteRealVectorQ[#,3]&/@stations),
      Return[Failure["InvalidICARUSStationGeometry",<|"StationPositionsLocal_m"->stations|>]]
    ];
    w=phase1WrenchMatrix[stations],
    (* A supplied matrix is sufficient for the isolated allocator primitive and its
       small deterministic helper fixtures. When physical station coordinates are also
       supplied, validate them; the Step 4 production path always supplies both. *)
    If[!MissingQ[stations]&&(!ListQ[stations]||Length[stations]=!=4||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@stations)),
      Return[Failure["InvalidICARUSStationGeometry",<|"StationPositionsLocal_m"->stations|>]]
    ]
  ];
  If[!MatrixQ[w,phase1FiniteRealNumberQ]||Dimensions[w]=!={6,12},
    Return[Failure["InvalidICARUSWrenchMatrix",<|"Dimensions"->If[MatrixQ[w],Dimensions[w],Missing["NotAMatrix"]],
      "RequiredDimensions"->{6,12},"RequiredRank"->6|>]]
  ];
  (* Force rows are in newtons while moment rows are in newton-metres. For the
     heliocentric collector, station lever arms are many orders of magnitude larger
     than one metre; applying PseudoInverse directly to the unscaled 6x12 matrix
     numerically suppresses the force rows and can fail even though the physical
     wrench matrix is full rank. Scale moment rows by the characteristic station
     radius before solving. This is an invertible row transformation, so it preserves
     the exact wrench constraint set and the minimum-norm station-force solution,
     while making force and moment rows comparable for numerical rank/SVD work. *)
  characteristicLength=If[ListQ[stations]&&Length[stations]===4,
    Max[Norm/@stations],
    Max[Norm/@w[[4;;6]]]/Max[Sqrt[$MinMachineNumber],Max[Norm/@w[[1;;3]]]]
  ];
  If[!phase1FiniteRealNumberQ[characteristicLength]||!TrueQ[characteristicLength>0.],
    Return[Failure["InvalidICARUSWrenchCharacteristicLength",<|"CharacteristicLength_m"->characteristicLength|>]]
  ];
  wrenchRowScale=DiagonalMatrix[Join[ConstantArray[1.,3],ConstantArray[1./characteristicLength,3]]];
  scaledWrenchMatrix=wrenchRowScale.w;
  scaledDemand=wrenchRowScale.wrench;
  If[MatrixRank[scaledWrenchMatrix]=!=6,
    Return[Failure["InvalidICARUSWrenchMatrix",<|"Dimensions"->Dimensions[w],
      "ScaledRank"->MatrixRank[scaledWrenchMatrix],"RequiredRank"->6,
      "CharacteristicLength_m"->characteristicLength|>]]
  ];
  raw=Quiet@Check[PseudoInverse[scaledWrenchMatrix].scaledDemand,$Failed];
  If[raw===$Failed||!phase1FiniteRealVectorQ[raw,12],
    Return[Failure["ICARUSWrenchAllocationSolveFailed",<|"WrenchMatrix"->w,"DesiredWrench"->wrench|>]]
  ];
  blocks=Partition[raw,3];
  capacityResult=phase1ApplyStationCapacity[blocks,capacity];
  If[FailureQ[capacityResult],Return[capacityResult]];
  clipped=capacityResult["AppliedStationForces_N"];
  saturated=capacityResult["SaturationByStation"];
  achieved=w.Flatten[clipped];
  If[!phase1FiniteRealVectorQ[achieved,6],
    Return[Failure["ICARUSAchievedWrenchInvalid",<|"AchievedWrench"->achieved|>]]
  ];
  forceResidual=Norm[achieved[[1;;3]]-wrench[[1;;3]]];
  momentResidual=Norm[achieved[[4;;6]]-wrench[[4;;6]]];
  (* A pure torque request has a zero target force, and a pure force request has
     a zero target moment. Scaling each residual only by its own near-zero target
     incorrectly rejects harmless roundoff in the nominally-zero channel. Use the
     characteristic length to express the wrench's moment magnitude as an equivalent
     force reference, then derive separate N and N m scales from that common physical
     envelope. The force and moment residuals remain independently tested and reported. *)
  forceScale=Max[Sqrt[$MinMachineNumber],Norm[wrench[[1;;3]]],Norm[achieved[[1;;3]]],
    Norm[wrench[[4;;6]]]/characteristicLength,Norm[achieved[[4;;6]]]/characteristicLength];
  momentScale=characteristicLength forceScale;
  tol=Lookup[in,"ICARUSLoadMapRelativeTolerance",Missing["WrenchToleranceUnavailable"]];
  reconstructionPass=If[phase1FiniteRealNumberQ[tol]&&TrueQ[tol>0.],
    TrueQ[forceResidual<=tol forceScale&&momentResidual<=tol momentScale],False];
  <|"DesiredWrench"->wrench,"UnconstrainedStationForces_N"->blocks,
    "StationForces_N"->clipped,"AchievedWrench"->achieved,
    "WrenchResidual"->(achieved-wrench),"ForceWrenchResidual_N"->forceResidual,
    "MomentWrenchResidual_Nm"->momentResidual,"ForceWrenchReferenceScale_N"->forceScale,
    "MomentWrenchReferenceScale_Nm"->momentScale,"WrenchReconstructionPass"->reconstructionPass,
    "SaturationByStation"->saturated,"CapacityPerStation_N"->capacity,
    "ForceCapacitySpecified"->capacityResult["ForceCapacitySpecified"],
    "HardwareQualified"->False,
    "CapacityMode"->capacityResult["CapacityMode"],"WrenchMatrix"->w,
    "WrenchAllocatorMethod"->"Minimum-norm pseudoinverse on an invertibly row-scaled wrench matrix; moment rows divided by characteristic station radius.",
    "WrenchCharacteristicLength_m"->characteristicLength,
    "ScaledWrenchMatrixRank"->MatrixRank[scaledWrenchMatrix]|>
];

(* Per-station force and moment demand are resolved independently at every
   dynamic sample. The force vectors, station positions and r x F moments are all
   expressed in the active pole's COM-centred collector body frame. The moment is
   not an actuator-local torque-rating comparison.
   WHAT: Preserve the vector demand, peak magnitude, direction, sample index and time
   for each station independently.
   WHY: A scalar peak alone cannot specify actuator orientation or identify when the
   largest load occurs in the disturbance/recovery history.
   HOW: Evaluate each finite-real force vector and its station-position cross product at every
   sampled state. Optional sample times, when supplied, must be finite real and strictly
   increasing; legacy two-argument internal diagnostics remain valid and explicitly report
   missing sample-time metadata rather than inventing it. The helper permits any positive
   station count for isolated diagnostics; the physical ICARUS controller separately
   enforces the project's four-station geometry. *)
phase1StationDemandSummary[stationPositions_List,forceSamples_List,sampleTimes_:Automatic] := Module[
  {stationCount,forceMagnitudes,torqueVectors,torqueMagnitudes,peakForceIndices,peakTorqueIndices,
   timeAt,peakForceVectors,peakTorqueVectors},
  stationCount=Length[stationPositions];
  If[stationCount<1 || !And@@(phase1FiniteRealVectorQ[#,3]&/@stationPositions),
    Return[Failure["InvalidStationPositionsForDemandSummary",<|"StationPositions"->stationPositions,
      "Requirement"->"A nonempty station register containing finite-real three-dimensional positions."|>]]
  ];
  If[!ListQ[forceSamples] || forceSamples==={} ||
      !And@@(Function[sample,ListQ[sample]&&Length[sample]===stationCount&&
        And@@(phase1FiniteRealVectorQ[#,3]&/@sample)]/@forceSamples),
    Return[Failure["InvalidStationForceSamplesForDemandSummary",<|"StationCount"->stationCount,
      "ForceSamples"->forceSamples,"Requirement"->"Each sample must contain one finite-real three-vector per registered station."|>]]
  ];
  If[sampleTimes=!=Automatic&&(!ListQ[sampleTimes]||Length[sampleTimes]=!=Length[forceSamples]||
      !phase1FiniteRealVectorQ[sampleTimes,Length[forceSamples]]||
      !TrueQ[And@@Thread[Rest[sampleTimes]>Most[sampleTimes]]]),
    Return[Failure["InvalidStationDemandSampleTimes",<|"SampleCount"->Length[forceSamples],
      "TimeCount"->If[ListQ[sampleTimes],Length[sampleTimes],Missing["NotAList"]],
      "Requirement"->"Finite-real sample times strictly increase and align one-to-one with force samples."|>]]
  ];
  forceMagnitudes=Map[Norm,forceSamples,{2}];
  torqueVectors=Table[Cross[stationPositions[[j]],forceSamples[[i,j]]],
    {i,Length[forceSamples]},{j,stationCount}];
  torqueMagnitudes=Map[Norm,torqueVectors,{2}];
  peakForceIndices=Table[First@Ordering[forceMagnitudes[[All,j]],-1],{j,stationCount}];
  peakTorqueIndices=Table[First@Ordering[torqueMagnitudes[[All,j]],-1],{j,stationCount}];
  peakForceVectors=Table[forceSamples[[peakForceIndices[[j]],j]],{j,stationCount}];
  peakTorqueVectors=Table[torqueVectors[[peakTorqueIndices[[j]],j]],{j,stationCount}];
  timeAt[index_Integer] := If[sampleTimes===Automatic,Missing["SampleTimesNotSupplied"],sampleTimes[[index]]];
  <|"StationForceVectorsBySample_N"->forceSamples,
    "StationForceMagnitudesBySample_N"->forceMagnitudes,
    "StationTorqueVectorsBySample_Nm"->torqueVectors,
    "StationTorqueMagnitudesBySample_Nm"->torqueMagnitudes,
    "MaximumStationForceByStation_N"->(Max/@Transpose[forceMagnitudes]),
    "MaximumStationTorqueByStation_Nm"->(Max/@Transpose[torqueMagnitudes]),
    "PeakStationForceSampleIndices"->peakForceIndices,
    "PeakStationForceTimes_s"->(timeAt/@peakForceIndices),
    "PeakStationForceVectors_N"->peakForceVectors,
    "PeakStationForceUnitDirections"->Map[If[Norm[#]>0.,Normalize[#],{0.,0.,0.}]&,peakForceVectors],
    "PeakStationTorqueSampleIndices"->peakTorqueIndices,
    "PeakStationTorqueTimes_s"->(timeAt/@peakTorqueIndices),
    "PeakStationTorqueVectors_Nm"->peakTorqueVectors,
    "MaximumStationForce_N"->Max[Flatten[forceMagnitudes]],
    "MaximumStationTorque_Nm"->Max[Flatten[torqueMagnitudes]],
    "SampleTimesSupplied"->(sampleTimes=!=Automatic),
    "ReferenceFrame"->"Active pole's COM-centred collector body frame; station positions, force vectors and r x F vectors use the same body frame at each dynamic sample.",
    "TorqueMeaning"->"Moment contribution of each station force about the assembly centre of mass, calculated as r x F. This is required demand, not an actuator torque rating."|>
];

(* Step 4 load-path input predicates are deliberately stricter than NumericQ:
   NumericQ alone can admit complex or non-finite numeric expressions. These helpers
   are shared by the static station map, concentrated attachment-gravity map and
   time-sampled environment transfer so each path accepts only finite real engineering
   quantities in the expected vector dimensions. They validate data shape and domain;
   they do not prove that an upstream physical model is correct. *)
phase1FiniteRealNumberQ[value_] := TrueQ[
  NumericQ[value] &&
  FreeQ[value, Indeterminate|ComplexInfinity|_DirectedInfinity] &&
  Im[N[value]]==0 && Abs[N[value]]<Infinity
];

phase1FiniteRealVectorQ[value_,length_Integer] := TrueQ[
  ListQ[value] && Length[value]===length &&
  And@@(phase1FiniteRealNumberQ /@ value)
];

(* A quaternion must be a finite-real four-vector with a finite, strictly positive
   norm before any rotation matrix, attitude angle, or quaternion normalization uses it.
   This predicate deliberately does not replace the configured unit-norm tolerance:
   zero/invalid norm is an input-domain failure, while small norm drift is evaluated
   separately by the trajectory acceptance checks. *)
phase1FiniteNonzeroQuaternionQ[value_] := TrueQ[
  phase1FiniteRealVectorQ[value,4] &&
  phase1FiniteRealNumberQ[Norm[value]] && TrueQ[Norm[value]>0.]
];

(* ------------------------------------------------------------------------
   STEP 5 — MATERIAL, MEMBRANE AND STRUCTURAL ARCHITECTURE
   ------------------------------------------------------------------------
   WHAT: Size the aluminum foil span between adjacent structural electrical runs,
   derive mechanical requirements for the inter-node bus runs acting as ribs, and
   compare a candidate anti-sunward film with mass-equivalent aluminum alone.
   WHY: The same inter-node wiring grid is intended to conduct electrical current and
   support the continuous ultrathin aluminum sheet. The unsupported foil panel between
   runs therefore sets a minimum viable foil thickness and a maximum allowable run
   spacing. The model must not add foil thickness without a demonstrated span/load
   requirement. An optional backside film is retained only if it outperforms a thicker
   aluminum-only alternative at equal total areal mass in both strength-per-mass and
   bending rigidity, with a characterized and qualified bond.
   HOW: Read the supplied same-pole Step 4 assessment; never call Step 4 or borrow the
   other pole's state. The global preliminary envelope combines the maximum local
   patch-normal pressure with the maximum patch tangential-traction magnitude; these
   extrema may occur on different patches. Patchwise panel screens use co-located
   normal pressure and tangential traction. Model the foil between runs as a simply
   supported, one-way, unit-width strip under uniform transverse pressure, with the
   same-pole membrane pretension treated as a uniform in-plane tensile resultant. That
   pretension contributes direct tensile stress and participates in the tension-plus-
   bending deflection solution. Uniformity of pretension is an input assumption, not a
   demonstrated stress field. Derive stress/deflection-limited spacing at the current
   aluminum baseline, or calculate the minimum thickness for a supplied candidate
   spacing. Do not credit two-way plate/shell action, directional membrane-network load
   redistribution, or wiring-rib bending stiffness in this one-way strip screen. Convert
   each rib's tributary normal and tangential surface-load magnitudes to a conservative
   equivalent uniform line load. The cable demand uses a small-sag parabolic cable
   approximation: the design horizontal tension required to hold the permitted sag is
   q L^2/(8 delta), vertical end reaction is q L/2, and the endpoint resultant sets the
   anchor demand. Separately, calculate the operating sag upper bound q L^2/(8 H_min)
   using a user-supplied lower bound on horizontal cable tension across the complete
   same-pole operating envelope. Require separate, traceable evidence for both positive
   cable tautness and the minimum horizontal-tension bound. These are source-supplied
   evidence assertions; the routine does not derive the envelope tension history. The
   parabolic approximation does not solve a direction-resolved catenary or cable-net
   interaction. Report cable tension, operating sag, axial rigidity EA and end-anchor
   demand, but do not treat the evidence reference as hardware qualification. Step 7 must supply exact node/run paths, conductor section/material,
   current, resistance, temperature, run length, mass and support coordinates before
   the rib model can be integrated into the active design mass.

   DuPont Kapton HN is recorded as a manufacturer-data candidate at its 12.7 um gauge.
   The ideal-bond laminate calculation is an optimistic upper bound; missing bond mass
   or bond qualification blocks selection. The candidate registry does not itself add
   film mass. Every result remains pole-local; no combined mechanical state is formed.
   ------------------------------------------------------------------------ *)
(* WHAT: Screen the low-mass intra-node tab/solder connector interface from one
   explicitly supplied pole-local connection record.
   WHY: PV cells within a node need short, low-mass electrical and mechanical
   interconnects. Their tab section, overlap/joint area, material density and elastic
   modulus determine connector mass, tab tension, nominal joint shear/peel stress and
   elastic extension. This is a distinct structural tier from the long inter-node bus
   runs that serve as the collector's candidate support ribs.
   HOW: Require the caller to supply the actual number of connections, tabs per
   connection, tab dimensions and constitutive properties, solder volume/density, and
   per-connection mechanical demands. Calculate a finite-real screening result and
   component mass. Nominal overlap stresses are simple average-stress screens only;
   they do not resolve solder fillets, eccentricity, peel concentration, fatigue,
   thermal cycling, electrical resistance, or process defects. No material is selected
   and no active mass input is changed by this helper. Missing Step 7 geometry and
   topology must remain explicit blockers rather than being guessed here. *)
(* WHAT: Evaluate the actual structural capacity and mass of supplied inter-node
   conductor runs and their shared physical anchors, independently for the active pole.
   WHY: An inter-node bus is intended to serve as a structural rib. Each routed run must
   meet its tensile and axial-rigidity requirements, while a physical anchor shared by
   several runs must resist their combined end demands and be counted once in structural
   mass. Treating each run's anchor rating independently would over-credit a shared
   junction and could duplicate anchor mass.
   HOW: Consume explicit same-pole run records with start/end AnchorIDs and a separate
   unique AnchorRecords register. Sum the magnitudes of all factored run-end demands
   attached to each anchor, a conservative rule when individual load directions are not
   supplied, and compare the aggregate with that anchor's unfactored capacity. Count each
   anchor mass once. The actual Step 4 patch pressure, tangential-traction magnitude and
   curved-area data may be integrated through supplied TributaryPatchShares; each patch's
   shares must close to one and both normal and tangential load integrals must conserve
   across the rib set. Those shares are not derived by this helper: each run also needs a
   non-empty geometry-evidence reference. Normal and tangential line-load magnitudes are
   added conservatively because rib-local directional projection is unresolved. The
   combined load is represented as an equivalent uniform line load over the unsupported
   span. The calculated design tension establishes the allowable sag; a separate operating
   sag check uses the user-supplied minimum horizontal tension across all same-pole cases
   and a separately evidenced maximum effective transverse acceleration component normal to the run axis. The scalar is a bound on the cable-normal component across run orientations and operating cases, not a complete acceleration vector; this routine does not project a vector from the Step 4 trajectory. Physical conductor
   mass per length is conductor count times strand area times material density, plus the
   supplied insulation linear mass. That total linear mass times the supplied transverse
   acceleration is added to the Step 4 surface-load envelope before design tension and
   q L^2/(8 H_min) operating sag are calculated. If acceleration evidence is absent, only
   a surface-load partial screen is retained and the structural run cannot pass; no zero
   cable-self-load assumption is silently credited. Acceleration and tension evidence are
   user supplied and not independently authenticated here. Without patch shares, a peak
   normal-plus-tangential envelope remains a provisional acceptance blocker. No AWG, current,
   resistance or I2R sizing is performed. *)
phase1Step5InterNodeRibScreenCurrent[data_Association,peakPressure_,peakTangentialTraction_,sagFraction_,
    extensionFraction_,safetyFactor_,step4PatchData_Association] := Module[
  {pole=Lookup[data,"Pole",None],materialName=Lookup[data,"ConductorMaterialName","Unspecified conductor"],
   density=Lookup[data,"ConductorDensity_kg_m3",Missing["ConductorDensityUnavailable"]],
   modulus=Lookup[data,"ConductorYoungsModulus_Pa",Missing["ConductorModulusUnavailable"]],
   tensileAllowable=Lookup[data,"ConductorTensileAllowable_Pa",Missing["ConductorTensileAllowableUnavailable"]],
   area=Lookup[data,"ConductorCrossSectionArea_m2",Missing["ConductorSectionUnavailable"]],
   runRecords=Lookup[data,"RunRecords",{}],anchorRecords=Lookup[data,"AnchorRecords",{}],
   runIDs,startAnchorIDs,endAnchorIDs,runLengths,spans,widths,counts,insulationLinearMass,
   requestedLoadBearingCounts,
   anchorIDs,anchorCapacities,anchorMasses,anchorLookup,usedAnchorIDs,anchorDemandRecords,anchorResults,
   patchIndices,patchPressures,patchTangentialTractions,patchAreas,patchNormals,patchTolerance,patchLookup,sharesByRun,
   anyPatchShares,allPatchShares,allShareRecords,shareIndices,shareValues,perRunShareIndices,
   patchCoverageShares,patchShareMapPass,coverageSharePass,patchLoadTotal,runLoadTotal,pressureClosureError,
   patchTangentialLoadTotal,runTangentialLoadTotal,tangentialClosureError,tangentialConservationPass,
   minimumOperatingTensions,minimumOperatingHorizontalTensions,maximumEffectiveTransverseAccelerations,runResults,conductorMass,insulationMass,anchorMass,totalMass,allRunPass,
   allRunCapacityPass,allAnchorCapacityPass,allAnchorQualified,allTributaryGeometryEvidence,allCableTautnessPass,
   allOperatingHorizontalTensionEvidencePass,allCombinedLineLoadEvidencePass,allOperatingSagWithinLimit,allOperatingSagPass,
   anyOperatingSagLimitExceeded,maximumOperatingSagUpperBound,allConductorLoadSharingRequirementsSatisfied},
  If[pole=!=$Phase1CurrentPole,
    Return[Failure["Step5InterNodeRibPoleMismatch",<|"ActivePole"->$Phase1CurrentPole,"RibRecordPole"->pole|>]]
  ];
  If[!StringQ[materialName]||StringTrim[materialName]===""||
      !And@@(phase1FiniteRealNumberQ/@{density,modulus,tensileAllowable,area,peakPressure,
        peakTangentialTraction,sagFraction,extensionFraction,safetyFactor})||
      !TrueQ[peakTangentialTraction>=0.]||
      !And@@(TrueQ[#>0.]&/@{density,modulus,tensileAllowable,area,peakPressure,sagFraction,
        extensionFraction,safetyFactor})||
      !TrueQ[safetyFactor>=1.&&sagFraction<1.&&extensionFraction<1.]||
      !ListQ[runRecords]||runRecords==={}||!And@@(AssociationQ/@runRecords)||
      !ListQ[anchorRecords]||anchorRecords==={}||!And@@(AssociationQ/@anchorRecords),
    Return[Failure["Step5InterNodeRibMaterialRunOrAnchorInputsInvalid",<|"Pole"->pole,
      "RunRecords"->runRecords,"AnchorRecords"->anchorRecords|>]]
  ];
  runIDs=Lookup[runRecords,"RunID",Missing["RunIDUnavailable"]];
  startAnchorIDs=Lookup[runRecords,"StartAnchorID",Missing["StartAnchorIDUnavailable"]];
  endAnchorIDs=Lookup[runRecords,"EndAnchorID",Missing["EndAnchorIDUnavailable"]];
  anchorIDs=Lookup[anchorRecords,"AnchorID",Missing["AnchorIDUnavailable"]];
  anchorCapacities=Lookup[anchorRecords,"AnchorUnfactoredCapacity_N",Missing["AnchorCapacityUnavailable"]];
  anchorMasses=Lookup[anchorRecords,"AnchorMass_kg",Missing["AnchorMassUnavailable"]];
  If[!And@@(StringQ/@runIDs)||!And@@(StringTrim[#]=!=""&/@runIDs)||
      Length[DeleteDuplicates[runIDs]]=!=Length[runIDs]||
      !And@@(StringQ/@anchorIDs)||!And@@(StringTrim[#]=!=""&/@anchorIDs)||
      Length[DeleteDuplicates[anchorIDs]]=!=Length[anchorIDs]||
      !And@@(StringQ/@startAnchorIDs)||!And@@(StringQ/@endAnchorIDs)||
      !And@@(MemberQ[anchorIDs,#]&/@Join[startAnchorIDs,endAnchorIDs])||
      !And@@(UnsameQ@@#&/@Transpose[{startAnchorIDs,endAnchorIDs}])||
      !And@@(phase1FiniteRealNumberQ/@anchorCapacities)||!And@@(TrueQ[#>0.]&/@anchorCapacities)||
      !And@@(phase1FiniteRealNumberQ/@anchorMasses)||!And@@(TrueQ[#>0.]&/@anchorMasses),
    Return[Failure["Step5InterNodeRunOrAnchorRegisterInvalid",<|"Pole"->pole,
      "RunIDs"->runIDs,"StartAnchorIDs"->startAnchorIDs,"EndAnchorIDs"->endAnchorIDs,
      "AnchorIDs"->anchorIDs,"AnchorCapacities_N"->anchorCapacities,
      "AnchorMasses_kg"->anchorMasses|>]]
  ];
  usedAnchorIDs=DeleteDuplicates[Join[startAnchorIDs,endAnchorIDs]];
  If[Length[usedAnchorIDs]=!=Length[anchorIDs]||!And@@(MemberQ[usedAnchorIDs,#]&/@anchorIDs),
    Return[Failure["Step5InterNodeAnchorRegisterContainsUnreferencedOrMissingAnchors",<|
      "Pole"->pole,"RunReferencedAnchorIDs"->usedAnchorIDs,"AnchorRecordIDs"->anchorIDs|>]]
  ];
  runLengths=Lookup[runRecords,"ActualRunLength_m",Missing["RunLengthUnavailable"]];
  spans=Lookup[runRecords,"UnsupportedSpan_m",Missing["UnsupportedSpanUnavailable"]];
  widths=Lookup[runRecords,"TributaryWidth_m",Missing["TributaryWidthUnavailable"]];
  counts=Lookup[runRecords,"ConductorCountPerRun",Missing["ConductorCountUnavailable"]];
  requestedLoadBearingCounts=(Lookup[#,"EffectiveLoadBearingConductorCount",1]&/@runRecords);
  insulationLinearMass=Lookup[runRecords,"InsulationLinearMass_kg_per_m",Missing["InsulationMassUnavailable"]];
  minimumOperatingTensions=Lookup[runRecords,"MinimumOperatingCableTensionAcrossCases_N",Missing["MinimumOperatingCableTensionUnavailable"]];
  minimumOperatingHorizontalTensions=Lookup[runRecords,"MinimumOperatingHorizontalTensionAcrossCases_N",Missing["MinimumOperatingHorizontalTensionUnavailable"]];
  If[!And@@((MissingQ[#]||(phase1FiniteRealNumberQ[#]&&TrueQ[#>=0.]))&/@minimumOperatingTensions),
    Return[Failure["Step5InterNodeCableTautnessInputInvalid",<|"Pole"->pole,
      "MinimumOperatingCableTensionAcrossCases_N"->minimumOperatingTensions|>]]
  ];
  If[!And@@((MissingQ[#]||(phase1FiniteRealNumberQ[#]&&TrueQ[#>0.]))&/@minimumOperatingHorizontalTensions),
    Return[Failure["Step5InterNodeHorizontalTensionInputInvalid",<|"Pole"->pole,
      "MinimumOperatingHorizontalTensionAcrossCases_N"->minimumOperatingHorizontalTensions|>]]
  ];
  maximumEffectiveTransverseAccelerations=Lookup[runRecords,"MaximumEffectiveTransverseAccelerationAcrossCases_m_s2",
    Missing["MaximumEffectiveTransverseAccelerationUnavailable"]];
  If[!And@@((MissingQ[#]||(phase1FiniteRealNumberQ[#]&&TrueQ[#>=0.]))&/@maximumEffectiveTransverseAccelerations),
    Return[Failure["Step5InterNodeEffectiveTransverseAccelerationInputInvalid",<|"Pole"->pole,
      "MaximumEffectiveTransverseAccelerationAcrossCases_m_s2"->maximumEffectiveTransverseAccelerations|>]]
  ];
  If[!And@@(IntegerQ/@requestedLoadBearingCounts)||
      !And@@MapThread[TrueQ[1<=#1<=#2]&,{requestedLoadBearingCounts,counts}],
    Return[Failure["Step5InterNodeConductorLoadSharingCountInvalid",<|"Pole"->pole,
      "PhysicalConductorCounts"->counts,"RequestedEffectiveLoadBearingCounts"->requestedLoadBearingCounts|>]]
  ];
  If[!And@@(phase1FiniteRealNumberQ/@runLengths)||!And@@(TrueQ[#>0.]&/@runLengths)||
      !And@@(phase1FiniteRealNumberQ/@spans)||!And@@(TrueQ[#>0.]&/@spans)||
      !And@@(phase1FiniteRealNumberQ/@widths)||!And@@(TrueQ[#>0.]&/@widths)||
      !And@@(IntegerQ/@counts)||!And@@(TrueQ[#>=1]&/@counts)||
      !And@@(phase1FiniteRealNumberQ/@insulationLinearMass)||!And@@(TrueQ[#>=0.]&/@insulationLinearMass)||
      !And@@MapThread[LessEqual,{spans,runLengths}],
    Return[Failure["Step5InterNodeRibRunGeometryInvalid",<|"Pole"->pole,
      "RunLengths_m"->runLengths,"UnsupportedSpans_m"->spans,"TributaryWidths_m"->widths,
      "ConductorCounts"->counts,"InsulationLinearMass_kg_per_m"->insulationLinearMass|>]]
  ];
  anchorLookup=AssociationThread[anchorIDs,anchorRecords];
  (* The exact pressure integration consumes the same pole-local Step 4 curved mesh
     record used by the foil-panel screen. The share records are supplied from the
     independently established rib/tributary geometry; they are not inferred here. *)
  patchIndices=Lookup[step4PatchData,"PatchIndices",{}];
  patchPressures=Lookup[step4PatchData,"PatchPressureSamples_Pa",{}];
  patchTangentialTractions=Lookup[step4PatchData,"PatchTangentialTractionSamples_Pa",{}];
  patchAreas=Lookup[step4PatchData,"PatchAreaWeights_m2",{}];
  patchNormals=Lookup[step4PatchData,"PatchNormals",{}];
  patchTolerance=Lookup[step4PatchData,"AreaShareClosureTolerance",Missing["PatchShareToleranceUnavailable"]];
  If[!ListQ[patchIndices]||patchIndices==={}||!VectorQ[patchIndices,IntegerQ]||
      Sort[patchIndices]=!=Range[Length[patchIndices]]||
      !ListQ[patchPressures]||Length[patchPressures]=!=Length[patchIndices]||
      !And@@(phase1FiniteRealNumberQ/@patchPressures)||!And@@(TrueQ[#>=0.]&/@patchPressures)||
      !ListQ[patchTangentialTractions]||Length[patchTangentialTractions]=!=Length[patchIndices]||
      !And@@(phase1FiniteRealNumberQ/@patchTangentialTractions)||
      !And@@(TrueQ[#>=0.]&/@patchTangentialTractions)||
      !ListQ[patchAreas]||Length[patchAreas]=!=Length[patchIndices]||
      !And@@(phase1FiniteRealNumberQ/@patchAreas)||!And@@(TrueQ[#>0.]&/@patchAreas)||
      !ListQ[patchNormals]||Length[patchNormals]=!=Length[patchIndices]||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@patchNormals)||
      !And@@(TrueQ[Abs[Norm[#]-1.]<=Sqrt[$MachineEpsilon]]&/@patchNormals)||
      !phase1FiniteRealNumberQ[patchTolerance]||!TrueQ[0.<patchTolerance<1.],
    Return[Failure["Step5InterNodeRibStep4PatchDataInvalid",<|"Pole"->pole,
      "PatchIndexCount"->Length[patchIndices],"PatchPressureCount"->Length[patchPressures],
      "PatchAreaCount"->Length[patchAreas],"PatchNormalCount"->Length[patchNormals]|>]]
  ];
  patchLookup=AssociationThread[patchIndices,Range[Length[patchIndices]]];
  sharesByRun=(Lookup[#,"TributaryPatchShares",{}]&/@runRecords);
  anyPatchShares=Or@@((ListQ[#]&&Length[#]>0)&/@sharesByRun);
  allPatchShares=And@@((ListQ[#]&&Length[#]>0)&/@sharesByRun);
  If[anyPatchShares&&!allPatchShares,
    Return[Failure["Step5InterNodeRibPatchShareRecordsIncomplete",<|"Pole"->pole,
      "RunsWithPatchShareRecords"->Pick[runIDs,(ListQ[#]&&Length[#]>0)&/@sharesByRun,True],
      "AllRunIDs"->runIDs|>]]
  ];
  patchShareMapPass=allPatchShares;
  coverageSharePass=False;
  pressureClosureError=Missing["PatchAreaShareIntegrationNotAvailable"];
  If[patchShareMapPass,
    If[!And@@(And@@(AssociationQ/@#)&/@sharesByRun),
      Return[Failure["Step5InterNodeRibPatchShareRecordMalformed",<|"Pole"->pole|>]]
    ];
    allShareRecords=Flatten[sharesByRun,1];
    shareIndices=Lookup[allShareRecords,"PatchIndex",Missing["PatchIndexUnavailable"]];
    shareValues=Lookup[allShareRecords,"AreaShare",Missing["AreaShareUnavailable"]];
    perRunShareIndices=(Lookup[#,"PatchIndex",Missing["PatchIndexUnavailable"]]&/@#)&/@sharesByRun;
    If[Length[shareIndices]=!=Length[allShareRecords]||Length[shareValues]=!=Length[allShareRecords]||
        !And@@(IntegerQ/@shareIndices)||!And@@(MemberQ[patchIndices,#]&/@shareIndices)||
        !And@@(phase1FiniteRealNumberQ/@shareValues)||!And@@(TrueQ[0.<#<=1.]&/@shareValues)||
        !And@@(Length[#]===Length[DeleteDuplicates[#]]&/@perRunShareIndices),
      Return[Failure["Step5InterNodeRibPatchShareValuesInvalid",<|"Pole"->pole,
        "PatchIndices"->shareIndices,"AreaShares"->shareValues|>]]
    ];
    patchCoverageShares=Table[Total[Pick[shareValues,shareIndices,idx]],{idx,patchIndices}];
    coverageSharePass=TrueQ[And@@(TrueQ[Abs[#-1.]<=patchTolerance]&/@patchCoverageShares)];
    If[!coverageSharePass,
      Return[Failure["Step5InterNodeRibPatchShareCoverageDoesNotClose",<|"Pole"->pole,
        "PatchIndices"->patchIndices,"PatchCoverageShares"->patchCoverageShares,
        "AllowedRelativeShareError"->patchTolerance|>]]
    ];
  ];
  runResults=Map[Function[rr,Module[
    {id=rr["RunID"],length=rr["ActualRunLength_m"],span=rr["UnsupportedSpan_m"],
     width=rr["TributaryWidth_m"],nConductor=rr["ConductorCountPerRun"],
     insulationPerLength=rr["InsulationLinearMass_kg_per_m"],
     requestedLoadBearingCount=Lookup[rr,"EffectiveLoadBearingConductorCount",1],
     suppliedLoadSharingEvidencePassed=TrueQ[Lookup[rr,"ConductorLoadSharingEvidencePassed",False]],
     suppliedLoadSharingEvidenceReference=Lookup[rr,"ConductorLoadSharingEvidenceReference",""],
     effectiveLoadBearingCount=1.,loadSharingEvidencePass=False,
     startID=rr["StartAnchorID"],endID=rr["EndAnchorID"],
     startAnchor=anchorLookup[rr["StartAnchorID"]],endAnchor=anchorLookup[rr["EndAnchorID"]],
     runShareRecords=Lookup[rr,"TributaryPatchShares",{}],runPatchIndices,runPatchPositions,runPatchShares,
     patchForceMagnitudes,patchForceVectors,patchTangentialForceMagnitudes,
     tributaryNormalLoad,tributaryNormalResultant,tributaryTangentialLoad,
     normalPressureLineLoad,tangentialTractionLineLoad,combinedSurfaceLoadLineEnvelope,surfaceLineLoad,
     lineLoad,cableLinearMass,maximumEffectiveTransverseAcceleration,transverseAccelerationEvidencePassed,
     transverseAccelerationEvidenceReference,transverseAccelerationEvidencePass,cableTransverseLineLoad,
     lineLoadCompletenessPass,pressureMappingMethod,sagLimit,horizontalTension,verticalReaction,endTension,
     factoredDemand,rawMaterialCapacity,allowableMaterialCapacity,actualEA,requiredEA,
     extensionFractionActual,factoredExtensionFraction,extension,factoredExtension,metalMass,
     insulationRunMass,tensilePass,eaPass,minimumOperatingTension,tautnessEvidencePassed,
     tautnessEvidenceReference,cableTautnessPass,minimumOperatingHorizontalTension,
     horizontalTensionEvidencePassed,horizontalTensionEvidenceReference,horizontalTensionEvidencePass,
     operatingSagUpperBound,operatingSagWithinLimit,operatingSagLimitExceeded,operatingSagScreenPass,runPass},
    If[patchShareMapPass,
      runPatchIndices=Lookup[runShareRecords,"PatchIndex",{}];
      runPatchPositions=Lookup[patchLookup,#,Missing["PatchIndexUnavailable"]]&/@runPatchIndices;
      runPatchShares=Lookup[runShareRecords,"AreaShare",{}];
      patchForceMagnitudes=MapThread[Abs[patchPressures[[#1]]]*patchAreas[[#1]]*#2&,
        {runPatchPositions,runPatchShares}];
      patchForceVectors=MapThread[(patchPressures[[#1]]*patchAreas[[#1]]*#2) patchNormals[[#1]]&,
        {runPatchPositions,runPatchShares}];
      patchTangentialForceMagnitudes=MapThread[patchTangentialTractions[[#1]]*patchAreas[[#1]]*#2&,
        {runPatchPositions,runPatchShares}];
      tributaryNormalLoad=Total[patchForceMagnitudes];
      tributaryNormalResultant=Total[patchForceVectors];
      tributaryTangentialLoad=Total[patchTangentialForceMagnitudes];
      normalPressureLineLoad=tributaryNormalLoad/span;
      tangentialTractionLineLoad=tributaryTangentialLoad/span;
      (* The normal and tangential directions vary over the curved collector and the
         rib-local projection is not yet resolved. Sum their nonnegative magnitudes as
         a conservative equivalent line-load envelope; do not invent a vector direction. *)
      combinedSurfaceLoadLineEnvelope=normalPressureLineLoad+tangentialTractionLineLoad;
      pressureMappingMethod="SuppliedStep4PatchAreaShareIntegration",
      tributaryNormalLoad=peakPressure width span;
      tributaryNormalResultant=Missing["PatchAreaShareIntegrationNotAvailable"];
      tributaryTangentialLoad=peakTangentialTraction width span;
      normalPressureLineLoad=peakPressure width;
      tangentialTractionLineLoad=peakTangentialTraction width;
      combinedSurfaceLoadLineEnvelope=normalPressureLineLoad+tangentialTractionLineLoad;
      patchTangentialForceMagnitudes={};
      pressureMappingMethod="ConservativePeakNormalPlusTangentialPressureEnvelopeFallback"
    ];
    surfaceLineLoad=combinedSurfaceLoadLineEnvelope;
    metalMass=nConductor area density length;
    insulationRunMass=insulationPerLength length;
    cableLinearMass=nConductor area density+insulationPerLength;
    maximumEffectiveTransverseAcceleration=Lookup[rr,"MaximumEffectiveTransverseAccelerationAcrossCases_m_s2",
      Missing["MaximumEffectiveTransverseAccelerationUnavailable"]];
    transverseAccelerationEvidencePassed=TrueQ[Lookup[rr,"TransverseAccelerationEvidencePassed",False]];
    transverseAccelerationEvidenceReference=Lookup[rr,"TransverseAccelerationEvidenceReference",""];
    transverseAccelerationEvidencePass=TrueQ[phase1FiniteRealNumberQ[maximumEffectiveTransverseAcceleration]&&
      maximumEffectiveTransverseAcceleration>=0.&&transverseAccelerationEvidencePassed&&
      StringQ[transverseAccelerationEvidenceReference]&&StringTrim[transverseAccelerationEvidenceReference]=!=""];
    cableTransverseLineLoad=If[transverseAccelerationEvidencePass,
      cableLinearMass maximumEffectiveTransverseAcceleration,
      Missing["EffectiveTransverseAccelerationEvidenceRequired"]];
    lineLoadCompletenessPass=transverseAccelerationEvidencePass;
    (* When the transverse-acceleration record is absent, retain the surface-load-only
       value solely as a partial screening number. The acceptance gate below remains
       false, and the returned complete line-load field is Missing rather than silently
       treating cable mass/inertia as zero. *)
    lineLoad=surfaceLineLoad+If[transverseAccelerationEvidencePass,cableTransverseLineLoad,0.];
    loadSharingEvidencePass=TrueQ[requestedLoadBearingCount<=1.||
      (suppliedLoadSharingEvidencePassed&&StringQ[suppliedLoadSharingEvidenceReference]&&
       StringTrim[suppliedLoadSharingEvidenceReference]=!="")];
    (* EffectiveLoadBearingConductorCount is an integer physical-strand count,
       validated against the per-run physical conductor count before this loop. Do not
       credit equal mechanical sharing merely because several conductors are physically
       present. The conservative default is one load-bearing strand. Credit a larger
       integer strand count only with a traceable, per-run load-sharing record. Physical
       strand count still governs conductor mass below. *)
    effectiveLoadBearingCount=If[loadSharingEvidencePass,requestedLoadBearingCount,1.];
    sagLimit=sagFraction span;
    horizontalTension=lineLoad span^2/(8. sagLimit);
    verticalReaction=lineLoad span/2.;
    endTension=Sqrt[horizontalTension^2+verticalReaction^2];
    factoredDemand=safetyFactor endTension;
    rawMaterialCapacity=effectiveLoadBearingCount area tensileAllowable;
    allowableMaterialCapacity=rawMaterialCapacity/safetyFactor;
    actualEA=effectiveLoadBearingCount modulus area;
    requiredEA=factoredDemand/extensionFraction;
    extensionFractionActual=endTension/actualEA;
    factoredExtensionFraction=factoredDemand/actualEA;
    extension=extensionFractionActual length;
    factoredExtension=factoredExtensionFraction length;
    (* Do not expose a passing tensile/EA result from surface-only arithmetic when the
       cable self-mass/inertial line-load evidence is absent. The preliminary numeric
       demand remains visible, but neither capacity flag can pass until q_total is complete. *)
    tensilePass=TrueQ[lineLoadCompletenessPass&&endTension<=allowableMaterialCapacity];
    eaPass=TrueQ[lineLoadCompletenessPass&&actualEA>=requiredEA&&factoredExtensionFraction<=extensionFraction];
    minimumOperatingTension=Lookup[rr,"MinimumOperatingCableTensionAcrossCases_N",Missing["MinimumOperatingCableTensionUnavailable"]];
    tautnessEvidencePassed=TrueQ[Lookup[rr,"CableTautnessEvidencePassed",False]];
    tautnessEvidenceReference=Lookup[rr,"CableTautnessEvidenceReference",""];
    cableTautnessPass=TrueQ[phase1FiniteRealNumberQ[minimumOperatingTension]&&
      minimumOperatingTension>0.&&tautnessEvidencePassed&&StringQ[tautnessEvidenceReference]&&
      StringTrim[tautnessEvidenceReference]=!=""];
    minimumOperatingHorizontalTension=Lookup[rr,"MinimumOperatingHorizontalTensionAcrossCases_N",
      Missing["MinimumOperatingHorizontalTensionUnavailable"]];
    horizontalTensionEvidencePassed=TrueQ[Lookup[rr,"HorizontalTensionEvidencePassed",False]];
    horizontalTensionEvidenceReference=Lookup[rr,"HorizontalTensionEvidenceReference",""];
    operatingSagUpperBound=If[lineLoadCompletenessPass&&
        phase1FiniteRealNumberQ[minimumOperatingHorizontalTension]&&TrueQ[minimumOperatingHorizontalTension>0.],
      lineLoad span^2/(8. minimumOperatingHorizontalTension),
      Missing["CompleteCombinedLineLoadAndHorizontalTensionEvidenceRequired"]];
    horizontalTensionEvidencePass=TrueQ[phase1FiniteRealNumberQ[minimumOperatingHorizontalTension]&&
      minimumOperatingHorizontalTension>0.&&horizontalTensionEvidencePassed&&
      StringQ[horizontalTensionEvidenceReference]&&StringTrim[horizontalTensionEvidenceReference]=!=""];
    operatingSagWithinLimit=If[phase1FiniteRealNumberQ[operatingSagUpperBound],
      TrueQ[operatingSagUpperBound<=sagLimit (1.+Sqrt[$MachineEpsilon])],
      Missing["CompleteCombinedLineLoadAndHorizontalTensionEvidenceRequired"]];
    operatingSagLimitExceeded=TrueQ[phase1FiniteRealNumberQ[operatingSagUpperBound]&&
      operatingSagUpperBound>sagLimit (1.+Sqrt[$MachineEpsilon])];
    operatingSagScreenPass=TrueQ[lineLoadCompletenessPass&&horizontalTensionEvidencePass&&
      TrueQ[operatingSagWithinLimit]];
    runPass=TrueQ[tensilePass&&eaPass&&cableTautnessPass&&operatingSagScreenPass&&
      lineLoadCompletenessPass&&loadSharingEvidencePass];
    <|"RunID"->id,"ActualRunLength_m"->length,"UnsupportedSpan_m"->span,
      "TributaryWidth_m"->width,"PressureMappingMethod"->pressureMappingMethod,
      "IntegratedTributaryNormalLoad_N"->tributaryNormalLoad,
      "IntegratedTributaryNormalResultant_N"->tributaryNormalResultant,
      "IntegratedTributaryTangentialTractionMagnitude_N"->tributaryTangentialLoad,
      "CalculatedNormalPressureLineLoad_N_per_m"->normalPressureLineLoad,
      "CalculatedTangentialTractionMagnitudeLineLoad_N_per_m"->tangentialTractionLineLoad,
      "CalculatedCombinedConservativeSurfaceLoadLineEnvelope_N_per_m"->combinedSurfaceLoadLineEnvelope,
      "SurfaceEnvironmentalLineLoad_N_per_m"->surfaceLineLoad,
      "ConductorAndInsulationLinearMass_kg_per_m"->cableLinearMass,
      "MaximumEffectiveTransverseAccelerationAcrossCases_m_s2"->maximumEffectiveTransverseAcceleration,
      "TransverseAccelerationEvidencePassed"->transverseAccelerationEvidencePassed,
      "TransverseAccelerationEvidenceReference"->transverseAccelerationEvidenceReference,
      "CombinedLineLoadEvidenceComplete"->lineLoadCompletenessPass,
      "CableSelfMassAndInertialTransverseLineLoad_N_per_m"->cableTransverseLineLoad,
      "CompleteCombinedLineLoad_N_per_m"->If[lineLoadCompletenessPass,lineLoad,Missing["EffectiveTransverseAccelerationEvidenceRequired"]],
      "PreliminaryLineLoadUsedForSizing_N_per_m"->lineLoad,
      "PreliminaryLineLoadIsSurfaceOnlyBecauseCableMassAndInertiaEvidenceIsMissing"->!lineLoadCompletenessPass,
      "ConservativePeakEnvelopeLineLoad_N_per_m"->If[patchShareMapPass,Missing["PatchAreaShareIntegrationUsed"],surfaceLineLoad],
      "LoadDistributionAssumption"->"Step 4 patch-normal load and tangential-traction magnitude are integrated over the same supplied tributary patch-area shares. Their nonnegative line-load magnitudes are summed conservatively because direction-resolved projection into each curved rib is not available. The conductor-plus-insulation linear mass is independently derived from physical strand count, per-strand area and density plus supplied insulation linear mass; multiplying by the separately evidenced maximum effective transverse acceleration adds the cable self-mass/inertial line load. The complete sum is represented as an equivalent uniform load over the unsupported span; actual along-run variation, catenary shape and rib-network redistribution are not modelled. Without acceleration evidence, only the clearly labelled surface-load partial value is used for provisional arithmetic and the run cannot pass.",
      "RequiredHorizontalTension_N"->horizontalTension,
      "RequiredVerticalEndReaction_N"->verticalReaction,"CalculatedEndTension_N"->endTension,
      "SafetyFactoredEndDemand_N"->factoredDemand,"ConductorCountPerRun"->nConductor,
      "PhysicalConductorCountPerRun"->nConductor,
      "RequestedEffectiveLoadBearingConductorCount"->requestedLoadBearingCount,
      "EffectiveLoadBearingConductorCountCredited"->effectiveLoadBearingCount,
      "ConductorLoadSharingEvidenceRequirementSatisfied"->loadSharingEvidencePass,
      "ConductorLoadSharingEvidenceWasRequired"->TrueQ[requestedLoadBearingCount>1.],
      "SuppliedConductorLoadSharingEvidencePassed"->suppliedLoadSharingEvidencePassed,
      "ConductorLoadSharingEvidenceReference"->suppliedLoadSharingEvidenceReference,
      "LoadSharingCapacityBasis"->If[loadSharingEvidencePass&&requestedLoadBearingCount>1.,
        "Evidence-backed effective parallel-conductor sharing; evidence is referenced but not independently qualified by this routine.",
        "Conservative single-strand tensile-capacity and axial-rigidity credit; all physical strands remain included in conductor-metal mass, while insulation mass uses the separately supplied per-run linear-mass input."],
      "ConductorCrossSectionAreaPerConductor_m2"->area,
      "RawConductorTensileCapacity_N"->rawMaterialCapacity,
      "AllowableConductorTensileCapacityAfterSafetyFactor_N"->allowableMaterialCapacity,
      "ConductorTensileScreenPass"->tensilePass,
      "ActualAxialRigidityEA_N"->actualEA,"RequiredAxialRigidityEA_N"->requiredEA,
      "ElasticExtensionFraction"->factoredExtensionFraction,
      "SafetyFactoredElasticExtensionFraction"->factoredExtensionFraction,
      "UnfactoredElasticExtensionFraction"->extensionFractionActual,
      "ElasticExtension_m"->factoredExtension,"UnfactoredElasticExtension_m"->extension,
      "AxialRigidityScreenPass"->eaPass,
      "MinimumOperatingCableTensionAcrossCases_N"->minimumOperatingTension,
      "SuppliedCableTautnessEvidencePassed"->tautnessEvidencePassed,
      "CableTautnessEvidenceReference"->tautnessEvidenceReference,
      "CableRemainsTautAcrossOperatingCases"->cableTautnessPass,
      "MinimumOperatingHorizontalTensionAcrossCases_N"->minimumOperatingHorizontalTension,
      "HorizontalTensionEvidencePassed"->horizontalTensionEvidencePassed,
      "HorizontalTensionEvidenceReference"->horizontalTensionEvidenceReference,
      "OperatingHorizontalTensionEvidenceComplete"->horizontalTensionEvidencePass,
      "OperatingSagUpperBound_m"->operatingSagUpperBound,
      "MaximumAllowedSag_m"->sagLimit,"OperatingSagWithinLimit"->operatingSagWithinLimit,
      "OperatingSagLimitExceeded"->operatingSagLimitExceeded,
      "OperatingSagScreenPass"->operatingSagScreenPass,
      "OperatingSagModel"->"Small-sag parabolic upper-bound estimate q_total L^2/(8 H_min). q_total combines the conservative integrated Step 4 normal-plus-tangential surface-load envelope with conductor-plus-insulation linear mass multiplied by the separately evidenced upper bound on acceleration perpendicular to the run axis across same-pole operating cases.",
      "StartAnchorID"->startID,"StartAnchorUnfactoredCapacity_N"->Lookup[startAnchor,"AnchorUnfactoredCapacity_N"],
      "StartAnchorMass_kg"->Lookup[startAnchor,"AnchorMass_kg"],
      "StartAnchorQualificationPassed"->TrueQ[Lookup[startAnchor,"AnchorQualificationPassed",False]],
      "StartAnchorEvidenceReference"->Lookup[startAnchor,"AnchorEvidenceReference",""],
      "EndAnchorID"->endID,"EndAnchorUnfactoredCapacity_N"->Lookup[endAnchor,"AnchorUnfactoredCapacity_N"],
      "EndAnchorMass_kg"->Lookup[endAnchor,"AnchorMass_kg"],
      "EndAnchorQualificationPassed"->TrueQ[Lookup[endAnchor,"AnchorQualificationPassed",False]],
      "EndAnchorEvidenceReference"->Lookup[endAnchor,"AnchorEvidenceReference",""],
      "TributaryGeometryMappingEvidencePassed"->TrueQ[Lookup[rr,"TributaryGeometryMappingEvidencePassed",False]],
      "TributaryGeometryEvidenceReference"->Lookup[rr,"TributaryGeometryEvidenceReference",""],
      "ConductorMetalMass_kg"->metalMass,
      "ConductorMetalMassBasis"->"Physical conductor count per run x per-strand cross-section area x conductor density x actual routed run length.",
      "InsulationLinearMass_kg_per_m"->insulationPerLength,
      "InsulationMass_kg"->insulationRunMass,
      "InsulationMassBasis"->"Supplied per-run insulation linear mass x actual routed run length; insulation mass is not inferred from conductor count by this helper.",
      "RunMassSubtotal_kg"->metalMass+insulationRunMass,"RunStructuralScreenPass"->runPass|>
  ]],runRecords];
  If[!And@@Flatten[
      ((phase1FiniteRealNumberQ/@Lookup[#,{"IntegratedTributaryNormalLoad_N",
        "IntegratedTributaryTangentialTractionMagnitude_N",
        "CalculatedNormalPressureLineLoad_N_per_m","CalculatedTangentialTractionMagnitudeLineLoad_N_per_m",
        "CalculatedCombinedConservativeSurfaceLoadLineEnvelope_N_per_m","SurfaceEnvironmentalLineLoad_N_per_m",
        "ConductorAndInsulationLinearMass_kg_per_m","PreliminaryLineLoadUsedForSizing_N_per_m","MaximumAllowedSag_m",
        "RequiredHorizontalTension_N","RequiredVerticalEndReaction_N","CalculatedEndTension_N",
        "SafetyFactoredEndDemand_N","RawConductorTensileCapacity_N",
        "AllowableConductorTensileCapacityAfterSafetyFactor_N","ActualAxialRigidityEA_N",
        "RequiredAxialRigidityEA_N","ElasticExtensionFraction","SafetyFactoredElasticExtensionFraction",
        "UnfactoredElasticExtensionFraction","ElasticExtension_m","UnfactoredElasticExtension_m",
        "ConductorMetalMass_kg","InsulationMass_kg","RunMassSubtotal_kg"},Missing["DerivedRunValueUnavailable"]])&/@runResults)],
    Return[Failure["Step5InterNodeRibDerivedRunValuesInvalid",<|"Pole"->pole|>]]
  ];
  If[!And@@((MissingQ[#]||phase1FiniteRealNumberQ[#])&/@Lookup[runResults,"OperatingSagUpperBound_m",{}]),
    Return[Failure["Step5InterNodeOperatingSagDerivedValueInvalid",<|"Pole"->pole|>]]
  ];
  If[!And@@((MissingQ[#]||phase1FiniteRealNumberQ[#])&/@Lookup[runResults,"CableSelfMassAndInertialTransverseLineLoad_N_per_m",{}]),
    Return[Failure["Step5InterNodeCableTransverseLineLoadInvalid",<|"Pole"->pole|>]]
  ];
  If[patchShareMapPass&&
      !And@@(phase1FiniteRealVectorQ[#,3]&/@Lookup[runResults,"IntegratedTributaryNormalResultant_N",{}]),
    Return[Failure["Step5InterNodeRibPatchResultantVectorInvalid",<|"Pole"->pole|>]]
  ];
  patchTangentialLoadTotal=If[patchShareMapPass,
    Total[MapThread[#1 #2&,{patchTangentialTractions,patchAreas}]],0.];
  runTangentialLoadTotal=If[patchShareMapPass,
    Total[Lookup[runResults,"IntegratedTributaryTangentialTractionMagnitude_N",{}]],0.];
  tangentialClosureError=If[!patchShareMapPass,Missing["PatchAreaShareIntegrationNotAvailable"],
    If[TrueQ[patchTangentialLoadTotal>0.],
      Abs[runTangentialLoadTotal/patchTangentialLoadTotal-1.],
      If[TrueQ[runTangentialLoadTotal==0.],0.,Infinity]]];
  tangentialConservationPass=TrueQ[patchShareMapPass&&phase1FiniteRealNumberQ[tangentialClosureError]&&
    tangentialClosureError<=patchTolerance];
  If[patchShareMapPass&&!tangentialConservationPass,
    Return[Failure["Step5InterNodeRibIntegratedTangentialLoadDoesNotConserve",<|"Pole"->pole,
      "Step4PatchTangentialTractionMagnitudeLoad_N"->patchTangentialLoadTotal,
      "AssignedRunTangentialTractionLoad_N"->runTangentialLoadTotal,
      "RelativeClosureError"->tangentialClosureError,"AllowedRelativeError"->patchTolerance|>]]
  ];
  patchLoadTotal=If[patchShareMapPass,Total[MapThread[Abs[#1]*#2&,{patchPressures,patchAreas}]],0.];
  runLoadTotal=If[patchShareMapPass,Total[Lookup[runResults,"IntegratedTributaryNormalLoad_N",{}]],0.];
  pressureClosureError=If[patchShareMapPass&&phase1FiniteRealNumberQ[patchLoadTotal]&&TrueQ[patchLoadTotal>0.],
    Abs[runLoadTotal/patchLoadTotal-1.],Missing["PatchAreaShareIntegrationNotAvailable"]];
  If[patchShareMapPass&&(!phase1FiniteRealNumberQ[pressureClosureError]||!TrueQ[pressureClosureError<=patchTolerance]),
    Return[Failure["Step5InterNodeRibIntegratedPressureLoadDoesNotConserve",<|"Pole"->pole,
      "Step4PatchNormalLoad_N"->patchLoadTotal,"AssignedRunNormalLoad_N"->runLoadTotal,
      "RelativeClosureError"->pressureClosureError,"AllowedRelativeError"->patchTolerance|>]]
  ];
  anchorDemandRecords=Join[
    (<|"AnchorID"->Lookup[#,"StartAnchorID"],"RunID"->Lookup[#,"RunID"],
      "SafetyFactoredEndDemand_N"->Lookup[#,"SafetyFactoredEndDemand_N"]|>&/@runResults),
    (<|"AnchorID"->Lookup[#,"EndAnchorID"],"RunID"->Lookup[#,"RunID"],
      "SafetyFactoredEndDemand_N"->Lookup[#,"SafetyFactoredEndDemand_N"]|>&/@runResults)];
  anchorResults=Map[Function[ar,Module[
    {id=ar["AnchorID"],capacity=ar["AnchorUnfactoredCapacity_N"],mass=ar["AnchorMass_kg"],
     qualification=Lookup[ar,"AnchorQualificationPassed",False],evidence=Lookup[ar,"AnchorEvidenceReference",""],
     connected,demand,capacityPass},
    connected=Select[anchorDemandRecords,Lookup[#,"AnchorID",None]===id&];
    demand=Total[Lookup[connected,"SafetyFactoredEndDemand_N",{}]];
    capacityPass=TrueQ[phase1FiniteRealNumberQ[demand]&&demand<=capacity];
    <|"AnchorID"->id,"AnchorUnfactoredCapacity_N"->capacity,"AggregateSafetyFactoredDemand_N"->demand,
      "CapacityScreenPass"->capacityPass,"ConnectedRunIDs"->DeleteDuplicates[Lookup[connected,"RunID",{}]],
      "AnchorMass_kg"->mass,"AnchorQualificationPassed"->TrueQ[qualification],
      "AnchorEvidenceReference"->evidence|>
  ]],anchorRecords];
  If[!And@@(phase1FiniteRealNumberQ/@Lookup[anchorResults,"AggregateSafetyFactoredDemand_N",{}]),
    Return[Failure["Step5InterNodeAnchorAggregateDemandInvalid",<|"Pole"->pole|>]]
  ];
  conductorMass=Total[Lookup[runResults,"ConductorMetalMass_kg",{}]];
  insulationMass=Total[Lookup[runResults,"InsulationMass_kg",{}]];
  anchorMass=Total[Lookup[anchorResults,"AnchorMass_kg",{}]];
  totalMass=conductorMass+insulationMass+anchorMass;
  If[!And@@(phase1FiniteRealNumberQ/@{conductorMass,insulationMass,anchorMass,totalMass})||
      !TrueQ[conductorMass>=0.&&insulationMass>=0.&&anchorMass>0.&&totalMass>0.],
    Return[Failure["Step5InterNodeRibMassTotalInvalid",<|"Pole"->pole,
      "ConductorMass_kg"->conductorMass,"InsulationMass_kg"->insulationMass,
      "AnchorHardwareMass_kg"->anchorMass,"TotalMass_kg"->totalMass|>]]
  ];
  allRunPass=TrueQ[And@@(TrueQ[Lookup[#,"RunStructuralScreenPass",False]]&/@runResults)];
  allRunCapacityPass=TrueQ[And@@((TrueQ[Lookup[#,"ConductorTensileScreenPass",False]]&&
    TrueQ[Lookup[#,"AxialRigidityScreenPass",False]]&&
    TrueQ[Lookup[#,"CombinedLineLoadEvidenceComplete",False]])&/@runResults)];
  allAnchorCapacityPass=TrueQ[And@@(TrueQ[Lookup[#,"CapacityScreenPass",False]]&/@anchorResults)];
  allAnchorQualified=TrueQ[And@@((TrueQ[Lookup[#,"AnchorQualificationPassed",False]]&&
    StringQ[Lookup[#,"AnchorEvidenceReference",""]]&&StringTrim[Lookup[#,"AnchorEvidenceReference",""]] =!= "")&/@anchorResults)];
  allTributaryGeometryEvidence=TrueQ[And@@((TrueQ[Lookup[#,"TributaryGeometryMappingEvidencePassed",False]]&&
    StringQ[Lookup[#,"TributaryGeometryEvidenceReference",""]]&&
    StringTrim[Lookup[#,"TributaryGeometryEvidenceReference",""]] =!= "")&/@runResults)];
  allCableTautnessPass=TrueQ[And@@(TrueQ[Lookup[#,"CableRemainsTautAcrossOperatingCases",False]]&/@runResults)];
  allOperatingHorizontalTensionEvidencePass=TrueQ[And@@(TrueQ[Lookup[#,"OperatingHorizontalTensionEvidenceComplete",False]]&/@runResults)];
  allCombinedLineLoadEvidencePass=TrueQ[And@@(TrueQ[Lookup[#,"CombinedLineLoadEvidenceComplete",False]]&/@runResults)];
  anyOperatingSagLimitExceeded=Or@@(TrueQ[Lookup[#,"OperatingSagLimitExceeded",False]]&/@runResults);
  allOperatingSagWithinLimit=TrueQ[And@@(TrueQ[Lookup[#,"OperatingSagWithinLimit",False]]&/@runResults)];
  allOperatingSagPass=TrueQ[And@@(TrueQ[Lookup[#,"OperatingSagScreenPass",False]]&/@runResults)];
  maximumOperatingSagUpperBound=If[And@@(phase1FiniteRealNumberQ/@Lookup[runResults,"OperatingSagUpperBound_m",{}]),
    Max[Lookup[runResults,"OperatingSagUpperBound_m",{}]],Missing["CompleteCombinedLineLoadAndHorizontalTensionEvidenceRequired"]];
  allConductorLoadSharingRequirementsSatisfied=TrueQ[And@@(TrueQ[Lookup[#,"ConductorLoadSharingEvidenceRequirementSatisfied",False]]&/@runResults)];
  <|"Pole"->pole,"ConductorMaterialName"->materialName,"ConductorDensity_kg_m3"->density,
    "ConductorYoungsModulus_Pa"->modulus,"ConductorTensileAllowable_Pa"->tensileAllowable,
    "ConductorCrossSectionArea_m2"->area,"PeakStep4PressureEnvelope_Pa"->peakPressure,
    "StructuralSafetyFactor"->safetyFactor,"MaximumRibSagFractionOfRunSpan"->sagFraction,
    "MaximumElasticExtensionFraction"->extensionFraction,"RunCount"->Length[runResults],
    "RunResults"->runResults,"AllRunStructuralScreensPass"->allRunPass,
    "AllRunTensileAndAxialRigidityScreensPass"->allRunCapacityPass,
    "AllRunsRemainTautAcrossOperatingCases"->allCableTautnessPass,
    "AllRunsHaveOperatingHorizontalTensionEvidence"->allOperatingHorizontalTensionEvidencePass,
    "AllRunsHaveCompleteCombinedLineLoadEvidence"->allCombinedLineLoadEvidencePass,
    "AnyRunOperatingSagLimitExceeded"->anyOperatingSagLimitExceeded,
    "AllRunsOperatingSagWithinLimit"->allOperatingSagWithinLimit,
    "AllRunsMeetOperatingSagLimit"->allOperatingSagPass,
    "MaximumOperatingSagUpperBound_m"->maximumOperatingSagUpperBound,
    "CombinedLineLoadEvidenceContract"->"Every run must provide a finite nonnegative MaximumEffectiveTransverseAccelerationAcrossCases_m_s2 that upper-bounds the magnitude of the acceleration component perpendicular to the run axis for the complete same-pole operating envelope, TransverseAccelerationEvidencePassed=True and a non-empty TransverseAccelerationEvidenceReference. The source derives conductor-plus-insulation linear mass from physical strand count, strand area, conductor density and supplied insulation linear mass, multiplies by the supplied effective transverse-acceleration bound, and adds that cable self-mass/inertial line load to the Step 4 patch-derived normal-plus-tangential surface line-load envelope. If this evidence is missing, the reported preliminary load uses the surface-load-only partial value, CompleteCombinedLineLoad_N_per_m is Missing, and the run cannot pass. The acceleration bound is supplied and not independently derived or authenticated here.",
    "CombinedLineLoadEvidenceIsUserSuppliedNotIndependentlyVerified"->True,
    "EffectiveTransverseAccelerationInterpretation"->"Scalar upper bound on the acceleration component perpendicular to each run axis, covering that same-pole run orientation over all operating cases. This routine does not project a vector time history or derive the bound from Step 4.",
    "OperatingSagEvidenceContract"->"Every inter-node rib run must provide a positive lower bound on horizontal cable tension across the complete same-pole operating envelope, HorizontalTensionEvidencePassed=True and a non-empty HorizontalTensionEvidenceReference. The q_total L^2/(8 H_min) parabolic estimate uses the combined surface-plus-cable-mass/inertial line load and is compared with the configured maximum sag. It does not derive H_min from the Step 4 time history or authenticate the supplied evidence.",
    "OperatingSagEvidenceIsUserSuppliedNotIndependentlyVerified"->True,
    "AllConductorLoadSharingEvidenceRequirementsSatisfied"->allConductorLoadSharingRequirementsSatisfied,
    "ConductorLoadSharingContract"->"Physical conductor count, per-strand cross-section, conductor density and actual run length determine conductor-metal mass. Insulation mass is calculated separately from the supplied per-run insulation linear mass and is not inferred from conductor count. Unless a run supplies an explicit effective load-bearing conductor count plus a passing evidence flag and non-empty reference, only one strand is credited for tensile capacity and axial rigidity. A larger effective count is an evidence-backed input assertion and is not independently verified by this routine.",
    "CableTautnessEvidenceContract"->"Every run must supply a positive minimum operating cable tension from the complete same-pole load envelope, CableTautnessEvidencePassed=True, and a traceable evidence reference. This distinct check establishes positive tension only; a separate minimum horizontal-tension bound and evidence record are required for the operating-sag estimate.",
    "CableTautnessEvidenceIsUserSuppliedNotIndependentlyVerified"->True,
    "AnchorResults"->anchorResults,"AnchorCount"->Length[anchorResults],
    "AllAnchorCapacityScreensPass"->allAnchorCapacityPass,
    "AllAnchorQualificationFlagsPassed"->allAnchorQualified,
    "AllTributaryGeometryMappingEvidencePassed"->allTributaryGeometryEvidence,
    "PressureMappingMethod"->If[patchShareMapPass,"SuppliedStep4PatchAreaShareIntegration","ConservativePeakNormalPlusTangentialPressureEnvelopeFallback"],
    "TangentialLoadMappingMethod"->If[patchShareMapPass,"SameSuppliedStep4PatchAreaSharesForTangentialTractionMagnitude","ConservativePeakTangentialTractionEnvelopeFallback"],
    "Step4PatchAreaShareIntegrationPass"->patchShareMapPass,
    "Step4PatchAreaShareCoveragePass"->coverageSharePass,
    "Step4PatchToRunNormalLoad_N"->runLoadTotal,
    "Step4PatchNormalLoadTotal_N"->patchLoadTotal,
    "Step4PatchToRunNormalLoadRelativeClosureError"->pressureClosureError,
    "Step4PatchToRunNormalLoadConservationPass"->If[patchShareMapPass,True,False],
    "Step4PatchTangentialTractionMagnitudeLoadTotal_N"->patchTangentialLoadTotal,
    "Step4PatchToRunTangentialTractionMagnitudeLoad_N"->runTangentialLoadTotal,
    "Step4PatchToRunTangentialLoadRelativeClosureError"->tangentialClosureError,
    "Step4PatchToRunTangentialLoadConservationPass"->tangentialConservationPass,
    "NormalAndTangentialTributaryLoadConservationPass"->TrueQ[If[patchShareMapPass,True,False]&&tangentialConservationPass],
    "TributaryGeometryMappingDerivedByThisCalculation"->False,
    "ConductorMetalMass_kg"->conductorMass,"InsulationMass_kg"->insulationMass,
    "AnchorHardwareMass_kg"->anchorMass,"TotalInterNodeRibMass_kg"->totalMass,
    "AggregateAnchorDemandRule"->"For a shared anchor, sum the magnitudes of the factored end-tension demands from every connected rib. This is conservative because run-end force directions are not yet resolved in a common anchor-local frame.",
    "ElectricalCurrentAndI2RCalculationPerformed"->False,"AWGOrElectricalSectionSelectedByThisCalculation"->False,
    "HardwareQualificationEstablishedByThisCalculation"->False,"PerPoleOnly"->True,"ActiveMassModelMutated"->False,
    "Limitations"->"Supplied patch-area shares integrate Step 4 normal pressure and tangential-traction magnitude over curved patch areas but are not derived from physical rib geometry; each run requires a non-empty geometry evidence reference and passing geometry flag. Normal and tangential surface-load magnitudes are integrated separately and must each conserve across the rib set. Their nonnegative line-load magnitudes are added as a conservative envelope because local tangential directions and projections into each curved rib are not resolved. The resulting combined envelope is treated as an equivalent uniform line load over the unsupported span. The cable model conservatively credits one strand for tensile capacity and axial rigidity unless a larger effective load-bearing count is accompanied by user-supplied evidence; this routine does not independently validate that evidence. It still omits along-run load variation, cable-net interaction, direction-resolved shear transfer, vector combination of forces at shared anchors, conductor temperature/resistivity, current capacity, voltage drop, I2R loss, insulation/jacket characterization and detailed terminations. Shared-anchor capacity uses a conservative sum of force magnitudes. Cable tautness through the full operating load envelope is not derived here; a positive same-pole minimum cable tension and traceable supporting evidence are mandatory. The separate operating-sag estimate also requires a positive minimum horizontal-tension lower bound with its own evidence flag/reference and a finite nonnegative maximum effective transverse acceleration with a separate evidence flag/reference. The routine derives cable-and-insulation linear mass from physical strand count, strand section and density plus supplied insulation linear mass, then multiplies by that acceleration bound to represent cable self-mass/inertial transverse loading. If acceleration evidence is missing, the returned capacity line-load is explicitly surface-only and cannot pass; no zero cable load is silently assumed. The combined q_total line load is used for design tension and the small-sag parabolic operating sag, but does not establish catenary behavior or direction-resolved cable dynamics. This is screening, not FEA or hardware qualification."|>
];

(* WHAT: Estimate per-connection intra-node tab and solder mass and screen the supplied
   tab against nominal tensile, overlap-shear, overlap-peel and elastic-extension limits.
   WHY: PV cells connected within a node require real connector material and joint mass;
   that local tier must be visible separately from the inter-node bus/rib architecture.
   HOW: Tab tensile area and overlap area are multiplied by TabsPerConnection. The
   supplied per-connection force demands are divided by those effective areas to produce
   nominal average stresses. Tab extension uses the axial relation F L/(E A). Tab mass
   is ConnectionCount*TabsPerConnection*width*thickness*length*density; solder mass is
   ConnectionCount*solder-volume-per-connection*solder-density. The calculation assumes
   equal load sharing across the supplied tabs and does not infer a load split from joint
   geometry. It does not resolve eccentricity, peel concentration, solder fillets, local
   stress concentration, fatigue/creep or thermal/electrical ageing. Passing these nominal
   checks is not material or hardware qualification. The separate evidence register
   requires material, mechanical, environmental, electrical-resistance and process items
   with user-supplied report references; this routine does not authenticate those reports. *)
phase1Step5IntraNodeConnectorScreenCurrent[data_Association,safetyFactor_] := Module[
  {pole=Lookup[data,"Pole",None],connectionCount=Lookup[data,"ConnectionCount",Missing["ConnectionCountUnavailable"]],
   tabsPerConnection=Lookup[data,"TabsPerConnection",Missing["TabsPerConnectionUnavailable"]],
   tabWidth=Lookup[data,"TabWidth_m",Missing["TabWidthUnavailable"]],
   tabThickness=Lookup[data,"TabThickness_m",Missing["TabThicknessUnavailable"]],
   tabLength=Lookup[data,"TabLength_m",Missing["TabLengthUnavailable"]],
   tabDensity=Lookup[data,"TabDensity_kg_m3",Missing["TabDensityUnavailable"]],
   tabModulus=Lookup[data,"TabYoungsModulus_Pa",Missing["TabModulusUnavailable"]],
   tabTensileAllowable=Lookup[data,"TabTensileAllowable_Pa",Missing["TabTensileAllowableUnavailable"]],
   overlapWidth=Lookup[data,"JointOverlapWidth_m",Missing["JointOverlapWidthUnavailable"]],
   overlapLength=Lookup[data,"JointOverlapLength_m",Missing["JointOverlapLengthUnavailable"]],
   jointShearAllowable=Lookup[data,"JointShearAllowable_Pa",Missing["JointShearAllowableUnavailable"]],
   jointPeelAllowable=Lookup[data,"JointPeelAllowable_Pa",Missing["JointPeelAllowableUnavailable"]],
   tabTensionDemand=Lookup[data,"TabTensionDemandPerConnection_N",Missing["TabTensionDemandUnavailable"]],
   jointShearDemand=Lookup[data,"JointShearDemandPerConnection_N",Missing["JointShearDemandUnavailable"]],
   jointPeelDemand=Lookup[data,"JointPeelDemandPerConnection_N",Missing["JointPeelDemandUnavailable"]],
   solderVolume=Lookup[data,"SolderVolumePerConnection_m3",Missing["SolderVolumeUnavailable"]],
   solderDensity=Lookup[data,"SolderDensity_kg_m3",Missing["SolderDensityUnavailable"]],
   maxExtensionFraction=Lookup[data,"MaximumElasticExtensionFraction",Missing["ConnectorExtensionLimitUnavailable"]],
   tabArea,jointArea,tabStress,shearStress,peelStress,extension,extensionFraction,
   solderMass,totalMass,tabPass,shearPass,peelPass,extensionPass,screenPass,
   jointQualificationProvided,jointQualificationOverallFlag,jointQualificationEvidence,
   jointQualificationEvidenceRequired,jointQualificationEvidenceReferences,
   jointQualificationEvidenceReferencesComplete,jointQualificationEvidenceReferencesMissingOrInvalid,
   jointQualificationEvidenceComplete,jointQualificationEvidenceMissingOrFailed,materialName},
  If[pole=!=$Phase1CurrentPole,
    Return[Failure["Step5ConnectorPoleMismatch",<|"ActivePole"->$Phase1CurrentPole,"ConnectorPole"->pole|>]]
  ];
  If[!IntegerQ[connectionCount]||connectionCount<1||!IntegerQ[tabsPerConnection]||tabsPerConnection<1||
      !And@@(phase1FiniteRealNumberQ/@{tabWidth,tabThickness,tabLength,tabDensity,tabModulus,
        tabTensileAllowable,overlapWidth,overlapLength,jointShearAllowable,jointPeelAllowable,
        tabTensionDemand,jointShearDemand,jointPeelDemand,solderVolume,
        maxExtensionFraction,safetyFactor})||
      !And@@(TrueQ[#>0.]&/@{tabWidth,tabThickness,tabLength,tabDensity,tabModulus,
        tabTensileAllowable,overlapWidth,overlapLength,jointShearAllowable,jointPeelAllowable,safetyFactor})||
      !And@@(TrueQ[#>=0.]&/@{tabTensionDemand,jointShearDemand,jointPeelDemand,solderVolume})||
      !TrueQ[0.<maxExtensionFraction<1.]||
      !TrueQ[solderVolume==0.||(phase1FiniteRealNumberQ[solderDensity]&&solderDensity>0.)],
    Return[Failure["Step5ConnectorInputsInvalid",<|"Pole"->pole,
      "ConnectionCount"->connectionCount,"TabsPerConnection"->tabsPerConnection,
      "ConnectorRecord"->data|>]]
  ];
  tabArea=tabsPerConnection tabWidth tabThickness;
  jointArea=tabsPerConnection overlapWidth overlapLength;
  If[!phase1FiniteRealNumberQ[tabArea]||!TrueQ[tabArea>0.]||
      !phase1FiniteRealNumberQ[jointArea]||!TrueQ[jointArea>0.],
    Return[Failure["Step5ConnectorEffectiveAreaInvalid",<|"TabAreaPerConnection_m2"->tabArea,
      "JointOverlapAreaPerConnection_m2"->jointArea|>]]
  ];
  tabStress=tabTensionDemand/tabArea;
  shearStress=jointShearDemand/jointArea;
  peelStress=jointPeelDemand/jointArea;
  extension=tabTensionDemand tabLength/(tabModulus tabArea);
  extensionFraction=extension/tabLength;
  tabPass=TrueQ[tabStress<=tabTensileAllowable/safetyFactor];
  shearPass=TrueQ[shearStress<=jointShearAllowable/safetyFactor];
  peelPass=TrueQ[peelStress<=jointPeelAllowable/safetyFactor];
  extensionPass=TrueQ[extensionFraction<=maxExtensionFraction];
  screenPass=TrueQ[tabPass&&shearPass&&peelPass&&extensionPass];
  tabMass=connectionCount tabsPerConnection tabWidth tabThickness tabLength tabDensity;
  solderMass=If[solderVolume==0.,0.,connectionCount solderVolume solderDensity];
  totalMass=tabMass+solderMass;
  If[!And@@(phase1FiniteRealNumberQ/@{tabStress,shearStress,peelStress,extension,extensionFraction,
      tabMass,solderMass,totalMass}),
    Return[Failure["Step5ConnectorDerivedValuesInvalid",<|"Pole"->pole|>]]
  ];
  jointQualificationOverallFlag=TrueQ[Lookup[data,"JointQualificationPassed",False]];
  jointQualificationEvidence=Lookup[data,"JointQualificationEvidence",<||>];
  jointQualificationEvidenceReferences=Lookup[data,"JointQualificationEvidenceReferences",<||>];
  jointQualificationEvidenceRequired={"TabMaterialAllowableVerified","JointLapShearQualificationPassed",
    "JointPeelQualificationPassed","ThermalCyclingPassed","VacuumOutgassingPassed",
    "RadiationCompatibilityPassed","ElectricalResistanceQualificationPassed","ProcessRepeatabilityPassed"};
  jointQualificationEvidenceReferencesComplete=TrueQ[AssociationQ[jointQualificationEvidenceReferences]&&
    And@@(With[{reference=Lookup[jointQualificationEvidenceReferences,#,""]},
      StringQ[reference]&&StringTrim[reference]=!=""]&/@jointQualificationEvidenceRequired)];
  jointQualificationEvidenceReferencesMissingOrInvalid=Select[jointQualificationEvidenceRequired,
    With[{reference=Lookup[If[AssociationQ[jointQualificationEvidenceReferences],
      jointQualificationEvidenceReferences,<||>],# ,""]},!StringQ[reference]||StringTrim[reference]===""]&];
  jointQualificationEvidenceMissingOrFailed=Select[jointQualificationEvidenceRequired,
    !TrueQ[Lookup[If[AssociationQ[jointQualificationEvidence],jointQualificationEvidence,<||>],#,False]]&];
  jointQualificationEvidenceComplete=TrueQ[AssociationQ[jointQualificationEvidence]&&
    jointQualificationEvidenceMissingOrFailed==={}&&jointQualificationEvidenceReferencesComplete];
  (* A single overall pass flag is not sufficient for a cell-to-cell tab/solder joint.
     Every required material, mechanical, environmental, electrical-resistance and
     process evidence item must be marked passed and carry a non-empty report reference.
     References are user-supplied pointers only; this routine does not authenticate or
     inspect the underlying reports. *)
  jointQualificationProvided=TrueQ[jointQualificationOverallFlag&&jointQualificationEvidenceComplete];
  materialName=Lookup[data,"TabMaterialName","Unspecified tab material"];
  <|"Pole"->pole,"ConnectionCount"->connectionCount,"TabsPerConnection"->tabsPerConnection,
    "TabMaterialName"->materialName,"TabAreaPerConnection_m2"->tabArea,
    "JointOverlapAreaPerConnection_m2"->jointArea,
    "ConnectorDemandBasis"->"Tab tension, joint shear and joint peel inputs are per-connection demands; do not pass whole-node totals unless first allocated to one connection.",
    "EqualLoadSharingAcrossTabsAssumed"->True,
    "TabMaterialMassBasis"->"ConnectionCount*TabsPerConnection*TabWidth*TabThickness*TabLength*TabDensity.",
    "SolderMassBasis"->"ConnectionCount*SolderVolumePerConnection*SolderDensity; solder volume and alloy density are separately supplied inputs.",
    "TabTensionDemandPerConnection_N"->tabTensionDemand,
    "TabTensileStress_Pa"->tabStress,"TabTensileScreenPass"->tabPass,
    "TabTensileAllowable_Pa"->tabTensileAllowable/safetyFactor,
    "JointShearDemandPerConnection_N"->jointShearDemand,"NominalJointShearStress_Pa"->shearStress,
    "JointShearScreenPass"->shearPass,"JointShearAllowable_Pa"->jointShearAllowable/safetyFactor,
    "JointPeelDemandPerConnection_N"->jointPeelDemand,"NominalJointPeelStress_Pa"->peelStress,
    "JointPeelScreenPass"->peelPass,"JointPeelAllowable_Pa"->jointPeelAllowable/safetyFactor,
    "CalculatedTabElasticExtension_m"->extension,"CalculatedTabElasticExtensionFraction"->extensionFraction,
    "MaximumElasticExtensionFraction"->maxExtensionFraction,"ElasticExtensionScreenPass"->extensionPass,
    "TabMaterialMass_kg"->tabMass,"SolderMass_kg"->solderMass,
    "TotalIntraNodeConnectorMass_kg"->totalMass,"NominalMechanicalScreenPass"->screenPass,
    "SuppliedOverallJointQualificationFlag"->jointQualificationOverallFlag,
    "JointQualificationEvidenceRequired"->jointQualificationEvidenceRequired,
    "JointQualificationEvidence"->jointQualificationEvidence,
    "JointQualificationEvidenceReferences"->jointQualificationEvidenceReferences,
    "JointQualificationEvidenceReferencesComplete"->jointQualificationEvidenceReferencesComplete,
    "JointQualificationEvidenceReferencesMissingOrInvalid"->jointQualificationEvidenceReferencesMissingOrInvalid,
    "JointQualificationEvidenceReferencesAreUserSuppliedNotIndependentlyVerified"->True,
    "JointQualificationEvidenceMissingOrFailed"->jointQualificationEvidenceMissingOrFailed,
    "JointQualificationEvidenceComplete"->jointQualificationEvidenceComplete,
    "JointQualificationEvidenceAcceptanceGatePass"->jointQualificationProvided,
    "JointQualificationFlagAloneSufficient"->False,
    "UserSuppliedJointQualificationPassed"->jointQualificationProvided,
    "HardwareQualificationEstablishedByThisCalculation"->False,
    "ElectricalResistanceOrI2RLossCalculatedByThisScreen"->False,
    "PerPoleOnly"->True,"ActiveMassModelMutated"->False,
    "Limitations"->"Tab tension and mean overlap shear/peel stresses are screening calculations only. Eccentricity, solder fillet geometry, local stress concentration, creep, fatigue, thermal cycling, vacuum, radiation, electrical resistance and manufacturing variability require detailed Step 7 design and independent qualification."|>
];

phase1BacksideFilmComparison[in_Association,aluminumThickness_?NumericQ,film_Association] := Module[
  {rhoAl=in["AluminumDensity_kg_m3"],eAl=in["AluminumYoungsModulus_Pa"],
   sigmaAl=in["AluminumYieldStrength_Pa"]/in["StructuralSafetyFactor"],
   tAl=aluminumThickness,rhoFilm,eFilm,nuFilm,sigmaFilm,tFilm,massTotal,tEquivalentAl,
   rhoBond,eBond,sigmaBond,tBond,bondLayerReady,bondMassConsistencyPass,
   tBondUsed,eBondUsed,sigmaBondUsed,zAl,zBond,zFilm,zNeutral,dComposite,
   dAluminumEquivalent,firstLimitStrain,compositeLineCapacity,aluminumLineCapacity,
   compositeSpecificStrength,aluminumSpecificStrength,strengthRatio,rigidityRatio,
   performancePass,bondMass,bondMassKnown,bondPropertiesAvailable,bondSectionModelled,
   bondEvidenceComplete,bondQualificationEvidence,bondQualificationEvidenceRequired,
   bondQualificationEvidenceReferences,bondQualificationEvidenceReferencesComplete,
   bondQualificationEvidenceReferencesMissingOrInvalid,bondQualificationEvidenceComplete,
   bondQualified,selected,selectionReason},
  rhoFilm=Lookup[film,"Density_kg_m3",Missing["FilmDensityUnavailable"]];
  eFilm=Lookup[film,"YoungsModulus_Pa",Missing["FilmModulusUnavailable"]];
  nuFilm=Lookup[film,"PoissonRatio",Missing["FilmPoissonRatioUnavailable"]];
  sigmaFilm=Lookup[film,"YieldPointAt3Percent_Pa",Missing["FilmLimitUnavailable"]]/in["StructuralSafetyFactor"];
  tFilm=Lookup[film,"Thickness_m",Missing["FilmThicknessUnavailable"]];
  bondMass=Lookup[film,"BondingLayerArealMass_kg_m2",Missing["BondMassNotCharacterized"]];
  rhoBond=Lookup[film,"BondLayerDensity_kg_m3",Missing["BondDensityNotCharacterized"]];
  eBond=Lookup[film,"BondLayerYoungsModulus_Pa",Missing["BondModulusNotCharacterized"]];
  sigmaBond=Lookup[film,"BondLayerAllowableStress_Pa",Missing["BondAllowableStressNotCharacterized"]];
  tBond=Lookup[film,"BondLayerThickness_m",Missing["BondThicknessNotCharacterized"]];
  bondMassKnown=phase1FiniteRealNumberQ[bondMass]&&TrueQ[bondMass>=0.];
  bondLayerReady=And@@(phase1FiniteRealNumberQ /@ {rhoBond,eBond,sigmaBond,tBond})&&
    And@@(TrueQ[#>0.]& /@ {rhoBond,eBond,sigmaBond,tBond});
  bondPropertiesAvailable=TrueQ[Lookup[film,"BondMechanicalPropertiesAvailable",False]]&&bondLayerReady;
  bondMassConsistencyPass=TrueQ[bondMassKnown&&bondLayerReady&&
    Abs[bondMass-rhoBond tBond]<=10^-6 Max[bondMass,rhoBond tBond,10^-30]];
  bondSectionModelled=TrueQ[Lookup[film,"BondLayerIncludedInBendingSectionModel",False]]&&
    bondPropertiesAvailable&&bondMassConsistencyPass;
  bondQualificationEvidence=Lookup[film,"BondQualificationEvidence",<||>];
  bondQualificationEvidenceReferences=Lookup[film,"BondQualificationEvidenceReferences",<||>];
  bondQualificationEvidenceRequired={"LapShearStrengthTestPassed","PeelResistanceTestPassed",
    "ThermalVacuumCyclingPassed","VacuumOutgassingPassed","RadiationCompatibilityPassed",
    "LongTermAgingPassed","ProcessRepeatabilityPassed","EnvironmentalCompatibilityPassed"};
  bondQualificationEvidenceReferencesComplete=TrueQ[AssociationQ[bondQualificationEvidenceReferences]&&
    And@@(With[{reference=Lookup[bondQualificationEvidenceReferences,#,""]},
      StringQ[reference]&&StringTrim[reference]=!=""]&/@bondQualificationEvidenceRequired)];
  bondQualificationEvidenceReferencesMissingOrInvalid=Select[bondQualificationEvidenceRequired,
    With[{reference=Lookup[If[AssociationQ[bondQualificationEvidenceReferences],
      bondQualificationEvidenceReferences,<||>],# ,""]},!StringQ[reference]||StringTrim[reference]===""]&];
  bondQualificationEvidenceComplete=TrueQ[AssociationQ[bondQualificationEvidence]&&
    And@@(TrueQ[Lookup[bondQualificationEvidence,#,False]]&/@bondQualificationEvidenceRequired)&&
    bondQualificationEvidenceReferencesComplete];
  (* A summary Boolean cannot replace the individual passed test flags and their
     traceable report references. Non-empty references are recorded as user-supplied
     pointers only; this routine does not authenticate or inspect the referenced reports. *)
  bondQualified=TrueQ[Lookup[film,"BondQualificationPassed",False]&&bondQualificationEvidenceComplete];
  If[!And@@(phase1FiniteRealNumberQ /@ {rhoAl,eAl,sigmaAl,tAl,rhoFilm,eFilm,nuFilm,sigmaFilm,tFilm})||
      !And@@(TrueQ[#>0.]& /@ {rhoAl,eAl,sigmaAl,tAl,rhoFilm,eFilm,sigmaFilm,tFilm})||
      !TrueQ[0.<=nuFilm<0.5],
    Return[Failure["InvalidBacksideFilmComparisonInputs",<|"Film"->film,
      "AluminumThickness_m"->aluminumThickness|>]]
  ];
  (* The aluminum-only comparator uses the total known areal mass of foil, film and
     bond layer. If bond mass is unknown, zero is used only for this optimistic upper
     bound and the independent mass/property/qualification gates below block film
     selection. A bond layer contributes to the laminate neutral axis, rigidity and
     first-limit line capacity only when its thickness, density, modulus and allowable
     stress are all supplied, its areal mass agrees with density times thickness, and
     the section-inclusion flag is true. *)
  massTotal=rhoAl tAl+rhoFilm tFilm+If[bondMassKnown,bondMass,0.];
  tEquivalentAl=massTotal/rhoAl;
  tBondUsed=If[bondSectionModelled,tBond,0.];
  eBondUsed=If[bondSectionModelled,eBond,0.];
  sigmaBondUsed=If[bondSectionModelled,sigmaBond/in["StructuralSafetyFactor"],Infinity];
  zAl=tAl/2.;zBond=tAl+tBondUsed/2.;zFilm=tAl+tBondUsed+tFilm/2.;
  zNeutral=(eAl tAl zAl+eBondUsed tBondUsed zBond+eFilm tFilm zFilm)/
    (eAl tAl+eBondUsed tBondUsed+eFilm tFilm);
  (* Ideal bonded beam-strip flexural rigidity per unit width. Poisson ratio is kept
     in the material data register but is not used by this 1-D beam-strip expression;
     two-dimensional plate action and adhesive compliance are intentionally omitted. *)
  dComposite=eAl (tAl^3/12.+tAl (zAl-zNeutral)^2)+
    eBondUsed (tBondUsed^3/12.+tBondUsed (zBond-zNeutral)^2)+
    eFilm (tFilm^3/12.+tFilm (zFilm-zNeutral)^2);
  dAluminumEquivalent=eAl tEquivalentAl^3/12.;
  (* Use the first reported material limit under common laminate extension. For the
     film, the source is DuPont's stated 3%-elongation yield-point stress, not its
     ultimate tensile strength. A characterized bond layer contributes its own
     allowable strain; otherwise it receives no mechanical credit and selection is
     blocked. Base material strengths are divided by the mutable screening factor. *)
  firstLimitStrain=Min[sigmaAl/eAl,sigmaFilm/eFilm,sigmaBondUsed/Max[eBondUsed,10^-30]];
  compositeLineCapacity=(eAl tAl+eBondUsed tBondUsed+eFilm tFilm) firstLimitStrain;
  aluminumLineCapacity=sigmaAl tEquivalentAl;
  compositeSpecificStrength=compositeLineCapacity/massTotal;
  aluminumSpecificStrength=aluminumLineCapacity/massTotal;
  strengthRatio=compositeSpecificStrength/aluminumSpecificStrength;
  rigidityRatio=dComposite/dAluminumEquivalent;
  performancePass=TrueQ[strengthRatio>1.&&rigidityRatio>1.];
  bondEvidenceComplete=TrueQ[bondMassKnown&&bondPropertiesAvailable&&bondMassConsistencyPass&&bondSectionModelled];
  selected=TrueQ[performancePass&&bondEvidenceComplete&&bondQualified&&
    Lookup[film,"InstallationSide",None]==="AntiSunward"];
  selectionReason=Which[
    !bondMassKnown,"Bonding-layer areal mass is uncharacterized; equal-mass ratios are illustrative only and the film is not selectable.",
    !bondPropertiesAvailable,"Bond-layer thickness, density, modulus or allowable stress is unavailable; equal-mass ratios are illustrative only and the film is not selectable.",
    !bondMassConsistencyPass,"Bond areal mass is inconsistent with its stated density and thickness; do not select.",
    !bondSectionModelled,"Bond-layer section stiffness/compliance is not explicitly included in the laminate bending model; do not select.",
    !performancePass,"Candidate fails at least one mandatory equal-mass performance comparison; do not select or add it.",
    !bondQualificationEvidenceComplete,"One or more required bond qualification test flags are absent/failed or their traceable report references are missing/invalid; do not select.",
    !TrueQ[Lookup[film,"BondQualificationPassed",False]],"The overall bond qualification flag is not passed; do not select.",
    Lookup[film,"InstallationSide",None]=!="AntiSunward","Candidate is not registered for anti-sunward installation; do not select.",
    True,"Candidate passes the source-level comparison and bond/mass/side gates; integration and qualification remain required."];
  <|"CandidateMaterial"->Lookup[film,"MaterialName","Unnamed film"],
    "InstallationSide"->Lookup[film,"InstallationSide",Missing["NotSpecified"]],
    "CandidateFilmThickness_m"->tFilm,"CandidateFilmArealMass_kg_m2"->rhoFilm tFilm,
    "AluminumBaselineThickness_m"->tAl,"EqualMassAluminumThickness_m"->tEquivalentAl,
    "CompositeArealMassIncludingKnownBond_kg_m2"->massTotal,
    "BondMassIncludedInEqualMassComparison"->bondMassKnown,
    "CompositeNeutralAxisFromSunwardAluminumFace_m"->zNeutral,
    "CompositeBendingRigidity_NmPerUnitWidth"->dComposite,
    "EqualMassAluminumBendingRigidity_NmPerUnitWidth"->dAluminumEquivalent,
    "BendingRigidityRatioToEqualMassAluminum"->rigidityRatio,
    "CompositeFirstReportedLimitStrain"->firstLimitStrain,
    "CompositeFirstLimitLineCapacity_N_per_m"->compositeLineCapacity,
    "EqualMassAluminumLimitLineCapacity_N_per_m"->aluminumLineCapacity,
    "CompositeFirstLimitStrengthPerArealMass_m2_s2"->compositeSpecificStrength,
    "EqualMassAluminumStrengthPerArealMass_m2_s2"->aluminumSpecificStrength,
    "StrengthToWeightRatioToEqualMassAluminum"->strengthRatio,
    "BothStrengthAndRigidityOutperformEqualMassAluminum"->TrueQ[bondEvidenceComplete&&performancePass],
    "IdealizedRatiosExceedUnityBeforeBondEvidenceGate"->performancePass,
    "CompleteBondEvidenceAvailableForSelectionComparison"->TrueQ[bondEvidenceComplete&&
      bondQualificationEvidenceComplete&&Lookup[film,"BondQualificationPassed",False]],
    "BondingLayerArealMass_kg_m2"->bondMass,
    "BondingLayerMassCharacterized"->bondMassKnown,
    "BondLayerThickness_m"->tBond,
    "BondLayerDensity_kg_m3"->rhoBond,
    "BondLayerYoungsModulus_Pa"->eBond,
    "BondLayerAllowableStress_Pa"->sigmaBond,
    "BondArealMassConsistentWithDensityTimesThickness"->bondMassConsistencyPass,
    "BondMechanicalPropertiesAvailable"->bondPropertiesAvailable,
    "BondLayerIncludedInBendingSectionModel"->bondSectionModelled,
    "BondLayerThicknessUsedInSectionModel_m"->tBondUsed,
    "BondLayerModulusUsedInSectionModel_Pa"->eBondUsed,
    "BondQualificationEvidenceRequired"->bondQualificationEvidenceRequired,
    "BondQualificationEvidence"->bondQualificationEvidence,
    "BondQualificationEvidenceReferences"->bondQualificationEvidenceReferences,
    "BondQualificationEvidenceReferencesComplete"->bondQualificationEvidenceReferencesComplete,
    "BondQualificationEvidenceReferencesMissingOrInvalid"->bondQualificationEvidenceReferencesMissingOrInvalid,
    "BondQualificationEvidenceReferencesAreUserSuppliedNotIndependentlyVerified"->True,
    "BondQualificationEvidenceComplete"->bondQualificationEvidenceComplete,
    "BondQualificationEvidenceMissingOrFailed"->Select[bondQualificationEvidenceRequired,
      !TrueQ[Lookup[If[AssociationQ[bondQualificationEvidence],bondQualificationEvidence,<||>],#,False]]&],
    "BondQualificationFlagAloneSufficient"->False,
    "BondQualificationPassed"->bondQualified,
    "PerfectBondUpperBoundUsed"->True,
    "BacksideFilmSelected"->selected,
    "BacksideFilmMassAddedToActiveDesign_kg_m2"->If[selected,rhoFilm tFilm+bondMass,0.],
    "SelectionReason"->selectionReason,
    "QualificationBoundary"->"Manufacturer typical properties at 23 C are reference values only. The ideal-bond model omits adhesive mass/compliance, thermal-cycle stress, vacuum/outgassing, radiation degradation, seams/edges, deployment damage and laminate process effects. It is comparative screening, not a bonded-structure qualification."|>
];

(* WHAT: Evaluate the maximum midspan deflection of a simply supported unit-width
   aluminum strip under uniform normal pressure, bending rigidity and in-plane tension.
   WHY: The existing Phase 1 membrane model supplies an explicit pretension input. It
   must contribute to both the foil tensile-stress budget and its resistance to transverse
   deflection; ignoring it would disconnect the Step 5 panel screen from the membrane
   load model established earlier in the source.
   HOW: Solve D*w'''' - T*w'' = p with zero displacement and zero bending moment at
   both supports. For u=(L/2)*sqrt(T/D), the centered closed-form solution is
   delta = p*L^4/D * [1/(32*u^2) - (1-Sech[u])/(16*u^4)]. Its T->0 limit is
   5*p*L^4/(384*D). A short series is used for small u to avoid cancellation between
   nearly equal terms. T is a uniform in-plane force per unit width (N/m); D is the
   one-way beam-strip flexural rigidity per unit width (N*m). This is not a two-way
   plate/shell or nonlinear membrane solution. *)
phase1TensionedStripMidspanDeflection[pressure_,span_,flexuralRigidity_,membranePretension_] := Module[
  {u,shapeFactor,deflection},
  If[!And@@(phase1FiniteRealNumberQ/@{pressure,span,flexuralRigidity,membranePretension})||
      !TrueQ[pressure>=0.]||!TrueQ[span>0.]||!TrueQ[flexuralRigidity>0.]||!TrueQ[membranePretension>=0.],
    Return[Failure["Step5TensionedStripInputsInvalid",<|"Pressure_Pa"->pressure,
      "Span_m"->span,"FlexuralRigidity_NmPerUnitWidth"->flexuralRigidity,
      "MembranePretension_N_per_m"->membranePretension|>]]
  ];
  If[TrueQ[pressure==0.],Return[0.]];
  If[TrueQ[membranePretension==0.],
    Return[5. pressure span^4/(384. flexuralRigidity)]];
  u=0.5 span Sqrt[membranePretension/flexuralRigidity];
  If[!phase1FiniteRealNumberQ[u]||!TrueQ[u>0.],
    Return[Failure["Step5TensionedStripDimensionlessParameterInvalid",<|"DimensionlessTensionParameter"->u|>]]
  ];
  (* The truncated series through u^4 is used only below 0.01, where its omitted
     terms are negligible compared with the cancellation error of the closed form. *)
  shapeFactor=If[u<0.01,
    5./384.-61. u^2/11520.+277. u^4/129024.,
    1./(32. u^2)-(1.-Sech[u])/(16. u^4)];
  deflection=pressure span^4/flexuralRigidity shapeFactor;
  If[phase1FiniteRealNumberQ[deflection]&&TrueQ[deflection>=0.],deflection,
    Failure["Step5TensionedStripDeflectionInvalid",<|"DimensionlessTensionParameter"->u,
      "ShapeFactor"->shapeFactor,"Deflection_m"->deflection|>]]
];

(* WHAT: Find the largest rib spacing that satisfies the deflection fraction for
   the current aluminum thickness under the coupled tension-plus-bending strip model.
   WHY: A bending-only span limit would ignore the real contribution of the registered
   membrane pretension and could prescribe unnecessary extra wiring ribs. The spacing
   is a structural input to the foil mass and support architecture, so the largest span
   that meets the configured deflection criterion is the appropriate first screen.
   HOW: Search monotonically between zero and the planform diameter. For each candidate
   span, compare the exact tensioned-strip midspan deflection with the permitted fraction
   of that span. The search stops at the configured internal relative interval tolerance.
   Every successful return, including zero-pressure and planform-limited cases, uses the
   same association schema with MaximumPassingSpan_m; the caller can therefore consume
   the result without depending on which branch ended the search. This is a reduced-order
   strip calculation, not a shell or membrane-network solution. *)
phase1MaximumTensionedStripSpan[pressure_,flexuralRigidity_,membranePretension_,maximumSpan_,
    maximumDeflectionFraction_,relativeTolerance_:10^-8,maxIterations_:80] := Module[
  {low=0.,high=maximumSpan,mid,deflection,highDeflection,iteration},
  If[!And@@(phase1FiniteRealNumberQ/@{pressure,flexuralRigidity,membranePretension,
        maximumSpan,maximumDeflectionFraction,relativeTolerance})||
      !TrueQ[pressure>=0.]||!TrueQ[flexuralRigidity>0.]||!TrueQ[membranePretension>=0.]||
      !TrueQ[maximumSpan>0.]||!TrueQ[0.<maximumDeflectionFraction<1.]||
      !TrueQ[0.<relativeTolerance<1.]||!IntegerQ[maxIterations]||maxIterations<1,
    Return[Failure["Step5MaximumTensionedSpanInputsInvalid",<|
      "Pressure_Pa"->pressure,"FlexuralRigidity_NmPerUnitWidth"->flexuralRigidity,
      "MembranePretension_N_per_m"->membranePretension,"MaximumSpan_m"->maximumSpan,
      "MaximumDeflectionFraction"->maximumDeflectionFraction|>]]
  ];
  If[TrueQ[pressure==0.],Return[<|
    "MaximumPassingSpan_m"->maximumSpan,"NextUpperBracket_m"->maximumSpan,
    "RelativeIntervalTolerance"->relativeTolerance,"Iterations"->0,
    "MaximumSpanBoundedByPlanform"->True,"PlanformBoundActive"->True,
    "ZeroPressureDegenerateCase"->True|>]];
  highDeflection=phase1TensionedStripMidspanDeflection[pressure,high,flexuralRigidity,membranePretension];
  If[FailureQ[highDeflection],Return[highDeflection]];
  If[TrueQ[highDeflection<=maximumDeflectionFraction high],Return[<|
    "MaximumPassingSpan_m"->high,"NextUpperBracket_m"->high,
    "RelativeIntervalTolerance"->relativeTolerance,"Iterations"->0,
    "MaximumSpanBoundedByPlanform"->True,"PlanformBoundActive"->True,
    "ZeroPressureDegenerateCase"->False|>]];
  For[iteration=1,iteration<=maxIterations&&
      high-low>relativeTolerance maximumSpan,iteration++,
    mid=(low+high)/2.;
    deflection=phase1TensionedStripMidspanDeflection[pressure,mid,flexuralRigidity,membranePretension];
    If[FailureQ[deflection],Return[deflection]];
    If[TrueQ[deflection<=maximumDeflectionFraction mid],low=mid,high=mid]
  ];
  If[!phase1FiniteRealNumberQ[low]||!TrueQ[low>0.],
    Return[Failure["Step5MaximumTensionedSpanSearchFailed",<|
      "LowerPassingSpan_m"->low,"UpperFailingSpan_m"->high,"Iterations"->iteration-1|>]]
  ];
  <|"MaximumPassingSpan_m"->low,"NextUpperBracket_m"->high,
    "RelativeIntervalTolerance"->relativeTolerance,"Iterations"->iteration-1,
    "MaximumSpanBoundedByPlanform"->True,"PlanformBoundActive"->False,
    "ZeroPressureDegenerateCase"->False|>
];

(* WHAT: Find the minimum aluminum thickness that satisfies the coupled strip
   deflection criterion for one global or local pressure value.
   WHY: The foil must not be thickened merely because pretension was excluded from a
   bending-only approximation. Conversely, the foil may not be thinner than the
   existing continuous-aluminum baseline or the thickness required by combined stress.
   HOW: Evaluate the exact tensioned-strip response at the baseline thickness. If it
   passes, retain the baseline. Otherwise use the closed-form bending-only thickness as
   a guaranteed upper bracket (pretension can only reduce deflection in this model),
   then bisect to the minimum passing thickness at the internal relative tolerance. *)
phase1MinimumTensionedStripThickness[pressure_,span_,youngsModulus_,membranePretension_,
    allowableDeflection_,minimumThickness_,relativeTolerance_:10^-8,maxIterations_:80] := Module[
  {low=minimumThickness,high,mid,baseRigidity,highRigidity,midRigidity,
   baseDeflection,highDeflection,midDeflection,iteration},
  If[!And@@(phase1FiniteRealNumberQ/@{pressure,span,youngsModulus,membranePretension,
        allowableDeflection,minimumThickness,relativeTolerance})||
      !TrueQ[pressure>=0.]||!TrueQ[span>0.]||!TrueQ[youngsModulus>0.]||
      !TrueQ[membranePretension>=0.]||!TrueQ[allowableDeflection>0.]||
      !TrueQ[minimumThickness>0.]||!TrueQ[0.<relativeTolerance<1.]||
      !IntegerQ[maxIterations]||maxIterations<1,
    Return[Failure["Step5MinimumTensionedThicknessInputsInvalid",<|
      "Pressure_Pa"->pressure,"Span_m"->span,"YoungsModulus_Pa"->youngsModulus,
      "MembranePretension_N_per_m"->membranePretension,
      "AllowableDeflection_m"->allowableDeflection,
      "MinimumThickness_m"->minimumThickness|>]]
  ];
  baseRigidity=youngsModulus low^3/12.;
  baseDeflection=phase1TensionedStripMidspanDeflection[pressure,span,baseRigidity,membranePretension];
  If[FailureQ[baseDeflection],Return[baseDeflection]];
  If[TrueQ[baseDeflection<=allowableDeflection],Return[<|
    "MinimumPassingThickness_m"->low,"NextLowerFailingBracket_m"->Missing["BaselineThicknessPasses"],
    "RelativeIntervalTolerance"->relativeTolerance,"Iterations"->0,
    "BaselineThicknessAlreadyPasses"->True|>]];
  (* This bending-only value is used solely as a conservative numerical upper bracket;
     it is not reported as the required thickness when pretension is present. *)
  high=Max[low,(5. pressure span^4/(32. youngsModulus allowableDeflection))^(1./3.)];
  highRigidity=youngsModulus high^3/12.;
  highDeflection=phase1TensionedStripMidspanDeflection[pressure,span,highRigidity,membranePretension];
  If[FailureQ[highDeflection],Return[highDeflection]];
  If[!TrueQ[highDeflection<=allowableDeflection (1.+10. relativeTolerance)],
    Return[Failure["Step5TensionedThicknessUpperBracketFailed",<|
      "UpperBracketThickness_m"->high,"UpperBracketDeflection_m"->highDeflection,
      "AllowableDeflection_m"->allowableDeflection|>]]
  ];
  For[iteration=1,iteration<=maxIterations&&
      high-low>relativeTolerance Max[high,minimumThickness],iteration++,
    mid=(low+high)/2.;
    midRigidity=youngsModulus mid^3/12.;
    midDeflection=phase1TensionedStripMidspanDeflection[pressure,span,midRigidity,membranePretension];
    If[FailureQ[midDeflection],Return[midDeflection]];
    If[TrueQ[midDeflection<=allowableDeflection],high=mid,low=mid]
  ];
  <|"MinimumPassingThickness_m"->high,"NextLowerFailingBracket_m"->low,
    "RelativeIntervalTolerance"->relativeTolerance,"Iterations"->iteration-1,
    "BaselineThicknessAlreadyPasses"->False|>
];

(* WHAT: Build a pole-specific Step 5 structural interface from that same pole's
   supplied Step 4 core and local pressure array.
   WHY: Wiring-run spacing sets foil panel span; foil span and pressure set the minimum
   foil thickness. The same inter-node conductor then receives the tributary surface-load
   envelope plus its own conductor/insulation linear mass multiplied by an explicitly
   evidenced maximum effective transverse acceleration, and must meet axial rigidity,
   tension, operating sag and anchor requirements.
   HOW: This routine accepts an explicit Step 4 assessment record; it does not execute
   Step 4 or its dynamics. Until Step 4 is resumed and accepted, the output is clearly
   provisional. Automatic spacing returns the largest current-baseline spacing allowed
   by the stress and deflection screen, capped at the collector diameter. A supplied
   spacing may require thicker foil, but only to the calculated minimum. The automatic
   unsupported rib span is conservatively the whole planform diameter until Step 7
   supplies actual node/station supports and route lengths. The live mass model is not
   modified by this preliminary assessment. *)
phase1Step5StructuralArchitectureCurrent[step4Assessment_Association,ribSpacingArgument_:Automatic,
    ribRunSpanArgument_:Automatic,intraNodeConnectorInput_:Automatic,interNodeRibInput_:Automatic] := Module[
  {in=Phase1GetInputs[],core,geometry,structural,surfaceMesh,meshPatches,patchAreaWeights,
   patchPositions,patchNormals,patchIndices,patchAreaClosureError,patchAreaTolerance,
   patchTangentialTractions,patchGravityNormalTractions,patchGravityTangentialTractions,
   patchAttachmentGravityNormalTractions,patchAttachmentGravityTangentialTractions,
   gravityIncluded,attachmentGravityTransferred,patchwiseScreen,patchwisePass,
   maximumPatchwisePanelDeflection,maximumPanelDeflectionEnvelope,
   maximumCombinedDeflectionEnvelope,maximumCombinedDeflectionLimit,combinedDeflectionPass,
   patchi,patchPressure,patchShearStress,patchEffectiveNormalAllowable,patchThicknessStress,
   patchThicknessDeflection,patchThicknessDeflectionRecord,patchStress,patchEquivalentStress,patchDeflection,
   step4ScopeComplete,pressureSamples,peakPressure,maximumPatchTangentialTraction,
   effectiveNormalStressAllowable,actualPanelEquivalentStress,
   radius,curvedArea,baseThickness,aluminumDensity,aluminumModulus,allowableStress,
   panelDeflectionFraction,deflectionLimitFraction,ribSagFraction,ribExtensionFraction,safetyFactor,
   membranePretension,baselinePretensionStress,baselineBendingStressBudget,
   maxSpacingByStress,maxSpacingByDeflection,maxSpacingByDeflectionRecord,maxSpacing,selectedSpacing,spacingDerived,
   panelDeflectionLimit,requiredThicknessByStress,requiredThicknessByDeflection,
   requiredThicknessByDeflectionRecord,
   minimumThickness,selectedThickness,actualPanelStress,actualPanelDeflection,spacingPass,
   runSpan,ribLineLoad,sagLimit,ribHorizontalTension,ribVerticalReaction,ribEndTension,
   ribEndCapacity,requiredEA,aluminumMass,foilArealMass,foilMembraneExtensionalStiffness,
   foilFlexuralRigidity,baselineFoilArealMass,baselineFoilFlexuralRigidity,
   foilArealMassRatio,foilFlexuralRigidityRatio,filmCandidate,filmComparison,selectedFilmMass,
   connectorScreen,connectorMass,connectorBlockers,interNodeRibScreen,interNodeRibMass,
   interNodeRibBlockers,totalKnownStructureMass,result,stamp},
  If[!TrueQ[$Phase1ExecutingPole]||!MemberQ[$Phase1PoleIDs,$Phase1CurrentPole],
    Return[Failure["Step5RequiresIndependentPoleContext",<|"ActivePole"->$Phase1CurrentPole|>]]
  ];
  If[Lookup[step4Assessment,"Pole",None]=!=$Phase1CurrentPole,
    Return[Failure["Step5Step4PoleMismatch",<|"ActivePole"->$Phase1CurrentPole,
      "Step4AssessmentPole"->Lookup[step4Assessment,"Pole",Missing["NoPole"]]|>]]
  ];
  core=Lookup[step4Assessment,"Step4Core",Missing["Step4CoreUnavailable"]];
  If[!AssociationQ[core],Return[Failure["Step5Step4CoreUnavailable",<|"Step4Assessment"->step4Assessment|>]]];
  geometry=Lookup[core,"Geometry",<||>];
  structural=Lookup[core,"StructuralScreen",<||>];
  surfaceMesh=Lookup[core,"SurfaceMesh",<||>];
  If[!AssociationQ[geometry]||!AssociationQ[structural]||!AssociationQ[surfaceMesh],
    Return[Failure["Step5Step4GeometryOrStructuralRecordUnavailable",<|
      "GeometryAvailable"->AssociationQ[geometry],"StructuralRecordAvailable"->AssociationQ[structural],
      "SurfaceMeshAvailable"->AssociationQ[surfaceMesh]|>]]
  ];
  pressureSamples=Lookup[structural,"PatchNormalPressureContributions_Pa",{}];
  patchTangentialTractions=Lookup[structural,"PatchTangentialTraction_Pa",{}];
  patchGravityNormalTractions=Lookup[structural,"PatchGravityNormalTraction_Pa",{}];
  patchGravityTangentialTractions=Lookup[structural,"PatchGravityTangentialTraction_Pa",{}];
  patchAttachmentGravityNormalTractions=Lookup[structural,"PatchAttachmentGravityNormalTraction_Pa",{}];
  patchAttachmentGravityTangentialTractions=Lookup[structural,"PatchAttachmentGravityTangentialTraction_Pa",{}];
  gravityIncluded=TrueQ[Lookup[structural,"DistributedGravityIncludedInStaticStructuralLoad",False]];
  attachmentGravityTransferred=TrueQ[Lookup[structural,"PerimeterAndStationGravityTransferredToMembrane",False]];
  meshPatches=Lookup[surfaceMesh,"Patches",{}];
  patchAreaWeights=Lookup[meshPatches,"SurfaceAreaWeight_m2",{}];
  patchPositions=Lookup[meshPatches,"Position_m",{}];
  patchNormals=Lookup[meshPatches,"Normal",{}];
  patchIndices=Lookup[meshPatches,"PatchIndex",{}];
  patchAreaTolerance=Lookup[in,"MeshAreaRelativeTolerance",Missing["MeshAreaToleranceUnavailable"]];
  radius=Lookup[geometry,"PlanformEquivalentRadius_m",Missing["PlanformRadiusUnavailable"]];
  curvedArea=Lookup[geometry,"GrossCurvedAreaPerPole_m2",Missing["CurvedAreaUnavailable"]];
  If[!ListQ[pressureSamples]||pressureSamples==={}||
      !And@@(phase1FiniteRealNumberQ/@pressureSamples)||
      !And@@(TrueQ[#>=0.]&/@pressureSamples)||
      !ListQ[patchTangentialTractions]||Length[patchTangentialTractions]=!=Length[pressureSamples]||
      !And@@(phase1FiniteRealNumberQ/@patchTangentialTractions)||
      !And@@(TrueQ[#>=0.]&/@patchTangentialTractions)||
      !ListQ[patchGravityNormalTractions]||Length[patchGravityNormalTractions]=!=Length[pressureSamples]||
      !And@@(phase1FiniteRealNumberQ/@patchGravityNormalTractions)||
      !And@@(TrueQ[#>=0.]&/@patchGravityNormalTractions)||
      !ListQ[patchGravityTangentialTractions]||Length[patchGravityTangentialTractions]=!=Length[pressureSamples]||
      !And@@(phase1FiniteRealNumberQ/@patchGravityTangentialTractions)||
      !And@@(TrueQ[#>=0.]&/@patchGravityTangentialTractions)||
      !ListQ[patchAttachmentGravityNormalTractions]||Length[patchAttachmentGravityNormalTractions]=!=Length[pressureSamples]||
      !And@@(phase1FiniteRealNumberQ/@patchAttachmentGravityNormalTractions)||
      !And@@(TrueQ[#>=0.]&/@patchAttachmentGravityNormalTractions)||
      !ListQ[patchAttachmentGravityTangentialTractions]||Length[patchAttachmentGravityTangentialTractions]=!=Length[pressureSamples]||
      !And@@(phase1FiniteRealNumberQ/@patchAttachmentGravityTangentialTractions)||
      !And@@(TrueQ[#>=0.]&/@patchAttachmentGravityTangentialTractions)||
      !ListQ[meshPatches]||Length[meshPatches]=!=Length[pressureSamples]||
      !And@@(AssociationQ/@meshPatches)||
      !ListQ[patchAreaWeights]||Length[patchAreaWeights]=!=Length[pressureSamples]||
      !VectorQ[patchAreaWeights,phase1FiniteRealNumberQ]||
      !And@@(TrueQ[#>0.]&/@patchAreaWeights)||
      !ListQ[patchPositions]||Length[patchPositions]=!=Length[pressureSamples]||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@patchPositions)||
      !ListQ[patchNormals]||Length[patchNormals]=!=Length[pressureSamples]||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@patchNormals)||
      !And@@(TrueQ[Abs[Norm[#]-1.]<=Sqrt[$MachineEpsilon]]&/@patchNormals)||
      !VectorQ[patchIndices,IntegerQ]||Length[patchIndices]=!=Length[pressureSamples]||
      Sort[patchIndices]=!=Range[Length[pressureSamples]]||
      !phase1FiniteRealNumberQ[patchAreaTolerance]||!TrueQ[patchAreaTolerance>0.]||
      !phase1FiniteRealNumberQ[curvedArea]||!TrueQ[curvedArea>0.],
    Return[Failure["Step5PatchGeometryLoadJoinInvalid",<|"Pole"->$Phase1CurrentPole,
      "PressureCount"->Length[pressureSamples],"TangentialTractionCount"->Length[patchTangentialTractions],
      "GravityNormalTractionCount"->Length[patchGravityNormalTractions],
      "GravityTangentialTractionCount"->Length[patchGravityTangentialTractions],
      "AttachmentGravityNormalTractionCount"->Length[patchAttachmentGravityNormalTractions],
      "AttachmentGravityTangentialTractionCount"->Length[patchAttachmentGravityTangentialTractions],
      "MeshPatchCount"->Length[meshPatches],
      "PatchAreaWeightCount"->Length[patchAreaWeights],"PatchPositionCount"->Length[patchPositions],
      "PatchNormalCount"->Length[patchNormals],"PatchIndexCount"->Length[patchIndices]|>]]
  ];
  patchAreaClosureError=Abs[Total[patchAreaWeights]/curvedArea-1.];
  If[!phase1FiniteRealNumberQ[patchAreaClosureError]||
      !TrueQ[patchAreaClosureError<=patchAreaTolerance],
    Return[Failure["Step5PatchAreaClosureFailed",<|"Pole"->$Phase1CurrentPole,
      "QuadratureCurvedArea_m2"->Total[patchAreaWeights],"AnalyticCurvedArea_m2"->curvedArea,
      "RelativeAreaError"->patchAreaClosureError,"AllowedRelativeAreaError"->patchAreaTolerance|>]]
  ];
  peakPressure=Max[pressureSamples];
  maximumPatchTangentialTraction=Max[patchTangentialTractions];
  baseThickness=Lookup[in,"AluminumFoilThickness_m",Missing["AluminumThicknessUnavailable"]];
  aluminumDensity=Lookup[in,"AluminumDensity_kg_m3",Missing["AluminumDensityUnavailable"]];
  aluminumModulus=Lookup[in,"AluminumYoungsModulus_Pa",Missing["AluminumModulusUnavailable"]];
  allowableStress=Lookup[in,"AluminumYieldStrength_Pa",Missing["AluminumYieldStrengthUnavailable"]]/
    Lookup[in,"StructuralSafetyFactor",Missing["StructuralSafetyFactorUnavailable"]];
  panelDeflectionFraction=Lookup[in,"MaximumPanelDeflectionFractionOfRibSpacing",Missing["PanelDeflectionFractionUnavailable"]];
  deflectionLimitFraction=Lookup[in,"MaximumDeflectionFractionOfRadius",Missing["CombinedDeflectionLimitFractionUnavailable"]];
  membranePretension=Lookup[in,"MembranePretension_N_m",Missing["MembranePretensionUnavailable"]];
  ribSagFraction=Lookup[in,"MaximumStructuralRibSagFractionOfRunSpan",Missing["RibSagFractionUnavailable"]];
  ribExtensionFraction=Lookup[in,"MaximumStructuralRibElasticExtensionFraction",Missing["RibExtensionFractionUnavailable"]];
  safetyFactor=Lookup[in,"StructuralSafetyFactor",Missing["StructuralSafetyFactorUnavailable"]];
  If[!And@@(phase1FiniteRealNumberQ/@{peakPressure,radius,curvedArea,baseThickness,aluminumDensity,
        aluminumModulus,allowableStress,panelDeflectionFraction,deflectionLimitFraction,membranePretension,ribSagFraction,ribExtensionFraction,safetyFactor})||
      !And@@(TrueQ[#>0.]&/@{peakPressure,radius,curvedArea,baseThickness,aluminumDensity,aluminumModulus,
        allowableStress,panelDeflectionFraction,deflectionLimitFraction,ribSagFraction,ribExtensionFraction,safetyFactor})||
      !TrueQ[membranePretension>=0.]||
      !And@@(TrueQ[#<1.]&/@{panelDeflectionFraction,deflectionLimitFraction,ribSagFraction,ribExtensionFraction}),
    Return[Failure["Step5StructuralInputsInvalid",<|"PeakPressure_Pa"->peakPressure,
      "PlanformRadius_m"->radius,"CurvedArea_m2"->curvedArea|>]]
  ];
  (* The foil carries both the configured in-plane pretension and transverse bending.
     Pretension stress is T/t; simply supported strip bending stress is 3*p*s^2/(4*t^2).
     Step 4 also supplies the patchwise magnitude of in-plane tangential surface
     traction. For the one-way local screen, the full traction magnitude is assigned to
     one scalar shear component; this is an explicit screening surrogate, not a resolved
     in-plane stress tensor. The maximum tangential traction reduces the available
     strip-normal stress to Sqrt[sigmaAllow^2 - 3*tauMax^2]. The baseline bending-stress
     budget is therefore this shear-reduced normal allowance minus T/t. If that budget
     is exhausted, the baseline thickness cannot pass any nonzero pressure span by
     itself: retain the planform cap as a provisional span ceiling and derive the
     structurally required thicker section below. The global envelope intentionally
     combines independent maximum pressure and maximum shear and can therefore be more
     conservative than any single patch; local patch checks use co-located values. *)
  (* Step 4 supplies normal pressure and in-plane tangential surface traction at the
     curved patches. The one-way strip screen assigns the full magnitude of tangential
     traction to a single scalar shear component, then combines it with strip-normal
     pretension/bending stress using a plane-stress von Mises screening surrogate:
     sigmaVM = Sqrt[sigmaNormal^2 + 3 tau^2]. The effective normal allowance is
     Sqrt[sigmaAllow^2 - 3 tau^2]. No directional in-plane stress tensor, membrane load
     redistribution, or two-way shell response is solved by this source routine. *)
  effectiveNormalStressAllowable=Sqrt[Max[0.,allowableStress^2-3. maximumPatchTangentialTraction^2]];
  If[!phase1FiniteRealNumberQ[effectiveNormalStressAllowable]||
      !TrueQ[effectiveNormalStressAllowable>0.],
    Return[Failure["Step5TangentialTractionConsumesAllowableStress",<|
      "AllowableStress_Pa"->allowableStress,
      "MaximumPatchTangentialTraction_Pa"->maximumPatchTangentialTraction,
      "VonMisesShearContribution_Pa"->Sqrt[3.] maximumPatchTangentialTraction,
      "RemainingNormalStressAllowable_Pa"->effectiveNormalStressAllowable|>]]
  ];
  baselinePretensionStress=membranePretension/baseThickness;
  baselineBendingStressBudget=effectiveNormalStressAllowable-baselinePretensionStress;
  maxSpacingByStress=If[baselineBendingStressBudget>0.,
    baseThickness Sqrt[4. baselineBendingStressBudget/(3. peakPressure)],2. radius];
  baselineFoilFlexuralRigidity=aluminumModulus baseThickness^3/12.;
  maxSpacingByDeflectionRecord=phase1MaximumTensionedStripSpan[peakPressure,
    baselineFoilFlexuralRigidity,membranePretension,2. radius,panelDeflectionFraction];
  If[FailureQ[maxSpacingByDeflectionRecord],Return[maxSpacingByDeflectionRecord]];
  maxSpacingByDeflection=Lookup[maxSpacingByDeflectionRecord,"MaximumPassingSpan_m",Missing["CoupledSpanNotAvailable"]];
  maxSpacing=Min[maxSpacingByStress,maxSpacingByDeflection,2. radius];
  If[!phase1FiniteRealNumberQ[maxSpacing]||!TrueQ[0.<maxSpacing<=2. radius],
    Return[Failure["Step5DerivedRibSpacingLimitInvalid",<|"MaximumSpacingByStress_m"->maxSpacingByStress,
      "MaximumSpacingByDeflection_m"->maxSpacingByDeflection,"PlanformDiameter_m"->2. radius|>]]
  ];
  spacingDerived=(ribSpacingArgument===Automatic);
  selectedSpacing=If[spacingDerived,maxSpacing,ribSpacingArgument];
  If[!phase1FiniteRealNumberQ[selectedSpacing]||!TrueQ[0.<selectedSpacing<=2. radius],
    Return[Failure["Step5SelectedRibSpacingInvalid",<|"SelectedSpacing_m"->selectedSpacing,
      "MaximumBaselineSpacing_m"->maxSpacing,"PlanformDiameter_m"->2. radius|>]]
  ];
  panelDeflectionLimit=panelDeflectionFraction selectedSpacing;
  (* Solve sigma_normal_allow*t^2 - T*t - 3*p*s^2/4 = 0 for the positive thickness
     that carries pretension and the maximum strip bending stress together, where
     sigma_normal_allow has already been reduced by the global tangential-traction
     envelope through the plane-stress von Mises interaction. The deflection-derived
     thickness remains a conservative search upper bracket; final deflection below uses
     the coupled tension-plus-bending response. *)
  requiredThicknessByStress=(membranePretension+
    Sqrt[membranePretension^2+3. effectiveNormalStressAllowable peakPressure selectedSpacing^2])/(2. effectiveNormalStressAllowable);
  requiredThicknessByDeflectionRecord=phase1MinimumTensionedStripThickness[peakPressure,selectedSpacing,
    aluminumModulus,membranePretension,panelDeflectionLimit,baseThickness];
  If[FailureQ[requiredThicknessByDeflectionRecord],Return[requiredThicknessByDeflectionRecord]];
  requiredThicknessByDeflection=Lookup[requiredThicknessByDeflectionRecord,
    "MinimumPassingThickness_m",Missing["CoupledThicknessNotAvailable"]];
  If[!phase1FiniteRealNumberQ[requiredThicknessByDeflection]||!TrueQ[requiredThicknessByDeflection>0.],
    Return[Failure["Step5CoupledThicknessSearchResultInvalid",<|
      "SearchRecord"->requiredThicknessByDeflectionRecord|>]]
  ];
  minimumThickness=Max[requiredThicknessByStress,requiredThicknessByDeflection];
  selectedThickness=Max[baseThickness,minimumThickness];
  (* Report the actual aluminum section properties before they are consumed by the
     panel response equations. Areal mass is rho*t, membrane extensional stiffness per
     unit width is E*t, and Euler-Bernoulli flexural rigidity per unit width is E*t^3/12.
     This is a unit-width beam-strip property, not a two-way plate rigidity or shell model. *)
  foilArealMass=selectedThickness aluminumDensity;
  foilMembraneExtensionalStiffness=aluminumModulus selectedThickness;
  foilFlexuralRigidity=aluminumModulus selectedThickness^3/12.;
  baselineFoilArealMass=baseThickness aluminumDensity;
  baselineFoilFlexuralRigidity=aluminumModulus baseThickness^3/12.;
  foilArealMassRatio=foilArealMass/baselineFoilArealMass;
  foilFlexuralRigidityRatio=foilFlexuralRigidity/baselineFoilFlexuralRigidity;
  If[!And@@(phase1FiniteRealNumberQ/@{foilArealMass,foilMembraneExtensionalStiffness,
        foilFlexuralRigidity,baselineFoilArealMass,baselineFoilFlexuralRigidity,
        foilArealMassRatio,foilFlexuralRigidityRatio})||
      !And@@(TrueQ[#>0.]&/@{foilArealMass,foilMembraneExtensionalStiffness,
        foilFlexuralRigidity,baselineFoilArealMass,baselineFoilFlexuralRigidity,
        foilArealMassRatio,foilFlexuralRigidityRatio}),
    Return[Failure["Step5AluminumSectionPropertiesInvalid",<|"Pole"->$Phase1CurrentPole,
      "SelectedThickness_m"->selectedThickness,"BaselineThickness_m"->baseThickness,
      "AluminumDensity_kg_m3"->aluminumDensity,"AluminumModulus_Pa"->aluminumModulus,
      "FoilArealMass_kg_m2"->foilArealMass,
      "FoilMembraneExtensionalStiffness_N_per_m"->foilMembraneExtensionalStiffness,
      "FoilFlexuralRigidity_NmPerUnitWidth"->foilFlexuralRigidity|>]]
  ];
  actualPanelStress=membranePretension/selectedThickness+
    3. peakPressure selectedSpacing^2/(4. selectedThickness^2);
  actualPanelEquivalentStress=Sqrt[actualPanelStress^2+3. maximumPatchTangentialTraction^2];
  actualPanelDeflection=phase1TensionedStripMidspanDeflection[peakPressure,selectedSpacing,
    foilFlexuralRigidity,membranePretension];
  If[FailureQ[actualPanelDeflection],Return[actualPanelDeflection]];
  spacingPass=TrueQ[phase1FiniteRealNumberQ[selectedThickness]&&selectedThickness>0.&&
    phase1FiniteRealNumberQ[actualPanelEquivalentStress]&&
    actualPanelEquivalentStress<=allowableStress (1.+Sqrt[$MachineEpsilon])&&
    actualPanelDeflection<=panelDeflectionLimit (1.+Sqrt[$MachineEpsilon])];
  (* The peak pressure sets a conservative common candidate thickness. Preserve the
     full local Step 4 pressure field as a second, patchwise view: each local patch is
     evaluated using its own normal pressure, actual curved-area weight, position and
     normal. This identifies local demand peaks without pretending that the final
     electrical rib route is already known. One common trial rib spacing is applied
     only as an interim grid assumption; Step 7 must replace it with the actual
     routed/support-bay geometry. *)
  patchwiseScreen=Table[
    patchPressure=pressureSamples[[patchi]];
    patchShearStress=patchTangentialTractions[[patchi]];
    patchEffectiveNormalAllowable=Sqrt[Max[0.,allowableStress^2-3. patchShearStress^2]];
    If[!phase1FiniteRealNumberQ[patchEffectiveNormalAllowable]||
        !TrueQ[patchEffectiveNormalAllowable>0.],
      Return[Failure["Step5PatchTangentialTractionConsumesAllowableStress",<|
        "PatchIndex"->patchIndices[[patchi]],"AllowableStress_Pa"->allowableStress,
        "TangentialTraction_Pa"->patchShearStress,
        "RemainingNormalStressAllowable_Pa"->patchEffectiveNormalAllowable|>]]
    ];
    patchThicknessStress=(membranePretension+
      Sqrt[membranePretension^2+3. patchEffectiveNormalAllowable patchPressure selectedSpacing^2])/(2. patchEffectiveNormalAllowable);
    patchThicknessDeflectionRecord=phase1MinimumTensionedStripThickness[patchPressure,selectedSpacing,
      aluminumModulus,membranePretension,panelDeflectionLimit,baseThickness];
    If[FailureQ[patchThicknessDeflectionRecord],Return[patchThicknessDeflectionRecord]];
    patchThicknessDeflection=Lookup[patchThicknessDeflectionRecord,
      "MinimumPassingThickness_m",Missing["PatchCoupledThicknessNotAvailable"]];
    If[!phase1FiniteRealNumberQ[patchThicknessDeflection]||!TrueQ[patchThicknessDeflection>0.],
      Return[Failure["Step5PatchCoupledThicknessSearchResultInvalid",<|
        "PatchIndex"->patchIndices[[patchi]],"SearchRecord"->patchThicknessDeflectionRecord|>]]
    ];
    patchStress=membranePretension/selectedThickness+
      3. patchPressure selectedSpacing^2/(4. selectedThickness^2);
    patchEquivalentStress=Sqrt[patchStress^2+3. patchShearStress^2];
    patchDeflection=phase1TensionedStripMidspanDeflection[patchPressure,selectedSpacing,
      foilFlexuralRigidity,membranePretension];
    If[FailureQ[patchDeflection],Return[patchDeflection]];
    <|"PatchIndex"->patchIndices[[patchi]],"PatchPosition_m"->patchPositions[[patchi]],
      "LocalSurfaceNormal"->patchNormals[[patchi]],"CurvedSurfaceAreaWeight_m2"->patchAreaWeights[[patchi]],
      "LocalNormalPressureMagnitude_Pa"->patchPressure,
      "LocalTangentialTraction_Pa"->patchShearStress,
      "PatchGravityNormalTraction_Pa"->patchGravityNormalTractions[[patchi]],
      "PatchGravityTangentialTraction_Pa"->patchGravityTangentialTractions[[patchi]],
      "PatchAttachmentGravityNormalTraction_Pa"->patchAttachmentGravityNormalTractions[[patchi]],
      "PatchAttachmentGravityTangentialTraction_Pa"->patchAttachmentGravityTangentialTractions[[patchi]],
      "PretensionStressAtSelectedThickness_Pa"->membranePretension/selectedThickness,
      "BendingStressAtSelectedThickness_Pa"->3. patchPressure selectedSpacing^2/(4. selectedThickness^2),
      "MinimumThicknessByStress_m"->patchThicknessStress,
      "MinimumThicknessByDeflection_m"->patchThicknessDeflection,
      "MinimumThicknessByDeflectionSearch"->patchThicknessDeflectionRecord,
      "StressAtSelectedThickness_Pa"->patchStress,
      "VonMisesEquivalentStressAtSelectedThickness_Pa"->patchEquivalentStress,
      "VonMisesStressSurrogateAtSelectedThickness_Pa"->patchEquivalentStress,
      "TangentialTractionMappedToScalarShearSurrogate"->True,
      "AllowableNormalStressAfterShearInteraction_Pa"->patchEffectiveNormalAllowable,
      "DeflectionAtSelectedThickness_m"->patchDeflection,
      "DeflectionLimit_m"->panelDeflectionLimit,
      "ScreenPass"->TrueQ[phase1FiniteRealNumberQ[patchEquivalentStress]&&
        patchEquivalentStress<=allowableStress (1.+Sqrt[$MachineEpsilon])&&
        patchDeflection<=panelDeflectionLimit (1.+Sqrt[$MachineEpsilon])]|>,
    {patchi,Length[pressureSamples]}];
  patchwisePass=TrueQ[Length[patchwiseScreen]===Length[pressureSamples]&&
    And@@(TrueQ[Lookup[#,"ScreenPass",False]]&/@patchwiseScreen)];
  spacingPass=TrueQ[spacingPass&&patchwisePass];
  runSpan=If[ribRunSpanArgument===Automatic,2. radius,ribRunSpanArgument];
  If[!phase1FiniteRealNumberQ[runSpan]||!TrueQ[0.<runSpan<=2. radius],
    Return[Failure["Step5StructuralRibRunSpanInvalid",<|"RunSpan_m"->runSpan,
      "PlanformDiameter_m"->2. radius|>]]
  ];
  If[!ListQ[patchwiseScreen]||Length[patchwiseScreen]<1,
    Return[Failure["Step5PatchwiseDeflectionResultsUnavailable",<|
      "PatchwiseResultCount"->If[ListQ[patchwiseScreen],Length[patchwiseScreen],Missing["NotAList"]]|>]]
  ];
  (* WHAT: Bound the collector's total out-of-plane displacement by combining the
     largest global/patchwise foil-bay deflection with the maximum allowed support-rib sag.
     WHY: The foil panel screen measures deflection relative to the wiring-rib supports;
     it does not include movement of the supports themselves. A panel-only pass must not
     hide a large support displacement when both belong to the same structural load path.
     HOW: Add the maximum local/global panel response to the conservative rib-sag sizing
     envelope, then compare that upper bound with the existing global maximum-deflection
     allowance expressed as a fraction of planform radius. This is a conservative scalar
     envelope; it does not resolve direction, spatial phase, or nonlinear coupling. *)
  maximumPatchwisePanelDeflection=Max[Lookup[patchwiseScreen,"DeflectionAtSelectedThickness_m"]];
  maximumPanelDeflectionEnvelope=Max[actualPanelDeflection,maximumPatchwisePanelDeflection];
  maximumCombinedDeflectionEnvelope=maximumPanelDeflectionEnvelope+ribSagFraction runSpan;
  maximumCombinedDeflectionLimit=deflectionLimitFraction radius;
  combinedDeflectionPass=TrueQ[And@@(phase1FiniteRealNumberQ/@{maximumPatchwisePanelDeflection,
      maximumPanelDeflectionEnvelope,maximumCombinedDeflectionEnvelope,maximumCombinedDeflectionLimit})&&
    maximumCombinedDeflectionEnvelope<=maximumCombinedDeflectionLimit (1.+Sqrt[$MachineEpsilon])];
  spacingPass=TrueQ[spacingPass&&combinedDeflectionPass];
  (* For the preliminary global rib screen, form a conservative line-load envelope
     from both the maximum normal pressure and maximum tangential-traction magnitude:
     q=(pMax+tauMax)*s. The two maxima may occur on different patches, and their rib-local
     directions are unresolved, so their nonnegative magnitudes are added rather than
     projected into an invented direction. For a small-sag parabolic cable, horizontal
     tension is approximately q L^2/(8 delta). The endpoint also carries half the
     distributed-load envelope; the factored resultant sets the anchor demand. The same
     factored endpoint tension divided by the maximum permitted elastic extension gives
     a conservative required EA. Actual per-run tributary integration below replaces
     this global envelope when Step 7 supplies the physical rib mapping. *)
  ribLineLoad=(peakPressure+maximumPatchTangentialTraction) selectedSpacing;
  sagLimit=ribSagFraction runSpan;
  ribHorizontalTension=ribLineLoad runSpan^2/(8. sagLimit);
  ribVerticalReaction=ribLineLoad runSpan/2.;
  ribEndTension=Sqrt[ribHorizontalTension^2+ribVerticalReaction^2];
  ribEndCapacity=safetyFactor ribEndTension;
  requiredEA=ribEndCapacity/ribExtensionFraction;
  aluminumMass=curvedArea selectedThickness aluminumDensity;
  filmCandidate=$Phase1AlternateMaterialScenarioPresets["BacksideFilm"]["Candidate"];
  filmComparison=phase1BacksideFilmComparison[in,selectedThickness,filmCandidate];
  If[FailureQ[filmComparison],Return[filmComparison]];
  selectedFilmMass=filmComparison["BacksideFilmMassAddedToActiveDesign_kg_m2"];
  (* Intra-node tabs/solder are a separate local connector tier. When exact Step 7
     geometry and per-connection demands are supplied, include their screened mass in
     this pole's known subtotal. Until then, preserve a Missing marker and do not guess
     a tab count, alloy, overlap, solder volume or installed mass. *)
  connectorScreen=Which[
    intraNodeConnectorInput===Automatic,Missing["Step7IntraNodeConnectorRecordRequired"],
    AssociationQ[intraNodeConnectorInput],phase1Step5IntraNodeConnectorScreenCurrent[intraNodeConnectorInput,safetyFactor],
    True,Failure["Step5ConnectorRecordMustBeAssociation",<|"SuppliedValue"->intraNodeConnectorInput|>]];
  If[FailureQ[connectorScreen],Return[connectorScreen]];
  connectorMass=If[AssociationQ[connectorScreen],connectorScreen["TotalIntraNodeConnectorMass_kg"],0.];
  connectorBlockers=Join[
    If[MissingQ[connectorScreen],{"Step 7 must supply exact intra-node tab/solder geometry, material, connection count and per-connection mechanical demands."},{}],
    If[AssociationQ[connectorScreen]&&!TrueQ[connectorScreen["NominalMechanicalScreenPass"]],
      {"The supplied intra-node connector record fails at least one nominal tab/joint/extension screen."},{}],
    If[AssociationQ[connectorScreen]&&!TrueQ[connectorScreen["UserSuppliedJointQualificationPassed"]],
      {"The supplied intra-node connector joint remains unqualified; a passing nominal stress screen is not hardware qualification. Supplied overall qualification flag: "<>
        ToString[connectorScreen["SuppliedOverallJointQualificationFlag"],InputForm]<>
        "; missing/failed evidence keys: "<>
        ToString[connectorScreen["JointQualificationEvidenceMissingOrFailed"],InputForm]<>
        "; missing/invalid report-reference keys: "<>
        ToString[connectorScreen["JointQualificationEvidenceReferencesMissingOrInvalid"],InputForm]},{}]];
  (* If Step 7 supplies exact inter-node routes, conductor section and per-run
     TributaryPatchShares, integrate both normal pressure and tangential-traction
     magnitude over the same pole's Step 4 curved patch areas. Require independent
     closure of both load categories. Because directional projection into each curved
     rib is not yet resolved, add the normal and tangential line-load magnitudes as a
     conservative envelope. Without patch shares, retain only a provisional peak
     envelope and block acceptance. No AWG, current capability or electrical topology
     is selected here. *)
  interNodeRibScreen=Which[
    interNodeRibInput===Automatic,Missing["Step7InterNodeRunAndConductorRecordRequired"],
    AssociationQ[interNodeRibInput],phase1Step5InterNodeRibScreenCurrent[interNodeRibInput,
      peakPressure,maximumPatchTangentialTraction,ribSagFraction,ribExtensionFraction,safetyFactor,<|
        "PatchIndices"->patchIndices,"PatchPressureSamples_Pa"->pressureSamples,
        "PatchTangentialTractionSamples_Pa"->patchTangentialTractions,
        "PatchAreaWeights_m2"->patchAreaWeights,"PatchNormals"->patchNormals,
        "AreaShareClosureTolerance"->patchAreaTolerance|>],
    True,Failure["Step5InterNodeRibRecordMustBeAssociation",<|"SuppliedValue"->interNodeRibInput|>]];
  If[FailureQ[interNodeRibScreen],Return[interNodeRibScreen]];
  interNodeRibMass=If[AssociationQ[interNodeRibScreen],interNodeRibScreen["TotalInterNodeRibMass_kg"],0.];
  interNodeRibBlockers=Join[
    If[MissingQ[interNodeRibScreen],
      {"Step 7 must supply per-run conductor/routing records and a separate unique AnchorRecords register with capacity, mass and qualification evidence."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllRunTensileAndAxialRigidityScreensPass"]],
      {"One or more supplied inter-node conductor runs fail tensile capacity or axial rigidity/extension screening."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllRunsRemainTautAcrossOperatingCases"]],
      {"Each inter-node tension-only structural rib must supply a positive minimum cable tension across the complete same-pole operating load envelope and a non-empty tautness evidence reference; the cable model does not infer this from the peak normal-pressure case."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllRunsHaveOperatingHorizontalTensionEvidence"]],
      {"Each inter-node rib must supply a finite positive minimum horizontal cable tension across the complete same-pole operating envelope, HorizontalTensionEvidencePassed=True and a non-empty HorizontalTensionEvidenceReference. The source does not derive this evidence from the Step 4 trajectory."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllRunsHaveCompleteCombinedLineLoadEvidence"]],
      {"Each inter-node rib must supply a finite nonnegative maximum effective transverse acceleration across the complete same-pole operating envelope, TransverseAccelerationEvidencePassed=True and a non-empty TransverseAccelerationEvidenceReference. The source derives physical conductor-plus-insulation mass per length, adds its transverse inertial/self-mass line load to the surface-load envelope, and blocks the run if this evidence is missing."},{}],
    If[AssociationQ[interNodeRibScreen]&&TrueQ[interNodeRibScreen["AnyRunOperatingSagLimitExceeded"]],
      {"One or more derived combined-load small-sag operating-sag upper bounds q_total L^2/(8 H_min) exceed the configured per-run sag limit."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllConductorLoadSharingEvidenceRequirementsSatisfied"]],
      {"One or more inter-node runs request credit for multiple load-bearing conductors without satisfying the per-run load-sharing evidence requirement. The source credits only one strand for mechanical capacity and axial rigidity until that evidence is supplied."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllAnchorCapacityScreensPass"]],
      {"One or more shared physical anchors fail the aggregate capacity check after summing all connected rib-end demand magnitudes."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllAnchorQualificationFlagsPassed"]],
      {"One or more shared physical anchors lack an explicit passing qualification flag and non-empty evidence reference; numerical capacity alone is not hardware qualification."},{}],
    If[AssociationQ[interNodeRibScreen]&&(!TrueQ[interNodeRibScreen["Step4PatchAreaShareIntegrationPass"]]||
        !TrueQ[interNodeRibScreen["Step4PatchAreaShareCoveragePass"]]||
        !TrueQ[interNodeRibScreen["Step4PatchToRunNormalLoadConservationPass"]]),
      {"Inter-node structural runs must provide TributaryPatchShares mapping every Step 4 patch to the rib set with per-patch share closure and total normal-load conservation; the peak-envelope fallback remains provisional."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["Step4PatchToRunTangentialLoadConservationPass"]],
      {"The same tributary patch-area shares must also integrate and conserve Step 4 patchwise tangential-traction magnitudes across the complete inter-node rib set."},{}],
    If[AssociationQ[interNodeRibScreen]&&!TrueQ[interNodeRibScreen["AllTributaryGeometryMappingEvidencePassed"]],
      {"Each inter-node run must provide TributaryGeometryMappingEvidencePassed=True and a non-empty TributaryGeometryEvidenceReference demonstrating that its tributary patch-area shares correspond to the physical rib and support geometry; this source calculation does not derive or independently qualify that geometry."},{}]];
  totalKnownStructureMass=aluminumMass+curvedArea selectedFilmMass+connectorMass+interNodeRibMass;
  (* Keep the partial subtotal numerically trustworthy. Unknown connector/run records
     are represented separately as Missing in the component ledger; they are not silently
     estimated or treated as zero-mass qualified hardware. This guard covers overflow and
     invalid arithmetic across the known aluminium, selected-film, connector and rib terms. *)
  If[!And@@(phase1FiniteRealNumberQ/@{aluminumMass,curvedArea,selectedFilmMass,
        connectorMass,interNodeRibMass,totalKnownStructureMass})||
      !TrueQ[aluminumMass>0.&&curvedArea>0.&&selectedFilmMass>=0.&&
        connectorMass>=0.&&interNodeRibMass>=0.&&totalKnownStructureMass>0.],
    Return[Failure["Step5KnownStructuralMassSubtotalInvalid",<|"Pole"->$Phase1CurrentPole,
      "AluminumFoilMass_kg"->aluminumMass,"CurvedArea_m2"->curvedArea,
      "SelectedFilmArealMass_kg_m2"->selectedFilmMass,
      "IntraNodeConnectorMass_kg"->connectorMass,"InterNodeRibMass_kg"->interNodeRibMass,
      "KnownStructuralMassSubtotal_kg"->totalKnownStructureMass|>]]
  ];
  step4ScopeComplete=TrueQ[Lookup[step4Assessment,"Step4ScopeComplete",False]];
  result=<|"Pole"->$Phase1CurrentPole,"Step"->5,
    "StepName"->"Complete the Material, Membrane, and Structural Architecture",
    "SourceRevision"->$Phase1ModelVersion,
    "Status"->"Preliminary Step 5 structural architecture; Step 4 has been resumed and must be completed and accepted before Step 5 acceptance. Step 7 electrical routing is not yet integrated.",
    "Step4ScopeChecksReportedComplete"->step4ScopeComplete,
    "Step4AcceptedByCurrentRoadmap"->False,
    "Step4MustBeResumedAndAcceptedBeforeStep5Acceptance"->True,
    "PeakStep4PatchNormalEnvironmentalPressure_Pa"->peakPressure,
    "MaximumStep4PatchTangentialTraction_Pa"->maximumPatchTangentialTraction,
    "Step4DistributedGravityIncludedInStructuralScreen"->gravityIncluded,
    "Step4PerimeterAndStationGravityTransferToMembranePassed"->attachmentGravityTransferred,
    "Step4GravityTractionArraysAlignedAndFinite"->True,
    "AluminumPanelSizing"-><|
      "PanelModel"->"Simply supported one-way unit-width strip between adjacent structural inter-node wiring runs. The global sizing envelope uses maximum Step 4 patch-normal pressure and maximum patch tangential traction (which may occur at different patches), while the patchwise screens use each patch's co-located normal pressure and tangential traction. Same-pole in-plane membrane pretension is coupled into direct tensile stress and transverse strip deflection.",
      "CurrentAluminumBaselineThickness_m"->baseThickness,
      "AllowableAluminumStress_Pa"->allowableStress,
      "MaximumStep4PatchTangentialTraction_Pa"->maximumPatchTangentialTraction,
      "EffectiveNormalStressAllowableAfterShear_Pa"->effectiveNormalStressAllowable,
      "PanelStressInteractionModel"->"Reduced-order plane-stress von Mises screening surrogate. The full magnitude of same-patch Step 4 tangential surface traction is assigned to one scalar shear component and combined with strip-normal pretension/bending stress: Sqrt[sigmaNormal^2 + 3*tau^2]. This is not a resolved in-plane stress tensor or membrane-network solution.",
      "TangentialTractionMappedToScalarShearSurrogate"->True,
      "DirectionalInPlaneStressTensorResolved"->False,
      "MembranePretension_N_per_m"->membranePretension,
      "BaselineFoilPretensionStress_Pa"->baselinePretensionStress,
      "RemainingBaselineBendingStressBudget_Pa"->baselineBendingStressBudget,
      "RemainingBaselineNormalStressBudgetAfterShearAndPretension_Pa"->baselineBendingStressBudget,
      "BaselineFoilStressBudgetAllowsBendingPass"->TrueQ[baselineBendingStressBudget>0.],
      "GlobalPressureShearEnvelopeMayCombineIndependentPatchExtrema"->True,
      "GlobalPressureShearEnvelopeInterpretation"->"The global thickness/spacing screen combines the largest patch normal pressure with the largest patch tangential traction, even when those maxima occur on different patches; this is intentionally conservative. Patchwise screens retain co-located pressure and shear.",
      "StressLimitedSpacingInterpretation"->If[baselineBendingStressBudget>0.,
        "Maximum span is limited by the baseline foil's shear-reduced normal stress allowance after subtracting initial pretension stress.",
        "The combination of baseline pretension and the maximum tangential-traction shear interaction consumes/exceeds the allowable stress; the span is provisionally bounded by deflection and planform while the coupled normal-stress equation derives a thicker foil."],
      "MaximumPanelDeflectionFractionOfRibSpacing"->panelDeflectionFraction,
      "MaximumRibSpacingByStress_m"->If[baselineBendingStressBudget>0.,maxSpacingByStress,
        Missing["BaselinePretensionConsumesAllowableStressBudget;ThicknessIncreaseRequired"]],
      "EffectiveStressSpacingCapUsedForAutomaticSelection_m"->maxSpacingByStress,
      "MaximumRibSpacingByDeflection_m"->maxSpacingByDeflection,
      "MaximumRibSpacingByDeflectionSearch"->maxSpacingByDeflectionRecord,
      "MaximumAllowableElectricalRunSpacing_m"->maxSpacing,
      "SelectedCandidateRibSpacing_m"->selectedSpacing,
      "SelectedSpacingIsDerivedMaximumNotFinalElectricalRouting"->spacingDerived,
      "ActualRunSpacingMustBeConfirmedInStep7"->True,
      "PanelDeflectionLimit_m"->panelDeflectionLimit,
      "RequiredThicknessByStress_m"->requiredThicknessByStress,
      "RequiredThicknessByStressIncludesMembranePretension"->True,
      "RequiredThicknessByStressIncludesTangentialTractionInteraction"->True,
      "PatchwiseStressUsesCoLocatedPressureAndTangentialTraction"->True,
      "RequiredThicknessByDeflection_m"->requiredThicknessByDeflection,
      "RequiredThicknessByDeflectionSearch"->requiredThicknessByDeflectionRecord,
      "DeflectionThicknessBoundIncludesMembranePretension"->True,
      "DeflectionThicknessSolver"->"Monotone bisection on the coupled tension-plus-bending midspan deflection; the bending-only expression is used only as a conservative upper bracket, not as the selected required thickness.",
      "DeflectionSpanSolver"->"Monotone bisection on the coupled tension-plus-bending deflection fraction, bounded by the planform diameter.",
      "PretensionStressAtSelectedThickness_Pa"->membranePretension/selectedThickness,
      "CombinedPretensionAndBendingStressAtSelectedThickness_Pa"->actualPanelStress,
      "MembranePretensionIncludedInPanelDeflectionModel"->True,
      "MinimumThicknessRequiredAtSelectedSpacing_m"->minimumThickness,
      "SelectedMinimumAluminumThickness_m"->selectedThickness,
      "AluminumDensity_kg_m3"->aluminumDensity,
      "AluminumYoungsModulus_Pa"->aluminumModulus,
      "BaselineFoilArealMass_kg_m2"->baselineFoilArealMass,
      "SelectedFoilArealMass_kg_m2"->foilArealMass,
      "FoilArealMassIncreaseRatio"->foilArealMassRatio,
      "SelectedFoilMembraneExtensionalStiffness_N_per_m"->foilMembraneExtensionalStiffness,
      "BaselineFoilFlexuralRigidity_NmPerUnitWidth"->baselineFoilFlexuralRigidity,
      "SelectedFoilFlexuralRigidity_NmPerUnitWidth"->foilFlexuralRigidity,
      "FoilFlexuralRigidityIncreaseRatio"->foilFlexuralRigidityRatio,
      "FlexuralRigidityModel"->"E*t^3/12 per unit width for the one-way simply supported beam-strip screen; this is the same rigidity used by the reported panel-deflection relation, not a two-way plate/shell constitutive model.",
      "CalculatedPanelStress_Pa"->actualPanelStress,
      "CalculatedPanelVonMisesEquivalentStress_Pa"->actualPanelEquivalentStress,
      "CalculatedPanelVonMisesStressSurrogate_Pa"->actualPanelEquivalentStress,
      "CalculatedPanelDeflection_m"->actualPanelDeflection,
      "MaximumPatchwisePanelDeflection_m"->maximumPatchwisePanelDeflection,
      "ConservativeMaximumPanelDeflectionEnvelope_m"->maximumPanelDeflectionEnvelope,
      "MaximumAllowedRibSagUsedForCombinedEnvelope_m"->ribSagFraction runSpan,
      "CombinedFoilBayAndRibSupportDeflectionEnvelope_m"->maximumCombinedDeflectionEnvelope,
      "CombinedDeflectionLimit_m"->maximumCombinedDeflectionLimit,
      "CombinedDeflectionLimitFractionOfPlanformRadius"->deflectionLimitFraction,
      "CombinedDeflectionScreenPass"->combinedDeflectionPass,
      "CombinedDeflectionEnvelopeRule"->"Conservative scalar sum of the maximum global/co-located patchwise foil-bay deflection and the maximum allowed rib sag. Compare with MaximumDeflectionFractionOfRadius*PlanformRadius. Directional cancellation is not credited; this is not a coupled nonlinear membrane/cable solution.",
      "AluminumThicknessIncreaseOnlyWhenStructurallyRequired_m"->Max[0.,selectedThickness-baseThickness],
      "SpacingRequirementPass"->spacingPass,
      "CandidateSpacingExceedsCurrentFoilBaselineLimit"->TrueQ[selectedSpacing>maxSpacing (1.+Sqrt[$MachineEpsilon])],
      "PatchwisePressureAndPanelScreen"-><|
        "PatchCount"->Length[patchwiseScreen],"MeshAndPressurePatchCountsAlign"->True,
        "TangentialTractionAndGravityArraysAlign"->True,
        "QuadratureCurvedArea_m2"->Total[patchAreaWeights],"AnalyticCurvedArea_m2"->curvedArea,
        "RelativePatchAreaClosureError"->patchAreaClosureError,
        "MeshAreaRelativeTolerance"->patchAreaTolerance,
        "CommonCandidateRibSpacingAppliedToEachPatch_m"->selectedSpacing,
        "UniformTrialGridAssumption"->True,
        "ActualRibGridAndSupportBayMappingStillRequiredFromStep7"->True,
        "AllPatchScreensPass"->patchwisePass,"PatchResults"->patchwiseScreen|>,
      "MembranePretensionCredited"->True,
      "MembranePretensionModel"->"The supplied uniform shared design assumption MembranePretension_N_m contributes direct tensile stress T/t and enters the tension-plus-bending simply supported strip deflection solution. Its installed value remains a synthetic/unqualified input until deployment and measurement evidence are available.",
      "TangentialTractionStressInteractionCredited"->True,
      "TangentialTractionStressModel"->"Each Step 4 patch tangential surface-traction magnitude is assigned in full to one scalar shear component and combined with its co-located strip-normal pretension/bending stress using a reduced-order plane-stress von Mises screening surrogate. The source does not resolve the in-plane stress tensor, traction direction relative to the rib grid, membrane load redistribution, or two-way shell action.",
      "Step4DistributedGravityLoadPathComplete"->TrueQ[gravityIncluded&&attachmentGravityTransferred],
      "TwoWayPlateAndShellActionCredited"->False,
      "WiringRibBendingStiffnessCredited"->False,
      "QualificationBoundary"->"One-way simply supported strip using uniform in-plane membrane pretension, transverse bending under local normal pressure, and local tangential surface traction assigned as a single scalar shear component in a reduced-order plane-stress von Mises screening surrogate. Patchwise values are co-located; the global envelope may combine separate patch extrema. The bending-only deflection thickness expression is used only as a search upper bound; the reported response uses the coupled tension-plus-bending strip solution. This reduced-order screen does not resolve the in-plane stress tensor, traction direction relative to ribs, two-way plate/shell action, directional membrane-network load sharing, nonlinear membrane coupling, nonuniform pretension, imperfections, seams, thermal residual stress, deployment dynamics or thin-film manufacturing allowables; it is not FEA or structural qualification."|>,
    (* WHAT: Record which structural stability modes are actually screened and which
       remain open. WHY: A tensile/deflection pass is not a complete membrane stability
       assessment; a flexible conductor that carries load in tension must also remain
       taut over the operating envelope. HOW: Expose the current strip/anchor screens,
       require separate same-pole minimum cable-tautness and horizontal-tension evidence,
       calculate a small-sag operating displacement bound, and explicitly retain missing
       directional wrinkling/buckling and thermal-stability analyses as unresolved. *)
    "StructuralStabilityAssessment"-><|
      "FoilGlobalStressAndDeflectionScreenPass"->spacingPass,
      "FoilPatchwiseStressAndDeflectionScreenPass"->patchwisePass,
      "InterNodeRibTensileAndAxialRigidityScreenAvailable"->AssociationQ[interNodeRibScreen],
      "InterNodeRibTensileAndAxialRigidityScreenPass"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunTensileAndAxialRigidityScreensPass"]],Missing["Step7RunAndConductorRecordsRequired"]],
      "InterNodeRibTautnessAcrossOperatingCasesPass"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsRemainTautAcrossOperatingCases"]],Missing["Step4OperatingEnvelopeAndStep7RibRecordsRequired"]],
      "InterNodeRibOperatingHorizontalTensionEvidenceComplete"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsHaveOperatingHorizontalTensionEvidence"]],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "InterNodeRibOperatingSagWithinLimit"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsOperatingSagWithinLimit"]],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "InterNodeRibOperatingSagLimitPass"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsMeetOperatingSagLimit"]],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "MaximumOperatingRibSagUpperBound_m"->If[AssociationQ[interNodeRibScreen],
        interNodeRibScreen["MaximumOperatingSagUpperBound_m"],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "InterNodeConductorLoadSharingEvidenceRequirementSatisfied"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllConductorLoadSharingEvidenceRequirementsSatisfied"]],Missing["Step7ConductorBundleAndLoadSharingEvidenceRequired"]],
      "SharedAnchorCapacityScreenPass"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllAnchorCapacityScreensPass"]],Missing["Step7AnchorRegisterRequired"]],
      "InterNodeRibNormalAndTangentialLoadMappingConservationPass"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["NormalAndTangentialTributaryLoadConservationPass"]],
        Missing["Step7RibRecordsAndStep4PatchTractionDataRequired"]],
      "CompressiveFoilWrinklingOrBuckling"->Missing["DirectionalInPlaneStressResultantsAndSupportBoundaryConditionsRequired"],
      "TwoWayPlateOrShellInstability"->Missing["TwoWayStructuralModelAndFinalSupportBayGeometryRequired"],
      "ThermalResidualStressAndThermalStability"->Missing["Step6TemperatureAndThermalGradientCouplingRequired"],
      "DirectionalInPlaneStressTensorResolved"->False,
      "FinalStructuralStabilityEstablished"->False,
      "UnresolvedStabilityItems"->{"Compressive wrinkling/buckling under directionally resolved in-plane resultants.",
        "Two-way plate/shell instability with final support-bay geometry.",
        "Cable slack/reverse-load stability unless minimum tautness, horizontal-tension and effective transverse-acceleration evidence are supplied for every same-pole inter-node run, with cable self-mass/inertial loading included and derived operating sag within its limit.",
        "Temperature-dependent residual stress and thermal stability coupling in Step 6."}|>,
    "TwoTierWiringStructuralInterface"-><|
      "IntraNodeConnections"->"Low-mass cell tabs/solder or equivalent local connectors join cells within a node. Their local tab tension, nominal overlap shear/peel, elastic extension and mass can be screened from an explicit same-pole record; detailed cell topology, current paths, resistance, I2R heating and final connector construction remain Step 7 work.",
      "IntraNodeConnectorScreen"->connectorScreen,
      "InterNodeBusRuns"->"Inter-node electrical bus runs form the candidate structural rib grid. Their spacing, unsupported span, line tension, EA, end-anchor demand and mass must satisfy this Step 5 interface and be reconciled with Step 7 electrical sizing.",
      "SharedPhysicalAnchors"->"A separate unique AnchorRecords register defines each physical support anchor once. All connected rib-end factored demand magnitudes are summed conservatively at each shared anchor, and anchor hardware mass is counted once.",
      "ElectricalSizingDeferredToStep7"->True,
      "InterNodeBusRunsMustMeetStructuralRibRequirements"->True|>,
    "StructuralWiringRibInterface"-><|
      "RibModel"->"Tensioned inter-node conductor cable surrogate under distributed tributary pressure load.",
      "TributaryWidth_m"->selectedSpacing,
      "RibRunUnsupportedSpan_m"->runSpan,
      "RunSpanDefaultBasis"->If[ribRunSpanArgument===Automatic,
        "Full planform diameter used as a provisional upper-bound unsupported run between anchors; replace with actual node/station support spacing when Step 7 routing is defined.",
        "Source-supplied candidate unsupported span; confirm against final Step 7 run/support geometry."],
      "DistributedRibLineLoad_N_per_m"->ribLineLoad,
      "NormalPressureContributionToGlobalRibLineLoad_N_per_m"->peakPressure selectedSpacing,
      "TangentialTractionMagnitudeContributionToGlobalRibLineLoad_N_per_m"->maximumPatchTangentialTraction selectedSpacing,
      "GlobalRibLineLoadUsesConservativeNormalPlusTangentialMagnitudeEnvelope"->True,
      "GlobalRibLineLoadExcludesCableSelfMassUntilPerRunMassAndAccelerationEvidenceIsProvided"->True,
      "AllRunsHaveCompleteCombinedLineLoadEvidence"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsHaveCompleteCombinedLineLoadEvidence"]],Missing["Step7PerRunMassAndStep4OperatingAccelerationEvidenceRequired"]],
      "CombinedCableSelfMassAndInertialLineLoadPerRun"->If[AssociationQ[interNodeRibScreen],
        Lookup[interNodeRibScreen["RunResults"],"CableSelfMassAndInertialTransverseLineLoad_N_per_m",{}],Missing["Step7PerRunMassAndStep4OperatingAccelerationEvidenceRequired"]],
      "PerRunNormalAndTangentialTributaryLoadIntegration"->If[AssociationQ[interNodeRibScreen],
        <|"Method"->"Normal and tangential magnitudes integrated over common patch-area shares; their line-load magnitudes are summed conservatively because rib-local traction projections are unresolved.",
          "AllNormalAndTangentialLoadConservationPass"->TrueQ[interNodeRibScreen["NormalAndTangentialTributaryLoadConservationPass"]],
          "RunResults"->interNodeRibScreen["RunResults"]|>,Missing["Step7InterNodeRunRecordsRequired"]],
      "MaximumRibSag_m"->sagLimit,
      "MaximumOperatingRibSagUpperBound_m"->If[AssociationQ[interNodeRibScreen],
        interNodeRibScreen["MaximumOperatingSagUpperBound_m"],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "OperatingHorizontalTensionEvidenceComplete"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsHaveOperatingHorizontalTensionEvidence"]],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "OperatingSagWithinLimit"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsOperatingSagWithinLimit"]],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "OperatingRibSagLimitPass"->If[AssociationQ[interNodeRibScreen],
        TrueQ[interNodeRibScreen["AllRunsMeetOperatingSagLimit"]],Missing["Step4OperatingHorizontalTensionAndStep7RibRecordsRequired"]],
      "RequiredRibHorizontalTension_N"->ribHorizontalTension,
      "RequiredRibVerticalEndReaction_N"->ribVerticalReaction,
      "UnfactoredRibEndTension_N"->ribEndTension,
      "RequiredRibEndAnchorCapacity_N"->ribEndCapacity,
      "MaximumElasticExtensionFraction"->ribExtensionFraction,
      "RequiredAxialRigidityEA_N"->requiredEA,
      "ConductorCrossSectionAndMaterial"->Missing["Step7ElectricalConductorSizingRequired"],
      "ExactRunLengthAndTotalRibMass"->Missing["Step7ElectricalRunLayoutRequired"],
      "OptionalActualStep7RunEvaluation"->interNodeRibScreen,
      "Step7MustSatisfyStructuralRibRequirements"->True|>,
    "BacksideFilmComparison"->filmComparison,
    "ComponentMassLedger"-><|
      "CurvedCollectorArea_m2"->curvedArea,
      "AluminumFoilMass_kg"->aluminumMass,
      "AluminumFoilArealMass_kg_m2"->foilArealMass,
      "AluminumFoilMembraneExtensionalStiffness_N_per_m"->foilMembraneExtensionalStiffness,
      "AluminumFoilFlexuralRigidity_NmPerUnitWidth"->foilFlexuralRigidity,
      "SelectedBacksideFilmMass_kg"->curvedArea selectedFilmMass,
      "IntraNodeConnectorMass_kg"->If[AssociationQ[connectorScreen],connectorMass,Missing["Step7LocalConnectorGeometryAndMassRequired"]],
      "IntraNodeTabMass_kg"->If[AssociationQ[connectorScreen],connectorScreen["TabMaterialMass_kg"],Missing["Step7TabGeometryAndMaterialRequired"]],
      "IntraNodeSolderMass_kg"->If[AssociationQ[connectorScreen],connectorScreen["SolderMass_kg"],Missing["Step7SolderVolumeAndAlloyRequired"]],
      "InterNodeStructuralRibMass_kg"->If[AssociationQ[interNodeRibScreen],interNodeRibMass,Missing["Step7ExactRunLengthsConductorSectionsAndAnchorRegisterRequired"]],
      "InterNodeAnchorHardwareMass_kg"->If[AssociationQ[interNodeRibScreen],interNodeRibScreen["AnchorHardwareMass_kg"],Missing["Step7UniqueAnchorRecordsWithMassRequired"]],
      "InterNodeConductorMetalMass_kg"->If[AssociationQ[interNodeRibScreen],interNodeRibScreen["ConductorMetalMass_kg"],Missing["Step7ConductorSectionsAndRunLengthsRequired"]],
      "InterNodeInsulationMass_kg"->If[AssociationQ[interNodeRibScreen],interNodeRibScreen["InsulationMass_kg"],Missing["Step7InsulationAndRunLengthsRequired"]],
      "PerimeterAndStationMassAccounting"->"Continue to use the existing per-pole mass ledger; do not double-count perimeter hardware or station masses in this Step 5 partial subtotal.",
      "KnownStructuralMassSubtotal_kg"->totalKnownStructureMass,
      "KnownSubtotalIncludesOnlyAvailableValidatedComponents"->True,
      "MissingConnectorOrRunRecordsAreNotInferredAsZeroMassDesignChoices"->True,
      "CompleteStructuralMassLedger"->False,
      "MassLedgerCompletionDependency"->"Step 7 must supply exact connector and bus-run geometry/mass; Step 4 must be resumed and accepted with reconciled loading, mass distribution and ICARUS requirements."|>,
    "ProposedMutableInputUpdate"-><|"AluminumFoilThickness_m"->selectedThickness|>,
    "ActiveMassModelMutated"->False,
    "Step5AssessmentAccepted"->False,
    "Step5AcceptanceBlockers"->Join[{
      "Step 4 must be completed and accepted before Step 5 acceptance.",
      If[!gravityIncluded,"The supplied Step 4 structural screen does not confirm distributed gravity is included in the patch traction field; Step 5 stress results are provisional until the full gravity load is applied.",Nothing],
      If[!attachmentGravityTransferred,"The supplied Step 4 structural screen does not confirm a force/moment-conserving perimeter-hardware and ICARUS-station gravity transfer to the membrane patches.",Nothing],
      "Step 7 must provide actual conductor material, electrical cross-section, exact run spacing/length, support locations, connector topology and rib mass.",
      "Candidate foil thickness and rib demands must be reconciled with accepted Step 4 loads, mass properties, ICARUS station loads, moments and attitude response.",
      "Compressive foil wrinkling/buckling and two-way plate/shell stability are not established by the current scalar shear surrogate and one-way strip model; resolve the directional in-plane stress resultants and actual support boundaries before Step 5 acceptance.",
      "Patchwise panel results use a common trial grid spacing; final cell/node/run routing and support-bay geometry from Step 7 must replace that assumption before structural acceptance.",
      "Backside-film bonding-layer mass and bonded-interface qualification are unresolved; no film mass is included unless all selection gates pass.",
      If[!combinedDeflectionPass,"The conservative sum of foil-bay deflection and rib-support sag exceeds the existing global deflection allowance; revise panel span, rib span or support design before Step 5 acceptance.",Nothing]},Join[connectorBlockers,interNodeRibBlockers]],
    "PerPoleOnly"->True,"OtherPoleOperatingStateReadOrModified"->False,
    "NoCombinedMechanicalEquilibrium"->True,
    "ExecutionStatus"->"Source implementation and static review only; no Mathematica execution, tests or simulations performed."|>;
  phase1StoreResult["Step5StructuralArchitecture",result];
  stamp=DateString[{"Year","-","Month","-","Day"," ","Hour",":","Minute",":","Second"}];
  phase1Audit["Step5StructuralArchitectureProduced",<|"Pole"->$Phase1CurrentPole,
    "Step4ScopeChecksReportedComplete"->step4ScopeComplete,"Step4AcceptedByCurrentRoadmap"->False,
    "Step5AssessmentAccepted"->False,"Time"->stamp|>];
  result
];

(* WHAT: Confirm that the complete per-station force and moment histories remain
   aligned with the sampled rigid-body trajectory that generated them.
   WHY: ICARUS force/moment sizing must not accept profiles with missing samples,
   incorrect station counts, invalid peak indices, or peak vectors/times detached
   from the trajectory records.
   HOW: Check every sample row and three-vector, enforce common sample/station
   dimensions, then reconstruct each station's peak vector and timestamp from its
   recorded peak index. The helper is a deterministic data-integrity gate; it does
   not execute or validate the underlying differential equations. *)
phase1StationDemandProfileIntegrityQ[simulation_Association,stationCount_Integer] := Module[
  {times,forces,torques,forceIndices,torqueIndices,forceTimes,torqueTimes,
   forcePeaks,torquePeaks,n,finiteRealQ,vectorProfileQ,timeMatchQ,peakMatchesQ},
  times=Lookup[simulation,"SampleTimes_s",{}];
  forces=Lookup[simulation,"StationForceVectorsBySample_N",{}];
  torques=Lookup[simulation,"StationTorqueVectorsBySample_Nm",{}];
  forceIndices=Lookup[simulation,"PeakStationForceSampleIndices",{}];
  torqueIndices=Lookup[simulation,"PeakStationTorqueSampleIndices",{}];
  forceTimes=Lookup[simulation,"PeakStationForceTimes_s",{}];
  torqueTimes=Lookup[simulation,"PeakStationTorqueTimes_s",{}];
  forcePeaks=Lookup[simulation,"PeakStationForceVectors_N",{}];
  torquePeaks=Lookup[simulation,"PeakStationTorqueVectors_Nm",{}];
  n=Length[times];
  finiteRealQ[value_] := phase1FiniteRealNumberQ[value];
  If[stationCount<1||n<2||!VectorQ[times,finiteRealQ]||
      !TrueQ[And@@Thread[Rest[times]>Most[times]]],Return[False]];
  vectorProfileQ[profile_] := ListQ[profile]&&Length[profile]===n&&
    And@@(Length[#]===stationCount&/@profile)&&
    And@@(And@@(Function[v,VectorQ[v,finiteRealQ]&&Length[v]===3]/@#)&/@profile);
  If[!vectorProfileQ[forces]||!vectorProfileQ[torques]||
      !VectorQ[forceIndices,IntegerQ]||Length[forceIndices]=!=stationCount||
      !VectorQ[torqueIndices,IntegerQ]||Length[torqueIndices]=!=stationCount||
      !VectorQ[forceTimes,finiteRealQ]||Length[forceTimes]=!=stationCount||
      !VectorQ[torqueTimes,finiteRealQ]||Length[torqueTimes]=!=stationCount||
      !ListQ[forcePeaks]||Length[forcePeaks]=!=stationCount||
      !VectorQ[forcePeaks,Function[v,VectorQ[v,finiteRealQ]&&Length[v]===3]]||
      !ListQ[torquePeaks]||Length[torquePeaks]=!=stationCount||
      !VectorQ[torquePeaks,Function[v,VectorQ[v,finiteRealQ]&&Length[v]===3]],
    Return[False]
  ];
  timeMatchQ[reported_,index_] := IntegerQ[index]&&1<=index<=n&&
    Abs[reported-times[[index]]]<=10^-10 Max[1.,Abs[reported],Abs[times[[index]]]];
  peakMatchesQ[reported_,profile_,index_] := IntegerQ[index]&&1<=index<=n&&
    Norm[reported-profile[[index]]]<=10^-10 Max[1.,Norm[reported],Norm[profile[[index]]]];
  TrueQ[And@@Table[
    timeMatchQ[forceTimes[[j]],forceIndices[[j]]]&&
    timeMatchQ[torqueTimes[[j]],torqueIndices[[j]]]&&
    peakMatchesQ[forcePeaks[[j]],Table[forces[[i,j]],{i,n}],forceIndices[[j]]]&&
    peakMatchesQ[torquePeaks[[j]],Table[torques[[i,j]],{i,n}],torqueIndices[[j]]],
    {j,stationCount}]]
];

phase1LoadMap[in_Association,geo_Association,mesh_Association,dyn_Association,stationForces_List] := Module[
  {a,width,stations,patches,rawWeights,normalizedWeights,stationMaps,stationPatchForceArrays,
   distributedPatchForces,loads,totalForce,distributedForce,targetMoment,distributedMoment,
   forceResidual,momentResidual,forceReferenceScale,momentReferenceScale,
   perStationForceResiduals,perStationMomentResiduals,perStationForceScales,perStationMomentScales,
   perStationForcePasses,perStationMomentPasses,positions,centerOfMass},
  If[in["ICARUSLoadTransferModel"] =!= "GaussianMomentCorrected",
    Return[Failure["UnsupportedICARUSLoadTransferModel",<|"SelectedModel"->in["ICARUSLoadTransferModel"]|>]]];
  a=geo["PlanformEquivalentRadius_m"];
  width=in["MembraneLoadSpreadFractionOfRadius"] a;
  stations=dyn["StationPositionsLocal_m"];
  patches=mesh["Patches"];
  centerOfMass=dyn["CenterOfMassLocal_m"];
  (* Reject incompatible station/patch data before constructing normalized spatial
     weights. The allocation must contain one finite three-vector per configured
     station; each target patch must have a finite position and positive curved area;
     and the Gaussian footprint must have a finite, positive width. Without these
     guards an incomplete interface could otherwise propagate malformed values into
     the force/moment correction and appear as an ordinary numerical residual. *)
  If[!phase1FiniteRealNumberQ[width]||!TrueQ[width>0.]||
      !ListQ[stations]||stations==={}||Length[stations]=!=Length[stationForces]||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@stations)||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@stationForces)||
      !phase1FiniteRealVectorQ[centerOfMass,3]||
      !ListQ[patches]||patches==={}||
      !And@@(Function[patch,AssociationQ[patch]&&
        phase1FiniteRealVectorQ[Lookup[patch,"Position_m",{}],3]&&
        phase1FiniteRealNumberQ[Lookup[patch,"SurfaceAreaWeight_m2",Missing[]]]&&
        TrueQ[Lookup[patch,"SurfaceAreaWeight_m2",0.]>0.]]/@patches),
    Return[Failure["InvalidICARUSLoadMapInputs",<|
      "StationPositionCount"->If[ListQ[stations],Length[stations],Missing["NotAList"]],
      "StationForceCount"->If[ListQ[stationForces],Length[stationForces],Missing["NotAList"]],
      "PatchCount"->If[ListQ[patches],Length[patches],Missing["NotAList"]],
      "LoadSpreadWidth_m"->width|>]]
  ];
  positions=(#-centerOfMass& /@ Lookup[patches,"Position_m"]);
  rawWeights=Table[Module[{logWeights},
    logWeights=Table[-Norm[positions[[j,2;;3]]-stations[[i,2;;3]]]^2/(2. width^2)+
      Log[patches[[j]]["SurfaceAreaWeight_m2"]],{j,Length[patches]}];
    Exp[Clip[logWeights-Max[logWeights],{Log[$MinMachineNumber],0.}]]
  ],{i,Length[stations]}];
  normalizedWeights=Map[#/Total[#]&,rawWeights];
  stationMaps=Table[Module[
    {f=stationForces[[i]],w=normalizedWeights[[i]],rbar,baseForces,baseMoment,wantedMoment,
     deltaMoment,covariance,lambda,correction,correctedForces,actualForce,actualMoment},
    rbar=Total[MapThread[#1 #2&,{w,positions}]];
    baseForces=Map[# f&,w];
    baseMoment=Total[MapThread[Cross[#1,#2]&,{positions,baseForces}]];
    wantedMoment=Cross[stations[[i]],f];
    deltaMoment=wantedMoment-baseMoment;
    covariance=Total[MapThread[#1 (Norm[#2-rbar]^2 IdentityMatrix[3]-Outer[Times,#2-rbar,#2-rbar])&,{w,positions}]];
    lambda=PseudoInverse[covariance].deltaMoment;
    correction=MapThread[#1 Cross[lambda,#2-rbar]&,{w,positions}];
    correctedForces=baseForces+correction;
    actualForce=Total[correctedForces];
    actualMoment=Total[MapThread[Cross[#1,#2]&,{positions,correctedForces}]];
    <|"PatchForces_N"->correctedForces,"TargetForce_N"->f,"TargetMoment_Nm"->wantedMoment,
      "DistributedForce_N"->actualForce,"DistributedMoment_Nm"->actualMoment,
      "ForceResidual_N"->Norm[actualForce-f],"MomentResidual_Nm"->Norm[actualMoment-wantedMoment]|>
  ],{i,Length[stations]}];
  (* Aggregate the station-by-patch force tensor once. The former per-patch Table
     repeatedly rebuilt Lookup[stationMaps,"PatchForces_N"] for every patch, making
     this operation quadratic in patch count. The single tensor reduction below is
     algebraically identical and scales with the actual station-by-patch data size. *)
  stationPatchForceArrays=Lookup[stationMaps,"PatchForces_N"];
  distributedPatchForces=Total[stationPatchForceArrays];
  loads=MapThread[Function[{patch,localForce,stationWeights},
    Join[patch,<|"PositionCOM_m"->(patch["Position_m"]-centerOfMass),
      "StationLoadWeights"->stationWeights,
      "EstimatedLocalLoadVector_N"->localForce|>]],
    {patches,distributedPatchForces,Transpose[normalizedWeights]}];
  totalForce=Total[stationForces];
  distributedForce=Total[distributedPatchForces];
  targetMoment=Total[MapThread[Cross[#1,#2]&,{stations,stationForces}]];
  distributedMoment=Total[MapThread[Cross[#1,#2]&,{positions,distributedPatchForces}]];
  forceResidual=Norm[distributedForce-totalForce];
  momentResidual=Norm[distributedMoment-targetMoment];
  forceReferenceScale=Max[Sqrt[$MinMachineNumber],Norm[totalForce],Total[Norm/@stationForces]];
  momentReferenceScale=Max[Sqrt[$MinMachineNumber],Norm[targetMoment],
    Total[MapThread[Norm[Cross[#1,#2]]&,{stations,stationForces}]],Total[Norm/@stationForces] a];
  perStationForceResiduals=Lookup[stationMaps,"ForceResidual_N"];
  perStationMomentResiduals=Lookup[stationMaps,"MomentResidual_Nm"];
  perStationForceScales=Norm/@stationForces;
  perStationMomentScales=MapThread[Max[Sqrt[$MinMachineNumber],Norm[Cross[#1,#2]],Norm[#2] a]&,
    {stations,stationForces}];
  perStationForcePasses=MapThread[TrueQ[#1<=in["ICARUSLoadMapRelativeTolerance"] Max[Sqrt[$MinMachineNumber],#2]]&,
    {perStationForceResiduals,perStationForceScales}];
  perStationMomentPasses=MapThread[TrueQ[#1<=in["ICARUSLoadMapRelativeTolerance"] Max[Sqrt[$MinMachineNumber],#2]]&,
    {perStationMomentResiduals,perStationMomentScales}];
  <|"Patches"->loads,"StationForceTotal_N"->totalForce,
    "DistributedPatchForceTotal_N"->distributedForce,
    "StationMomentTotal_Nm"->targetMoment,"DistributedPatchMomentTotal_Nm"->distributedMoment,
    "ForceConservationResidual_N"->forceResidual,"MomentConservationResidual_Nm"->momentResidual,
    "PerStationForceResiduals_N"->perStationForceResiduals,
    "PerStationMomentResiduals_Nm"->perStationMomentResiduals,
    "PerStationForceConservationPasses"->perStationForcePasses,
    "PerStationMomentConservationPasses"->perStationMomentPasses,
    "AllIndividualStationTransfersConserved"->TrueQ[And@@perStationForcePasses&&And@@perStationMomentPasses],
    "PerStationPatchWeightSums"->(Total/@normalizedWeights),
    "ForceConservationPass"->TrueQ[forceResidual<=in["ICARUSLoadMapRelativeTolerance"] forceReferenceScale&&
      And@@perStationForcePasses],
    "MomentConservationPass"->TrueQ[momentResidual<=in["ICARUSLoadMapRelativeTolerance"] momentReferenceScale&&
      And@@perStationMomentPasses],
    "ForceAndMomentConservationPass"->TrueQ[
      forceResidual<=in["ICARUSLoadMapRelativeTolerance"] forceReferenceScale &&
      momentResidual<=in["ICARUSLoadMapRelativeTolerance"] momentReferenceScale &&
      And@@perStationForcePasses&&And@@perStationMomentPasses],
    "LoadTransferModel"->in["ICARUSLoadTransferModel"],
    "Model"->"For the explicitly selected GaussianMomentCorrected model, station and patch locations are both evaluated in the centre-of-mass frame. Log-shifted Gaussian weights prevent numerical underflow; each station's spatial load is normalized across all surface patches. A zero-net-force correction then preserves the station's exact resultant moment; global force and moment are independently checked. Conservation tolerances scale against the sum of the individual station resultants/moments, so pure torque commands with nearly zero net force are not falsely failed by cancellation roundoff. This is a reduced-order load-transfer surrogate, not a constitutive finite-element stress solution."|>
];


phase1RotationMatrix[qInput_List] := Module[{qv=Normalize[qInput],q0,q1,q2,q3},
  {q0,q1,q2,q3}=qv;
  {{1.-2. (q2^2+q3^2),2. (q1 q2-q0 q3),2. (q1 q3+q0 q2)},
   {2. (q1 q2+q0 q3),1.-2. (q1^2+q3^2),2. (q2 q3-q0 q1)},
   {2. (q1 q3-q0 q2),2. (q2 q3+q0 q1),1.-2. (q1^2+q2^2)}}
];

phase1RotateMeshToCOM[mesh_Association,center_List,q_List] := Module[{rot,patches},
  rot=phase1RotationMatrix[q];
  patches=Map[Function[p,Join[p,<|"Position_m"->rot.(p["Position_m"]-center),
    "Normal"->Normalize[rot.p["Normal"]]|>]],mesh["Patches"]];
  Join[mesh,<|"Patches"->patches,"ReferencePointLocal_m"->center,
    "AttitudeQuaternion"->Normalize[q],"FrameDescription"->"Patch positions are relative to centre of mass and rotated into the inertial frame."|>]
];

(* WHAT: Resolve solar gravity at each distributed mass point and sum the force
   and centre-of-mass moment for this pole.
   WHY: A single lumped gravity force cannot describe the gravity-gradient torque
   that enters the natural attitude and ICARUS load requirements.
   HOW: Rotate each body-fixed mass location by the current attitude, place it at
   the pole's heliocentric position, and evaluate the inverse-square attraction. *)
phase1GravityLoads[in_Association,dyn_Association,heliocentricCenter_List,q_List] := Module[
  {rot,bodyPositions,masses,inertialPositions,forces,torques},
  rot=phase1RotationMatrix[q];
  bodyPositions=dyn["MassPointPositionsLocal_m"];
  masses=dyn["MassPointMasses_kg"];
  inertialPositions=Map[heliocentricCenter+rot.#&,bodyPositions];
  forces=MapThread[-in["SolarGravitationalParameter_m3_s2"] #1 #2/Norm[#2]^3&,{masses,inertialPositions}];
  torques=MapThread[Cross[rot.#1,#2]&,{bodyPositions,forces}];
  <|"MassPointIdentifiers"->dyn["MassPointIdentifiers"],
    "MassPointKinds"->dyn["MassPointKinds"],"MassPointCount"->dyn["MassPointCount"],
    "IndividualMassPointPositionsHeliocentric_m"->inertialPositions,
    "MassPointPositionsCOMInertial_m"->(Map[rot.#& ,bodyPositions]),
    "IndividualGravityForces_N"->forces,"IndividualGravityTorquesAboutCOM_Nm"->torques,
    "TotalGravityForce_N"->Total[forces],"TotalGravityTorqueInertial_Nm"->Total[torques],
    "GravityModel"->"Solar gravity is evaluated at every discretized sheet, perimeter-hardware and configured station mass point; the resulting net force and gravity-gradient torque are summed about the system centre of mass. Body-fixed attachment coordinates are also returned in the same inertial orientation as the force vectors so concentrated hardware loads can be transferred to the sheet without a frame mismatch."|>
];

(* WHAT: Distribute gravity forces acting on discrete perimeter-hardware and ICARUS
   station masses into the surrounding collector membrane patches.
   WHY: Their gravitational forces are already included in the pole's centre-of-mass
   force and gravity-gradient torque. The corresponding attachment reactions must also
   enter the local membrane load path; otherwise the global dynamics and local traction
   screen would describe different physical load paths.
   HOW: Use each attachment's COM-referenced position and its gravity force in one common
   inertial or body frame. A surface-area-weighted Gaussian footprint assigns the local
   load, then a moment correction preserves that point load's exact force and moment
   resultants about the centre of mass. The routine returns a patch-resolved reduced-order
   transfer map and explicit conservation residuals. It is not a joint, seam or FEA model. *)
phase1ConcentratedGravityLoadMap[in_Association,patches_List,attachmentPositions_List,
    attachmentForces_List,attachmentIdentifiers_List] := Module[
  {width,characteristicRadius,patchPositions,patchYZ,patchLogArea,normalizedWeights,
   attachmentMaps,attachmentPatchForceArrays,patchForces,forceTotal,distributedForce,
   momentTotal,distributedMoment,forceResidual,momentResidual,forceScale,momentScale,
   perAttachmentForceResiduals,perAttachmentMomentResiduals,perAttachmentForceScales,
   perAttachmentMomentScales,perAttachmentForcePasses,perAttachmentMomentPasses},
  If[Length[attachmentPositions]===0 ||
      Length[attachmentPositions]=!=Length[attachmentForces] ||
      Length[attachmentPositions]=!=Length[attachmentIdentifiers] || Length[patches]===0 ||
      !VectorQ[attachmentIdentifiers,StringQ] || !DuplicateFreeQ[attachmentIdentifiers] ||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@attachmentPositions) ||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@attachmentForces),
    Return[Failure["InvalidConcentratedGravityAttachmentInputs",<|
      "AttachmentPositionCount"->Length[attachmentPositions],
      "AttachmentForceCount"->Length[attachmentForces],
      "AttachmentIdentifierCount"->Length[attachmentIdentifiers],
      "PatchCount"->Length[patches]|>]]
  ];
  If[!And@@(Function[p,phase1FiniteRealVectorQ[Lookup[p,"Position_m",{}],3]&&
        phase1FiniteRealNumberQ[Lookup[p,"SurfaceAreaWeight_m2",Missing[]]]&&
        TrueQ[Lookup[p,"SurfaceAreaWeight_m2",0.]>0.]]/@patches),
    Return[Failure["InvalidConcentratedGravityTargetPatches",<|"PatchCount"->Length[patches]|>]]
  ];
  width=in["MembraneLoadSpreadFractionOfRadius"] Sqrt[in["PerPoleProjectedArea_m2"]/Pi];
  If[!phase1FiniteRealNumberQ[width]||!TrueQ[width>0.],
    Return[Failure["InvalidConcentratedGravityLoadSpreadWidth",<|
      "LoadSpreadFractionOfRadius"->Lookup[in,"MembraneLoadSpreadFractionOfRadius",Missing[]],
      "ProjectedArea_m2"->Lookup[in,"PerPoleProjectedArea_m2",Missing[]],
      "ComputedWidth_m"->width|>]]
  ];
  patchPositions=Lookup[patches,"Position_m"];
  patchYZ=patchPositions[[All,2;;3]];
  patchLogArea=Log[Lookup[patches,"SurfaceAreaWeight_m2"]];
  (* Evaluate each Gaussian footprint as vector arithmetic over the patch coordinate
     arrays. This avoids constructing an interpreted 1,280-element inner Table for
     every attachment. The normalized weights are the same area-weighted Gaussian
     distribution used by the v11.137 implementation. *)
  normalizedWeights=Map[Function[attachmentYZ,
    Module[{logWeights,scaledWeights},
      logWeights=-((patchYZ[[All,1]]-attachmentYZ[[1]])^2+
        (patchYZ[[All,2]]-attachmentYZ[[2]])^2)/(2. width^2)+patchLogArea;
      scaledWeights=Exp[Clip[logWeights-Max[logWeights],{Log[$MinMachineNumber],0.}]];
      scaledWeights/Total[scaledWeights]
    ]],attachmentPositions[[All,2;;3]]];
  (* For each attachment, compute the weighted patch centroid and the second-moment
     matrix Q = Sum_j w_j u_j u_j^T. The existing correction covariance is exactly
     Tr[Q] I - Q. This matrix form avoids a second interpreted pass over every patch
     for every covariance element while preserving the same moment-correction law. *)
  attachmentMaps=MapThread[Function[{attachmentPosition,attachmentForce,attachmentID,w},
    Module[{rbar,offsets,weightedOffsets,secondMoment,covariance,wantedMoment,
      baseMoment,deltaMoment,lambda,correction,correctedForces,actualForce,actualMoment},
      rbar=w.patchPositions;
      offsets=(#-rbar&)/@patchPositions;
      weightedOffsets=MapThread[Times,{w,offsets}];
      secondMoment=Transpose[offsets].weightedOffsets;
      covariance=Tr[secondMoment] IdentityMatrix[3]-secondMoment;
      wantedMoment=Cross[attachmentPosition,attachmentForce];
      baseMoment=Cross[rbar,attachmentForce];
      deltaMoment=wantedMoment-baseMoment;
      lambda=PseudoInverse[covariance].deltaMoment;
      correction=MapThread[#1 Cross[lambda,#2]&,{w,offsets}];
      correctedForces=MapThread[#1 attachmentForce+#2&,{w,correction}];
      actualForce=Total[correctedForces];
      actualMoment=Total[MapThread[Cross[#1,#2]&,{patchPositions,correctedForces}]];
      <|"AttachmentIdentifier"->attachmentID,
        "TargetForce_N"->attachmentForce,"TargetMomentAboutCOM_Nm"->wantedMoment,
        "DistributedForce_N"->actualForce,"DistributedMomentAboutCOM_Nm"->actualMoment,
        "PatchForces_N"->correctedForces,
        "ForceResidual_N"->Norm[actualForce-attachmentForce],
        "MomentResidual_Nm"->Norm[actualMoment-wantedMoment]|>
    ]],{attachmentPositions,attachmentForces,attachmentIdentifiers,normalizedWeights}];
  If[!And@@(AssociationQ/@attachmentMaps),
    Return[Failure["ConcentratedGravityAttachmentMapFailed",<|"AttachmentMapCount"->Length[attachmentMaps]|>]]
  ];
  (* Reduce the attachment-by-patch force tensor once. *)
  attachmentPatchForceArrays=Lookup[attachmentMaps,"PatchForces_N"];
  patchForces=Total[attachmentPatchForceArrays];
  forceTotal=Total[attachmentForces];distributedForce=Total[patchForces];
  momentTotal=Total[MapThread[Cross[#1,#2]&,{attachmentPositions,attachmentForces}]];
  distributedMoment=Total[MapThread[Cross[#1,#2]&,{patchPositions,patchForces}]];
  forceResidual=Norm[distributedForce-forceTotal];momentResidual=Norm[distributedMoment-momentTotal];
  forceScale=Max[Sqrt[$MinMachineNumber],Norm[forceTotal],Total[Norm/@attachmentForces]];
  momentScale=Max[Sqrt[$MinMachineNumber],Norm[momentTotal],
    Total[MapThread[Norm[Cross[#1,#2]]&,{attachmentPositions,attachmentForces}]],
    Total[Norm/@attachmentForces] Sqrt[in["PerPoleProjectedArea_m2"]/Pi]];
  perAttachmentForceResiduals=Lookup[attachmentMaps,"ForceResidual_N"];
  perAttachmentMomentResiduals=Lookup[attachmentMaps,"MomentResidual_Nm"];
  characteristicRadius=Sqrt[in["PerPoleProjectedArea_m2"]/Pi];
  perAttachmentForceScales=Norm/@attachmentForces;
  perAttachmentMomentScales=MapThread[Max[Sqrt[$MinMachineNumber],Norm[Cross[#1,#2]],Norm[#2] characteristicRadius]&,
    {attachmentPositions,attachmentForces}];
  perAttachmentForcePasses=MapThread[TrueQ[#1<=in["ICARUSLoadMapRelativeTolerance"] Max[Sqrt[$MinMachineNumber],#2]]&,
    {perAttachmentForceResiduals,perAttachmentForceScales}];
  perAttachmentMomentPasses=MapThread[TrueQ[#1<=in["ICARUSLoadMapRelativeTolerance"] Max[Sqrt[$MinMachineNumber],#2]]&,
    {perAttachmentMomentResiduals,perAttachmentMomentScales}];
  <|"PatchForces_N"->patchForces,"AttachmentMaps"->attachmentMaps,
    "AttachmentIdentifiers"->attachmentIdentifiers,
    "TargetForceTotal_N"->forceTotal,"DistributedPatchForceTotal_N"->distributedForce,
    "TargetMomentTotalAboutCOM_Nm"->momentTotal,"DistributedPatchMomentTotalAboutCOM_Nm"->distributedMoment,
    "ForceConservationResidual_N"->forceResidual,"MomentConservationResidual_Nm"->momentResidual,
    "PerAttachmentForceResiduals_N"->perAttachmentForceResiduals,
    "PerAttachmentMomentResiduals_Nm"->perAttachmentMomentResiduals,
    "PerAttachmentForceConservationPasses"->perAttachmentForcePasses,
    "PerAttachmentMomentConservationPasses"->perAttachmentMomentPasses,
    "AllIndividualAttachmentTransfersConserved"->TrueQ[And@@perAttachmentForcePasses&&And@@perAttachmentMomentPasses],
    "ForceConservationPass"->TrueQ[forceResidual<=in["ICARUSLoadMapRelativeTolerance"] forceScale&&
      And@@perAttachmentForcePasses],
    "MomentConservationPass"->TrueQ[momentResidual<=in["ICARUSLoadMapRelativeTolerance"] momentScale&&
      And@@perAttachmentMomentPasses],
    "ForceAndMomentConservationPass"->TrueQ[
      forceResidual<=in["ICARUSLoadMapRelativeTolerance"] forceScale&&
      momentResidual<=in["ICARUSLoadMapRelativeTolerance"] momentScale&&
      And@@perAttachmentForcePasses&&And@@perAttachmentMomentPasses],
    "FrameDescription"->"The supplied attachment coordinates, force vectors and target patch positions share one reference frame. The static structural call uses the initial-attitude COM-centred inertial frame; the time-sampled dynamic call uses the pole-local COM-centred body frame.",
    "Model"->"Surface-area-weighted Gaussian attachment footprints with per-attachment force and moment correction. Each attachment is transferred independently; the weighted covariance is evaluated as Tr[Q] I - Q from the patch-offset second moment. Individual and aggregate force and moment resultants are checked separately. The transfer is a reduced-order load map, not a joint, seam or finite-element model."|>
];


phase1SolarWindLoads[in_Association,patches_List,r_?NumericQ,radialDirection_List] := Module[
  {pressure,dir,forces,torques,totalForce,totalTorque,projectedArea},
  dir=Normalize[radialDirection];
  pressure=in["SolarWindProtonDensity_1AU_cm3"] in["CentimetersPerMeter"]^3 in["ProtonMass_kg"] in["SolarWindSpeed_1AU_m_s"]^2 (in["AstronomicalUnit_m"]/r)^2;
  forces=Map[Function[p,pressure Max[0.,p["Normal"].dir] p["SurfaceAreaWeight_m2"] dir],patches];
  torques=MapThread[Cross[#1,#2]&,{Lookup[patches,"Position_m"],forces}];
  totalForce=Total[forces];totalTorque=Total[torques];
  projectedArea=Total[Map[Max[0.,# ["Normal"].dir] # ["SurfaceAreaWeight_m2"]&,patches]];
  <|"DynamicPressure_Pa"->pressure,"ProjectedArea_m2"->projectedArea,
    "PatchForces_N"->forces,"PatchTorquesAboutCOM_Nm"->torques,
    "TotalForce_N"->totalForce,"TotalTorqueAboutCOM_Nm"->totalTorque,
    "Model"->"Proton ram pressure at local heliocentric distance, applied patchwise along the outward Sun-radial direction using local projected area. Magnetic-field, alpha-particle and anisotropic-flow terms are omitted."|>
];

(* WHAT: Combine patch-integrated radiation, distributed solar gravity and solar-wind
   ram pressure for one pole; calculate radial, transverse and torque residuals.
   WHY: The governing design objective is a positive radiation-only outward force
   margin with controlled transverse force and natural torque, not zero-net-force
   equilibrium. This margin quantifies future payload mass headroom.
   HOW: Radiation and gravity radial resultants are compared directly. The incremental
   added-mass capacity is the difference divided by local solar gravitational acceleration.
   Each independent pole must retain the configured fraction of its own current mass as
   additional payload headroom. The initial 10% target is a mutable screening assumption,
   not a downstream mass commitment. Solar-wind force is included in environmental loads
   but receives no mass-capacity credit. *)
phase1NaturalEquilibrium[in_Association,rad_Association,mass_Association,dyn_Association] := Module[
  {center,q,gravity,wind,netForce,netTorque,acc,forceResidual,torqueResidual,forcePass,torquePass,forceScale,characteristicRadius,accelerationTolerance,torqueTolerance,
   radialDirection,radiationRadialForce,gravityInwardRadialForce,windRadialForce,netRadialForce,radialForceRatio,transverseForce,
   transverseResidual,transversePass,outwardBiasPass,controlledForcePass,currentMass,gravityAcceleration,
   radiationEquivalentMass,gravityEquivalentMass,addedMassCapacitySigned,addedMassCapacity,futureMassTarget,futureMassGrowthPass},
  center={in["Distance_m"],0.,0.};q=dyn["InitialQuaternion"];
  radialDirection=Normalize[center];
  gravity=phase1GravityLoads[in,dyn,center,q];
  wind=phase1SolarWindLoads[in,rad["PatchLoads"],in["Distance_m"],radialDirection];
  radiationRadialForce=Dot[rad["NetRadiationForceVector_N"],radialDirection];
  gravityInwardRadialForce=Max[0.,-Dot[gravity["TotalGravityForce_N"],radialDirection]];
  windRadialForce=Dot[wind["TotalForce_N"],radialDirection];
  netForce=rad["NetRadiationForceVector_N"]+gravity["TotalGravityForce_N"]+wind["TotalForce_N"];
  netRadialForce=Dot[netForce,radialDirection];
  transverseForce=netForce-netRadialForce radialDirection;
  netTorque=rad["NetRadiationMoment_Nm"]+gravity["TotalGravityTorqueInertial_Nm"]+wind["TotalTorqueAboutCOM_Nm"];
  acc=netForce/mass["TotalMass_kg"];
  forceResidual=Norm[acc];torqueResidual=Norm[netTorque];
  forceScale=Max[Norm[rad["NetRadiationForceVector_N"]],Norm[gravity["TotalGravityForce_N"]],Norm[wind["TotalForce_N"]],mass["TotalMass_kg"] in["SolarGravitationalParameter_m3_s2"]/in["Distance_m"]^2,$MinMachineNumber];
  characteristicRadius=Sqrt[in["PerPoleProjectedArea_m2"]/Pi];
  accelerationTolerance=in["ExactEquilibriumRelativeTolerance"] forceScale/mass["TotalMass_kg"];
  torqueTolerance=in["ExactEquilibriumRelativeTolerance"] forceScale characteristicRadius;
  forcePass=TrueQ[forceResidual<=accelerationTolerance];
  transverseResidual=Norm[transverseForce]/mass["TotalMass_kg"];
  transversePass=TrueQ[transverseResidual<=accelerationTolerance];
  outwardBiasPass=TrueQ[radiationRadialForce>gravityInwardRadialForce&&netRadialForce>0.];
  controlledForcePass=TrueQ[outwardBiasPass&&transversePass];
  radialForceRatio=If[gravityInwardRadialForce>0.,radiationRadialForce/gravityInwardRadialForce,Missing["NoInwardGravityComponent"]];
  (* Future mass-growth capacity is calculated from radiation pressure alone. At this
     heliocentric distance, each added kilogram increases solar gravitational pull by
     gravityAcceleration newtons. The radiation force is held fixed for this threshold
     calculation; added payload is assumed not to change projected area, reflectivity,
     orientation or PV coverage. A negative signed capacity means the present design is
     already beyond the radiation-only mass threshold. Solar wind is deliberately excluded. *)
  currentMass=mass["TotalMass_kg"];
  gravityAcceleration=in["SolarGravitationalParameter_m3_s2"]/in["Distance_m"]^2;
  radiationEquivalentMass=radiationRadialForce/gravityAcceleration;
  gravityEquivalentMass=gravityInwardRadialForce/gravityAcceleration;
  (* The incremental capacity uses the actual distributed gravity resultant, not an
     assumed point-mass approximation for the existing collector. Future added payload
     is treated as a compact mass at the collector COM and therefore uses local g. *)
  addedMassCapacitySigned=(radiationRadialForce-gravityInwardRadialForce)/gravityAcceleration;
  addedMassCapacity=Max[0.,addedMassCapacitySigned];
  futureMassTarget=currentMass in["FutureAddedMassTargetFractionOfCurrentMass"];
  futureMassGrowthPass=TrueQ[addedMassCapacitySigned>=futureMassTarget];
  torquePass=TrueQ[torqueResidual<=torqueTolerance];
  <|"GravityLoads"->KeyDrop[gravity,{"IndividualMassPointPositionsHeliocentric_m","IndividualGravityForces_N","IndividualGravityTorquesAboutCOM_Nm"}],
    "DistributedGravityLoads"->gravity,
    "SolarWindLoads"->KeyDrop[wind,{"PatchForces_N","PatchTorquesAboutCOM_Nm"}],
    "NetNaturalForceVector_N"->netForce,"NetNaturalTorqueAboutCOM_Nm"->netTorque,
    "NetNaturalAccelerationVector_m_s2"->acc,"NaturalForceResidualMagnitude_m_s2"->forceResidual,
    "NaturalTorqueResidualMagnitude_Nm"->torqueResidual,
    "SunRadialUnitVector"->radialDirection,
    "RadiationOutwardRadialForce_N"->radiationRadialForce,
    "GravityInwardRadialForce_N"->gravityInwardRadialForce,
    "SolarWindRadialForce_N"->windRadialForce,
    "NetNaturalRadialForce_N"->netRadialForce,
    "NetNaturalTransverseForceVector_N"->transverseForce,
    "NetNaturalTransverseForceResidual_N"->Norm[transverseForce],
    "NetNaturalTransverseAccelerationResidual_m_s2"->transverseResidual,
    "RadiationToInwardGravityRadialForceRatio"->radialForceRatio,
    "CurrentPoleMass_kg"->currentMass,
    "SolarGravityAcceleration_m_s2"->gravityAcceleration,
    "RadiationEquivalentMassAtRadialBalance_kg"->radiationEquivalentMass,
    "CurrentGravityEquivalentMass_kg"->gravityEquivalentMass,
    "SignedFutureAddedMassCapacityBeforeRadialBalance_kg"->addedMassCapacitySigned,
    "FutureMassCapacityBeforeRadialBalance_kg"->addedMassCapacity,
    "MaximumFutureAddedMassCapacity_kg"->addedMassCapacity,
    "FutureMassTarget_kg"->futureMassTarget,
    "FutureMassTargetFractionOfCurrentMass"->in["FutureAddedMassTargetFractionOfCurrentMass"],
    "FutureAddedMassCapacityToCurrentMassRatio"->addedMassCapacitySigned/currentMass,
    "FutureMassTargetBasis"->"The pole must retain radiation-only added-mass capacity at least equal to the configured fraction of its own current modeled mass. The initial 10% fraction is a mutable screening target pending a downstream structural/payload mass budget; it is not a qualified safety factor or a shared two-pole mass allowance.",
    "FutureMassGrowthTargetPass"->futureMassGrowthPass,
    "FutureMassCapacityAssumptions"->"Radiation force and projected area are held fixed while added mass increases solar gravity linearly at the current heliocentric distance. Solar-wind ram pressure is excluded from the capacity credit.",
    "RadiationExceedsInwardGravityPass"->TrueQ[radiationRadialForce>gravityInwardRadialForce],
    "NetNaturalOutwardRadialForcePass"->TrueQ[netRadialForce>0.],
    "OutwardRadialBiasPass"->outwardBiasPass,
    "TransverseForceBalancePass"->transversePass,
    "ControlledOutwardForceEnvelopePass"->controlledForcePass,
    "OutwardRadialBiasObjective"->"Maintain strictly positive net Sun-radial outward force for future mass-growth capacity; retain separate transverse-force and natural-torque tolerances. This is intentionally not zero-net-vector-force equilibrium.",
    "NaturalForceScale_N"->forceScale,"CharacteristicRadius_m"->characteristicRadius,
    "DerivedNaturalAccelerationTolerance_m_s2"->accelerationTolerance,
    "DerivedNaturalTorqueTolerance_Nm"->torqueTolerance,
    "ExactVectorEquilibrium"->forcePass,"ExactTorqueEquilibrium"->torquePass,
    "ExactNaturalEquilibrium"->(forcePass&&torquePass),
    "ExactNaturalEquilibriumPerPoleAssembly"->(forcePass&&torquePass),
    "EquilibriumScope"->"One independently operated pole system; evaluated separately for Pole1 and Pole2. Exact zero-force is retained only as a diagnostic; the governing radial objective is positive outward surplus with controlled transverse load and torque.",
    "SyntheticAssumptionPolicy"->"Use a defensible mathematical approximation first; otherwise use an explicitly approved, slightly varied synthetic value, label it in the assumption register and code comments, and check upstream/downstream consistency. The default variation bound is 10% where a baseline exists.",
    "ICARUSRedesignPremise"->"The user approves modest mission-specific actuator reengineering as feasible. Current hardware ratings remain unknown; only a demand-derived conditional redesign target may be reported until the full actuator is specified and qualified.",
    "PoleOperatingStateIsIndependent"->True,
  "WholeTwoPoleSystemEquilibriumEvaluated"->False,
    "WholeSystemEquilibriumNotEvaluatedReason"->"The two pole systems are intentionally independent. No inter-pole force, torque, controller, operating-state or structural coupling is modelled or required. Each pole receives its own independent force/torque equilibrium assessment; only scalar outputs such as mass and power are summed for reporting.",
    "ForceEquilibriumModel"->"Distributed solar gravity plus attitude-dependent patch-integrated radiation and continuous solar-wind ram-pressure force at the supplied initial attitude.",
    "TorqueEquilibriumModel"->"Radiation-pressure torque, gravity-gradient torque and patch-resolved solar-wind ram-pressure torque; thermal recoil and elastic coupling remain outside this Phase 1 model.",
    "NaturalEquilibriumQualification"->If[controlledForcePass&&torquePass,
      "Controlled outward-force envelope passes: positive net Sun-radial surplus, transverse force residual within the derived tolerance, and natural torque residual within the derived tolerance. The radial surplus is retained for future added mass; no zero-net-force equilibrium is claimed.",
      "Controlled outward-force envelope does not pass: require positive net Sun-radial surplus, transverse force residual within the derived tolerance, and natural torque residual within the derived tolerance." ]|>
];

phase1MergeNaturalEquilibrium[mass_Association,nat_Association] := Join[mass,<|
  "NetNaturalForceVector_N"->nat["NetNaturalForceVector_N"],
  "NetNaturalTorqueAboutCOM_Nm"->nat["NetNaturalTorqueAboutCOM_Nm"],
  "NetNaturalAccelerationVector_m_s2"->nat["NetNaturalAccelerationVector_m_s2"],
  "NetRadialAcceleration_m_s2"->nat["NetNaturalAccelerationVector_m_s2"][[1]],
  "NaturalForceResidualMagnitude_m_s2"->nat["NaturalForceResidualMagnitude_m_s2"],
  "NaturalTorqueResidualMagnitude_Nm"->nat["NaturalTorqueResidualMagnitude_Nm"],
  "NaturalForceScale_N"->nat["NaturalForceScale_N"],"CharacteristicRadius_m"->nat["CharacteristicRadius_m"],
  "DerivedNaturalAccelerationTolerance_m_s2"->nat["DerivedNaturalAccelerationTolerance_m_s2"],
  "DerivedNaturalTorqueTolerance_Nm"->nat["DerivedNaturalTorqueTolerance_Nm"],
  "ExactVectorEquilibrium"->nat["ExactVectorEquilibrium"],
  "ExactTorqueEquilibrium"->nat["ExactTorqueEquilibrium"],
  "ExactNaturalEquilibrium"->nat["ExactNaturalEquilibrium"],
  "ExactNaturalEquilibriumPerPoleAssembly"->nat["ExactNaturalEquilibriumPerPoleAssembly"],
  "RadiationOutwardRadialForce_N"->nat["RadiationOutwardRadialForce_N"],
  "GravityInwardRadialForce_N"->nat["GravityInwardRadialForce_N"],
  "SolarWindRadialForce_N"->nat["SolarWindRadialForce_N"],
  "NetNaturalRadialForce_N"->nat["NetNaturalRadialForce_N"],
  "NetNaturalTransverseForceVector_N"->nat["NetNaturalTransverseForceVector_N"],
  "NetNaturalTransverseForceResidual_N"->nat["NetNaturalTransverseForceResidual_N"],
  "NetNaturalTransverseAccelerationResidual_m_s2"->nat["NetNaturalTransverseAccelerationResidual_m_s2"],
  "RadiationToInwardGravityRadialForceRatio"->nat["RadiationToInwardGravityRadialForceRatio"],
  "CurrentPoleMass_kg"->nat["CurrentPoleMass_kg"],
  "SolarGravityAcceleration_m_s2"->nat["SolarGravityAcceleration_m_s2"],
  "RadiationEquivalentMassAtRadialBalance_kg"->nat["RadiationEquivalentMassAtRadialBalance_kg"],
  "CurrentGravityEquivalentMass_kg"->nat["CurrentGravityEquivalentMass_kg"],
  "SignedFutureAddedMassCapacityBeforeRadialBalance_kg"->nat["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"],
  "FutureMassCapacityBeforeRadialBalance_kg"->nat["FutureMassCapacityBeforeRadialBalance_kg"],
  "MaximumFutureAddedMassCapacity_kg"->nat["MaximumFutureAddedMassCapacity_kg"],
  "FutureMassTarget_kg"->nat["FutureMassTarget_kg"],
  "FutureMassTargetFractionOfCurrentMass"->nat["FutureMassTargetFractionOfCurrentMass"],
  "FutureAddedMassCapacityToCurrentMassRatio"->nat["FutureAddedMassCapacityToCurrentMassRatio"],
  "FutureMassTargetBasis"->nat["FutureMassTargetBasis"],
  "FutureMassGrowthTargetPass"->nat["FutureMassGrowthTargetPass"],
  "FutureMassCapacityAssumptions"->nat["FutureMassCapacityAssumptions"],
  "RadiationExceedsInwardGravityPass"->nat["RadiationExceedsInwardGravityPass"],
  "NetNaturalOutwardRadialForcePass"->nat["NetNaturalOutwardRadialForcePass"],
  "OutwardRadialBiasPass"->nat["OutwardRadialBiasPass"],
  "TransverseForceBalancePass"->nat["TransverseForceBalancePass"],
  "ControlledOutwardForceEnvelopePass"->nat["ControlledOutwardForceEnvelopePass"],
  "OutwardRadialBiasObjective"->nat["OutwardRadialBiasObjective"],
  "EquilibriumScope"->nat["EquilibriumScope"],
  "WholeTwoPoleSystemEquilibriumEvaluated"->nat["WholeTwoPoleSystemEquilibriumEvaluated"],
  "WholeSystemEquilibriumNotEvaluatedReason"->nat["WholeSystemEquilibriumNotEvaluatedReason"],
  "NaturalEquilibriumQualification"->nat["NaturalEquilibriumQualification"]|>];


phase1NaturalCandidateAt[in_Association,geo_Association,mesh_Association,optics_Association,
    pvFraction_?NumericQ,distance_?NumericQ] := Module[
  {candidateInputs,rad0,mass0,dyn0,attitudeMesh,rad,mass,dyn,natural},
  candidateInputs=Join[in,<|"Distance_m"->distance,"PVFraction"->pvFraction|>];
  rad0=phase1Radiation[candidateInputs,geo,mesh,optics,pvFraction,distance,
    candidateInputs["IncidenceAngle_deg"]];
  mass0=phase1Mass[candidateInputs,geo,rad0,pvFraction,distance];
  dyn0=phase1DynamicsInitial[candidateInputs,geo,mass0,mesh];
  attitudeMesh=phase1RotateMeshToCOM[mesh,dyn0["CenterOfMassLocal_m"],dyn0["InitialQuaternion"]];
  rad=phase1Radiation[candidateInputs,geo,attitudeMesh,optics,pvFraction,distance,
    candidateInputs["IncidenceAngle_deg"],phase1SunVector[candidateInputs["IncidenceAngle_deg"]]];
  mass=phase1Mass[candidateInputs,geo,rad,pvFraction,distance];
  dyn=phase1DynamicsInitial[candidateInputs,geo,mass,mesh];
  natural=phase1NaturalEquilibrium[candidateInputs,rad,mass,dyn];
  <|"Inputs"->candidateInputs,"Radiation"->rad,"RawMass"->mass,
    "Mass"->phase1MergeNaturalEquilibrium[mass,natural],"Dynamics"->dyn,
    "AttitudeMesh"->attitudeMesh,"Natural"->natural|>
];

(* Independent bracketed bisection used by the joint optimizer. The standalone
   exact-equilibrium solver uses FindRoot/Brent on the same distributed-force
   residual, so the two root methods can be compared without duplicating physics. *)
phase1BracketedBisection[f_,{lo_?NumericQ,hi_?NumericQ},tol_?NumericQ,maxIter_Integer] := Module[
  {a=lo,b=hi,fa,fb,m,fm,k=0,width},
  If[!TrueQ[a<b] || !TrueQ[tol>0.] || !TrueQ[maxIter>0],Return[$Failed]];
  fa=f[a];fb=f[b];
  If[!NumericQ[fa] || !NumericQ[fb],Return[$Failed]];
  If[Abs[fa]<=tol,Return[a]];
  If[Abs[fb]<=tol,Return[b]];
  If[fa fb>0.,Return[$Failed]];
  While[k<maxIter,
    m=(a+b)/2;fm=f[m];
    If[!NumericQ[fm],Return[$Failed]];
    If[Abs[fm]<=tol,Return[m]];
    If[fa fm<0.,b=m;fb=fm,a=m;fa=fm];
    width=Abs[b-a];
    If[width<=tol Max[Sqrt[$MinMachineNumber],Abs[a],Abs[b]],
      m=(a+b)/2;fm=f[m];
      If[NumericQ[fm] && Abs[fm]<=tol,Return[m],Return[$Failed]]
    ];
    k++
  ];
  $Failed
];


phase1InputChecksPass[checks_Association] := Module[{metadata, booleanChecks},
  metadata = {"RequiredInputsPresent", "MissingRequiredInputKeys", "InputValidationEvaluationFailed"};
  booleanChecks = KeyDrop[checks, metadata];
  TrueQ[Lookup[checks, "RequiredInputsPresent", False]] &&
    Lookup[checks, "MissingRequiredInputKeys", {"MissingMetadata"}] === {} &&
    !TrueQ[Lookup[checks, "InputValidationEvaluationFailed", False]] &&
    And @@ (TrueQ /@ Values[booleanChecks])
];

phase1InputChecks[in_Association] := Module[{missing,checks},
  missing=Select[Keys[in],MissingQ[in[#]]&];
  If[missing =!= {},Return[<|"RequiredInputsPresent"->False,"MissingRequiredInputKeys"->missing|>]];
  checks=Quiet@Check[<|
    "PositivePhysicalConstants"->TrueQ[And@@(NumericQ[#]&&#>0.&/@{in["SolarLuminosity_W"],in["SolarGravitationalParameter_m3_s2"],in["UniversalGravitationalConstant_m3_kg_s2"],in["SolarIrradianceAt1AU_W_m2"],in["SpeedOfLight_m_s"],in["AstronomicalUnit_m"],in["StefanBoltzmann_W_m2_K4"]})],
    "PositiveDistance"->TrueQ[NumericQ[in["Distance_m"]]&&in["Distance_m"]>0.],
    "PositiveGeometryAndPoleInputs"->TrueQ[NumericQ[in["PerPoleProjectedArea_m2"]]&&in["PerPoleProjectedArea_m2"]>0.&&in["PoleCount"]===2&&IntegerQ[in["PoleCount"]]&&0.<in["CapDepthToPlanformRadius"]<1.&&NumericQ[in["IncidenceAngle_deg"]]&&-90.<in["IncidenceAngle_deg"]<90.],
    "ICARUSStationCountScopeSupported"->TrueQ[in["ICARUSStationCountScope"]==="PerPoleAssembly"],
    "CoverageWithinUnitInterval"->TrueQ[0.<=in["PVFraction"]<=1.],
    "OpticalFractionsPhysicallyValid"->TrueQ[0.<=in["ReflectorSolarReflectivity"]<=1.&&0.<=in["ReflectorSolarTransmissivity"]<=1.&&in["ReflectorSolarReflectivity"]+in["ReflectorSolarTransmissivity"]<=1.&&0.<=in["PVSolarReflectivity"]<=1.&&0.<=in["PVSolarTransmissivity"]<=1.&&in["PVSolarReflectivity"]+in["PVSolarTransmissivity"]<=1.],
    "MembraneSubstrateMaterialNamePresent"->TrueQ[StringQ[in["MembraneSubstrateMaterialName"]]&&StringTrim[in["MembraneSubstrateMaterialName"]]=!=""],
    "MembraneSubstrateMaterialClassSupported"->TrueQ[in["MembraneSubstrateMaterialClass"]==="AluminumFilm"],
    "AluminumBaseMaterialInputsValid"->TrueQ[And@@(NumericQ[#]&&#>0.&/@{in["AluminumFoilThickness_m"],in["AluminumDensity_kg_m3"],in["AluminumYoungsModulus_Pa"],in["AluminumPoissonRatio"],in["AluminumYieldStrength_Pa"],in["AluminumTensileStrength_Pa"],in["AluminumElectricalResistivity_Ohm_m"],in["CopperDensity_kg_m3"],in["CopperElectricalResistivity_Ohm_m"]})&&in["AluminumPoissonRatio"]<0.5],
    "ContinuousAluminumSubstratePolicy"->TrueQ[in["PVCellArrayMassPolicy"]===False],
    "MassInputsNonnegative"->TrueQ[And@@(NumericQ[#]&&#>=0.&/@{in["PVArealMass_kg_m2"],in["ReflectorArealMass_kg_m2"],in["WiringArealMass_kg_m2"],in["OtherInstalledArealMass_kg_m2"],in["ICARUSStationMass_kg"],in["DeferredEquipmentMass_kg"]})],
    "PVSpecificPowerReferenceIrradiancePositive"->TrueQ[NumericQ[in["PVSpecificPowerReferenceIrradiance_W_m2"]]&&in["PVSpecificPowerReferenceIrradiance_W_m2"]>0.],
    "PerimeterHardwareLinearMassValid"->TrueQ[NumericQ[in["PerimeterHardwareLinearMass_kg_m"]]&&in["PerimeterHardwareLinearMass_kg_m"]>=0.],
    "DeferredEquipmentMassExcludedFromPhase1MassDistribution"->TrueQ[in["DeferredEquipmentMass_kg"]==0.],
    "StationCountMatchesRegisteredStationPositions"->TrueQ[IntegerQ[in["ICARUSStationCount"]] && in["ICARUSStationCount"]>=1 &&
      ListQ[in["ICARUSStationPositionsLocal_m"]] && Length[in["ICARUSStationPositionsLocal_m"]]==in["ICARUSStationCount"] &&
      And@@(Function[p,Length[p]==3 && VectorQ[p,NumericQ]]/@in["ICARUSStationPositionsLocal_m"])],
    "StationCoordinatesWithinPlanform"->TrueQ[And@@(Function[p,Norm[p[[2;;3]]]<=Sqrt[in["PerPoleProjectedArea_m2"]/Pi] (1.+Sqrt[$MachineEpsilon])]/@in["ICARUSStationPositionsLocal_m"])],
    "MassDistributionInputsValid"->TrueQ[in["ICARUSStationMass_kg"]>=0.&&(in["ICARUSStationForceCapacity_N"]===Automatic||TrueQ[NumericQ[in["ICARUSStationForceCapacity_N"]]&&in["ICARUSStationForceCapacity_N"]>0.])&&0.<in["MembraneLoadSpreadFractionOfRadius"]<1.],
    "ICARUSRedesignAssumptionInputsValid"->TrueQ[MemberQ[{True,False},in["ICARUSRedesignFeasibilityApproved"]]&&NumericQ[in["ICARUSRedesignForceReserveFraction"]]&&0.<=in["ICARUSRedesignForceReserveFraction"]<Infinity],
    "ICARUSValidationInputsValid"->TrueQ[in["ICARUSLoadMapRelativeTolerance"]>0.],
    "DisturbanceInputsValid"->TrueQ[in["FlarePeakFraction"]>=0.&&in["FlarePeakTime_s"]>=0.&&in["FlareDuration_s"]>0.&&0.<in["FlareTailCutoffFraction"]<1.&&phase1FlareTimeBounds[in]["StartTime_s"]>=0.&&in["CMEOnset_s"]>=0.&&in["CMEWindPressureMultiplier"]>=1.&&in["CMEDuration_s"]>0.&&in["Year_s"]>0.&&in["ReferenceMissionYears"]>0.],
    "ControllerAndWobbleInputsValid"->TrueQ[And@@(#>=0.&/@{in["ControllerTranslationKp_perS2"],in["ControllerTranslationKd_perS"],in["ControllerAttitudeKp_perS2"],in["ControllerAttitudeKd_perS"],in["WobbleDampingRatio"]})],
    "PVScenarioOptionsValid"->TrueQ[Sort[in["PVScenarioOptions"]]===Sort[{"PVCellArraySpecificPowerLimited","PVCellReferenceEfficiency","ProjectSpecifiedTargetEfficiency"}]],
        "PVScenarioRecognized"->MemberQ[in["PVScenarioOptions"],in["PrimaryPVScenario"]],
    "PVLayoutModelSupported"->TrueQ[in["PVLayoutModel"]==="UniformSurfaceCoverage"],
    "GeometryProfileModelSupported"->TrueQ[in["GeometryProfileModel"]==="SphericalCapSurrogate"],
    "MassDistributionModelSupported"->TrueQ[in["MassDistributionModel"]==="UniformSheetMassWithPerimeterLineMassAndStationPointMasses"],
    "FutureAddedMassTargetFractionValid"->TrueQ[NumericQ[in["FutureAddedMassTargetFractionOfCurrentMass"]]&&
      0.<=in["FutureAddedMassTargetFractionOfCurrentMass"]<Infinity],
    "FlareTemporalProfileSupported"->TrueQ[in["FlareTemporalProfile"]==="GaussianFWHM"],
    "CMETemporalProfileSupported"->TrueQ[in["CMETemporalProfile"]==="RectangularPressureEnvelope"],
    "ICARUSLoadTransferModelSupported"->TrueQ[in["ICARUSLoadTransferModel"]==="GaussianMomentCorrected"],
    "MembraneStructuralModelSupported"->TrueQ[in["MembraneStructuralModel"]==="TensionedCircularMembrane"],
    "WobbleRestoringModelSupported"->TrueQ[in["WobbleRestoringModel"]==="NonlinearGravityGradientRigidBody"],
    "PVCellArrayMassPolicyValid"->TrueQ[in["PVCellArrayMassPolicy"]===False],
    "ReflectionModelSupported"->TrueQ[in["ReflectionModel"]==="Specular"],
    "ThermalAndStructuralInputsPositive"->TrueQ[And@@(#>0.&/@{in["PVIRemissivity"],in["ReflectorIRemissivity"],in["ReflectorTemperatureLimit_K"],in["PVTemperatureLimit_K"],in["AluminumDensity_kg_m3"],in["AluminumYoungsModulus_Pa"],in["AluminumTensileStrength_Pa"],in["StructuralSafetyFactor"],in["MaximumDeflectionFractionOfRadius"],in["MembranePretension_N_m"],in["CentimetersPerMeter"],in["CircularMembraneDeflectionCoefficient"],in["SEPDoseReference_protons_cm2"]})&&in["PVIRemissivity"]<=1.&&in["ReflectorIRemissivity"]<=1.&&in["MaximumDeflectionFractionOfRadius"]<1.],
    "Step5StructuralScreeningFractionsValid"->TrueQ[And@@(phase1FiniteRealNumberQ /@ {in["MaximumPanelDeflectionFractionOfRibSpacing"],in["MaximumStructuralRibSagFractionOfRunSpan"],in["MaximumStructuralRibElasticExtensionFraction"]})&&And@@(0.<#<1.& /@ {in["MaximumPanelDeflectionFractionOfRibSpacing"],in["MaximumStructuralRibSagFractionOfRunSpan"],in["MaximumStructuralRibElasticExtensionFraction"]})],
    "ThermalInputsValid"->TrueQ[MemberQ[{True,False},in["BothSidesRadiate"]]&&0.<in["PVIRemissivity"]<=1.&&0.<in["ReflectorIRemissivity"]<=1.&&in["PVTemperatureLimit_K"]>0.&&in["ReflectorTemperatureLimit_K"]>0.],
    "SolarWindInputsValid"->TrueQ[in["SolarWindProtonDensity_1AU_cm3"]>=0.&&in["SolarWindSpeed_1AU_m_s"]>=0.&&in["ProtonMass_kg"]>0.],
    "DegradationInputsValid"->TrueQ[0.<=in["PVAnnualDegradationFraction"]<1.&&0.<=in["ReflectivityAnnualLossFraction"]<1.&&0.<=in["PVDegradationPerSEPReferenceDoseFraction"]<1.&&in["SEPDose_protons_cm2"]>=0.],
    "EfficiencyAndElectricalInputsValid"->TrueQ[0.<=in["PVCellReferenceEfficiency"]<=1.&&0.<=in["PVCellArrayEfficiencyReference"]<=1.&&0.<=in["ProjectTargetEfficiency"]<=1.&&0.<in["TransferEfficiency"]<=1.&&0.<in["ConditioningEfficiency"]<=1.],
    "RecoveryCriteriaValid"->TrueQ[in["RecoveryTimeMaximum_s"]>0.&&in["VelocityRecoveryTolerance_m_s"]>0.&&in["AngularRateRecoveryTolerance_rad_s"]>0.&&in["DynamicCheckDuration_s"]>Max[phase1FlareTimeBounds[in]["EndTime_s"],in["CMEOnset_s"]+in["CMEDuration_s"]]+in["RecoveryTimeMaximum_s"]],
    "AcceptanceTolerancesValid"->TrueQ[And@@(#>0.&/@{in["ExactEquilibriumRelativeTolerance"],in["RadialDeviationToleranceFractionOfRadius"],in["LateralDeviationToleranceFractionOfRadius"],in["AttitudeTolerance_rad"],in["RecoveryTimeMaximum_s"],in["VelocityRecoveryTolerance_m_s"],in["AngularRateRecoveryTolerance_rad_s"],in["DynamicCheckDuration_s"],in["MeshCoefficientCrossCheckTolerance"],in["OptimizerGridCrossCheckRelativeTolerance"]})&&in["AttitudeTolerance_rad"]<Pi&&0.<=in["PVSearchRange"][[1]]<in["PVSearchRange"][[2]]<=1.],
    "ModelCoefficientInputsValid"->TrueQ[NumericQ[in["PVEfficiencyTemperatureCoefficient_perK"]]&&in["PVReferenceTemperature_K"]>0.],
    "DynamicAndMeshCountsValid"->TrueQ[And@@(IntegerQ[#]&&#>0&/@{in["MeshRadialCount"],in["MeshAzimuthCount"],in["OptimizerMeshRadialCount"],in["OptimizerMeshAzimuthCount"],in["DynamicSampleCount"],in["DynamicLoadPropagationSampleCount"]})&&IntegerQ[in["DynamicAccuracyGoal"]]&&in["DynamicAccuracyGoal"]>0&&IntegerQ[in["DynamicPrecisionGoal"]]&&in["DynamicPrecisionGoal"]>0&&(in["DynamicMaxSteps"]===Infinity||(IntegerQ[in["DynamicMaxSteps"]]&&in["DynamicMaxSteps"]>0))],
    "SearchBoundsValid"->TrueQ[VectorQ[in["DistanceSearchRange_m"],NumericQ]&&Length[in["DistanceSearchRange_m"]]==2&&in["DistanceSearchRange_m"][[1]]>0.&&in["DistanceSearchRange_m"][[2]]>in["DistanceSearchRange_m"][[1]]&&0.<=in["PVSearchRange"][[1]]<in["PVSearchRange"][[2]]<=1.],
    "VectorInitialConditionsValid"->TrueQ[And@@(Function[v,Length[v]==3&&VectorQ[v,NumericQ]]/@{in["InitialAngularVelocity_rad_s"],in["InitialAttitudeSmallAngles_rad"],in["InitialPositionLocal_m"],in["InitialVelocityLocal_m_s"],in["InitialVelocityHeliocentric_m_s"]})],
    "HeliocentricReferenceMotionModeSupported"->TrueQ[in["HeliocentricReferenceMotionMode"]==="StaticHover"],
    "HeliocentricStaticHoverVelocityValid"->TrueQ[in["HeliocentricReferenceMotionMode"]==="StaticHover"&&Norm[in["InitialVelocityHeliocentric_m_s"]]==0.],
    "NumericalSolverSettingsValid"->TrueQ[IntegerQ[in["OptimizerMaxIterations"]]&&in["OptimizerMaxIterations"]>0&&IntegerQ[in["PVThermalCouplingMaxIterations"]]&&in["PVThermalCouplingMaxIterations"]>0&&IntegerQ[in["OptimizerGridPointCount"]]&&in["OptimizerGridPointCount"]>=1&&
      IntegerQ[in["OptimizerCoverageGridPointCount"]]&&in["OptimizerCoverageGridPointCount"]>=1&&in["OptimizerGridCrossCheckRelativeTolerance"]>0.&&(in["NumericalWorkingPrecision"]===MachinePrecision||(NumericQ[in["NumericalWorkingPrecision"]]&&in["NumericalWorkingPrecision"]>=MachinePrecision))&&And@@(#>0.&/@{in["MeshAreaRelativeTolerance"],in["AccelerationCrossCheckRelativeTolerance"],in["SolarReferenceConsistencyRelativeTolerance"],in["ThermalResidualRelativeTolerance"],in["QuaternionNormalizationTolerance"],in["OpticalClosureTolerance"],in["PowerLedgerRelativeTolerance"],in["ICARUSLoadMapRelativeTolerance"]})]
  |>,False];
  If[!AssociationQ[checks],<|"RequiredInputsPresent"->True,"InputValidationEvaluationFailed"->True|>,
    Join[<|"RequiredInputsPresent"->True,"MissingRequiredInputKeys"->{}|>,checks]]
];

(* ========================================================================
   3. PUBLIC CALCULATION PIPELINE — dependency order and central storage
   ======================================================================== *)

phase1StoreRun[derived_Association,results_Association,dependencies_Association] := Module[{stamp,resolvedInputs},
  stamp=DateString[{"Year","-","Month","-","Day"," ","Hour",":","Minute",":","Second"}];
  resolvedInputs=Phase1GetInputs[];
  $Phase1State=Join[$Phase1State,<|"Derived"->derived,"Results"->results,
    "LastRun"-><|"Time"->stamp,"InputSnapshot"->resolvedInputs,
      "InputSnapshotHash"->Hash[resolvedInputs,"SHA256"],
      "CalculationManifest"->dependencies|>|>];
  phase1Audit["FullCalculationPipelineCompleted",<|"ResultNames"->Keys[results],"DerivedNames"->Keys[derived]|>];
  results
];

phase1ComputeCurrentPole[] := Module[
  {in,inputChecks,geo,mesh,optics,sun,illum,rad,mass,thermal,pv,power,missionEnd,structure,dyn,wrench,capacity,coupledPerformance,
   zeroWrench,allocation,loadmap,testAllocations,testLoadMaps,disturbance,checks,derived,results,manifest,
   meshAttitude,naturalEquilibrium},
  in=Phase1GetInputs[];
  inputChecks=phase1InputChecks[in];
  If[!phase1InputChecksPass[inputChecks],
    phase1Audit["InputValidationFailed",inputChecks];
    Return[Failure["InvalidPhase1Inputs",<|"Checks"->inputChecks|>]]
  ];
  geo=phase1Geometry[in];
  mesh=phase1Mesh[in,geo];
  optics=phase1Optics[in];
  sun=phase1SunVector[in["IncidenceAngle_deg"]];
  illum=phase1Illumination[mesh,sun];
  (* A first radiation/mass pass establishes sheet mass and centre of mass. *)
  rad=phase1Radiation[in,geo,mesh,optics,in["PVFraction"],in["Distance_m"],in["IncidenceAngle_deg"]];
  mass=phase1Mass[in,geo,rad,in["PVFraction"],in["Distance_m"]];
  dyn=phase1DynamicsInitial[in,geo,mass,mesh];
  (* Recompute radiation force and torque using the actual supplied initial attitude and COM. *)
  meshAttitude=phase1RotateMeshToCOM[mesh,dyn["CenterOfMassLocal_m"],dyn["InitialQuaternion"]];
  rad=phase1Radiation[in,geo,meshAttitude,optics,in["PVFraction"],in["Distance_m"],in["IncidenceAngle_deg"],sun];
  mass=phase1Mass[in,geo,rad,in["PVFraction"],in["Distance_m"]];
  dyn=phase1DynamicsInitial[in,geo,mass,mesh];
  naturalEquilibrium=phase1NaturalEquilibrium[in,rad,mass,dyn];
  mass=phase1MergeNaturalEquilibrium[mass,naturalEquilibrium];
  coupledPerformance=phase1CoupledPVThermal[in,geo,meshAttitude,optics,rad,in["PVFraction"],in["Distance_m"],0.];
  If[FailureQ[coupledPerformance],Return[coupledPerformance]];
  thermal=coupledPerformance["Thermal"];pv=coupledPerformance["PVPerformance"];
  power=phase1Power[in,pv];
  missionEnd=phase1PerformanceAtTime[in,geo,meshAttitude,in["ReferenceMissionYears"] in["Year_s"],
    dyn["InitialPositionLocal_m"],dyn["InitialQuaternion"]];
  If[FailureQ[missionEnd],Return[missionEnd]];
  structure=phase1Structural[in,geo,rad];
  wrench=dyn["WrenchMatrix"];
  capacity=If[in["ICARUSStationForceCapacity_N"]===Automatic,Automatic,in["ICARUSStationForceCapacity_N"]];
  zeroWrench=ConstantArray[0.,6];
  allocation=phase1Controller[dyn,zeroWrench,capacity];
  If[FailureQ[allocation]||!AssociationQ[allocation]||
      !TrueQ[Lookup[allocation,"WrenchReconstructionPass",False]],
    Return[Failure["ICARUSZeroCommandWrenchAllocationFailed",<|
      "Pole"->$Phase1CurrentPole,"UnderlyingResult"->allocation|>]]
  ];
  loadmap=phase1LoadMap[in,geo,mesh,dyn,allocation["StationForces_N"]];
  If[FailureQ[loadmap]||!AssociationQ[loadmap],
    Return[Failure["ICARUSZeroCommandLoadMapFailed",<|
      "Pole"->$Phase1CurrentPole,"UnderlyingResult"->loadmap|>]]
  ];
  testAllocations=Table[phase1Controller[dyn,UnitVector[6,i],Infinity],{i,6}];
  If[Length[testAllocations]=!=6||!And@@(AssociationQ/@testAllocations)||
      !And@@(TrueQ[Lookup[#,"WrenchReconstructionPass",False]]&/@testAllocations),
    Return[Failure["ICARUSWrenchBasisAllocationFailed",<|
      "Pole"->$Phase1CurrentPole,"AllocationResults"->testAllocations|>]]
  ];
  testLoadMaps=Table[phase1LoadMap[in,geo,mesh,dyn,testAllocations[[i]]["StationForces_N"]],{i,6}];
  If[Length[testLoadMaps]=!=6||!And@@(AssociationQ/@testLoadMaps),
    Return[Failure["ICARUSWrenchBasisLoadMapFailed",<|
      "Pole"->$Phase1CurrentPole,"LoadMapResults"->testLoadMaps|>]]
  ];
  disturbance=<|"FlarePeakFraction"->in["FlarePeakFraction"],"FlarePeakTime_s"->in["FlarePeakTime_s"],
    "FlareDuration_s"->in["FlareDuration_s"],"FlareTailCutoffFraction"->in["FlareTailCutoffFraction"],"CMEWindPressureMultiplier"->in["CMEWindPressureMultiplier"],
    "CMEOnset_s"->in["CMEOnset_s"],"CMEDuration_s"->in["CMEDuration_s"],
    "BaselineSolarWindDynamicPressureAt1AU_Pa"->in["SolarWindProtonDensity_1AU_cm3"] in["CentimetersPerMeter"]^3 in["ProtonMass_kg"] in["SolarWindSpeed_1AU_m_s"]^2|>;
  checks=phase1ValidateCore[in,geo,meshAttitude,optics,rad,mass,thermal,pv,power,structure,dyn,wrench,naturalEquilibrium];
  checks=Join[checks,<|
    "StationCoordinatesWithinPlanform"->TrueQ[Lookup[inputChecks,"StationCoordinatesWithinPlanform",False]],
    "HeliocentricReferenceMotionModeSupported"->TrueQ[Lookup[inputChecks,"HeliocentricReferenceMotionModeSupported",False]],
    "HeliocentricStaticHoverVelocityValid"->TrueQ[Lookup[inputChecks,"HeliocentricStaticHoverVelocityValid",False]],
    "AllCentralInputChecksPass"->TrueQ[phase1InputChecksPass[inputChecks]],
    "PVScenarioOptionsValid"->TrueQ[Lookup[inputChecks,"PVScenarioOptionsValid",False]],
    "PVScenarioRecognized"->TrueQ[Lookup[inputChecks,"PVScenarioRecognized",False]],
    "ICARUSWrenchAllocatorReconstructsDemand"->TrueQ[Length[testAllocations]===6&&
      And@@(AssociationQ[#]&&TrueQ[Lookup[#,"WrenchReconstructionPass",False]]&&
        phase1FiniteRealNumberQ[Lookup[#,"ForceWrenchResidual_N",Missing[]]]&&
        phase1FiniteRealNumberQ[Lookup[#,"MomentWrenchResidual_Nm",Missing[]]]&/@testAllocations)],
    "ICARUSLoadMapConservesStationForce"->TrueQ[Length[testLoadMaps]==6 && And@@(AssociationQ[#] && TrueQ[Lookup[#,"ForceConservationPass",False]]&/@testLoadMaps)],
    "ICARUSLoadMapConservesStationMoment"->TrueQ[Length[testLoadMaps]==6 && And@@(AssociationQ[#] && TrueQ[Lookup[#,"MomentConservationPass",False]]&/@testLoadMaps)],
    "ICARUSPerStationLoadWeightsNormalize"->TrueQ[Max[Flatten[Abs[Lookup[testLoadMaps,"PerStationPatchWeightSums"]-1.]]]<=in["ICARUSLoadMapRelativeTolerance"]]
  |>];
  derived=<|"Geometry"->geo,"SurfaceMesh"->mesh,"InitialAttitudeSurfaceMesh"->meshAttitude,
    "OpticalRegister"->optics,"SunVector"->sun,"Illumination"->KeyDrop[illum,"PatchIncidenceCosines"]|>;
  results=<|"InputValidation"->inputChecks,"LocalRadiation"->rad,"MassBalance"->mass,
    "NaturalEquilibrium"->naturalEquilibrium,"Thermal"->thermal,"PVPerformance"->pv,"PowerLedger"->power,
    "MissionEndPerformance"->missionEnd,"StructuralScreen"->structure,"DynamicInitialConditions"->dyn,
    "ICARUSWrenchMatrix"->wrench,"ICARUSCapacityPerStation_N"->capacity,
    "ICARUSZeroCommandAllocation"->KeyDrop[allocation,"WrenchMatrix"],
    "ICARUSInitialLoadMap"->KeyDrop[loadmap,"Patches"],
    "ICARUSWrenchAllocatorCrossCheck"->testAllocations,
    "ICARUSLoadMapCrossCheck"->Map[KeyDrop[#,"Patches"]&,testLoadMaps],
    "DisturbanceInputs"->disturbance,"Validation"->checks|>;
  manifest=<|
    "01_Geometry"-><|"Inputs"->{"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius"},"Outputs"->{"Geometry"}|>,
    "02_SurfaceMesh"-><|"DependsOn"->{"Geometry"},"Outputs"->{"SurfaceMesh","LocalNormals","AreaWeights"}|>,
    "03_OpticalClosure"-><|"Inputs"->{"ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity"},"Outputs"->{"OpticalRegister"}|>,
    "04_LocalRadiation"-><|"DependsOn"->{"SurfaceMesh","OpticalRegister","Distance_m","PVFraction","IncidenceAngle_deg","InitialAttitudeSmallAngles_rad"},"Outputs"->{"LocalRadiation","MomentumCoefficient","RadiationForce","RadiationMoment"}|>,
    "05_MassAndNaturalEquilibrium"-><|"DependsOn"->{"MassDistributionModel","Geometry","LocalRadiation","PVModuleMass","MembraneSubstrateMass","ReflectiveCoatingMass","WiringMass","PerimeterHardwareLinearMass","StationMass","StationCoordinates"},"Outputs"->{"MassBalance","DistributedGravity","NaturalForceResidual","NaturalTorqueResidual"}|>,
    "06_Thermal"-><|"DependsOn"->{"Geometry","LocalRadiation","OpticalRegister","ThermalInputs"},"Outputs"->{"Thermal"}|>,
    "07_PVAndPower"-><|"DependsOn"->{"PVLayoutModel","Thermal","LocalRadiation","PVInputs","SpecificPowerReference","ElectricalInputs","Degradation","MissionDuration"},"Outputs"->{"PVPerformance","PowerLedger","MissionEndPerformance"}|>,
    "08_Structure"-><|"DependsOn"->{"MembraneStructuralModel","Geometry","LocalRadiation","MembraneInputs"},"Outputs"->{"StructuralScreen"}|>,
    "09_DynamicsAndICARUS"-><|"DependsOn"->{"MassDistributionModel","ICARUSLoadTransferModel","GravityGradientRigidBodyDynamics","MassBalance","Geometry","ICARUSInputs","DynamicsInputs"},"Outputs"->{"DynamicInitialConditions","ICARUSWrenchMatrix","ICARUSCapacityPerStation_N","ICARUSInitialLoadMap","NaturalEquilibrium"}|>,
    "10_Validation"-><|"DependsOn"->{"All preceding calculation outputs"},"Outputs"->{"Validation"}|>,
    "11_CentralStateAudit"-><|"InputsFrom"->{"$Phase1State[Inputs]"},"OutputsStoredIn"->{"$Phase1State[Derived]","$Phase1State[Results]","$Phase1State[LastRun]"},
      "FreshnessRule"->"Every core accessor verifies the exact numerical/model input snapshot and calculation manifest."|>
  |>;
  phase1StoreRun[derived,results,manifest];
  results
];

phase1ValidateCore[in_,geo_,mesh_,optics_,rad_,mass_,thermal_,pv_,power_,structure_,dyn_,wrench_,natural_] := Module[
  {analyticCoefficient,numericalCoefficient,coefficientError,independentAccel,arealAccel,qNorm,
   fineMesh,fineMeshAtt,fineCoefficients,meshMomentumError,energyScale,validation,independentPVTemp,independentRefTemp,
   independentRadiationForce,massComponentResidual,solarMassDerived,luminosityFromSolarConstant,
   luminosityRelativeDifference,pvSpecificPowerImpliedEfficiency,integratedSpecificPowerImpliedEfficiency,
   independentScenarioOutputs,pvOutputIndependent,deliveredPowerIndependent,inertiaEigenvalues,expectedSubstrateMass,
   independentPVIrradianceFactor,independentTorque,gravityRotation,gravityPositionsHelio,gravityForcesIndependent,
   gravityTorquesIndependent,gravityForceIndependent,gravityTorqueIndependent,windPressureIndependent,
   windDirection,windForcesIndependent,windTorquesIndependent,windForceIndependent,windTorqueIndependent,
   independentRadiationFlux,independentSunDirection,independentMixAbsorptivity,independentMixReflectivity,
   independentRadiationPatchForces,independentRadiationTorque,fineMeshRadiationForce,
   independentMITReferenceEfficiency,independentIntegratedReferenceEfficiency,independentProjectTargetEfficiency},
  analyticCoefficient=Module[{a=geo["PlanformEquivalentRadius_m"],sr=geo["GeneratingSphereRadius_m"],f=in["PVFraction"],aPV=optics["PV"]["A"],rPV=optics["PV"]["R"],aR=optics["Reflector"]["A"],rR=optics["Reflector"]["R"],mixA,mixR,meanCosSquared},
    mixA=f aPV+(1.-f) aR;mixR=f rPV+(1.-f) rR;
    meanCosSquared=1.-a^2/(2. sr^2);
    mixA+2. mixR meanCosSquared
  ];
  numericalCoefficient=rad["NumericalMomentumCoefficientRadial"];
  coefficientError=Abs[numericalCoefficient-analyticCoefficient]/Max[Abs[analyticCoefficient],$MinMachineNumber];
  fineMesh=phase1Mesh[in,geo,2 in["MeshRadialCount"],2 in["MeshAzimuthCount"]];
  fineMeshAtt=phase1RotateMeshToCOM[fineMesh,dyn["CenterOfMassLocal_m"],dyn["InitialQuaternion"]];
  fineCoefficients=phase1MaterialMomentumCoefficients[fineMeshAtt,phase1SunVector[in["IncidenceAngle_deg"]],optics];
  meshMomentumError=Norm[rad["NumericalMomentumCoefficientVector"]-(in["PVFraction"] fineCoefficients["PVVectorCoefficient"]+(1.-in["PVFraction"]) fineCoefficients["ReflectorVectorCoefficient"]) ]/
    Max[Norm[fineCoefficients["PVVectorCoefficient"]],$MinMachineNumber];
  (* Independent radiation-force and torque ledger: recompute local specular momentum transfer
     from each rotated patch's normal, area and material fractions. Do not reuse phase1Radiation's
     stored force or moment, nor its stored momentum-coefficient vector. *)
  independentRadiationFlux=phase1SolarIrradiance[in,in["Distance_m"]];
  If[FailureQ[independentRadiationFlux],Return[independentRadiationFlux]];
  independentSunDirection=Normalize[{Cos[in["IncidenceAngle_deg"] Degree],Sin[in["IncidenceAngle_deg"] Degree],0.}];
  independentMixAbsorptivity=in["PVFraction"] optics["PV"]["A"]+(1.-in["PVFraction"]) optics["Reflector"]["A"];
  independentMixReflectivity=in["PVFraction"] optics["PV"]["R"]+(1.-in["PVFraction"]) optics["Reflector"]["R"];
  independentRadiationPatchForces=Map[Function[p,Module[{ci=Max[0.,p["Normal"].independentSunDirection]},
    (independentRadiationFlux/in["SpeedOfLight_m_s"])*ci*p["SurfaceAreaWeight_m2"]*
      (independentMixAbsorptivity*independentSunDirection+2.*independentMixReflectivity*ci*p["Normal"])]],rad["PatchLoads"]];
  independentRadiationForce=Total[independentRadiationPatchForces];
  independentRadiationTorque=Total[MapThread[Cross[#1,#2]&,
    {Lookup[rad["PatchLoads"],"Position_m"],independentRadiationPatchForces}]];
  fineMeshRadiationForce=independentRadiationFlux*geo["GrossProjectedAreaPerPole_m2"]/in["SpeedOfLight_m_s"]*
    (in["PVFraction"]*fineCoefficients["PVVectorCoefficient"]+(1.-in["PVFraction"])*fineCoefficients["ReflectorVectorCoefficient"]);
  (* Independent gravity recomputation: directly sum Newtonian attraction over the registered
     distributed mass points, without calling phase1GravityLoads. *)
  gravityRotation=phase1RotationMatrix[dyn["InitialQuaternion"]];
  gravityPositionsHelio=Map[{in["Distance_m"],0.,0.}+gravityRotation.#&,dyn["MassPointPositionsLocal_m"]];
  gravityForcesIndependent=MapThread[-in["SolarGravitationalParameter_m3_s2"] #1 #2/Norm[#2]^3&,
    {dyn["MassPointMasses_kg"],gravityPositionsHelio}];
  gravityTorquesIndependent=MapThread[Cross[gravityRotation.#1,#2]&,
    {dyn["MassPointPositionsLocal_m"],gravityForcesIndependent}];
  gravityForceIndependent=Total[gravityForcesIndependent];gravityTorqueIndependent=Total[gravityTorquesIndependent];
  (* Independent solar-wind recomputation: recalculate density conversion, inverse-square pressure,
     local projected patch forces and COM moments directly rather than reusing phase1SolarWindLoads. *)
  windDirection={1.,0.,0.};
  windPressureIndependent=in["SolarWindProtonDensity_1AU_cm3"]*in["CentimetersPerMeter"]^3*in["ProtonMass_kg"]*in["SolarWindSpeed_1AU_m_s"]^2*
    (in["AstronomicalUnit_m"]/in["Distance_m"])^2;
  windForcesIndependent=Map[Function[p,windPressureIndependent*Max[0.,p["Normal"].windDirection]*
    p["SurfaceAreaWeight_m2"]*windDirection],rad["PatchLoads"]];
  windTorquesIndependent=MapThread[Cross[#1,#2]&,{Lookup[rad["PatchLoads"],"Position_m"],windForcesIndependent}];
  windForceIndependent=Total[windForcesIndependent];windTorqueIndependent=Total[windTorquesIndependent];
  independentAccel=(independentRadiationForce+gravityForceIndependent+windForceIndependent)/mass["TotalMass_kg"];
  independentTorque=independentRadiationTorque+gravityTorqueIndependent+windTorqueIndependent;
  massComponentResidual=mass["TotalMass_kg"]-(mass["PVMass_kg"]+mass["ReflectorCoatingMass_kg"]+mass["MembraneSubstrateMass_kg"]+mass["WiringMass_kg"]+mass["OtherInstalledArealMass_kg"]+mass["PerimeterHardwareMass_kg"]+mass["StationMassTotal_kg"]+mass["DeferredEquipmentMass_kg"]);
  arealAccel=independentRadiationForce/(geo["GrossProjectedAreaPerPole_m2"] mass["TotalArealMass_kg_m2"])+
    (gravityForceIndependent+windForceIndependent)/mass["TotalMass_kg"];
  qNorm=Norm[dyn["InitialQuaternion"]];
  independentPVTemp=If[thermal["PVActiveArea_m2"]>0.,
    (Max[0.,rad["PVAbsorbedPower_W"]-pv["SelectedDCOutput_W"]]/(thermal["PVActiveArea_m2"] (If[TrueQ[in["BothSidesRadiate"]],2.,1.] in["PVIRemissivity"] in["StefanBoltzmann_W_m2_K4"])))^(1/4),0.];
  independentRefTemp=If[thermal["ReflectorActiveArea_m2"]>0.,
    (rad["ReflectorAbsorbedPower_W"]/(thermal["ReflectorActiveArea_m2"] (If[TrueQ[in["BothSidesRadiate"]],2.,1.] in["ReflectorIRemissivity"] in["StefanBoltzmann_W_m2_K4"])))^(1/4),0.];
  energyScale=Max[Sqrt[$MinMachineNumber],Abs[rad["TotalIncidentOpticalPower_W"]]];
  solarMassDerived=in["SolarGravitationalParameter_m3_s2"]/in["UniversalGravitationalConstant_m3_kg_s2"];
  luminosityFromSolarConstant=4. Pi in["AstronomicalUnit_m"]^2 in["SolarIrradianceAt1AU_W_m2"];
  luminosityRelativeDifference=Abs[luminosityFromSolarConstant-in["SolarLuminosity_W"]]/in["SolarLuminosity_W"];
  pvSpecificPowerImpliedEfficiency=in["PVArealMass_kg_m2"] in["PVCellArraySpecificPower_W_kg"]/in["PVSpecificPowerReferenceIrradiance_W_m2"];
  integratedSpecificPowerImpliedEfficiency=in["PVArealMass_kg_m2"] in["PVCellArraySpecificPower_W_kg"]/in["PVSpecificPowerReferenceIrradiance_W_m2"];
  independentPVIrradianceFactor=If[pv["PVInstalledCurvedArea_m2"]>0.,
    pv["IncidentPVPower_W"]/(pv["PVInstalledCurvedArea_m2"] in["PVSpecificPowerReferenceIrradiance_W_m2"]),0.];
  independentMITReferenceEfficiency=Clip[in["PVCellReferenceEfficiency"]*(1.+in["PVEfficiencyTemperatureCoefficient_perK"]*
    (thermal["PVTemperature_K"]-in["PVReferenceTemperature_K"])),{0.,1.}];
  independentIntegratedReferenceEfficiency=Clip[in["PVCellArrayEfficiencyReference"]*(1.+in["PVEfficiencyTemperatureCoefficient_perK"]*
    (thermal["PVTemperature_K"]-in["PVReferenceTemperature_K"])),{0.,1.}];
  independentProjectTargetEfficiency=Clip[in["ProjectTargetEfficiency"]*(1.+in["PVEfficiencyTemperatureCoefficient_perK"]*
    (thermal["PVTemperature_K"]-in["PVReferenceTemperature_K"])),{0.,1.}];
  independentScenarioOutputs=<|
    "PVCellArraySpecificPowerLimited"->Min[pv["PVCellArrayDeviceMass_kg"] in["PVCellArraySpecificPower_W_kg"] independentPVIrradianceFactor pv["TotalPVDegradationFactor"],
      pv["IncidentPVPower_W"] independentMITReferenceEfficiency pv["TotalPVDegradationFactor"]],
    "PVCellArraySpecificPowerLimited"->Min[pv["PVCellArrayDeviceMass_kg"] in["PVCellArraySpecificPower_W_kg"] independentPVIrradianceFactor pv["TotalPVDegradationFactor"],
      pv["IncidentPVPower_W"] independentIntegratedReferenceEfficiency pv["TotalPVDegradationFactor"]],
    "PVCellReferenceEfficiency"->pv["IncidentPVPower_W"] independentMITReferenceEfficiency pv["TotalPVDegradationFactor"],
    "ProjectSpecifiedTargetEfficiency"->pv["IncidentPVPower_W"] independentProjectTargetEfficiency pv["TotalPVDegradationFactor"]|>;
  pvOutputIndependent=Lookup[independentScenarioOutputs,pv["SelectedScenario"],Missing["ScenarioMismatch"]];
  deliveredPowerIndependent=pvOutputIndependent in["TransferEfficiency"] in["ConditioningEfficiency"];
  inertiaEigenvalues=Eigenvalues[dyn["InertiaTensor_kg_m2"]];
  expectedSubstrateMass=geo["GrossCurvedAreaPerPole_m2"]*
    If[TrueQ[in["PVCellArrayMassPolicy"] &&
      in["PrimaryPVScenario"]==="PVCellArraySpecificPowerLimited"],
      1.-in["PVFraction"],1.]*phase1EffectiveSubstrateArealMass[in];
  validation=<|
    "CentralInputSchemaComplete"->TrueQ[Sort[Keys[in]]===Sort[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]]],
    "SolarLuminosityNominalReferenceConsistencyCheck"->TrueQ[luminosityRelativeDifference<=in["SolarReferenceConsistencyRelativeTolerance"]],
    "SolarGravitationalParameterPositive"->TrueQ[in["SolarGravitationalParameter_m3_s2"]>0.],
    "DerivedSolarMassFromNominalGM_kg"->solarMassDerived,
    "SolarParameterCrossCheckQualification"->"The GM/G mass reconstruction is an algebraic identity. The luminosity/TSI/AU comparison checks internal consistency of nominal reference constants; neither is an independent measurement of solar GM or luminosity.",
    "SolarParameterCrossCheckValues"-><|"NominalSolarGM_m3_s2"->in["SolarGravitationalParameter_m3_s2"],
      "DerivedSolarMass_kg"->solarMassDerived,
      "GMReconstructionResidual_m3_s2"->Abs[in["UniversalGravitationalConstant_m3_kg_s2"] solarMassDerived-in["SolarGravitationalParameter_m3_s2"]],
      "GMReconstructionIsAlgebraicIdentity"->True,
      "LuminosityFromNominalSolarIrradiance_W"->luminosityFromSolarConstant,
      "NominalSolarLuminosity_W"->in["SolarLuminosity_W"],"LuminosityRelativeDifference"->luminosityRelativeDifference,
      "LuminosityComparisonType"->"Consistency of IAU nominal reference constants, not an independent physical measurement."|>,
    "MITSpecificPowerImpliedEfficiency"->pvSpecificPowerImpliedEfficiency,
    "MITIntegratedSpecificPowerImpliedEfficiency"->integratedSpecificPowerImpliedEfficiency,
    "PVCellArraySpecificPowerImpliedEfficiencyDoesNotExceedFreeStandingReference"->TrueQ[
      pvSpecificPowerImpliedEfficiency<=in["PVCellReferenceEfficiency"]+in["PowerLedgerRelativeTolerance"]],
    "IntegratedSpecificPowerImpliedEfficiencyDoesNotExceedIntegratedReference"->TrueQ[
      integratedSpecificPowerImpliedEfficiency<=in["PVCellArrayEfficiencyReference"]+in["PowerLedgerRelativeTolerance"]],
    "PVSpecificPowerReferenceIrradiance_W_m2"->in["PVSpecificPowerReferenceIrradiance_W_m2"],
    "PVSpecificPowerIrradianceScalingIndependentlyRecalculated"->TrueQ[Abs[independentPVIrradianceFactor-pv["SpecificPowerIrradianceScalingFactor"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[independentPVIrradianceFactor],Abs[pv["SpecificPowerIrradianceScalingFactor"]]]],
    "PVTechnologyScenarioMassesIndependentlyRecalculated"->TrueQ[
      Abs[pv["PVCellArrayDeviceMass_kg"]-pv["PVInstalledCurvedArea_m2"] in["PVArealMass_kg_m2"]]<=
        in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[pv["PVCellArrayDeviceMass_kg"]]] &&
      Abs[pv["PVCellArrayDeviceMass_kg"]-pv["PVInstalledCurvedArea_m2"] in["PVArealMass_kg_m2"]]<=
        in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[pv["PVCellArrayDeviceMass_kg"]]]],
    "MITTemperatureAdjustedEfficiencyIndependentRecalculation"->TrueQ[
      Abs[independentMITReferenceEfficiency-pv["EffectiveMITReferenceEfficiency"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[independentMITReferenceEfficiency]]],
    "IntegratedPVTemperatureAdjustedEfficiencyIndependentRecalculation"->TrueQ[
      Abs[independentIntegratedReferenceEfficiency-pv["EffectiveIntegratedPVReferenceEfficiency"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[independentIntegratedReferenceEfficiency]]],
    "ProjectTargetTemperatureAdjustedEfficiencyIndependentRecalculation"->TrueQ[
      Abs[independentProjectTargetEfficiency-pv["EffectiveProjectTargetEfficiency"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[independentProjectTargetEfficiency]]],
    "PVScenarioOutputIndependentRecalculation"->TrueQ[NumericQ[pvOutputIndependent] &&
      Abs[pvOutputIndependent-pv["SelectedDCOutput_W"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[pvOutputIndependent]]],
    "ConditionedPowerIndependentRecalculation"->TrueQ[NumericQ[deliveredPowerIndependent] &&
      Abs[deliveredPowerIndependent-power["ConditionedDeliveredPower_W_PerPole"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[deliveredPowerIndependent]]],
    "OpticalReflectorEnergyClosure"->TrueQ[Abs[optics["EnergyClosure"]["Reflector"]-1.]<in["OpticalClosureTolerance"]],
    "OpticalPVEnergyClosure"->TrueQ[Abs[optics["EnergyClosure"]["PV"]-1.]<in["OpticalClosureTolerance"]],
    "WholeSurfaceOpticalEnergyConservation"->TrueQ[Abs[rad["OpticalEnergyClosureResidual_W"]]<=in["PowerLedgerRelativeTolerance"] energyScale],
    "PVFractionEnergyLedgerConnected"->TrueQ[Abs[rad["PVIncidentPower_W"]-rad["PVAbsorbedPower_W"]-rad["PVReflectedPower_W"]-rad["PVTransmittedPower_W"]]<=in["PowerLedgerRelativeTolerance"] energyScale],
    "ReflectorEnergyLedgerConnected"->TrueQ[Abs[rad["ReflectorIncidentPower_W"]-rad["ReflectorAbsorbedPower_W"]-rad["ReflectorReflectedPower_W"]-rad["ReflectorTransmittedPower_W"]]<=in["PowerLedgerRelativeTolerance"] energyScale],
    "CoverageRange"->TrueQ[0.<=in["PVFraction"]<=1.],
    "DistancePositive"->TrueQ[in["Distance_m"]>0.],
    "GeometryMeshCurvedAreaConverges"->TrueQ[Abs[mesh["QuadratureAreaRelativeError"]]<in["MeshAreaRelativeTolerance"]],
    "MeshMomentumResolutionConverges"->TrueQ[meshMomentumError<=in["MeshCoefficientCrossCheckTolerance"]],
    "MeshMomentumRelativeDifference"->meshMomentumError,
    "NumericalVsAnalyticMomentumCoefficient"->If[Abs[in["IncidenceAngle_deg"]]<Sqrt[$MachineEpsilon] &&
        Norm[in["InitialAttitudeSmallAngles_rad"]]<Sqrt[$MachineEpsilon],
      TrueQ[coefficientError<=in["MeshCoefficientCrossCheckTolerance"]],Missing["AnalyticFaceOnCheckNotApplicableAtTiltOrAttitude"]],
    "AnalyticFaceOnSpecularMeanCosineSquared"->1.-geo["PlanformEquivalentRadius_m"]^2/(2. geo["GeneratingSphereRadius_m"]^2),
    "MomentumCoefficientRelativeError"->If[Abs[in["IncidenceAngle_deg"]]<Sqrt[$MachineEpsilon] &&
        Norm[in["InitialAttitudeSmallAngles_rad"]]<Sqrt[$MachineEpsilon],coefficientError,Missing["NotApplicableAtTiltOrAttitude"]],
    "RadiationPatchForceIndependentRecalculation"->TrueQ[Norm[independentRadiationForce-rad["NetRadiationForceVector_N"]]<=in["AccelerationCrossCheckRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[independentRadiationForce],Norm[rad["NetRadiationForceVector_N"]]]],
    "RadiationTorqueIndependentRecalculation"->TrueQ[Norm[independentRadiationTorque-rad["NetRadiationMoment_Nm"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[independentRadiationTorque],Norm[rad["NetRadiationMoment_Nm"]]]],
    "PatchForceVsMomentumCoefficientCrossCheck"->TrueQ[Norm[independentRadiationForce-fineMeshRadiationForce]<=in["MeshCoefficientCrossCheckTolerance"] Max[Sqrt[$MinMachineNumber],Norm[independentRadiationForce],Norm[fineMeshRadiationForce]]],
    "RadiationForceMassAccelerationCrossCheck"->TrueQ[Norm[independentAccel-mass["NetNaturalAccelerationVector_m_s2"]]<=in["AccelerationCrossCheckRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[independentAccel],Norm[rad["NetRadiationForceVector_N"]/mass["TotalMass_kg"]]]],
    "ArealAndTotalForceAccelerationCrossCheck"->TrueQ[Norm[independentAccel-arealAccel]<=in["AccelerationCrossCheckRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[independentAccel],Norm[arealAccel]]],
    "NaturalForceOutwardBiasAtCurrentInputs"->natural["OutwardRadialBiasPass"],
    "NaturalTransverseForceBalanceAtCurrentInputs"->natural["TransverseForceBalancePass"],
    "NaturalTorqueEquilibriumAtCurrentInputs"->natural["ExactTorqueEquilibrium"],
    "ControlledOutwardForceEnvelopeAtCurrentInputs"->TrueQ[natural["ControlledOutwardForceEnvelopePass"]&&natural["ExactTorqueEquilibrium"]],
    "ExactNaturalEquilibriumDiagnosticAtCurrentInputs"->mass["ExactNaturalEquilibrium"],
    "DistributedGravityIndependentRecalculation"->TrueQ[Norm[gravityForceIndependent-natural["GravityLoads"]["TotalGravityForce_N"]]<=in["AccelerationCrossCheckRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[gravityForceIndependent],Norm[natural["GravityLoads"]["TotalGravityForce_N"]]]],
    "SolarWindForceIndependentRecalculation"->TrueQ[Norm[windForceIndependent-natural["SolarWindLoads"]["TotalForce_N"]]<=in["AccelerationCrossCheckRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[windForceIndependent],Norm[natural["SolarWindLoads"]["TotalForce_N"]]]],
    "SolarWindForceIncludedInEquilibrium"->TrueQ[Norm[independentAccel-natural["NetNaturalAccelerationVector_m_s2"]]<=in["AccelerationCrossCheckRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[independentAccel],Norm[natural["NetNaturalAccelerationVector_m_s2"]]]],
    "NaturalTorqueIndependentRecalculation"->TrueQ[Norm[independentTorque-natural["NetNaturalTorqueAboutCOM_Nm"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[independentTorque],Norm[natural["NetNaturalTorqueAboutCOM_Nm"]]]],
    (* The radial surplus is intentional, not a residual to drive to zero. The governing
       force gate therefore requires positive outward radial force, transverse balance,
       natural torque balance and a closed, mass-feasible ledger. *)
    "OutwardEnvelopeRequiresMassLedgerAndTransverseBalance"->TrueQ[
      mass["MassLedgerCloses"]&&mass["MassFeasible"]&&natural["OutwardRadialBiasPass"]&&
      natural["FutureMassGrowthTargetPass"]&&natural["TransverseForceBalancePass"]&&
      natural["ExactTorqueEquilibrium"]],
    "FutureAddedMassCapacityPositiveAtCurrentInputs"->TrueQ[natural["FutureMassGrowthTargetPass"]],
    "PVTemperatureIndependentRecalculation"->TrueQ[Abs[independentPVTemp-thermal["PVTemperature_K"]]<=in["ThermalResidualRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[independentPVTemp]]],
    "ReflectorTemperatureIndependentRecalculation"->TrueQ[Abs[independentRefTemp-thermal["ReflectorTemperature_K"]]<=in["ThermalResidualRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[independentRefTemp]]],
    "PVThermalBalanceResidual"->TrueQ[Abs[thermal["PVThermalBalanceResidual_W_m2"]]<in["ThermalResidualRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[thermal["PVMeanAbsorbedHeatFlux_W_m2"]]]],
    "PVThermalCouplingConverged"->TrueQ[thermal["PVThermalCouplingConverged"]],
    "ReflectorThermalBalanceResidual"->TrueQ[Abs[thermal["ReflectorThermalBalanceResidual_W_m2"]]<in["ThermalResidualRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[thermal["ReflectorMeanAbsorbedHeatFlux_W_m2"]]]],
    "AllThermalLimitsWithinBounds"->thermal["AllThermalLimitsWithinBounds"],
    "PVOutputBelowAbsorbedEnergy"->pv["PVOutputDoesNotExceedAbsorbedPower"],
    "PVSpecificPowerCapApplied"->pv["PVOutputDoesNotExceedSpecificPower"],
    "PVMassConsistentAcrossMassAndPowerLedgers"->TrueQ[Abs[mass["PVMass_kg"]-pv["PVDeviceMass_kg"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[mass["PVMass_kg"]]]],
    "TransferAndConditioningConnected"->TrueQ[Abs[power["ConditionedDeliveredPower_W"]-power["PVDirectCurrent_W"] in["TransferEfficiency"] in["ConditioningEfficiency"]]<in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[power["PVDirectCurrent_W"]]]],
    "StationMassCountedOnce"->TrueQ[Abs[mass["StationMassTotal_kg"]-in["ICARUSStationCount"] in["ICARUSStationMass_kg"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[mass["StationMassTotal_kg"]]] && Abs[dyn["StationMassTotal_kg"]-mass["StationMassTotal_kg"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[mass["StationMassTotal_kg"]]]],
    "PerimeterHardwareMassIncludedInMassLedger"->TrueQ[Abs[mass["PerimeterHardwareMass_kg"]-geo["PlanformPerimeter_m"] in["PerimeterHardwareLinearMass_kg_m"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[mass["PerimeterHardwareMass_kg"]]] && mass["PerimeterHardwareMass_kg"]==dyn["PerimeterHardwareMass_kg"] && Abs[dyn["MassConservationResidual_kg"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[mass["TotalMass_kg"]]]],
    "MembraneSubstrateIncludedInMassLedger"->TrueQ[
      Abs[mass["MembraneSubstrateMass_kg"]-expectedSubstrateMass]<=
        in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[expectedSubstrateMass]]],
    "ExpectedMembraneSubstrateMass_kg"->expectedSubstrateMass,
    "TotalMassComponentLedgerCloses"->TrueQ[Abs[massComponentResidual]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[mass["TotalMass_kg"]]]],
    "InertiaTensorPositive"->TrueQ[Min[inertiaEigenvalues]>0.],
    "InertiaTensorEigenvalues_kg_m2"->inertiaEigenvalues,
    "DistributedMassConservation"->TrueQ[Abs[dyn["MassConservationResidual_kg"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[mass["TotalMass_kg"]]]],
    "CenterOfMassFinite"->TrueQ[VectorQ[dyn["CenterOfMassLocal_m"],NumericQ]],
    "QuaternionNormalized"->TrueQ[Abs[qNorm-1.]<in["QuaternionNormalizationTolerance"]],
    "ICARUSWrenchMatrixFullRank"->TrueQ[MatrixRank[wrench]==6],
    "StructuralScreenCalculated"->TrueQ[NumericQ[structure["DeflectionFractionOfRadius"]]],
    "AllSelectedModelFormInputsSupported"->Module[{modelChecks=phase1InputChecks[in],modelKeys},
      modelKeys={"PVLayoutModelSupported","GeometryProfileModelSupported","MassDistributionModelSupported",
        "FlareTemporalProfileSupported","CMETemporalProfileSupported","HeliocentricReferenceMotionModeSupported",
        "ICARUSLoadTransferModelSupported","MembraneStructuralModelSupported","WobbleRestoringModelSupported",
        "ICARUSStationCountScopeSupported"};
      TrueQ[AssociationQ[modelChecks] && And@@(TrueQ[Lookup[modelChecks,#,False]]&/@modelKeys)]],
    "ICARUSCapacityRequirementCalculated"->TrueQ[AssociationQ[allocation]],
    "ICARUSStationForceCapacitySpecified"->TrueQ[NumericQ[in["ICARUSStationForceCapacity_N"]]&&0.<in["ICARUSStationForceCapacity_N"]<Infinity],
    "ICARUSStationForceCapacityInputValid"->TrueQ[in["ICARUSStationForceCapacity_N"]===Automatic || (NumericQ[in["ICARUSStationForceCapacity_N"]]&&0.<in["ICARUSStationForceCapacity_N"]<Infinity)],
    "ICARUSHardwareCapacityQualified"->False
  |>;
  validation
];

(* ========================================================================
   4. PUBLIC CALCULATION ACCESSORS — read central output store
   ======================================================================== *)

phase1EnsureCalculated[] := Module[{results=phase1RawResults[],run=Lookup[$Phase1State,"LastRun",Missing["NotRun"]],
  currentInputs=Phase1GetInputs[],requiredResults},
  requiredResults={"InputValidation","LocalRadiation","MassBalance","Thermal","PVPerformance","PowerLedger",
    "MissionEndPerformance","StructuralScreen","DynamicInitialConditions","ICARUSWrenchMatrix",
    "ICARUSCapacityPerStation_N","ICARUSZeroCommandAllocation","ICARUSInitialLoadMap",
    "ICARUSWrenchAllocatorCrossCheck","ICARUSLoadMapCrossCheck","DisturbanceInputs","NaturalEquilibrium","Validation"};
  If[Lookup[$Phase1State,"SchemaVersion",""]  =!= "11.9" || !AssociationQ[run] || !KeyExistsQ[run,"CalculationManifest"] ||
      Lookup[run,"InputSnapshot",Missing["NoInputSnapshot"]]=!=currentInputs ||
      Lookup[run,"InputSnapshotHash",Missing["NoInputHash"]]=!=Hash[currentInputs,"SHA256"] ||
      !And@@(KeyExistsQ[results,#]&/@requiredResults) ||
      !And@@(KeyExistsQ[$Phase1State["Derived"],#]&/@{"Geometry","SurfaceMesh","InitialAttitudeSurfaceMesh","OpticalRegister","SunVector","Illumination"}),
    results=Phase1ComputeAll[]
  ];
  results
];

Phase1LocalSurfaceMesh[] := Module[{results=phase1EnsureCalculated[]},If[FailureQ[results],results,Phase1GetState[]["Derived"]["SurfaceMesh"]]];
Phase1LocalRadiationLoads[] := Module[{results=phase1EnsureCalculated[]},If[FailureQ[results],results,Phase1GetResult["LocalRadiation"]]];
Phase1MassBalance[] := Module[{results=phase1EnsureCalculated[]},If[FailureQ[results],results,Phase1GetResult["MassBalance"]]];
Phase1ThermalScreen[] := Module[{results=phase1EnsureCalculated[]},If[FailureQ[results],results,Phase1GetResult["Thermal"]]];
Phase1PowerLedger[] := Module[{results=phase1EnsureCalculated[]},If[FailureQ[results],results,Phase1GetResult["PowerLedger"]]];
Phase1DynamicInitialConditions[] := Module[{results=phase1EnsureCalculated[]},If[FailureQ[results],results,Phase1GetResult["DynamicInitialConditions"]]];


(* ========================================================================
   5. INDEPENDENT NUMERICAL SOLVES AND OPTIMIZATION
   ======================================================================== *)

phase1SolveExactEquilibriumCurrent[] := Module[
  {in=Phase1GetInputs[],geo,mesh,optics,sun,coeff,lo,hi,seed,root,rootMethod,ff,rad,mass,fn,result,lowResidual,highResidual,dyn,meshAtt,natural,candidate},
  If[!phase1InputChecksPass[phase1InputChecks[in]],Return[Failure["InvalidPhase1Inputs",<|"Checks"->phase1InputChecks[in]|>]]];
  geo=phase1Geometry[in];mesh=phase1Mesh[in,geo,in["OptimizerMeshRadialCount"],in["OptimizerMeshAzimuthCount"]];
  optics=phase1Optics[in];sun=phase1SunVector[in["IncidenceAngle_deg"]];
  coeff=phase1MaterialMomentumCoefficients[mesh,sun,optics];
  lo=in["PVSearchRange"][[1]];hi=in["PVSearchRange"][[2]];
  seed=Clip[in["PVFraction"],{lo,hi}];
  fn[x_?NumericQ] := Module[{trialCandidate=phase1NaturalCandidateAt[in,geo,mesh,optics,x,in["Distance_m"]]},
    trialCandidate["Natural"]["NetNaturalAccelerationVector_m_s2"][[1]] /
      (in["SolarGravitationalParameter_m3_s2"]/in["Distance_m"]^2)
  ];
  lowResidual=fn[lo];highResidual=fn[hi];
  root=Quiet@Check[FindRoot[fn[ff]==0.,{ff,seed,lo,hi},Method->"Brent",WorkingPrecision->in["NumericalWorkingPrecision"]],$Failed];
  rootMethod="FindRootBrent";
  (* If Brent fails despite a sign-changing bracket, use the model's independent
     bracketed-bisection routine rather than misreporting a physically available root
     as absent. This changes only the numerical root-finding path, not the force model. *)
  If[root===$Failed && NumericQ[lowResidual] && NumericQ[highResidual] && TrueQ[lowResidual highResidual<=0.],
    With[{coverageRoot=phase1BracketedBisection[fn,{lo,hi},in["ExactEquilibriumRelativeTolerance"],
        Max[200,2 in["OptimizerMaxIterations"]]]},
      If[NumericQ[coverageRoot],root={ff->coverageRoot};rootMethod="BracketedBisectionFallback"]
    ]
  ];
  If[root===$Failed,
    result=<|"Status"->"No radial equilibrium root found within the configured PV coverage range.",
      "Root"->Missing["NoRoot"],"PVFractionSearchBounds"->{lo,hi},
      "NetRadialAccelerationAtLowerCoverage_m_s2"->lowResidual,
      "NetRadialAccelerationAtUpperCoverage_m_s2"->highResidual,
      "EndpointResidualsBracketRoot"->TrueQ[lowResidual highResidual<=0.],
      "Interpretation"->"The selected PV technology, areal masses, optical momentum coefficient and station mass do not produce a radial equilibrium root within the allowed coverage interval."|>,
    ff=ff/.root;candidate=phase1NaturalCandidateAt[in,geo,mesh,optics,ff,in["Distance_m"]];
    rad=candidate["Radiation"];mass=candidate["Mass"];dyn=candidate["Dynamics"];
    meshAtt=candidate["AttitudeMesh"];natural=candidate["Natural"];
    result=<|"Status"->If[mass["ExactNaturalEquilibrium"],"Natural force and torque equilibrium found within the approved relative tolerance converted to the active pole-specific acceleration and torque tolerances.","A one-dimensional PV-coverage radial root was found, but exact vector-force and/or torque equilibrium failed; it remains diagnostic only."],
      "InputSnapshot"->in,"OptimizerMeshResolution"->mesh["MeshResolution"],
      "MomentumCoefficients"->coeff,"PVFraction"->ff,"MassBalance"->mass,"NaturalEquilibrium"->natural,
      "ExactNaturalEquilibrium"->mass["ExactNaturalEquilibrium"],"RootMethod"->rootMethod,"RootRule"->root|>
  ];
  phase1StoreResult["ExactEquilibriumSolve",result]
];

phase1DistanceThermalFloorCurrent[coverage_:Automatic] := Module[
  {in=Phase1GetInputs[],f,geo,mesh,optics,sun,illum,sides,pvCoeff,refCoeff,pvRoot,refRoot,numericPV,numericRef,x,
   pvLimit,refLimit,pvEps,refEps,pvFloor,refFloor,limiting,rad0,mass0,dyn0,meshAtt},
  If[!phase1InputChecksPass[phase1InputChecks[in]],Return[Failure["InvalidPhase1Inputs",<|"Checks"->phase1InputChecks[in]|>]]];
  f=If[coverage===Automatic,in["PVFraction"],coverage];
  If[!TrueQ[NumericQ[f] && 0.<=f<=1.],Return[Failure["InvalidThermalCoverage",<|"PVFraction"->f|>]]];
  geo=phase1Geometry[in];mesh=phase1Mesh[in,geo,in["OptimizerMeshRadialCount"],in["OptimizerMeshAzimuthCount"]];
  optics=phase1Optics[in];sun=phase1SunVector[in["IncidenceAngle_deg"]];
  rad0=phase1Radiation[in,geo,mesh,optics,f,in["Distance_m"],in["IncidenceAngle_deg"],sun];
  mass0=phase1Mass[in,geo,rad0,f,in["Distance_m"]];dyn0=phase1DynamicsInitial[in,geo,mass0,mesh];
  meshAtt=phase1RotateMeshToCOM[mesh,dyn0["CenterOfMassLocal_m"],dyn0["InitialQuaternion"]];
  illum=phase1Illumination[meshAtt,sun];
  sides=If[TrueQ[in["BothSidesRadiate"]],2.,1.];
  pvLimit=in["PVTemperatureLimit_K"];refLimit=in["ReflectorTemperatureLimit_K"];
  pvEps=in["PVIRemissivity"];refEps=in["ReflectorIRemissivity"];
  pvCoeff=optics["PV"]["A"] in["SolarLuminosity_W"] illum["IlluminationWeightedProjectedArea_m2"]/(4. Pi geo["GrossCurvedAreaPerPole_m2"]);
  refCoeff=optics["Reflector"]["A"] in["SolarLuminosity_W"] illum["IlluminationWeightedProjectedArea_m2"]/(4. Pi geo["GrossCurvedAreaPerPole_m2"]);
  pvRoot=If[f>0.,Sqrt[pvCoeff/(sides pvEps in["StefanBoltzmann_W_m2_K4"] pvLimit^4)],0.];
  refRoot=If[f<1.,Sqrt[refCoeff/(sides refEps in["StefanBoltzmann_W_m2_K4"] refLimit^4)],0.];
  numericPV=If[pvRoot>0.,Quiet@Check[FindRoot[pvCoeff/x^2==sides pvEps in["StefanBoltzmann_W_m2_K4"] pvLimit^4,{x,pvRoot},WorkingPrecision->in["NumericalWorkingPrecision"]],$Failed],$Failed];
  numericRef=If[refRoot>0.,Quiet@Check[FindRoot[refCoeff/x^2==sides refEps in["StefanBoltzmann_W_m2_K4"] refLimit^4,{x,refRoot},WorkingPrecision->in["NumericalWorkingPrecision"]],$Failed],$Failed];
  pvFloor=If[pvRoot==0.,0.,If[numericPV===$Failed,pvRoot,x/.numericPV]];
  refFloor=If[refRoot==0.,0.,If[numericRef===$Failed,refRoot,x/.numericRef]];
  limiting=If[pvFloor>=refFloor,"PV", "Reflector"];
  phase1StoreResult["ThermalDistanceFloor",<|"PVFractionUsed"->f,"MinimumDistance_m"->Max[pvFloor,refFloor],
    "MinimumDistance_AU"->Max[pvFloor,refFloor]/in["AstronomicalUnit_m"],
    "PVMinimumDistance_m"->pvFloor,"ReflectorMinimumDistance_m"->refFloor,
    "LimitingThermalSubsystem"->limiting,
    "PVAnalyticDistance_m"->pvRoot,"ReflectorAnalyticDistance_m"->refRoot,
    "PVFindRootResult"->numericPV,"ReflectorFindRootResult"->numericRef,
    "TemperatureLimitPV_K"->pvLimit,"TemperatureLimitReflector_K"->refLimit,
    "Qualification"->"Both material-specific thermal boundaries use local-normal illumination and separate infrared emissivity. The larger distance is the operating floor."|>]
];

phase1EvaluateCandidateTransient[distance_?NumericQ,coverage_?NumericQ,preChecks_Association:<||>] := Module[
  {liveState=$Phase1State,candidateInputs,candidateState,core,dynamicRun,
   dynamicSummary,checks,accepted,temporaryResult,noLeak,candidatePoleInputs},
  If[!TrueQ[$Phase1ExecutingPole],
    Return[Failure["CandidateEvaluationRequiresPoleContext",<|"Reason"->"A candidate must be evaluated inside one pole's isolated execution context."|>]]];
  candidateInputs=Join[Phase1GetInputs[],<|"Distance_m"->distance,"PVFraction"->coverage|>];
  candidatePoleInputs=Join[Lookup[Lookup[$Phase1State,"PoleOperatingInputs",<||>],$Phase1CurrentPole,<||>],<|"Distance_m"->distance|>];
  candidateState=Join[$Phase1State,<|"Inputs"->candidateInputs,
    "PoleOperatingInputs"-><|$Phase1CurrentPole->candidatePoleInputs|>,
    "Derived"-><||>,"Results"-><||>,"LastRun"->Missing["TransientCandidateRequiresFullRecalculation"]|>];
  temporaryResult=Block[{$Phase1State=candidateState},
    core=Phase1ComputeAll[];
    If[FailureQ[core],
      <|"CandidateEvaluatedTransiently"->True,"CandidateEvaluationPole"->$Phase1CurrentPole,
        "CandidateDistance_m"->distance,"CandidatePVFraction"->coverage,
        "CandidateCoreRecalculation"->core,
        "DynamicSimulation"->Missing["NotRunCoreRecalculationFailed"],
        "AcceptanceChecks"->Join[preChecks,<|"TransientCoreRecalculation"->False|>],
        "ModelledAcceptanceUnderAssumptions"->False,"CandidateAppliedToCentralInputs"->False,
        "CandidateInputsRetained"->False,"CandidateInputSnapshot"->candidateInputs,
        "Status"->"Transient core recalculation failed; no dynamic acceptance is claimed."|>,
      dynamicRun=Phase1IntegratedSimulation[];
      dynamicSummary=If[AssociationQ[dynamicRun],KeyDrop[dynamicRun,"Solution"],dynamicRun];
      checks=Join[preChecks,<|
        "TransientCoreRecalculation"->True,
        "MassLedgerCloses"->TrueQ[Lookup[Lookup[core,"MassBalance",<||>],"MassLedgerCloses",False]],
        "RadiationOutwardMargin"->TrueQ[Lookup[Lookup[core,"NaturalEquilibrium",<||>],"OutwardRadialBiasPass",False]],
        "FutureAddedMassHeadroom"->TrueQ[Lookup[Lookup[core,"NaturalEquilibrium",<||>],"FutureMassGrowthTargetPass",False]],
        "TransverseNaturalForceWithinTolerance"->TrueQ[Lookup[Lookup[core,"NaturalEquilibrium",<||>],"TransverseForceBalancePass",False]],
        "NaturalTorqueWithinTolerance"->TrueQ[Lookup[Lookup[core,"NaturalEquilibrium",<||>],"ExactTorqueEquilibrium",False]],
        "ThermalLimits"->TrueQ[Lookup[Lookup[core,"Thermal",<||>],"AllThermalLimitsWithinBounds",False]],
        "PVThermalCouplingConverged"->TrueQ[Lookup[Lookup[core,"Validation",<||>],"PVThermalCouplingConverged",False]],
        "StaticStructuralScreen"->TrueQ[Lookup[Lookup[core,"StructuralScreen",<||>],"StructuralScreenPass",False]],
        "DynamicIntegration"->(AssociationQ[dynamicRun]&&KeyExistsQ[dynamicRun,"Solution"]&&dynamicRun["Solution"] =!= $Failed),
        "BaseAccelerationConsistency"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"BaseAccelerationConsistencyRelativeError",Infinity]<=candidateInputs["AccelerationCrossCheckRelativeTolerance"]],False],
        "QuaternionNormalization"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"MaximumQuaternionNormalizationError",Infinity]<=candidateInputs["QuaternionNormalizationTolerance"]],False],
        "RadialStability"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"RadialDeviationWithinLimit",False]],False],
        "LateralStability"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"LateralDeviationWithinLimit",False]],False],
        "AttitudeStability"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"AttitudeWithinLimit",False]],False],
        "ICARUSSpecifiedForceCapacity"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"ICARUSForceDemandWithinSpecifiedCapacity",False]],False],
        "ICARUSHardwareQualificationBoundaryRecorded"->If[AssociationQ[dynamicRun],
          TrueQ[Lookup[dynamicRun,"ICARUSHardwareCapacityQualified",False]===False&&
            ListQ[Lookup[dynamicRun,"ICARUSHardwareQualificationBlockers",{}]]&&
            Length[Lookup[dynamicRun,"ICARUSHardwareQualificationBlockers",{}]]>0],False],
        "DynamicLoadMapForceAndMomentConserved"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"DynamicLoadMapForceAndMomentConserved",False]],False],
        "DynamicStructuralLoadScreen"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"DynamicStructuralLoadScreenPass",False]],False],
        "RecoveryTime"->If[AssociationQ[dynamicRun],TrueQ[Lookup[dynamicRun,"RecoveryWithinLimit",False]],False]|>];
      accepted=And@@(TrueQ/@Values[checks]);
      <|"CandidateEvaluatedTransiently"->True,"CandidateEvaluationPole"->$Phase1CurrentPole,
        "CandidateDistance_m"->distance,"CandidatePVFraction"->coverage,
        "CandidateCoreRecalculation"->KeyDrop[core,"CalculationManifest"],
        "DynamicSimulation"->dynamicSummary,"AcceptanceChecks"->checks,
        "ModelledAcceptanceUnderAssumptions"->accepted,
        "CandidateAppliedToCentralInputs"->False,"CandidateInputsRetained"->False,
        "CandidateInputSnapshot"->candidateInputs,
        "Status"->If[accepted,"Candidate passed the static and dynamic model gates in a temporary per-pole snapshot; live inputs were not modified.",
          "Candidate failed one or more static or dynamic gates in a temporary per-pole snapshot; live inputs were not modified."]|>
    ]
  ];
  noLeak=SameQ[$Phase1State,liveState];
  checks=Join[Lookup[temporaryResult,"AcceptanceChecks",<||>],<|"NoLivePoleStateMutation"->noLeak|>];
  accepted=TrueQ[Lookup[temporaryResult,"ModelledAcceptanceUnderAssumptions",False]]&&TrueQ[noLeak];
  Join[temporaryResult,<|"AcceptanceChecks"->checks,"ModelledAcceptanceUnderAssumptions"->accepted,
    "NoLivePoleStateMutation"->noLeak,"CandidateAppliedToCentralInputs"->False,
    "CandidateInputsRetained"->False|>]
];

phase1JointOptimizationCurrent[] := Module[
  {in=Phase1GetInputs[],computed,geo,mesh,optics,sun,coeff,illum,loF,hiF,loR,hiR,
   full,screen,rr,ff,radCandidate,massCandidate,thermalCandidate,pvCandidate,powerCandidate,
   structureCandidate,capacity,fullFeasible,dynamicAccepted,results,candidateEvaluation,
   validOptimizationResultQ,gridDistancePoints,gridCoveragePoints,gridRecords,
   gridFeasibleRecords,gridBest,gridCrossCheckPass,gridConstraintCrossCheckPass,gridConstraintViolations,
   fullCandidateDistance,fullCandidateCoverage,tempFloorResult,exactEquilibriumCheck,
   candidateBisectionRoot,candidateFindRoot,candidateRootCrossCheck,candidateRootResidual,
   optimizerMassCheck,optimizerPowerCheck,optimizerPowerResidual,optimizerThermalCheck,optimizerStructuralCheck,
   structuralFloorResult,lowerDistance,gridTolerance,naturalStateAt,performanceStateAt,thermalStateAt,structuralStateAt,
   futureMassMargin,transverseMargin,torqueMargin,pvTemperatureMargin,reflectorTemperatureMargin,deflectionMargin,
   stressMargin,pretensionMargin,structuralModelGate,thermalOK,structOK,equilibriumOK,objective,
   candidateFeasibleQ,candidateMassResidual,rootSymbol,selectedCandidate,rootAtCandidate,
   candidateState,dynCandidate,meshCandidate,naturalCandidate,independentAcceleration,residualScale,
   objectiveAtCandidate},
  computed=phase1EnsureCalculated[];
  If[FailureQ[computed],Return[computed]];
  in=Phase1GetInputs[];
  exactEquilibriumCheck=Phase1SolveExactEquilibrium[];
  If[FailureQ[exactEquilibriumCheck],Return[exactEquilibriumCheck]];
  geo=phase1Geometry[in];mesh=phase1Mesh[in,geo,in["OptimizerMeshRadialCount"],in["OptimizerMeshAzimuthCount"]];
  optics=phase1Optics[in];sun=phase1SunVector[in["IncidenceAngle_deg"]];
  coeff=phase1MaterialMomentumCoefficients[mesh,sun,optics];illum=phase1Illumination[mesh,sun];
  loF=in["PVSearchRange"][[1]];hiF=in["PVSearchRange"][[2]];
  loR=in["DistanceSearchRange_m"][[1]];hiR=in["DistanceSearchRange_m"][[2]];
  (* Candidate functions are memoized by both independent optimizer variables. *)
  naturalStateAt[r_?NumericQ,f_?NumericQ] := naturalStateAt[r,f]=
    phase1NaturalCandidateAt[in,geo,mesh,optics,f,r];
  performanceStateAt[r_?NumericQ,f_?NumericQ] := performanceStateAt[r,f]=Module[{candidate=naturalStateAt[r,f],coupled},
    coupled=phase1CoupledPVThermal[candidate["Inputs"],geo,candidate["AttitudeMesh"],optics,candidate["Radiation"],f,r,0.];
    If[FailureQ[coupled],
      <|"Thermal"-><|"PVTemperature_K"->Infinity,"ReflectorTemperature_K"->Infinity,
          "AllThermalLimitsWithinBounds"->False,"PVThermalCouplingConverged"->False|>,
        "PVPerformance"-><|"SelectedDCOutput_W"->0.,"PVOutputDoesNotExceedAbsorbedPower"->False,
          "PVOutputDoesNotExceedSpecificPower"->False|>,"ConvergenceFailure"->coupled|>,coupled]];
  thermalStateAt[r_?NumericQ,f_?NumericQ] := performanceStateAt[r,f]["Thermal"];
  structuralStateAt[r_?NumericQ,f_?NumericQ] := structuralStateAt[r,f]=Module[{candidate=naturalStateAt[r,f]},
    phase1Structural[candidate["Inputs"],geo,candidate["Radiation"],f]];
  (* The optimization constraint is not zero-net-force equilibrium. Require a
     strictly positive radiation-only added-mass margin, while independently bounding
     the transverse natural-force residual and the natural torque residual. *)
  futureMassMargin[r_?NumericQ,f_?NumericQ] :=
    naturalStateAt[r,f]["Natural"]["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"];
  transverseMargin[r_?NumericQ,f_?NumericQ] :=
    naturalStateAt[r,f]["Natural"]["DerivedNaturalAccelerationTolerance_m_s2"]-
    naturalStateAt[r,f]["Natural"]["NetNaturalTransverseAccelerationResidual_m_s2"];
  torqueMargin[r_?NumericQ,f_?NumericQ] := naturalStateAt[r,f]["Natural"]["DerivedNaturalTorqueTolerance_Nm"]-
    naturalStateAt[r,f]["Natural"]["NaturalTorqueResidualMagnitude_Nm"];
  pvTemperatureMargin[r_?NumericQ,f_?NumericQ] := in["PVTemperatureLimit_K"]-thermalStateAt[r,f]["PVTemperature_K"];
  reflectorTemperatureMargin[r_?NumericQ,f_?NumericQ] := in["ReflectorTemperatureLimit_K"]-
    thermalStateAt[r,f]["ReflectorTemperature_K"];
  deflectionMargin[r_?NumericQ,f_?NumericQ] := structuralStateAt[r,f]["DeflectionMargin"];
  stressMargin[r_?NumericQ,f_?NumericQ] := structuralStateAt[r,f]["TensileStressMargin_Pa"];
  pretensionMargin[r_?NumericQ,f_?NumericQ] := structuralStateAt[r,f]["PretensionCapacityMargin_N_m"];
  structuralModelGate[r_?NumericQ,f_?NumericQ] := If[TrueQ[structuralStateAt[r,f]["StructuralScreenPass"]],1.,-1.];
  thermalOK[r_?NumericQ,f_?NumericQ] := TrueQ[thermalStateAt[r,f]["AllThermalLimitsWithinBounds"]];
  structOK[r_?NumericQ,f_?NumericQ] := TrueQ[structuralStateAt[r,f]["StructuralScreenPass"]];
  equilibriumOK[r_?NumericQ,f_?NumericQ] := TrueQ[
    futureMassMargin[r,f]>0. && transverseMargin[r,f]>=0. && torqueMargin[r,f]>=0.];
  candidateFeasibleQ[r_?NumericQ,f_?NumericQ] := TrueQ[
    loR<=r<=hiR && loF<=f<=hiF && equilibriumOK[r,f] && thermalOK[r,f] && structOK[r,f] &&
    TrueQ[performanceStateAt[r,f]["PVPerformance"]["PVOutputDoesNotExceedAbsorbedPower"]] &&
    TrueQ[performanceStateAt[r,f]["PVPerformance"]["PVOutputDoesNotExceedSpecificPower"]]];
  objective[r_?NumericQ,f_?NumericQ] := Module[{candidate,thermal,pv,power},
    candidate=naturalStateAt[r,f];thermal=thermalStateAt[r,f];
    pv=performanceStateAt[r,f]["PVPerformance"];
    power=phase1Power[candidate["Inputs"],pv];power["ConditionedDeliveredPower_W_PerPole"]
  ];
  (* The thermal and structural floors at the current coverage are reported as diagnostics only;
     candidate-specific calculated margins below are the actual optimization constraints. *)
  tempFloorResult=Phase1DistanceThermalFloor[];
  structuralFloorResult=phase1StructuralDistanceFloor[in,geo,mesh,optics,in["PVFraction"]];
  full=Quiet@Check[NMaximize[
    {objective[r,f],
      loR<=r<=hiR && loF<=f<=hiF && futureMassMargin[r,f]>0. &&
      transverseMargin[r,f]>=0. && torqueMargin[r,f]>=0. &&
      pvTemperatureMargin[r,f]>=0. && reflectorTemperatureMargin[r,f]>=0. &&
      deflectionMargin[r,f]>=0. && stressMargin[r,f]>=0. && pretensionMargin[r,f]>=0. &&
      structuralModelGate[r,f]>=0.},
    {r,f},MaxIterations->in["OptimizerMaxIterations"],
    WorkingPrecision->in["NumericalWorkingPrecision"]],$Failed];
  gridDistancePoints=Subdivide[loR,hiR,in["OptimizerGridPointCount"]];
  gridCoveragePoints=Subdivide[loF,hiF,in["OptimizerCoverageGridPointCount"]];
  gridRecords=Flatten[Table[
    With[{rr0=dr,ff0=fc},
      {If[candidateFeasibleQ[rr0,ff0],objective[rr0,ff0],-Infinity],rr0,ff0,
       candidateFeasibleQ[rr0,ff0]}],
    {dr,gridDistancePoints},{fc,gridCoveragePoints}],1];
  gridFeasibleRecords=Select[gridRecords,TrueQ[#[[4]]]&];
  gridConstraintViolations=Select[gridRecords,Not@TrueQ[#[[4]]]&];
  gridConstraintCrossCheckPass=(Length[gridFeasibleRecords]>0);
  gridBest=If[gridConstraintCrossCheckPass,First@MaximalBy[gridFeasibleRecords,First],Missing["NoGridFeasiblePoint"]];
  validOptimizationResultQ[res_] := Module[{candR,candF},
    If[!ListQ[res] || Length[res]!=2 || !ListQ[res[[2]]],Return[False]];
    candR=Quiet@Check[N[r/.res[[2]]],Indeterminate];candF=Quiet@Check[N[f/.res[[2]]],Indeterminate];
    TrueQ[NumericQ[res[[1]]] && -Infinity<res[[1]]<Infinity && NumericQ[candR] && NumericQ[candF] &&
      candidateFeasibleQ[candR,candF]]
  ];
  If[validOptimizationResultQ[full],
    fullCandidateDistance=N[r/.full[[2]]];fullCandidateCoverage=N[f/.full[[2]]],
    fullCandidateDistance=Missing["NoCandidate"];fullCandidateCoverage=Missing["NoCandidate"]];
  gridTolerance=If[gridConstraintCrossCheckPass,
    in["OptimizerGridCrossCheckRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[gridBest[[1]]],
      Abs[If[NumericQ[fullCandidateDistance]&&NumericQ[fullCandidateCoverage],objective[fullCandidateDistance,fullCandidateCoverage],0.]]],Infinity];
  gridCrossCheckPass=If[validOptimizationResultQ[full]&&gridConstraintCrossCheckPass,
    TrueQ[objective[fullCandidateDistance,fullCandidateCoverage]+gridTolerance>=gridBest[[1]]],False];
  (* A coarse grid candidate is diagnostic only; it is never promoted to an accepted optimizer result. *)
  selectedCandidate=If[validOptimizationResultQ[full],full,
    If[gridConstraintCrossCheckPass,{gridBest[[1]],{r->gridBest[[2]],f->gridBest[[3]]}},$Failed]];
  If[!ListQ[selectedCandidate],
    results=<|"Status"->"No candidate satisfies the positive radiation-only mass-growth margin, transverse-force and torque tolerances, thermal and structural constraints within the configured distance and PV-coverage intervals.",
      "FullConstraintOptimization"->full,"IndependentFeasibleGridBest"->gridBest,
      "GridConstraintCrossCheck"->gridConstraintCrossCheckPass,
      "ThermalDistanceFloorAtCurrentCoverage"->tempFloorResult,
      "StructuralDistanceFloorAtCurrentCoverage"->structuralFloorResult,
      "DistanceSearchRange_m"->{loR,hiR},"PVSearchRange"->{loF,hiF},
      "ExactNaturalEquilibrium"->False,"StaticConstraintProblemFeasible"->False,
      "DynamicCandidateAcceptancePassed"->False,"FullConstraintProblemFeasible"->False|>;
    $Phase1State=Join[$Phase1State,<|"Results"->Join[$Phase1State["Results"],<|"JointOptimization"->results|>]|>];
    phase1Audit["JointOptimizationNoFeasibleCandidate",results];Return[results]
  ];
  rr=N[r/.selectedCandidate[[2]]];ff=N[f/.selectedCandidate[[2]]];
  candidateState=naturalStateAt[rr,ff];radCandidate=candidateState["Radiation"];
  massCandidate=candidateState["Mass"];dynCandidate=candidateState["Dynamics"];
  meshCandidate=candidateState["AttitudeMesh"];naturalCandidate=candidateState["Natural"];
  thermalCandidate=thermalStateAt[rr,ff];pvCandidate=performanceStateAt[rr,ff]["PVPerformance"];
  powerCandidate=phase1Power[candidateState["Inputs"],pvCandidate];structureCandidate=structuralStateAt[rr,ff];
  independentAcceleration=(radCandidate["NetRadiationForceVector_N"]+
    naturalCandidate["GravityLoads"]["TotalGravityForce_N"]+naturalCandidate["SolarWindLoads"]["TotalForce_N"])/massCandidate["TotalMass_kg"];
  residualScale=Max[Sqrt[$MinMachineNumber],Norm[independentAcceleration],
    Norm[naturalCandidate["NetNaturalAccelerationVector_m_s2"]]];
  optimizerMassCheck=TrueQ[massCandidate["MassLedgerCloses"] &&
    Norm[independentAcceleration-naturalCandidate["NetNaturalAccelerationVector_m_s2"]]<=
      in["AccelerationCrossCheckRelativeTolerance"] residualScale];
  objectiveAtCandidate=objective[rr,ff];
  optimizerPowerResidual=Abs[objectiveAtCandidate-powerCandidate["ConditionedDeliveredPower_W_PerPole"]];
  optimizerPowerCheck=TrueQ[optimizerPowerResidual<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[pvCandidate["SelectedDCOutput_W"]]]];
  optimizerThermalCheck=TrueQ[TrueQ[thermalOK[rr,ff]]===TrueQ[thermalCandidate["AllThermalLimitsWithinBounds"]]];
  optimizerStructuralCheck=TrueQ[TrueQ[structOK[rr,ff]]===TrueQ[structureCandidate["StructuralScreenPass"]]];
  (* Independent bisection and FindRoot checks of the radial mass-balance coverage root at the selected distance. *)
  candidateMassResidual[z_?NumericQ] := naturalStateAt[rr,z]["Natural"]["NetNaturalAccelerationVector_m_s2"][[1]]/
    (in["SolarGravitationalParameter_m3_s2"]/rr^2);
  candidateBisectionRoot=phase1BracketedBisection[candidateMassResidual,{loF,hiF},
    in["ExactEquilibriumRelativeTolerance"],in["OptimizerMaxIterations"]];
  candidateFindRoot=Quiet@Check[FindRoot[candidateMassResidual[rootSymbol]==0.,
    {rootSymbol,ff,loF,hiF},Method->"Brent",WorkingPrecision->in["NumericalWorkingPrecision"]],$Failed];
  rootAtCandidate=If[candidateFindRoot===$Failed,Missing["FindRootFailed"],N[rootSymbol/.candidateFindRoot]];
  candidateRootCrossCheck=NumericQ[candidateBisectionRoot]&&NumericQ[rootAtCandidate]&&
    Abs[candidateBisectionRoot-rootAtCandidate]<=in["ExactEquilibriumRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[ff],Abs[candidateBisectionRoot]];
  candidateRootResidual=Abs[candidateMassResidual[ff]];
  capacity=If[in["ICARUSStationForceCapacity_N"]===Automatic,Automatic,in["ICARUSStationForceCapacity_N"]];
  fullFeasible=validOptimizationResultQ[full] && gridCrossCheckPass && gridConstraintCrossCheckPass &&
    optimizerMassCheck && optimizerPowerCheck && optimizerThermalCheck && optimizerStructuralCheck &&
    massCandidate["MassLedgerCloses"] && TrueQ[naturalCandidate["FutureMassGrowthTargetPass"]] &&
    TrueQ[naturalCandidate["TransverseForceBalancePass"]] && TrueQ[naturalCandidate["ExactTorqueEquilibrium"]] &&
    thermalCandidate["AllThermalLimitsWithinBounds"] && structureCandidate["StructuralScreenPass"] &&
    TrueQ[pvCandidate["PVOutputDoesNotExceedAbsorbedPower"]] && TrueQ[pvCandidate["PVOutputDoesNotExceedSpecificPower"]] &&
    TrueQ[thermalCandidate["PVThermalCouplingConverged"]];
  results=<|"Status"->"Joint distance/PV-coverage optimization; every candidate is evaluated with patch-integrated radiation, distributed gravity and gravity-gradient torque, its own mass/inertia, PV output, thermal state and structural margins.",
    "InputSnapshot"->in,
    "OptimizationGeometry"->geo,"OptimizationMeshResolution"->mesh["MeshResolution"],
    "OptimizationMomentumCoefficients"->coeff,"OptimizationIllumination"->illum,
    "ThermalDistanceFloorAtCurrentCoverage"->tempFloorResult,
    "StructuralDistanceFloorAtCurrentCoverage"->structuralFloorResult,
    "DistanceSearchRange_m"->{loR,hiR},"PVSearchRange"->{loF,hiF},
    "FullConstraintOptimization"->full,"FullConstraintOptimizerResultValid"->validOptimizationResultQ[full],
    "IndependentInitialDistanceExactEquilibriumDiagnostic"->exactEquilibriumCheck,
    "RadialBalanceThresholdRootBisectionDiagnosticOnly"->candidateBisectionRoot,
    "RadialBalanceThresholdRootFindRootDiagnosticOnly"->candidateFindRoot,
    "RadialBalanceThresholdRootCrossCheckDiagnosticOnly"->candidateRootCrossCheck,
    "CandidateRadialBalanceThresholdResidualNormalizedToSolarGravityDiagnosticOnly"->candidateRootResidual,
    "OptimizerMassVectorCrossCheck"->optimizerMassCheck,
    "OptimizerPowerOutputCrossCheck"->optimizerPowerCheck,
    "OptimizerPowerOutputResidual_W"->optimizerPowerResidual,
    "OptimizerThermalFunctionCrossCheck"->optimizerThermalCheck,
    "OptimizerStructuralFunctionCrossCheck"->optimizerStructuralCheck,
    "OptimizerNaturalForceResidual_m_s2"->naturalCandidate["NaturalForceResidualMagnitude_m_s2"],
    "OptimizerNaturalTorqueResidual_Nm"->naturalCandidate["NaturalTorqueResidualMagnitude_Nm"],
    "ScalarMassFeasibilityDiagnosticOnly"->massCandidate["MassFeasible"],
    "OptimizerPVTemperatureMargin_K"->pvTemperatureMargin[rr,ff],
    "OptimizerReflectorTemperatureMargin_K"->reflectorTemperatureMargin[rr,ff],
    "OptimizerStructuralDeflectionMargin"->deflectionMargin[rr,ff],
    "OptimizerStructuralStressMargin_Pa"->stressMargin[rr,ff],
    "OptimizerStructuralPretensionMargin_N_m"->pretensionMargin[rr,ff],
    "OptimizerExactNaturalEquilibrium"->naturalCandidate["ExactNaturalEquilibrium"],
    "CandidateKind"->Which[TrueQ[fullFeasible],"StaticGatesPassedCandidateAwaitingDynamicAcceptance",
      validOptimizationResultQ[full],"NMaximizeCandidateFailedOneOrMoreStaticCrossChecks",
      True,"IndependentTwoDimensionalGridDiagnosticOnly"],
    "IndependentDistanceGridPointCount"->Length[gridDistancePoints],
    "IndependentCoverageGridPointCount"->Length[gridCoveragePoints],
    "IndependentGridPointCount"->Length[gridRecords],
    "IndependentGridFeasiblePointCount"->Length[gridFeasibleRecords],
    "IndependentTwoDimensionalGridBestFeasiblePoint"->gridBest,
    "IndependentGridConstraintCrossCheck"->gridConstraintCrossCheckPass,
    "IndependentGridConstraintViolationCount"->Length[gridConstraintViolations],
    "IndependentGridConstraintCrossCheckRule"->"At least one point on the user-configured distance-by-coverage grid must satisfy all natural force, torque, thermal and structural constraints; all other sampled points are counted as infeasible.",
    "OptimizerBeatsIndependentTwoDimensionalGrid"->gridCrossCheckPass,
    "StaticConstraintProblemFeasible"->fullFeasible,
    "FullConstraintProblemFeasible"->False,
    "DynamicCandidateAcceptancePassed"->False,
    "FullConstraintProblemFeasibleDefinition"->"True only when positive radiation-only future added-mass headroom, transverse-force tolerance, natural torque tolerance, thermal and structural constraints, solver/grid and independent calculation gates pass AND a transient candidate-local recalculation plus integrated dynamic acceptance checks pass. Exact zero-net-force roots are diagnostic only.",
    "CandidateDistance_m"->rr,"CandidateDistance_AU"->rr/in["AstronomicalUnit_m"],
    "CandidatePVFraction"->ff,"CandidateReflectiveFraction"->1.-ff,
    "CandidateDeliveredPower_W_PerPole"->powerCandidate["ConditionedDeliveredPower_W_PerPole"],
    "OptimizerObjectiveDeliveredPower_W_PerPole"->objectiveAtCandidate,
    "CandidateDeliveredPower_W_TwoPoles"->Missing["PerPoleOptimizerOnly; reconcile shared design across both poles"],
    "MassBalance"->massCandidate,"NaturalEquilibrium"->naturalCandidate,
    "DynamicInitialConditions"->dynCandidate,"Thermal"->thermalCandidate,"PVThermalCouplingFailure"->Lookup[performanceStateAt[rr,ff],"ConvergenceFailure",Missing["None"]],
    "PowerLedger"->powerCandidate,"StructuralScreen"->structureCandidate,
    "ICARUSCapacityPerStation_N"->capacity,
    "ExactNaturalEquilibrium"->naturalCandidate["ExactNaturalEquilibrium"],
    "ExactNaturalEquilibriumPerPoleAssembly"->naturalCandidate["ExactNaturalEquilibrium"],
    "WholeTwoPoleSystemEquilibriumEvaluated"->False,
    "OptimizationPowerReferenceEpoch"->"Start-of-mission; mission-end degradation is calculated separately and is not included in this objective.",
    "AssumptionPolicy"->"All non-universal design/material/operating register values are user-approved assumptions or per-pole derived values, centrally stored and separately classified. Both distance and PV coverage are independent optimization variables. Candidate natural equilibrium is recomputed at each pair using attitude-dependent patch radiation and distributed solar gravity/torque. Thermal/structural/dynamic models remain explicitly reduced-order screens; assumptions do not imply qualification."|>;
  (* Recalculate and dynamically integrate every statically feasible optimizer candidate
     in a temporary pole-local snapshot. No optimizer value is written to live inputs. *)
  candidateEvaluation=If[TrueQ[fullFeasible],
    phase1EvaluateCandidateTransient[rr,ff,<|
      "FullJointConstraintOptimizationFeasible"->TrueQ[fullFeasible],
      "OptimizerIndependentTwoDimensionalGridCrossCheck"->TrueQ[gridCrossCheckPass],
      "OptimizerCandidateCoverageRootCrossCheck"->TrueQ[candidateRootCrossCheck],
      "OptimizerMassVectorCrossCheck"->TrueQ[optimizerMassCheck],
      "OptimizerPowerOutputCrossCheck"->TrueQ[optimizerPowerCheck],
      "OptimizerThermalFunctionCrossCheck"->TrueQ[optimizerThermalCheck],
      "OptimizerStructuralFunctionCrossCheck"->TrueQ[optimizerStructuralCheck]|>],
    <|"DynamicSimulation"->Missing["NotRunBecauseFullStaticOptimizerGatesDidNotPass"],
      "AcceptanceChecks"-><|"FullJointConstraintOptimizationFeasible"->False|>,
      "ModelledAcceptanceUnderAssumptions"->False,"CandidateEvaluatedTransiently"->False,
      "CandidateAppliedToCentralInputs"->False,"CandidateInputsRetained"->False,
      "Status"->"Dynamic evaluation was not run because the full static optimizer gates did not pass."|>
  ];
  dynamicAccepted=TrueQ[Lookup[candidateEvaluation,"ModelledAcceptanceUnderAssumptions",False]] &&
    TrueQ[Lookup[candidateEvaluation,"NoLivePoleStateMutation",False]];
  results=Join[results,candidateEvaluation,<|
    "StaticConstraintProblemFeasible"->TrueQ[fullFeasible],
    "DynamicCandidateAcceptancePassed"->dynamicAccepted,
    "FullConstraintProblemFeasible"->(TrueQ[fullFeasible]&&TrueQ[dynamicAccepted]),
    "FullConstraintProblemAcceptanceScope"->"This flag includes both the independent static optimizer cross-checks and the transient per-pole integrated dynamic acceptance checks; a static-only candidate is not an accepted full candidate."
  |>];
  $Phase1State=Join[$Phase1State,<|"Results"->Join[$Phase1State["Results"],<|"JointOptimization"->results|>]|>];
  phase1Audit["JointOptimizationCompleted",KeyDrop[results,"DynamicSimulation"]];
  results
];

(* ========================================================================
   6. DISTURBANCES, 3-D ROTATION, ICARUS AND INTEGRATED DYNAMICS
   ======================================================================== *)

phase1Quaternion[theta_List,tol_:Sqrt[$MachineEpsilon]] := Module[{a=Norm[theta]},If[a<tol,{1.,0.,0.,0.},Join[{Cos[a/2.]},Sin[a/2.] Normalize[theta]]]];
phase1QuaternionToRotationVector[qIn_List,tol_:Sqrt[$MachineEpsilon]] := Module[{qv=Normalize[qIn],vnorm,angle},
  If[qv[[1]]<0.,qv=-qv];vnorm=Norm[qv[[2;;4]]];
  If[vnorm<tol,{0.,0.,0.},angle=2. ArcTan[qv[[1]],vnorm];(angle/vnorm) qv[[2;;4]]]
];
phase1QuaternionRate[q_,w_] := 0.5 {{-q[[2]],-q[[3]],-q[[4]]},{q[[1]],-q[[4]],q[[3]]},{q[[4]],q[[1]],-q[[2]]},{-q[[3]],q[[2]],q[[1]]}}.w;


phase1CrossProductMatrix[v_List] := {{0.,-v[[3]],v[[2]]},{v[[3]],0.,-v[[1]]},{-v[[2]],v[[1]],0.}};

(* Classical first-order gravity-gradient torque for a rigid body whose dimensions
   are small relative to heliocentric distance. The pole-local radial direction is
   expressed in body coordinates; each pole uses its own distance, inertia, and attitude. *)
phase1GravityGradientTorqueBody[in_Association,inertia_?MatrixQ,q_List] := Module[{radialBody},
  (* The ODE is assembled symbolically, so the initial and sampled trajectory gates
     protect those boundaries. During numeric RHS evaluation, also reject any
     malformed/zero-norm attitude before phase1RotationMatrix calls Normalize. *)
  If[VectorQ[q,NumericQ]&&!phase1FiniteNonzeroQuaternionQ[q],
    Return[Failure["InvalidGravityGradientAttitudeQuaternion",<|"Quaternion"->q,
      "Requirement"->"Finite-real four-component quaternion with strictly positive finite norm"|>]]
  ];
  radialBody=Transpose[phase1RotationMatrix[q]].{1.,0.,0.};
  3. in["SolarGravitationalParameter_m3_s2"]/in["Distance_m"]^3 Cross[radialBody,inertia.radialBody]
];

(* Linearize the exact gravity-gradient torque about the radially aligned attitude.
   The generalized eigenproblem is mass-normalized with the pole's own inertia tensor.
   Positive eigenvalues identify exponentially unstable modes; negative eigenvalues
   identify oscillatory modes; zero eigenvalues are neutral (including spin about the
   Sun-radial axis). Damping is applied only to stable oscillatory modes, so it cannot
   conceal a physically unstable gravity-gradient mode. *)
phase1GravityGradientLinearization[in_Association,inertia_?MatrixQ] := Module[
  {radial={1.,0.,0.},skew,kappa,stiffness,inertiaSqrt,inertiaInvSqrt,h,
   eigenvalues,eigenvectors,ordered,modalBasis,tolerance,modalFrequencies,
   modalPeriods,unstableRates,modeClass,dampingMatrix,modes,modeScale},
  If[Dimensions[inertia]=!={3,3} || !MatrixQ[inertia,NumericQ] ||
      !TrueQ[Min[Eigenvalues[inertia]]>0.],
    Return[Failure["InvalidInertiaForGravityGradientLinearization",<|"InertiaTensor"->inertia|>]]
  ];
  skew=phase1CrossProductMatrix[radial];
  kappa=3. in["SolarGravitationalParameter_m3_s2"]/in["Distance_m"]^3;
  stiffness=kappa (skew.inertia-phase1CrossProductMatrix[inertia.radial]).skew;
  stiffness=N[(stiffness+Transpose[stiffness])/2.];
  inertiaSqrt=MatrixPower[inertia,1/2];
  inertiaInvSqrt=MatrixPower[inertia,-1/2];
  h=N[inertiaInvSqrt.stiffness.inertiaInvSqrt];
  h=(h+Transpose[h])/2.;
  {eigenvalues,eigenvectors}=Eigensystem[h];
  ordered=SortBy[Transpose[{Re@N[eigenvalues],N[eigenvectors]}],First];
  eigenvalues=ordered[[All,1]];
  eigenvectors=ordered[[All,2]];
  modalBasis=Transpose[eigenvectors];
  modeScale=Max[Abs[eigenvalues]];
  tolerance=Which[
    modeScale==0.,0.,
    modeScale>$MinMachineNumber/(100. $MachineEpsilon),100. $MachineEpsilon modeScale,
    True,$MinMachineNumber
  ];
  modalFrequencies=Map[If[# < -tolerance,Sqrt[-#],0.]&,eigenvalues];
  modalPeriods=Map[If[# < -tolerance,2. Pi/Sqrt[-#],Missing["NoOscillatoryGravityGradientMode"]]&,eigenvalues];
  unstableRates=Map[If[# > tolerance,Sqrt[#],0.]&,eigenvalues];
  modeClass=Which[
    AnyTrue[eigenvalues,#>tolerance&],"Unstable",
    AnyTrue[eigenvalues,# < -tolerance&],"TransverselyStableWithNeutralModes",
    True,"Neutral"
  ];
  dampingMatrix=2. in["WobbleDampingRatio"] inertiaSqrt.modalBasis.
    DiagonalMatrix[modalFrequencies].Transpose[modalBasis].inertiaSqrt;
  modes=Table[<|"ModeIndex"->i,"Eigenvalue_s2"->eigenvalues[[i]],
    "ModeType"->Which[eigenvalues[[i]]>tolerance,"Unstable",
      eigenvalues[[i]] < -tolerance,"OscillatoryStable",True,"Neutral"],
    "NaturalFrequency_rad_s"->If[eigenvalues[[i]] < -tolerance,modalFrequencies[[i]],Missing["NoOscillatoryMode"]],
    "Period_s"->modalPeriods[[i]],
    "InstabilityGrowthRate_s"->If[eigenvalues[[i]]>tolerance,unstableRates[[i]],Missing["NoUnstableGrowthMode"]]|>,{i,3}];
  <|"ReferenceAttitude"->"Body x-axis aligned with the pole-local Sun-radial direction.",
    "GravityGradientStiffnessMatrix_Nm_per_rad"->stiffness,
    "MassNormalizedLinearization_s2"->h,
    "LinearizedModeEigenvalues_s2"->eigenvalues,
    "Modes"->modes,
    "StableNaturalFrequencies_rad_s"->Pick[modalFrequencies,eigenvalues,_?(# < -tolerance&)],
    "StableNaturalPeriods_s"->Pick[modalPeriods,eigenvalues,_?(# < -tolerance&)],
    "UnstableGrowthRates_s"->Pick[unstableRates,eigenvalues,_?(# > tolerance&)],
    "NeutralModeCount"->Count[eigenvalues,_?(Abs[#]<=tolerance&)],
    "LinearizedModeClass"->modeClass,
    "LinearizedTransverseStabilityPass"->(modeClass==="TransverselyStableWithNeutralModes"),
    "EigenvalueTolerance_s2"->tolerance,
    "DampingMatrix_Nm_s_per_rad"->N[dampingMatrix],
    "DampingAppliedOnlyToStableModes"->True,
    "Distance_m"->in["Distance_m"],
    "InertiaTensor_kg_m2"->inertia|>
];

(* Software-only synthetic tests. These test pure mathematical helpers without
   requiring collector inputs and without changing the central model state. *)
Phase1RunSoftwareSelfTests[] := Module[
  {rotationVector = {0.13, -0.21, 0.08}, q, rotation, stations, wrench,
   irradiance1, irradiance2, root, bisectionChecks, checks, stateBefore, stateAfter,
   testInputs,doubledDistanceInputs,diskInertia,rodInertia,sphereInertia,diskModes,rodModes,sphereModes,
   rodModesDoubledDistance,thetaStep,numericalDiskStiffness,
   aluminumMaterialInput,aluminumEffectiveMass,
   capacityProbe,capacityFiniteProbe,capacityInvalidProbe,
   controllerUnknownCapacity,controllerFiniteCapacity,largeStations,largeWrench,largeScaleControllerResults,
   taskGeometryReady,taskGeometryMissing,
   taskRadiationMissing,taskUnknownName,taskIntegratedMissing,taskSoftwareOnly,taskCrossPoleBlocked,taskUnknownPublic,
   stationDemandProbe,stationDemandInvalidProbe,requirementsProbe,independentTaskFixture,independentGeometryRun,independentMeshRun,independentOpticsRun,independentGeometryStatus,independentPoleState,independentDerived,independentPole2Update,independentStatusAfterPole2Update,independentSharedUpdate,independentStatusAfterSharedUpdate,independentInitialRadiationRun,independentInitialRadiationStatus,independentInitialRadiation},
  stateBefore = $Phase1State;
  q = phase1Quaternion[rotationVector];
  rotation = phase1RotationMatrix[q];
  stations = {{0., 1., 0.}, {0., 0., 1.}, {0., -1., 0.}, {0., 0., -1.}};
  wrench = phase1WrenchMatrix[stations];
  irradiance1 = phase1SolarIrradiance[<|"SolarLuminosity_W" -> 4. Pi|>, 1.];
  irradiance2 = phase1SolarIrradiance[<|"SolarLuminosity_W" -> 4. Pi|>, 2.];
  root = phase1BracketedBisection[Function[x, x^2 - 2.], {1., 2.}, 10.^-10, 100];
  bisectionChecks = <|
    "InteriorRootConverges" -> TrueQ[NumericQ[root] && Abs[root - Sqrt[2.]] < 10.^-8],
    "EndpointRootAccepted" -> TrueQ[phase1BracketedBisection[Function[x, x - 1.], {1., 2.}, 10.^-10, 20] === 1.],
    "UnbracketedRootRejected" -> (phase1BracketedBisection[Function[x, x^2 + 1.], {-1., 1.}, 10.^-8, 20] === $Failed)
  |>;
  testInputs=<|"SolarGravitationalParameter_m3_s2"->1.3271244*10^20,"Distance_m"->149597870700.,"WobbleDampingRatio"->0.|>;
  diskInertia=DiagonalMatrix[{10.,5.,5.}];
  rodInertia=DiagonalMatrix[{1.,5.,5.}];
  sphereInertia=IdentityMatrix[3];
  diskModes=phase1GravityGradientLinearization[testInputs,diskInertia];
  rodModes=phase1GravityGradientLinearization[testInputs,rodInertia];
  sphereModes=phase1GravityGradientLinearization[testInputs,sphereInertia];
  doubledDistanceInputs=Join[testInputs,<|"Distance_m"->2. testInputs["Distance_m"]|>];
  rodModesDoubledDistance=phase1GravityGradientLinearization[doubledDistanceInputs,rodInertia];
  aluminumMaterialInput=<|"MembraneSubstrateMaterialName"->"1060-O aluminum foil; provisional ultrathin-film baseline",
    "MembraneSubstrateMaterialClass"->"AluminumFilm","AluminumFoilThickness_m"->1.0*10^-7,
    "AluminumDensity_kg_m3"->2705.0|>;
  aluminumEffectiveMass=phase1EffectiveSubstrateArealMass[aluminumMaterialInput];
  capacityProbe=phase1ApplyStationCapacity[{{3.,4.,0.}},Automatic];
  capacityFiniteProbe=phase1ApplyStationCapacity[{{3.,4.,0.}},3.];
  capacityInvalidProbe=phase1ApplyStationCapacity[{{3.,4.,0.}},0.];
  controllerUnknownCapacity=phase1Controller[<|"WrenchMatrix"->wrench,"StationPositionsLocal_m"->stations|>,UnitVector[6,1],Automatic];
  controllerFiniteCapacity=phase1Controller[<|"WrenchMatrix"->wrench,"StationPositionsLocal_m"->stations|>,UnitVector[6,1],0.01];
  largeStations=10.^8 stations;
  largeWrench=phase1WrenchMatrix[largeStations];
  largeScaleControllerResults=Table[phase1Controller[<|"WrenchMatrix"->largeWrench,
      "StationPositionsLocal_m"->largeStations|>,UnitVector[6,i],Infinity],{i,6}];
  taskGeometryReady=phase1TaskInputStatusFromInputs[<|"GeometryProfileModel"->"SphericalCapSurrogate",
    "PerPoleProjectedArea_m2"->100.,"CapDepthToPlanformRadius"->0.2|>,"Geometry"];
  taskGeometryMissing=phase1TaskInputStatusFromInputs[<|"GeometryProfileModel"->"SphericalCapSurrogate",
    "CapDepthToPlanformRadius"->0.2|>,"Geometry"];
  taskRadiationMissing=phase1TaskInputStatusFromInputs[<||>,"RadiationLoads"];
  taskUnknownName=phase1TaskInputStatusFromInputs[<||>,"NotARegisteredTask"];
  taskIntegratedMissing=phase1TaskInputStatusFromInputs[<||>,"IntegratedSimulation"];
  taskSoftwareOnly=phase1TaskInputStatusFromInputs[<||>,"SoftwareSelfTests"];
  taskCrossPoleBlocked=Block[{$Phase1ExecutingPole=True,$Phase1CurrentPole="Pole1"},
    Phase1TaskInputStatus["Pole2","NaturalEquilibrium"]];
  taskUnknownPublic=Phase1TaskInputStatus["NotARegisteredTask"];
  stationDemandProbe=phase1StationDemandSummary[{{0.,1.,0.},{0.,0.,2.}},
    {{{0.,0.,3.},{4.,0.,0.}},{{0.,0.,2.},{0.,3.,0.}}}];
  stationDemandInvalidProbe=phase1StationDemandSummary[{{0.,1.,0.}},{{{1.,0.,0.},{0.,1.,0.}}}];
  requirementsProbe=Phase1InputRequirements[];
  independentTaskFixture=Block[{$Phase1State=Join[$Phase1State,<|
      "Inputs"->Join[$Phase1State["Inputs"],<|
        "GeometryProfileModel"->"SphericalCapSurrogate","PerPoleProjectedArea_m2"->100.,
        "CapDepthToPlanformRadius"->0.2,"MeshRadialCount"->16,"MeshAzimuthCount"->32,
        "MeshAreaRelativeTolerance"->0.01,"ReflectionModel"->"Specular",
        "ReflectorSolarReflectivity"->0.999,"ReflectorSolarTransmissivity"->0.,
        "PVSolarReflectivity"->0.1,"PVSolarTransmissivity"->0.,
        "OpticalClosureTolerance"->10.^-12,"PVFraction"->0.005|>],
      "PoleOperatingInputs"->Join[$Phase1State["PoleOperatingInputs"],<|
        "Pole1"->Join[$Phase1State["PoleOperatingInputs"]["Pole1"],<|
          "Distance_m"->149597870700.,"IncidenceAngle_deg"->0.|>]|>],
      "PoleStates"-><||>,"AuditLog"->{}, "LastRun"->Missing["NotRun"]|>]},
    Module[{g,m,o,st,ps,pole2Update,statusAfterPole2,sharedUpdate,statusAfterShared,poleStatesCleared},
      g=Phase1RunPoleTask["Pole1","Geometry"];
      st=Phase1TaskInputStatus["Pole1","Geometry"];
      m=Phase1RunPoleTask["Pole1","SurfaceMesh"];
      o=Phase1RunPoleTask["Pole1","OpticalRegister"];
      r=Phase1RunPoleTask["Pole1","InitialRadiationLoads"];
      rs=Phase1TaskInputStatus["Pole1","InitialRadiationLoads"];
      ps=Phase1GetPoleState["Pole1"];
      pole2Update=Phase1SetPoleOperatingInputs["Pole2",<|"Distance_m"->1.|>];
      statusAfterPole2=Phase1TaskInputStatus["Pole1","Geometry"];
      sharedUpdate=Phase1SetInputs[<|"PerPoleProjectedArea_m2"->101.|>];
      statusAfterShared=Phase1TaskInputStatus["Pole1","Geometry"];
      poleStatesCleared=Lookup[$Phase1State,"PoleStates",<||>]===<||>;
      <|"GeometryRun"->g,"GeometryStatusAfterRun"->st,
        "MeshRun"->m,"OpticsRun"->o,"InitialRadiationRun"->r,
        "InitialRadiationStatusAfterRun"->rs,"PoleState"->ps,
        "Pole2Update"->pole2Update,"GeometryStatusAfterPole2Update"->statusAfterPole2,
        "SharedUpdate"->sharedUpdate,"GeometryStatusAfterSharedUpdate"->statusAfterShared,
        "PoleStatesEmptyAfterSharedUpdate"->poleStatesCleared,
        "Pole2StateAbsent"->!KeyExistsQ[Lookup[$Phase1State,"PoleStates",<||>],"Pole2"],
        "SharedInputFixtureRetained"->TrueQ[$Phase1State["Inputs"]["PerPoleProjectedArea_m2"]===101.]|>
    ]
  ];
  independentGeometryRun=Lookup[independentTaskFixture,"GeometryRun",$Failed];
  independentMeshRun=Lookup[independentTaskFixture,"MeshRun",$Failed];
  independentOpticsRun=Lookup[independentTaskFixture,"OpticsRun",$Failed];
  independentInitialRadiationRun=Lookup[independentTaskFixture,"InitialRadiationRun",$Failed];
  independentInitialRadiationStatus=Lookup[independentTaskFixture,"InitialRadiationStatusAfterRun",<||>];
  independentGeometryStatus=Lookup[independentTaskFixture,"GeometryStatusAfterRun",<||>];
  independentPoleState=Lookup[independentTaskFixture,"PoleState",<||>];
  independentDerived=Lookup[independentPoleState,"Derived",<||>];
  independentInitialRadiation=Lookup[independentDerived,"InitialRadiationLoads",<||>];
  thetaStep=10.^-6;
  numericalDiskStiffness=Transpose@Table[
    (phase1GravityGradientTorqueBody[testInputs,diskInertia,phase1Quaternion[thetaStep UnitVector[3,j]]]-
      phase1GravityGradientTorqueBody[testInputs,diskInertia,phase1Quaternion[-thetaStep UnitVector[3,j]]])/(2. thetaStep),{j,3}];
  checks = <|
    "QuaternionFiniteAndUnit" -> TrueQ[VectorQ[q, NumericQ] && Length[q] == 4 && Abs[Norm[q] - 1.] < 10.^-12],
    "QuaternionRoundTrip" -> TrueQ[Norm[phase1QuaternionToRotationVector[q] - rotationVector] < 10.^-10],
    "RotationMatrixOrthogonal" -> TrueQ[Norm[Flatten[rotation.Transpose[rotation] - IdentityMatrix[3]]] < 10.^-10],
    "RotationMatrixProper" -> TrueQ[Abs[Det[rotation] - 1.] < 10.^-10],
    "WrenchMatrixDimensions" -> TrueQ[Dimensions[wrench] === {6, 12}],
    "FourStationWrenchMatrixFullRank" -> TrueQ[MatrixRank[wrench] == 6],
    "SolarIrradianceInverseSquare" -> TrueQ[NumericQ[irradiance1] && NumericQ[irradiance2] && Abs[irradiance2/irradiance1 - 1./4.] < 10.^-12],
    "InvalidSolarDistanceRejected" -> FailureQ[phase1SolarIrradiance[<|"SolarLuminosity_W" -> 4. Pi|>, 0.]],
    "GravityGradientStiffnessMatchesFiniteDifference" -> TrueQ[Norm[numericalDiskStiffness-diskModes["GravityGradientStiffnessMatrix_Nm_per_rad"]]/Max[1.,Norm[numericalDiskStiffness]]<10.^-8],
    "RadiallyAlignedThinDiskIsClassifiedUnstable" -> TrueQ[diskModes["LinearizedModeClass"]==="Unstable"&&Length[diskModes["UnstableGrowthRates_s"]]==2],
    "RadiallyAlignedRodHasTwoStableTransverseModes" -> TrueQ[rodModes["LinearizedModeClass"]==="TransverselyStableWithNeutralModes"&&Length[rodModes["StableNaturalPeriods_s"]]==2],
    "SphericalInertiaHasOnlyNeutralGravityGradientModes" -> TrueQ[sphereModes["LinearizedModeClass"]==="Neutral"&&sphereModes["NeutralModeCount"]==3],
    "GravityGradientPeriodsScaleAsDistanceThreeHalves" -> TrueQ[
      Length[rodModes["StableNaturalPeriods_s"]]==2 && Length[rodModesDoubledDistance["StableNaturalPeriods_s"]]==2 &&
      Max[Abs[rodModesDoubledDistance["StableNaturalPeriods_s"]/rodModes["StableNaturalPeriods_s"]-2.^(3./2.)]]<10.^-10],
    "WobbleModelIsInternalNotProjectInput" -> TrueQ[
      MemberQ[$Phase1ReferenceAndSoftwareDefaultKeys,"WobbleRestoringModel"] &&
      !MemberQ[Flatten[Values[$Phase1InputCategories]],"WobbleRestoringModel"]],
    "AluminumSubstrateMassDerivedFromThicknessAndDensity" -> TrueQ[
      Abs[aluminumEffectiveMass-2.705*10^-4]<10.^-16 &&
      SameQ[aluminumMaterialInput["AluminumFoilThickness_m"]  aluminumMaterialInput["AluminumDensity_kg_m3"],aluminumEffectiveMass]],
    "UnknownICARUSCapacityPreservesDemandWithoutNumericClipping" -> TrueQ[
      AssociationQ[capacityProbe] && capacityProbe["CapacityMode"]==="UnknownCapacity_UnclippedDemand" &&
      capacityProbe["ForceCapacitySpecified"]===False && capacityProbe["HardwareQualified"]===False && capacityProbe["AppliedStationForces_N"]==={{3.,4.,0.}} &&
      capacityProbe["SaturationByStation"]==={False}],
    "FiniteICARUSCapacityClipsDemandAndIsExplicit" -> TrueQ[
      AssociationQ[capacityFiniteProbe] && capacityFiniteProbe["CapacityMode"]==="ExplicitFinitePerStationLimit" &&
      capacityFiniteProbe["ForceCapacitySpecified"]===True && capacityFiniteProbe["HardwareQualified"]===False &&
      Abs[Norm[capacityFiniteProbe["AppliedStationForces_N"][[1]]]-3.]<10.^-12 &&
      capacityFiniteProbe["SaturationByStation"]==={True}],
    "InvalidICARUSCapacityRejected" -> FailureQ[capacityInvalidProbe],
    "ControllerUnknownCapacityPreservesWrenchDemandButDoesNotQualify" -> TrueQ[
      AssociationQ[controllerUnknownCapacity] && controllerUnknownCapacity["ForceCapacitySpecified"]===False && controllerUnknownCapacity["HardwareQualified"]===False &&
      controllerUnknownCapacity["CapacityMode"]==="UnknownCapacity_UnclippedDemand" &&
      Norm[controllerUnknownCapacity["AchievedWrench"]-UnitVector[6,1]]<10.^-10],
    "ControllerFiniteCapacityAppliesStationForceLimit" -> TrueQ[
      AssociationQ[controllerFiniteCapacity] && controllerFiniteCapacity["ForceCapacitySpecified"]===True && controllerFiniteCapacity["HardwareQualified"]===False &&
      Max[Norm/@controllerFiniteCapacity["StationForces_N"]]<=0.01+10.^-12 &&
      Or@@controllerFiniteCapacity["SaturationByStation"]],
    "LargeScaleStationGeometryReconstructsAllSixWrenchBasis" -> TrueQ[
      Length[largeScaleControllerResults]===6&&And@@(AssociationQ/@largeScaleControllerResults)&&
      And@@(TrueQ[Lookup[#,"WrenchReconstructionPass",False]]&/@largeScaleControllerResults)&&
      Max[Lookup[largeScaleControllerResults,"ForceWrenchResidual_N"]]<10.^-10&&
      Max[Lookup[largeScaleControllerResults,"MomentWrenchResidual_Nm"]]<10.^-10&&
      And@@(TrueQ[Lookup[#,"ScaledWrenchMatrixRank",0]===6]&/@largeScaleControllerResults)],
    "TaskGeometryPreflightReadyWhenItsInputsArePresent" -> TrueQ[
      AssociationQ[taskGeometryReady] && taskGeometryReady["InputDependenciesSatisfied"]===True &&
      taskGeometryReady["CalculationExecuted"]===False],
    "TaskGeometryPreflightIdentifiesExactMissingInput" -> TrueQ[
      AssociationQ[taskGeometryMissing] && taskGeometryMissing["MissingInputKeys"]==={"PerPoleProjectedArea_m2"}],
    "TaskRadiationPreflightIncludesPoleSpecificDistanceAndIncidence" -> TrueQ[
      AssociationQ[taskRadiationMissing] && MemberQ[taskRadiationMissing["MissingInputKeys"],"Distance_m"] &&
      MemberQ[taskRadiationMissing["MissingInputKeys"],"IncidenceAngle_deg"]],
    "UnknownTaskNameFailsClosed" -> FailureQ[taskUnknownName],
    "IntegratedSimulationPreflightIncludesFullCoreAndPoleInputs" -> TrueQ[
      AssociationQ[taskIntegratedMissing] &&
      Sort[taskIntegratedMissing["RequiredInputKeys"]]===Sort[DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]]] &&
      taskIntegratedMissing["CalculationExecuted"]===False && taskIntegratedMissing["IndependentTaskExecutionAvailable"]===False],
    "SoftwareOnlyTestsHaveNoProjectInputDependencies" -> TrueQ[
      AssociationQ[taskSoftwareOnly] && taskSoftwareOnly["InputDependenciesSatisfied"]===True &&
      taskSoftwareOnly["RequiredInputCount"]===0],
    "IndependentGeometryTaskExecutesWithoutFullCoreInputs" -> TrueQ[
      AssociationQ[independentGeometryRun]&&TrueQ[independentGeometryRun["Executed"]]&&
      independentGeometryRun["ExecutionMode"]==="IndependentPartialTask"&&
      independentGeometryRun["OutputKeys"]==={"Geometry"}&&
      independentGeometryRun["FullCoreCalculationExecuted"]===False],
    "IndependentTaskStatusReportsFreshGeometryOutput" -> TrueQ[
      AssociationQ[independentGeometryStatus]&&independentGeometryStatus["CalculationExecuted"]===True&&
      independentGeometryStatus["IndependentTaskExecutionAvailable"]===True&&
      independentGeometryStatus["ExecutedOutputKeys"]==={"Geometry"}],
    "IndependentSurfaceMeshTaskExecutesAndStoresConvergedMesh" -> TrueQ[
      AssociationQ[independentMeshRun]&&TrueQ[independentMeshRun["Executed"]]&&
      AssociationQ[Lookup[independentDerived,"SurfaceMesh",Missing[]]]&&
      Lookup[independentDerived["SurfaceMesh"],"PatchCount",0]===512&&
      Abs[independentDerived["SurfaceMesh"]["QuadratureAreaRelativeError"]]<=0.01],
    "IndependentOpticalRegisterTaskExecutesAndClosesEnergy" -> TrueQ[
      AssociationQ[independentOpticsRun]&&TrueQ[independentOpticsRun["Executed"]]&&
      AssociationQ[Lookup[independentDerived,"OpticalRegister",Missing[]]]&&
      And@@(Abs[independentDerived["OpticalRegister"]["EnergyClosure"][#]-1.]<10.^-12&/@{"Reflector","PV"})],
    "IndependentInitialRadiationTaskExecutesAndIsFresh" -> TrueQ[
      AssociationQ[independentInitialRadiationRun]&&
      TrueQ[independentInitialRadiationRun["Executed"]]&&
      independentInitialRadiationRun["ExecutionMode"]==="IndependentPartialTask"&&
      independentInitialRadiationRun["OutputKeys"]==={"Geometry","SurfaceMesh","OpticalRegister",
        "InitialReferenceFrameIllumination","InitialRadiationLoads"}&&
      AssociationQ[independentInitialRadiationStatus]&&
      independentInitialRadiationStatus["CalculationExecuted"]===True],
    "InitialRadiationForceAndMomentAreNumericThreeVectors" -> TrueQ[
      VectorQ[Lookup[independentInitialRadiation,"NetRadiationForceVector_N",{}],NumericQ]&&
      Length[independentInitialRadiation["NetRadiationForceVector_N"]]===3&&
      VectorQ[Lookup[independentInitialRadiation,"NetRadiationMoment_Nm",{}],NumericQ]&&
      Length[independentInitialRadiation["NetRadiationMoment_Nm"]]===3&&
      Norm[independentInitialRadiation["NetRadiationForceVector_N"]]>0.],
    "InitialRadiationOpticalLedgerCloses" -> TrueQ[
      NumericQ[Lookup[independentInitialRadiation,"OpticalEnergyClosureResidual_W",Missing[]]]&&
      Abs[independentInitialRadiation["OpticalEnergyClosureResidual_W"]]<=
        10.^-8 Max[Abs[independentInitialRadiation["TotalIncidentOpticalPower_W"]],$MinMachineNumber]],
    "InitialRadiationExplicitlyPrecedesCOMAndAttitudeCorrection" -> TrueQ[
      Lookup[independentInitialRadiation,"FinalCOMAndInitialAttitudeCorrectionApplied",True]===False&&
      Lookup[independentInitialRadiation,"ForceTorqueReferenceFrame",""]===
        "Pole-local geometry origin before centre-of-mass and initial-attitude correction"&&
      Lookup[independentInitialRadiation,"FullCoreCalculationExecuted",True]===False],
    "IndependentTasksDoNotMarkFullCoreCalculationComplete" -> TrueQ[
      AssociationQ[independentPoleState]&&MissingQ[Lookup[independentPoleState,"LastRun",Missing["NotRun"]]]],
    "IndependentTasksLeavePole2Untouched" -> TrueQ[
      Lookup[independentTaskFixture,"Pole2StateAbsent",False]===True],
    "IndependentTasksPreserveExplicitSharedInputRegister" -> TrueQ[
      Lookup[independentTaskFixture,"SharedInputFixtureRetained",False]===True],
    "Pole2OperatingChangePreservesPole1GeometryCache" -> TrueQ[
      AssociationQ[Lookup[independentTaskFixture,"Pole2Update",$Failed]]&&
      AssociationQ[Lookup[independentTaskFixture,"GeometryStatusAfterPole2Update",<||>]]&&
      independentTaskFixture["GeometryStatusAfterPole2Update"]["CalculationExecuted"]===True],
    "SharedGeometryChangeInvalidatesIndependentTaskCache" -> TrueQ[
      AssociationQ[Lookup[independentTaskFixture,"SharedUpdate",$Failed]]&&
      AssociationQ[Lookup[independentTaskFixture,"GeometryStatusAfterSharedUpdate",<||>]]&&
      independentTaskFixture["GeometryStatusAfterSharedUpdate"]["CalculationExecuted"]===False&&
      independentTaskFixture["PoleStatesEmptyAfterSharedUpdate"]===True],
    "TaskStatusCannotReadOtherPoleDuringExecution" -> FailureQ[taskCrossPoleBlocked],
    "UnknownTaskNamePropagatesFailureThroughPublicAPI" -> FailureQ[taskUnknownPublic],
    "StationForceAndTorqueDemandSummaryMatchesIndependentCrossProducts" -> TrueQ[
      AssociationQ[stationDemandProbe] && stationDemandProbe["MaximumStationForceByStation_N"]==={3.,4.} &&
      stationDemandProbe["MaximumStationTorqueByStation_Nm"]==={3.,8.} &&
      Abs[stationDemandProbe["MaximumStationTorque_Nm"]-8.]<10.^-12],
    "StationDemandSummaryRejectsMismatchedStationCounts" -> FailureQ[stationDemandInvalidProbe],
    "InputRequirementsClassifiesApprovedAssumptionsAndUnresolvedItemsSeparately" -> TrueQ[
      AssociationQ[requirementsProbe] && requirementsProbe["Ready"] === True &&
      requirementsProbe["MissingValueCount"] === 0 &&
      requirementsProbe["UnclassifiedRequiredInputs"] === {} &&
      And @@ (requirementsProbe["UnclassifiedPoleOperatingInputs"][#] === {} & /@ $Phase1PoleIDs) &&
      requirementsProbe["RequiredValuesMustBeExplicit"] === False &&
      AssociationQ[requirementsProbe["ApprovedAssumptions"]] &&
      Length[requirementsProbe["UnresolvedEngineeringAndQualificationItems"]] >= 1]
  |>;
  checks = Join[checks, bisectionChecks];
  stateAfter = $Phase1State;
  checks = Join[checks, <|"ProjectStateUnchanged" -> SameQ[stateBefore, stateAfter]|>];
  <|"TestCount" -> Length[checks], "PassedCount" -> Count[Values[checks], True],
    "FailedChecks" -> Select[checks, !TrueQ[#] &], "Passed" -> And @@ (TrueQ /@ Values[checks]),
    "TestScope" -> "Pure software/math-path tests only; these are not engineering feasibility tests."|>
];

(* Torque-free rotation and damped wobble are solved using separate scalar
   dependent functions for each quaternion and angular-velocity component.
   NDSolveValue treats each listed dependent function as scalar; representing
   q[t] and w[t] as vector-valued unknown functions and then Part-indexing them
   is not a valid vector ODE formulation. The output samples are reassembled
   into four-component quaternion and three-component angular-rate vectors. *)

(* Step 4 attitude-trajectory integrity gate shared by the independent torque-free
   rotation and nonlinear gravity-gradient wobble models.
   WHAT: Confirm that each attitude solver returns one complete, finite, real
   quaternion/angular-rate record for every configured sample time.
   WHY: A solver object can exist while its sampled output is incomplete, malformed,
   non-finite, duplicated in time, or short of the requested integration interval.
   HOW: Check the exact sample count, the {4-component quaternion, 3-component
   angular-rate} record shape, finite real values, strictly increasing time points,
   and coverage from t=0 through the requested duration. This is a source-level
   integrity gate; it does not execute or validate either solver. *)
phase1AttitudeTrajectoryIntegrity[sampleTimes_,samples_,configuredCount_,duration_] := Module[
  {finiteRealQ,timeListQ,stateListQ,countPass,shapePass,finitePass,quaternionNormPass,timePass,coveragePass},
  finiteRealQ[value_] := TrueQ[NumericQ[value]&&
    FreeQ[value,Indeterminate|ComplexInfinity|_DirectedInfinity]&&
    TrueQ[Im[N[value]]==0]];
  timeListQ=ListQ[sampleTimes];
  stateListQ=ListQ[samples];
  countPass=TrueQ[IntegerQ[configuredCount]&&configuredCount>0&&timeListQ&&stateListQ&&
    Length[sampleTimes]===configuredCount+1&&Length[samples]===configuredCount+1];
  shapePass=TrueQ[stateListQ&&Length[samples]>0&&
    And@@(Function[state,MatchQ[state,{_List,_List}]&&
      Length[state[[1]]]===4&&Length[state[[2]]]===3]/@samples)];
  finitePass=TrueQ[stateListQ&&Length[samples]>0&&And@@(finiteRealQ/@Flatten[samples])&&
    timeListQ&&Length[sampleTimes]>0&&And@@(finiteRealQ/@sampleTimes)];
  (* This gate runs before either model calculates attitude angles or evaluates
     quaternion-normalizing functions on the sampled trajectory. Shape and finite
     component checks precede the norm operation; an exactly zero quaternion, or a
     norm that overflows/underflows to a non-finite/zero value, fails closed. *)
  quaternionNormPass=TrueQ[shapePass&&finitePass&&And@@(
    phase1FiniteNonzeroQuaternionQ /@ (#[[1]]& /@ samples))];
  timePass=TrueQ[timeListQ&&Length[sampleTimes]>=2&&
    And@@(TrueQ[#>0.]&/@Differences[sampleTimes])];
  coveragePass=TrueQ[timeListQ&&Length[sampleTimes]>=2&&finiteRealQ[duration]&&duration>0.&&
    Abs[First[sampleTimes]]<=10^-10 Max[1.,Abs[duration]]&&
    Abs[Last[sampleTimes]-duration]<=10^-10 Max[1.,Abs[duration]]];
  <|"ConfiguredSampleCountMatches"->countPass,"QuaternionAndRateStateShapeValid"->shapePass,
    "SamplesAndTimesFiniteReal"->finitePass,"QuaternionNormsFiniteAndPositive"->quaternionNormPass,
    "SampleTimesStrictlyIncreasing"->timePass,"SamplesCoverFullDuration"->coveragePass,
    "Pass"->TrueQ[countPass&&shapePass&&finitePass&&quaternionNormPass&&timePass&&coveragePass]|>
];
(* Step 4 attitude/stability solvers must not call phase1EnsureCalculated[], because
   that accessor intentionally requires the complete Phase 1 calculation register,
   including the PV electrical network deferred to Step 7. Reuse a current-input-hash
   Step 4 core when available; otherwise build the Step 4 core directly. *)
phase1EnsureStep4CoreCurrent[] := Module[
  {inputHash=Hash[Phase1GetInputs[],"SHA256"],cached},
  cached=Lookup[Lookup[$Phase1State,"Results",<||>],"Step4EngineeringCore",Missing["NotRun"]];
  If[AssociationQ[cached] &&
      SameQ[Lookup[cached,"InputSnapshotHash",Missing[]],inputHash],
    cached,
    phase1BuildStep4Core[]
  ]
];

phase1FreeRotationTrajectoryCurrent[durationS_:Automatic] := Module[
  {in=Phase1GetInputs[],core,dyn,inertiaMat,q0,w0,ts,sol,sampleTimes,samples,sampleIntegrity,
   momentumNorms,rotationalEnergies,quaternionNormError,energyDrift,momentumDrift,
   t,q0f,q1f,q2f,q3f,w1f,w2f,w3f,qFunctions,wFunctions,qVector,wVector,
   qDerivative,wDerivative,equations,dependentFunctions,qAt,wAt},
  core=phase1EnsureStep4CoreCurrent[];If[FailureQ[core],Return[core]];
  dyn=Lookup[core,"DynamicInitialConditions",Missing["DynamicInitialConditionsUnavailable"]];
  If[!AssociationQ[dyn],Return[Failure["DynamicInitialConditionsUnavailable",<||>]]];
  inertiaMat=dyn["InertiaTensor_kg_m2"];q0=dyn["InitialQuaternion"];w0=dyn["InitialAngularVelocity_rad_s"];
  If[!phase1FiniteNonzeroQuaternionQ[q0],
    Return[Failure["InvalidInitialFreeRotationQuaternion",<|"InitialQuaternion"->q0,
      "Requirement"->"Finite-real four-component quaternion with strictly positive finite norm"|>]]
  ];
  ts=If[durationS===Automatic,in["DynamicCheckDuration_s"],durationS];
  If[!phase1FiniteRealNumberQ[ts]||!TrueQ[ts>0.],
    Return[Failure["InvalidRotationDuration",<|"Duration_s"->ts,"Requirement"->"Finite positive real duration"|>]]
  ];
  qFunctions={q0f,q1f,q2f,q3f};wFunctions={w1f,w2f,w3f};
  qVector={q0f[t],q1f[t],q2f[t],q3f[t]};
  wVector={w1f[t],w2f[t],w3f[t]};
  qDerivative={q0f'[t],q1f'[t],q2f'[t],q3f'[t]};
  wDerivative={w1f'[t],w2f'[t],w3f'[t]};
  dependentFunctions=Join[qFunctions,wFunctions];
  equations=Join[
    Thread[qDerivative==phase1QuaternionRate[qVector,wVector]],
    Thread[inertiaMat.wDerivative+Cross[wVector,inertiaMat.wVector]=={0.,0.,0.}],
    Thread[{q0f[0.],q1f[0.],q2f[0.],q3f[0.]}==q0],
    Thread[{w1f[0.],w2f[0.],w3f[0.]}==w0]
  ];
  sol=Quiet@Check[NDSolveValue[equations,dependentFunctions,{t,0.,ts},
    AccuracyGoal->in["DynamicAccuracyGoal"],PrecisionGoal->in["DynamicPrecisionGoal"],
    MaxSteps->in["DynamicMaxSteps"]],$Failed];
  If[sol===$Failed,
    phase1StoreResult["FreeRotationTrajectory",<|"Solution"->$Failed,"SolverSucceeded"->False,
      "Status"->"Scalar-component torque-free rigid-body integration failed; no rotational stability result is claimed."|>],
    qAt[tt_?NumericQ]:=(#[tt]&/@Take[sol,4]);
    wAt[tt_?NumericQ]:=(#[tt]&/@Take[sol,-3]);
    sampleTimes=Subdivide[0.,ts,in["DynamicSampleCount"]];
    samples=Table[{qAt[tt],wAt[tt]},{tt,sampleTimes}];
    sampleIntegrity=phase1AttitudeTrajectoryIntegrity[sampleTimes,samples,in["DynamicSampleCount"],ts];
    If[!TrueQ[Lookup[sampleIntegrity,"Pass",False]],
      phase1StoreResult["FreeRotationTrajectory",<|"Solution"->sol,"SolverSucceeded"->True,
        "TrajectoryIntegrity"->sampleIntegrity,
        "Status"->"Torque-free rotation solver returned an incomplete or invalid sampled trajectory; conservation and rotation acceptance are not asserted."|>];
      Return[Failure["FreeRotationTrajectoryIntegrityFailed",<|"Pole"->$Phase1CurrentPole,
        "TrajectoryIntegrity"->sampleIntegrity|>]]
    ];
    momentumNorms=Norm/@(inertiaMat.#&/@samples[[All,2]]);
    rotationalEnergies=(0.5 #.inertiaMat.#&/@samples[[All,2]]);
    quaternionNormError=Max[Abs[(Norm/@samples[[All,1]])-1.]];
    momentumDrift=Max[Abs[momentumNorms-momentumNorms[[1]]]]/Max[Sqrt[$MinMachineNumber],momentumNorms[[1]]];
    energyDrift=Max[Abs[rotationalEnergies-rotationalEnergies[[1]]]]/Max[Sqrt[$MinMachineNumber],Abs[rotationalEnergies[[1]]]];
    phase1StoreResult["FreeRotationTrajectory",<|"Solution"->sol,"SolverSucceeded"->True,"Duration_s"->ts,
      "SampleTimes_s"->sampleTimes,"SampleStates"->samples,
      "TrajectoryIntegrity"->sampleIntegrity,
      "TrajectorySampleCountMatchesConfigured"->sampleIntegrity["ConfiguredSampleCountMatches"],
      "TrajectoryStateShapeValid"->sampleIntegrity["QuaternionAndRateStateShapeValid"],
      "TrajectorySamplesFiniteReal"->sampleIntegrity["SamplesAndTimesFiniteReal"],
      "TrajectoryQuaternionNormsFiniteAndPositive"->sampleIntegrity["QuaternionNormsFiniteAndPositive"],
      "TrajectoryTimesStrictlyIncreasing"->sampleIntegrity["SampleTimesStrictlyIncreasing"],
      "TrajectoryCoversFullDuration"->sampleIntegrity["SamplesCoverFullDuration"],
      "TrajectoryIntegrityPass"->sampleIntegrity["Pass"],
      "MaximumAngularRate_rad_s"->Max[Norm/@samples[[All,2]]],
      "MaximumQuaternionNormalizationError"->quaternionNormError,
      "SpecificAngularMomentumNormRelativeDrift"->momentumDrift,
      "RotationalKineticEnergyRelativeDrift"->energyDrift,
      "QuaternionNormalizationPass"->TrueQ[quaternionNormError<=in["QuaternionNormalizationTolerance"]],
      "AngularMomentumConservationPass"->TrueQ[momentumDrift<=in["PowerLedgerRelativeTolerance"]],
      "RotationalEnergyConservationPass"->TrueQ[energyDrift<=in["PowerLedgerRelativeTolerance"]],
      "Equations"->"Four scalar quaternion component equations and three scalar torque-free Euler angular-velocity equations; inertia is the central lumped-mass approximation. Angular momentum and rotational kinetic energy are independently monitored."|>]
  ]
];

phase1WobbleSimulationCurrent[durationS_:Automatic] := Module[
  {in=Phase1GetInputs[],core,dyn,inertiaMat,q0,w0,linearization,dMat,ts,sol,sampleTimes,samples,sampleIntegrity,
   angleOf,maxAngle,maxRate,quaternionNormError,maxGravityTorque,stableReferenceQ,
   t,q0f,q1f,q2f,q3f,w1f,w2f,w3f,qFunctions,wFunctions,qVector,wVector,
   qDerivative,wDerivative,equations,dependentFunctions,qAt,wAt},
  core=phase1EnsureStep4CoreCurrent[];If[FailureQ[core],Return[core]];
  dyn=Lookup[core,"DynamicInitialConditions",Missing["DynamicInitialConditionsUnavailable"]];
  If[!AssociationQ[dyn],Return[Failure["DynamicInitialConditionsUnavailable",<||>]]];
  If[in["WobbleRestoringModel"] =!= "NonlinearGravityGradientRigidBody",
    Return[Failure["UnsupportedWobbleRestoringModel",<|"SelectedModel"->in["WobbleRestoringModel"]|>]]];
  inertiaMat=dyn["InertiaTensor_kg_m2"];q0=dyn["InitialQuaternion"];w0=dyn["InitialAngularVelocity_rad_s"];
  (* Reject a zero/invalid initial attitude before the gravity-gradient RHS calls
     phase1RotationMatrix, which normalizes its quaternion argument. *)
  If[!phase1FiniteNonzeroQuaternionQ[q0],
    Return[Failure["InvalidInitialWobbleQuaternion",<|"InitialQuaternion"->q0,
      "Requirement"->"Finite-real four-component quaternion with strictly positive finite norm"|>]]
  ];
  linearization=phase1GravityGradientLinearization[in,inertiaMat];
  If[FailureQ[linearization],Return[linearization]];
  dMat=linearization["DampingMatrix_Nm_s_per_rad"];
  stableReferenceQ=TrueQ[linearization["LinearizedTransverseStabilityPass"]];
  ts=If[durationS===Automatic,in["DynamicCheckDuration_s"],durationS];
  If[!phase1FiniteRealNumberQ[ts]||!TrueQ[ts>0.],
    Return[Failure["InvalidWobbleDuration",<|"Duration_s"->ts,"Requirement"->"Finite positive real duration"|>]]
  ];
  qFunctions={q0f,q1f,q2f,q3f};wFunctions={w1f,w2f,w3f};
  qVector={q0f[t],q1f[t],q2f[t],q3f[t]};
  wVector={w1f[t],w2f[t],w3f[t]};
  qDerivative={q0f'[t],q1f'[t],q2f'[t],q3f'[t]};
  wDerivative={w1f'[t],w2f'[t],w3f'[t]};
  dependentFunctions=Join[qFunctions,wFunctions];
  equations=Join[
    Thread[qDerivative==phase1QuaternionRate[qVector,wVector]],
    Thread[inertiaMat.wDerivative+Cross[wVector,inertiaMat.wVector]==
      phase1GravityGradientTorqueBody[in,inertiaMat,qVector]-dMat.wVector],
    Thread[{q0f[0.],q1f[0.],q2f[0.],q3f[0.]}==q0],
    Thread[{w1f[0.],w2f[0.],w3f[0.]}==w0]
  ];
  sol=Quiet@Check[NDSolveValue[equations,dependentFunctions,{t,0.,ts},
    AccuracyGoal->in["DynamicAccuracyGoal"],PrecisionGoal->in["DynamicPrecisionGoal"],
    MaxSteps->in["DynamicMaxSteps"]],$Failed];
  If[sol===$Failed,
    phase1StoreResult["WobbleSimulation",<|"Solution"->$Failed,"SolverSucceeded"->False,
      "GravityGradientLinearization"->linearization,
      "Status"->"Nonlinear gravity-gradient rigid-body integration failed; no bounded-wobble or stability result is claimed."|>],
    qAt[tt_?NumericQ]:=(#[tt]&/@Take[sol,4]);
    wAt[tt_?NumericQ]:=(#[tt]&/@Take[sol,-3]);
    sampleTimes=Subdivide[0.,ts,in["DynamicSampleCount"]];
    samples=Table[{qAt[tt],wAt[tt]},{tt,sampleTimes}];
    sampleIntegrity=phase1AttitudeTrajectoryIntegrity[sampleTimes,samples,in["DynamicSampleCount"],ts];
    If[!TrueQ[Lookup[sampleIntegrity,"Pass",False]],
      phase1StoreResult["WobbleSimulation",<|"Solution"->sol,"SolverSucceeded"->True,
        "GravityGradientLinearization"->linearization,"TrajectoryIntegrity"->sampleIntegrity,
        "Status"->"Gravity-gradient wobble solver returned an incomplete or invalid sampled trajectory; bounded-wobble and stability acceptance are not asserted."|>];
      Return[Failure["WobbleTrajectoryIntegrityFailed",<|"Pole"->$Phase1CurrentPole,
        "TrajectoryIntegrity"->sampleIntegrity|>]]
    ];
    angleOf[qv_?VectorQ]:=2. ArcCos[Clip[Abs[Normalize[qv][[1]]],{0.,1.}]];
    maxAngle=Max[angleOf/@samples[[All,1]]];
    maxRate=Max[Norm/@samples[[All,2]]];
    quaternionNormError=Max[Abs[(Norm/@samples[[All,1]])-1.]];
    maxGravityTorque=Max[Norm/@Map[phase1GravityGradientTorqueBody[in,inertiaMat,#]&,samples[[All,1]]]];
    phase1StoreResult["WobbleSimulation",<|"Solution"->sol,"SolverSucceeded"->True,"Duration_s"->ts,
      "SampleTimes_s"->sampleTimes,"SampleStates"->samples,
      "TrajectoryIntegrity"->sampleIntegrity,
      "TrajectorySampleCountMatchesConfigured"->sampleIntegrity["ConfiguredSampleCountMatches"],
      "TrajectoryStateShapeValid"->sampleIntegrity["QuaternionAndRateStateShapeValid"],
      "TrajectorySamplesFiniteReal"->sampleIntegrity["SamplesAndTimesFiniteReal"],
      "TrajectoryQuaternionNormsFiniteAndPositive"->sampleIntegrity["QuaternionNormsFiniteAndPositive"],
      "TrajectoryTimesStrictlyIncreasing"->sampleIntegrity["SampleTimesStrictlyIncreasing"],
      "TrajectoryCoversFullDuration"->sampleIntegrity["SamplesCoverFullDuration"],
      "TrajectoryIntegrityPass"->sampleIntegrity["Pass"],
      "MaximumAttitudeDeviation_rad"->maxAngle,"MaximumAngularRate_rad_s"->maxRate,
      "MaximumGravityGradientTorque_Nm"->maxGravityTorque,
      "MaximumQuaternionNormalizationError"->quaternionNormError,
      "GravityGradientLinearization"->linearization,
      "AlignedReferenceTransverseStabilityPass"->stableReferenceQ,
      "AttitudeWithinTolerance"->TrueQ[maxAngle<=in["AttitudeTolerance_rad"]],
      "AngularRateWithinTolerance"->TrueQ[maxRate<=in["AngularRateRecoveryTolerance_rad_s"]],
      "QuaternionNormalizationPass"->TrueQ[quaternionNormError<=in["QuaternionNormalizationTolerance"]],
      "SelectedWobbleRestoringModel"->in["WobbleRestoringModel"],
      "Model"->"The simulation integrates the nonlinear classical first-order rigid-body gravity-gradient torque 3 GM/r^3 (u_body x I.u_body), using the current quaternion-derived Sun-radial direction in each pole's body frame. Small-angle natural modes are derived independently from that pole's inertia tensor and distance. Modal damping is applied only to stable oscillatory modes; unstable modes are not converted into artificial restoring modes. This approximation assumes body dimensions are small relative to heliocentric distance and does not represent higher-order distributed gravity, flexible-membrane wobble, or measured material damping."|>]
  ]
];

phase1FlareTimeBounds[in_Association] := Module[{sigma,cutoff,extent,peak},
  sigma=in["FlareDuration_s"]/(2. Sqrt[2. Log[2.]]);
  cutoff=in["FlareTailCutoffFraction"];
  peak=in["FlarePeakTime_s"];
  extent=sigma Sqrt[2. Log[1./cutoff]];
  <|"Sigma_s"->sigma,"PeakTime_s"->peak,"StartTime_s"->peak-extent,
    "EndTime_s"->peak+extent,"RawGaussianTailCutoffFraction"->cutoff,
    "NominalGaussianFWHM_s"->in["FlareDuration_s"]|>
];

phase1Disturbance[in_Association,timeS_?NumericQ,r_?NumericQ] := Module[
  {flareBounds,flareWidth,cutoff,extent,delta,rawGaussian,flareShape,flare,years,pwindAU,pwind,cme,deltaCME,irradiance,sepFactor},
  If[in["FlareTemporalProfile"] =!= "GaussianFWHM" || in["CMETemporalProfile"] =!= "RectangularPressureEnvelope",
    Return[Failure["UnsupportedDisturbanceProfile",<|"Flare"->in["FlareTemporalProfile"],"CME"->in["CMETemporalProfile"]|>]]];
  (* The flare is a finite-support, baseline-corrected Gaussian. PeakTime is its centre;
     Duration is the raw Gaussian FWHM; TailCutoffFraction sets the exact support boundary. *)
  flareBounds=phase1FlareTimeBounds[in];
  flareWidth=flareBounds["Sigma_s"];cutoff=in["FlareTailCutoffFraction"];
  extent=flareBounds["EndTime_s"]-flareBounds["PeakTime_s"];
  delta=Abs[timeS-flareBounds["PeakTime_s"]];
  rawGaussian=If[delta<=extent,Exp[-delta^2/(2. flareWidth^2)],0.];
  flareShape=If[delta<=extent,Clip[(rawGaussian-cutoff)/(1.-cutoff),{0.,1.}],0.];
  flare=1.+in["FlarePeakFraction"] flareShape;
  years=Max[0.,timeS/in["Year_s"]];
  pwindAU=in["SolarWindProtonDensity_1AU_cm3"]*in["CentimetersPerMeter"]^3*in["ProtonMass_kg"]*in["SolarWindSpeed_1AU_m_s"]^2;
  pwind=pwindAU*(in["AstronomicalUnit_m"]/r)^2;
  cme=If[in["CMEOnset_s"]<=timeS<=in["CMEOnset_s"]+in["CMEDuration_s"],in["CMEWindPressureMultiplier"],1.];
  deltaCME=pwind*(cme-1.);
  irradiance=phase1SolarIrradiance[in,r]*flare;
  sepFactor=Clip[1.-in["PVDegradationPerSEPReferenceDoseFraction"]*in["SEPDose_protons_cm2"]/in["SEPDoseReference_protons_cm2"],{0.,1.}];
  <|"FlareMultiplier"->flare,"FlareProfileStartTime_s"->flareBounds["StartTime_s"],
    "FlareProfilePeakTime_s"->flareBounds["PeakTime_s"],"FlareProfileEndTime_s"->flareBounds["EndTime_s"],
    "FlareNominalGaussianFWHM_s"->in["FlareDuration_s"],"FlareRawGaussianTailCutoffFraction"->cutoff,
    "FlareAdjustedIrradiance_W_m2"->irradiance,
    "CMEWindMultiplier"->cme,"BaselineSolarWindPressure_Pa"->pwind,
    "CMEExcessDynamicPressure_Pa"->deltaCME,
    "PVAnnualDegradationFactor"->(1.-in["PVAnnualDegradationFraction"])^years,
    "PVSEPDegradationFactor"->sepFactor,
    "PVDegradationFactor"->(1.-in["PVAnnualDegradationFraction"])^years sepFactor,
    "ReflectivityFactor"->(1.-in["ReflectivityAnnualLossFraction"])^years,
    "ElapsedMissionYears"->years|>
];

phase1DisturbanceScenariosCurrent[] := Module[{in=Phase1GetInputs[],pwind,result,computed},
  computed=phase1EnsureCalculated[];If[FailureQ[computed],Return[computed]];
  in=Phase1GetInputs[];
  pwind=in["SolarWindProtonDensity_1AU_cm3"] in["CentimetersPerMeter"]^3 in["ProtonMass_kg"] in["SolarWindSpeed_1AU_m_s"]^2;
  result=<|"Flare"-><|"PeakIncreaseFraction"->in["FlarePeakFraction"],"PeakTime_s"->in["FlarePeakTime_s"],"NominalGaussianFWHM_s"->in["FlareDuration_s"],"TailCutoffFraction"->in["FlareTailCutoffFraction"],"FiniteSupportBounds"->phase1FlareTimeBounds[in],"Profile"->in["FlareTemporalProfile"]|>,
    "CME"-><|"PressureMultiplier"->in["CMEWindPressureMultiplier"],"Onset_s"->in["CMEOnset_s"],"Duration_s"->in["CMEDuration_s"],"BaselinePressureAt1AU_Pa"->pwind,"Profile"->in["CMETemporalProfile"]|>,
    "SolarEnergeticParticles"-><|"Fluence_protons_cm2"->in["SEPDose_protons_cm2"],"Use"->"Degradation sensitivity placeholder; not a radiation transport calculation"|>,
    "LongTermDegradation"-><|"PVAnnualLossFraction"->in["PVAnnualDegradationFraction"],"ReflectivityAnnualLossFraction"->in["ReflectivityAnnualLossFraction"],"MissionYears"->in["ReferenceMissionYears"]|>|>;
  phase1StoreResult["DisturbanceScenarios",result]
];

phase1PerformanceAtTime[in_Association,geo_Association,mesh_Association,timeS_?NumericQ,
    localPosition_List:{0.,0.,0.},attitudeQuaternion_:Automatic] := Module[
  {d,optics,reflectorR,reflectorT,reflectorA,timeInputs,rad,coupled,thermal,pv,power,
   heliocentricPosition,actualDistance,radialDirection,solarRotation,sun,q},
  (* This evaluator supplies time-dependent illumination and power to the curved-sheet
     model. Its position and attitude are pole-local inputs, while the heliocentric
     vector is used for both the Sun direction and inverse-square solar loading. Reject
     non-finite or non-real values before normalization or distance-dependent physics. *)
  If[!phase1FiniteRealNumberQ[timeS],
    Return[Failure["InvalidTimeForTimeDependentPower",<|"Time_s"->timeS|>]]];
  If[!phase1FiniteRealVectorQ[localPosition,3],
    Return[Failure["InvalidLocalPositionForTimeDependentPower",<|"Position"->localPosition|>]]];
  q=If[attitudeQuaternion===Automatic,Lookup[mesh,"AttitudeQuaternion",{1.,0.,0.,0.}],attitudeQuaternion];
  If[!phase1FiniteRealVectorQ[q,4] || !TrueQ[Norm[q]>0.],
    Return[Failure["InvalidAttitudeForTimeDependentPower",<|"Quaternion"->q|>]]];
  heliocentricPosition={in["Distance_m"],0.,0.}+localPosition;
  If[!phase1FiniteRealVectorQ[heliocentricPosition,3],
    Return[Failure["InvalidHeliocentricPositionAtTime",<|"Position"->heliocentricPosition|>]]];
  actualDistance=Norm[heliocentricPosition];
  If[!phase1FiniteRealNumberQ[actualDistance]||!TrueQ[actualDistance>0.],
    Return[Failure["InvalidHeliocentricDistanceAtTime",<|"Position"->heliocentricPosition,"Distance_m"->actualDistance|>]]];
  radialDirection=Normalize[heliocentricPosition];
  solarRotation={{Cos[in["IncidenceAngle_deg"] Degree],-Sin[in["IncidenceAngle_deg"] Degree],0.},
    {Sin[in["IncidenceAngle_deg"] Degree],Cos[in["IncidenceAngle_deg"] Degree],0.},{0.,0.,1.}};
  sun=Normalize[solarRotation.radialDirection];
  d=phase1Disturbance[in,timeS,actualDistance];
  If[FailureQ[d],Return[d]];
  optics=phase1Optics[in];
  If[FailureQ[optics] || !AssociationQ[optics] || !AssociationQ[Lookup[optics,"Reflector",Missing["NoReflectorOptics"]]],
    Return[Failure["OpticalStateUnavailable",<|"Time_s"->timeS,"Optics"->optics|>]]];
  reflectorT=optics["Reflector"]["T"];
  reflectorR=Clip[in["ReflectorSolarReflectivity"] d["ReflectivityFactor"],{0.,1.-reflectorT}];
  reflectorA=1.-reflectorR-reflectorT;
  optics=Join[optics,<|"Reflector"-><|"R"->reflectorR,"A"->reflectorA,"T"->reflectorT|>,
    "EnergyClosure"->Join[optics["EnergyClosure"],<|"Reflector"->reflectorR+reflectorA+reflectorT|>]|>];
  timeInputs=Join[in,<|"SolarLuminosity_W"->in["SolarLuminosity_W"] d["FlareMultiplier"]|>];
  rad=phase1Radiation[timeInputs,geo,mesh,optics,in["PVFraction"],actualDistance,in["IncidenceAngle_deg"],sun];
  If[FailureQ[rad] || !AssociationQ[rad],Return[Failure["TimeDependentRadiationCalculationFailed",<|"Time_s"->timeS,"Result"->rad|>]]];
  coupled=phase1CoupledPVThermal[timeInputs,geo,mesh,optics,rad,in["PVFraction"],actualDistance,d["ElapsedMissionYears"]];
  If[FailureQ[coupled],Return[coupled]];
  thermal=coupled["Thermal"];pv=coupled["PVPerformance"];
  power=phase1Power[in,pv];
  <|"Time_s"->timeS,"MissionYears"->d["ElapsedMissionYears"],"DistanceAtTime_m"->actualDistance,
    "LocalPositionAtTime_m"->localPosition,"AttitudeQuaternionAtTime"->Normalize[q],
    "SunDirectionAtTime"->sun,"Disturbance"->d,"OpticalRegister"->optics,
    "LocalRadiation"->rad,"Thermal"->thermal,"PVPerformance"->pv,
    "PowerLedger"->power,"PVThermalCoupling"->KeyDrop[coupled,{"Thermal","PVPerformance"}]|>
];

(* WHAT: Evaluate pole-local solar collection performance at one requested time using
   the integrated trajectory when it is available, otherwise the registered initial state.
   WHY: Step 4 attitude/load reconciliation and later coupled optical/thermal calculations
   must use a physically valid position and attitude from the same independent pole run.
   HOW: Validate finite-real time and trajectory range, evaluate position and quaternion
   components, enforce their physical dimensions and quaternion norm, rotate the mesh only
   after those checks pass, then pass the validated state into the time-dependent power model.
   A failed integrated trajectory is never replaced silently by static initial conditions. *)
phase1TimeDependentPowerCurrent[timeS_?NumericQ] := Module[
  {in,computed,geo,mesh,dyn,sim,sol,localPosition,attitude,attitudeSource,solutionRange,result,qNorm,com},
  If[!phase1FiniteRealNumberQ[timeS]||!TrueQ[timeS>=0.],
    Return[Failure["InvalidTimeDependentPowerTime",<|"Time_s"->timeS,
      "Requirement"->"Time must be a finite, nonnegative real number."|>]]
  ];
  in=Phase1GetInputs[];
  computed=phase1EnsureCalculated[];
  If[FailureQ[computed],Return[computed]];
  If[!AssociationQ[Lookup[$Phase1State,"Derived",Missing["NoDerivedState"]]] ||
     !AssociationQ[Lookup[$Phase1State,"Results",Missing["NoResultState"]]],
    Return[Failure["CentralCalculationStateUnavailable",<||>]]];
  geo=Lookup[$Phase1State["Derived"],"Geometry",Missing["GeometryUnavailable"]];
  dyn=Lookup[$Phase1State["Results"],"DynamicInitialConditions",Missing["DynamicInitialConditionsUnavailable"]];
  mesh=Lookup[$Phase1State["Derived"],"SurfaceMesh",Missing["SurfaceMeshUnavailable"]];
  If[!AssociationQ[geo] || !AssociationQ[dyn] || !AssociationQ[mesh],
    Return[Failure["DerivedGeometryOrDynamicStateUnavailable",<||>]]];
  com=Lookup[dyn,"CenterOfMassLocal_m",Missing["CenterOfMassUnavailable"]];
  If[!phase1FiniteRealVectorQ[com,3],
    Return[Failure["TimeDependentPowerCenterOfMassInvalid",<|"CenterOfMassLocal_m"->com|>]]
  ];
  sim=Lookup[$Phase1State["Results"],"IntegratedSimulation",Missing["NoIntegratedSimulation"]];
  If[AssociationQ[sim] && KeyExistsQ[sim,"Solution"] && sim["Solution"] =!= $Failed,
    solutionRange=Lookup[sim,"Duration_s",Missing["DurationUnavailable"]];
    If[!phase1FiniteRealNumberQ[solutionRange]||!TrueQ[solutionRange>=0.],
      Return[Failure["IntegratedTrajectoryDurationInvalid",<|"Duration_s"->solutionRange|>]]
    ];
    If[!TrueQ[0.<=timeS<=solutionRange],
      Return[Failure["TimeOutsideIntegratedSimulationDuration",<|"Time_s"->timeS,"Duration_s"->solutionRange|>]]];
    sol=sim["Solution"];
    If[!AssociationQ[sol] || !And@@(KeyExistsQ[sol,#]& /@ {"PositionFunctions","VelocityFunctions","AttitudeFunctions","AngularVelocityFunctions"}) ||
       !ListQ[sol["PositionFunctions"]]||Length[sol["PositionFunctions"]]=!=3||
       !ListQ[sol["AttitudeFunctions"]]||Length[sol["AttitudeFunctions"]]=!=4,
      Return[Failure["IntegratedTrajectorySolutionFormatInvalid",<|"Time_s"->timeS|>]]];
    localPosition=Quiet@Check[(#[timeS]& /@ sol["PositionFunctions"]),$Failed];
    attitude=Quiet@Check[(#[timeS]& /@ sol["AttitudeFunctions"]),$Failed];
    If[localPosition===$Failed||attitude===$Failed||
       !phase1FiniteRealVectorQ[localPosition,3]||!phase1FiniteRealVectorQ[attitude,4],
      Return[Failure["IntegratedTrajectoryEvaluationFailed",<|"Time_s"->timeS,
        "Position_m"->localPosition,"AttitudeQuaternion"->attitude|>]]
    ];
    qNorm=Norm[attitude];
    If[!phase1FiniteRealNumberQ[qNorm]||!TrueQ[qNorm>0.]||
       !TrueQ[Abs[qNorm-1.]<=in["QuaternionNormalizationTolerance"]],
      Return[Failure["IntegratedTrajectoryQuaternionInvalid",<|"Time_s"->timeS,
        "QuaternionNorm"->qNorm,"AllowedNormalizationError"->in["QuaternionNormalizationTolerance"]|>]]
    ];
    mesh=phase1RotateMeshToCOM[mesh,com,attitude];
    If[FailureQ[mesh]||!AssociationQ[mesh],
      Return[Failure["IntegratedTrajectoryMeshRotationFailed",<|"Time_s"->timeS,"UnderlyingResult"->mesh|>]]
    ];
    attitudeSource="IntegratedSimulationTrajectory";
    ,
    If[AssociationQ[sim] && Lookup[sim,"Solution",None]===$Failed,
      Return[Failure["IntegratedSimulationFailed",<|"Reason"->"Dynamic attitude and position are unavailable; refusing to substitute static conditions."|>]]];
    localPosition=Lookup[dyn,"InitialPositionLocal_m",Missing["InitialPositionUnavailable"]];
    attitude=Lookup[dyn,"InitialQuaternion",Missing["InitialQuaternionUnavailable"]];
    If[!phase1FiniteRealVectorQ[localPosition,3]||!phase1FiniteRealVectorQ[attitude,4],
      Return[Failure["InitialTrajectoryStateInvalid",<|"Position_m"->localPosition,
        "AttitudeQuaternion"->attitude|>]]
    ];
    qNorm=Norm[attitude];
    If[!phase1FiniteRealNumberQ[qNorm]||!TrueQ[qNorm>0.]||
       !TrueQ[Abs[qNorm-1.]<=in["QuaternionNormalizationTolerance"]],
      Return[Failure["InitialTrajectoryQuaternionInvalid",<|"QuaternionNorm"->qNorm,
        "AllowedNormalizationError"->in["QuaternionNormalizationTolerance"]|>]]
    ];
    mesh=phase1RotateMeshToCOM[mesh,com,attitude];
    If[FailureQ[mesh]||!AssociationQ[mesh],
      Return[Failure["InitialTrajectoryMeshRotationFailed",<|"UnderlyingResult"->mesh|>]]
    ];
    attitudeSource="InitialConditions; no integrated trajectory has been stored"
  ];
  result=phase1PerformanceAtTime[in,geo,mesh,timeS,localPosition,attitude];
  If[FailureQ[result] || !AssociationQ[result],Return[If[FailureQ[result],result,Failure["TimeDependentPerformanceResultInvalid",<|"Result"->result|>]]]];
  result=Join[result,<|"AttitudeAndPositionSource"->attitudeSource,
    "UsesIntegratedPositionWhenAvailable"->True,"UsesIntegratedAttitudeWhenAvailable"->True|>];
  phase1StoreResult["TimeDependentPower",result];
  phase1Audit["TimeDependentPowerCalculated",<|"Time_s"->timeS,"MissionYears"->result["MissionYears"],
    "DistanceAtTime_m"->result["DistanceAtTime_m"],
    "AttitudeAndPositionSource"->attitudeSource,
    "DeliveredPower_W_PerPole"->result["PowerLedger"]["ConditionedDeliveredPower_W_PerPole"]|>];
  result
];

phase1ICARUSControlLawCurrent[desiredWrench_List,capacityN_:Automatic] := Module[
  {in=Phase1GetInputs[],dyn,cap,res},
  With[{computed=phase1EnsureCalculated[]},If[FailureQ[computed],Return[computed]]];
  dyn=Phase1GetResult["DynamicInitialConditions"];
  If[!AssociationQ[dyn],Return[Failure["DynamicInitialConditionsUnavailable",<||>]]];
  cap=If[capacityN===Automatic,Phase1GetResult["ICARUSCapacityPerStation_N"],capacityN];
  res=phase1Controller[dyn,desiredWrench,cap];
  phase1StoreResult["ICARUSLastControlAllocation",res]
];

(* WHAT: Convert one supplied pole-local rigid-body state into the four-station ICARUS
   control wrench and its corresponding membrane patch-load map.
   WHY: The standalone load-propagation interface must use the same body-frame convention
   as the integrated rigid-body controller. Otherwise an identical attitude/position state
   could generate different station demands depending on which public entry point is used.
   HOW: Validate the complete finite-real state and pole model, canonicalize the unit
   quaternion sign, rotate pole-local position and velocity into the collector body frame,
   form the six-axis wrench, allocate it across the configured stations, and require both
   aggregate and individual station-to-patch force/moment conservation before storing it.
   The Sun-radial control component remains disabled by the governing natural-load rule. *)
phase1ICARUSLoadPropagationCurrent[localPosition_List,localVelocity_List,attitudeQuaternion_List,angularVelocity_List] := Module[
  {in=Phase1GetInputs[],dyn,mass,inertia,kp,kd,kt,kw,qNorm,qBody,rotation,bodyPosition,bodyVelocity,
   att,translationError,wrench,allocation,mesh,geo,loadmap,stationPositions,propagationPass},
  If[!phase1FiniteRealVectorQ[localPosition,3]||!phase1FiniteRealVectorQ[localVelocity,3]||
      !phase1FiniteRealVectorQ[attitudeQuaternion,4]||!phase1FiniteRealVectorQ[angularVelocity,3],
    Return[Failure["InvalidICARUSLoadPropagationState",<|
      "Position_m"->localPosition,"Velocity_m_s"->localVelocity,
      "Quaternion"->attitudeQuaternion,"AngularVelocity_rad_s"->angularVelocity,
      "Requirement"->"Finite real 3-vectors for position, velocity and angular rate, and a finite real 4-component quaternion."|>]]
  ];
  qNorm=Norm[attitudeQuaternion];
  If[!phase1FiniteRealNumberQ[qNorm]||!TrueQ[qNorm>0.]||
      !TrueQ[Abs[qNorm-1.]<=in["QuaternionNormalizationTolerance"]],
    Return[Failure["ICARUSLoadPropagationQuaternionInvalid",<|
      "QuaternionNorm"->qNorm,"AllowedNormalizationError"->in["QuaternionNormalizationTolerance"]|>]]
  ];
  With[{computed=phase1EnsureCalculated[]},If[FailureQ[computed],Return[computed]]];
  dyn=Phase1GetResult["DynamicInitialConditions"];
  If[!AssociationQ[dyn],Return[Failure["DynamicInitialConditionsUnavailable",<||>]]];
  mass=Lookup[dyn,"TotalMass_kg",Missing["MassUnavailable"]];
  inertia=Lookup[dyn,"InertiaTensor_kg_m2",Missing["InertiaUnavailable"]];
  stationPositions=Lookup[dyn,"StationPositionsLocal_m",Missing["StationGeometryUnavailable"]];
  If[!phase1FiniteRealNumberQ[mass]||!TrueQ[mass>0.]||
      !MatrixQ[inertia,phase1FiniteRealNumberQ]||Dimensions[inertia]=!={3,3}||
      !TrueQ[Min[Eigenvalues[inertia]]>0.]||
      !ListQ[stationPositions]||Length[stationPositions]=!=in["ICARUSStationCount"]||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@stationPositions),
    Return[Failure["InvalidICARUSDynamicMassProperties",<|
      "Mass_kg"->mass,"InertiaTensor_kg_m2"->inertia,
      "StationPositionCount"->If[ListQ[stationPositions],Length[stationPositions],Missing["NotAList"]]|>]]
  ];
  {kp,kd,kt,kw}=Lookup[in,{"ControllerTranslationKp_perS2","ControllerTranslationKd_perS",
    "ControllerAttitudeKp_perS2","ControllerAttitudeKd_perS"},Missing["ControllerGainUnavailable"]];
  If[!And@@(phase1FiniteRealNumberQ[#]&&TrueQ[#>=0.]&/@{kp,kd,kt,kw}),
    Return[Failure["InvalidICARUSControllerGains",<|"Gains"->{kp,kd,kt,kw}|>]]
  ];
  (* Quaternions q and -q encode the same physical attitude. Use the nonnegative-scalar
     representative, matching the integrated controller's shortest-rotation convention.
     Position and velocity arrive in the pole-local inertial frame and are transformed
     into the collector body frame; angular velocity is already a body-frame state.
     Use the exact principal axis-angle rotation vector used by the integrated attitude
     controller rather than the small-angle 2 q_vector approximation. *)
  qBody=If[attitudeQuaternion[[1]]<0.,-attitudeQuaternion,attitudeQuaternion]/qNorm;
  rotation=phase1RotationMatrix[qBody];
  bodyPosition=Transpose[rotation].localPosition;
  bodyVelocity=Transpose[rotation].localVelocity;
  att=phase1QuaternionToRotationVector[qBody,Sqrt[$MachineEpsilon]];
  translationError=kp bodyPosition+kd bodyVelocity;
  (* Do not command the Sun-radial component; the natural outward force surplus is
     an explicit mass-growth margin and cannot be hidden by an attitude controller. *)
  wrench=Join[{0.,-mass translationError[[2]],-mass translationError[[3]]},
    -inertia.(kt att+kw angularVelocity)];
  If[!phase1FiniteRealVectorQ[wrench,6],
    Return[Failure["ICARUSDesiredWrenchInvalid",<|"DesiredWrench"->wrench|>]]
  ];
  allocation=Phase1ICARUSControlLaw[wrench];
  If[FailureQ[allocation]||!AssociationQ[allocation],
    Return[Failure["ICARUSControlAllocationFailed",<|"UnderlyingResult"->allocation|>]]
  ];
  If[!ListQ[Lookup[allocation,"StationForces_N",Missing[]]]||
      Length[allocation["StationForces_N"]]=!=Length[stationPositions]||
      !And@@(phase1FiniteRealVectorQ[#,3]&/@allocation["StationForces_N"]),
    Return[Failure["ICARUSStationAllocationRecordInvalid",<|"Allocation"->allocation|>]]
  ];
  geo=Lookup[Lookup[$Phase1State,"Derived",<||>],"Geometry",Missing["GeometryUnavailable"]];
  If[!AssociationQ[geo],Return[Failure["ICARUSLoadPropagationGeometryUnavailable",<||>]]];
  mesh=phase1Mesh[in,geo];
  If[FailureQ[mesh]||!AssociationQ[mesh],
    Return[Failure["ICARUSLoadPropagationMeshUnavailable",<|"UnderlyingResult"->mesh|>]]
  ];
  loadmap=phase1LoadMap[in,geo,mesh,dyn,allocation["StationForces_N"]];
  If[FailureQ[loadmap]||!AssociationQ[loadmap],
    Return[Failure["ICARUSMembraneLoadMapFailed",<|"UnderlyingResult"->loadmap|>]]
  ];
  propagationPass=TrueQ[Lookup[loadmap,"ForceAndMomentConservationPass",False]&&
    Lookup[loadmap,"AllIndividualStationTransfersConserved",False]&&
    Length[Lookup[loadmap,"Patches",{}]]===mesh["PatchCount"]];
  If[!propagationPass,
    Return[Failure["ICARUSMembraneLoadMapConservationFailed",<|
      "ForceResidual_N"->Lookup[loadmap,"ForceConservationResidual_N",Missing[]],
      "MomentResidual_Nm"->Lookup[loadmap,"MomentConservationResidual_Nm",Missing[]],
      "IndividualStationTransfersConserved"->Lookup[loadmap,"AllIndividualStationTransfersConserved",False]|>]]
  ];
  phase1StoreResult["ICARUSLastLoadPropagation",<|
    "InputPositionPoleLocal_m"->localPosition,"InputVelocityPoleLocal_m_s"->localVelocity,
    "BodyFramePosition_m"->bodyPosition,"BodyFrameVelocity_m_s"->bodyVelocity,
    "CanonicalUnitQuaternion"->qBody,"DesiredWrench"->wrench,"Allocation"->allocation,
    "LocalMembraneLoadMap"->loadmap,"ForceAndMomentConservationPass"->True,
    "EveryIndividualStationTransferConserved"->True,
    "ReferenceFrame"->"Pole-local COM-centred collector body frame.",
    "RadialControl"->"Disabled by governing rule; controller cannot conceal radial natural-force imbalance."|>]
];

(* ------------------------------------------------------------------------
   STEP 4 ENGINEERING CORE — ICARUS CARRYOVER, GEOMETRY AND DISTRIBUTED LOADS

   WHAT: Assemble the geometry, patch loads, distributed mass properties, natural
   force/torque resultants, station wrench allocation and membrane load transfer for
   the active collector. The carried-forward ICARUS dynamic sizing is then evaluated
   against that pole's own modelled load history.
   WHY: Step 4 must close the unfinished ICARUS work administratively transferred
   from Step 3 and reconcile it with local curved-sheet geometry and distributed loads.
   HOW: The core executes only within one pole's isolated state. A separate outer
   assessment invokes the unbounded-demand and finite-capacity dynamic runs for that
   same pole, then reports Pole 1 and Pole 2 independently. The full PV wiring network
   is not called here; its detailed sizing and losses belong to Step 7. Structural
   wiring-rib design and backing-film comparison belong to Step 5.

   Acceptance boundary: the model can derive redesign requirements and demonstrate
   reduced-order allocation/load-transfer consistency, but it cannot qualify actuator
   hardware, ultrathin-film strength, seams, or deployment performance.
   ------------------------------------------------------------------------ *)
phase1BuildStep4Core[] := Module[
  {in=Phase1GetInputs[],inputChecks,geo,mesh,optics,sun,illum,rad0,mass0,dyn0,
   attitudeMesh,rad,mass,dyn,natural,massFinal,structure,zeroWrench,allocation,
   loadmap,basisAllocations,basisLoadMaps,basisResiduals,basisWrenchPasses,forceChecks,momentChecks,
   normError,derived,core,stamp},
  If[!TrueQ[$Phase1ExecutingPole]||!MemberQ[$Phase1PoleIDs,$Phase1CurrentPole],
    Return[Failure["Step4CoreRequiresIndependentPoleContext",<|"CurrentPole"->$Phase1CurrentPole|>]]
  ];
  (* Stage 1 — establish the active pole's own input snapshot and geometric envelope.
     The shared design/material register is read together with only the current pole's
     operating register. The spherical-cap geometry and its patch mesh remain attached
     to this pole's run; no operating position, disturbance, attitude or cache from the
     other pole is consulted. The mesh gate below compares the integrated patch area
     against the analytic curved-cap area before any physical loads are accepted. *)
  inputChecks=phase1InputChecks[in];
  If[!phase1InputChecksPass[inputChecks],
    Return[Failure["Step4CoreInputValidationFailed",<|"Pole"->$Phase1CurrentPole,"Checks"->inputChecks|>]]
  ];
  geo=phase1Geometry[in];If[FailureQ[geo],Return[geo]];
  mesh=phase1Mesh[in,geo];If[FailureQ[mesh],Return[mesh]];
  If[!AssociationQ[mesh]||!IntegerQ[Lookup[mesh,"PatchCount",Missing[]]]||
      mesh["PatchCount"]<1||!NumericQ[Lookup[mesh,"QuadratureAreaRelativeError",Missing[]]]||
      !TrueQ[Abs[mesh["QuadratureAreaRelativeError"]]<=in["MeshAreaRelativeTolerance"]],
    Return[Failure["Step4GeometryMeshGateFailed",<|"Pole"->$Phase1CurrentPole,
      "Mesh"->mesh,"Tolerance"->in["MeshAreaRelativeTolerance"]|>]]
  ];
  (* Stage 2 — resolve optical fractions and local illumination before load integration.
     Reflectivity, absorptivity and transmissivity must close to unity independently
     for PV-covered and reflector-covered regions. The Sun vector is established from
     this pole's incidence setting; each patch then uses its own local normal, so edge
     patches are not assigned the centre patch's incidence. The first radiation pass
     supplies the patch-resolved momentum and heat ledger used in the initial mass model. *)
  optics=phase1Optics[in];If[FailureQ[optics],Return[optics]];
  If[!And@@(TrueQ[NumericQ[Lookup[optics["EnergyClosure"],#,Missing[]]]&&
      Abs[Lookup[optics["EnergyClosure"],#,-Infinity]-1.]<=in["OpticalClosureTolerance"]]&/@{"Reflector","PV"}),
    Return[Failure["Step4OpticalClosureGateFailed",<|"Pole"->$Phase1CurrentPole,"Optics"->optics|>]]
  ];
  sun=phase1SunVector[in["IncidenceAngle_deg"]];
  illum=phase1Illumination[mesh,sun];
  rad0=phase1Radiation[in,geo,mesh,optics,in["PVFraction"],in["Distance_m"],in["IncidenceAngle_deg"],sun];
  If[FailureQ[rad0],Return[rad0]];
  mass0=phase1Mass[in,geo,rad0,in["PVFraction"],in["Distance_m"]];
  If[FailureQ[mass0],Return[mass0]];
  If[!TrueQ[Lookup[mass0,"MassLedgerCloses",False]],
    Return[Failure["Step4InitialMassLedgerFailed",<|"Pole"->$Phase1CurrentPole,"MassBalance"->mass0|>]]
  ];
  (* Stage 3 — build the bottom-up current mass distribution and its centre of mass.
     The initial mass model includes the continuous aluminum film, PV devices, coatings,
     configured wiring/support allowance, perimeter hardware, stations and deferred mass.
     The patch mesh is rotated about the resulting centre of mass before radiation is
     recomputed, so the optical moment uses the physical attitude reference rather than
     an arbitrary planform origin. Gravity is then evaluated at every distributed mass
     point, preserving the gravity-gradient moment instead of collapsing the sheet to one
     point mass. The natural-load calculation credits radiation pressure only when deriving
     future added-mass capacity; solar-wind ram pressure remains a separately reported load. *)
  dyn0=phase1DynamicsInitial[in,geo,mass0,mesh];If[FailureQ[dyn0],Return[dyn0]];
  attitudeMesh=phase1RotateMeshToCOM[mesh,dyn0["CenterOfMassLocal_m"],dyn0["InitialQuaternion"]];
  If[FailureQ[attitudeMesh],Return[attitudeMesh]];
  rad=phase1Radiation[in,geo,attitudeMesh,optics,in["PVFraction"],in["Distance_m"],
    in["IncidenceAngle_deg"],sun];
  If[FailureQ[rad],Return[rad]];
  mass=phase1Mass[in,geo,rad,in["PVFraction"],in["Distance_m"]];If[FailureQ[mass],Return[mass]];
  dyn=phase1DynamicsInitial[in,geo,mass,mesh];If[FailureQ[dyn],Return[dyn]];
  natural=phase1NaturalEquilibrium[in,rad,mass,dyn];If[FailureQ[natural],Return[natural]];
  massFinal=phase1MergeNaturalEquilibrium[mass,natural];
  (* Stage 4 — connect the physical sheet loads to the four-station ICARUS interface.
     The current structural screen uses the active material/geometry inputs and the
     radiation load. A zero-command allocation establishes the station geometry and
     baseline load-transfer state; six independent unit-wrench allocations then expose
     whether the station layout spans three force and three moment directions. This is
     a kinematic/load-path consistency screen, not an actuator qualification or finite-
     element stress solution. The per-station force maps are transferred into patch-level
     membrane loads and must conserve both total force and total moment. *)
  (* Include the same pole-local, COM-referenced distributed gravity forces in the
     sheet-patch structural traction screen. Perimeter and station gravity forces remain
     in the full mass-point record and are carried through station/COM dynamic loads. *)
  structure=phase1Structural[in,geo,rad,in["PVFraction"],natural["DistributedGravityLoads"]];
  If[FailureQ[structure],Return[structure]];
  zeroWrench=ConstantArray[0.,6];
  allocation=phase1Controller[dyn,zeroWrench,in["ICARUSStationForceCapacity_N"]];
  If[FailureQ[allocation],Return[allocation]];
  loadmap=phase1LoadMap[in,geo,mesh,dyn,allocation["StationForces_N"]];
  If[FailureQ[loadmap],Return[loadmap]];
  basisAllocations=Table[phase1Controller[dyn,UnitVector[6,i],Infinity],{i,6}];
  If[Length[basisAllocations]=!=6||!And@@(AssociationQ/@basisAllocations),
    Return[Failure["Step4ICARUSBasisAllocationFailed",<|
      "Pole"->$Phase1CurrentPole,"AllocationResults"->basisAllocations|>]]
  ];
  basisWrenchPasses=TrueQ[Lookup[#,"WrenchReconstructionPass",False]]&/@basisAllocations;
  If[Length[basisWrenchPasses]=!=6||!And@@basisWrenchPasses,
    Return[Failure["Step4ICARUSBasisWrenchReconstructionFailed",<|
      "Pole"->$Phase1CurrentPole,"ReconstructionPassByBasis"->basisWrenchPasses|>]]
  ];
  basisLoadMaps=Table[phase1LoadMap[in,geo,mesh,dyn,basisAllocations[[i]]["StationForces_N"]],{i,6}];
  If[!And@@(AssociationQ/@basisLoadMaps),
    Return[Failure["Step4ICARUSBasisLoadMapFailed",<|"Pole"->$Phase1CurrentPole|>]]
  ];
  basisResiduals=Table[Norm[basisAllocations[[i]]["AchievedWrench"]-UnitVector[6,i]],{i,6}];
  forceChecks=And@@(TrueQ[Lookup[#,"ForceConservationPass",False]]&/@basisLoadMaps);
  momentChecks=And@@(TrueQ[Lookup[#,"MomentConservationPass",False]]&/@basisLoadMaps);
  normError=Max[Abs[(Norm/@Lookup[mesh["Patches"],"Normal"])-1.]];
  derived=Join[Lookup[$Phase1State,"Derived",<||>],<|
    "Geometry"->geo,"SurfaceMesh"->mesh,"InitialAttitudeSurfaceMesh"->attitudeMesh,
    "OpticalRegister"->optics,"SunVector"->sun,"Illumination"->KeyDrop[illum,"PatchIncidenceCosines"]|>];
  $Phase1State=Join[$Phase1State,<|"Derived"->derived|>];
  core=<|"Pole"->$Phase1CurrentPole,"SourceRevision"->$Phase1ModelVersion,
    "InputSnapshotHash"->Hash[in,"SHA256"],"InputValidation"->inputChecks,
    "Geometry"->geo,"SurfaceMesh"->mesh,"InitialAttitudeSurfaceMesh"->attitudeMesh,
    "OpticalRegister"->optics,"SunVector"->sun,"Illumination"->illum,
    "LocalRadiation"->rad,"InitialMassBalance"->mass0,"MassBalance"->massFinal,
    "NaturalEquilibrium"->natural,"DistributedGravityLoads"->natural["DistributedGravityLoads"],
    "StructuralScreen"->structure,
    "DynamicInitialConditions"->dyn,"ICARUSWrenchMatrix"->dyn["WrenchMatrix"],
    "ICARUSCapacityPerStation_N"->in["ICARUSStationForceCapacity_N"],
    "ICARUSZeroCommandAllocation"->allocation,"ICARUSInitialLoadMap"->loadmap,
    "ICARUSWrenchBasisAllocations"->basisAllocations,"ICARUSWrenchBasisLoadMaps"->basisLoadMaps,
    "ICARUSWrenchBasisReconstructionResiduals"->basisResiduals,
    "StationWrenchMatrixRank"->MatrixRank[dyn["WrenchMatrix"]],
    "StationWrenchMatrixDimensions"->Dimensions[dyn["WrenchMatrix"]],
    "StationWrenchReconstructionPass"->TrueQ[Length[basisWrenchPasses]===6&&And@@basisWrenchPasses],
    "StationWrenchReconstructionPassByBasis"->basisWrenchPasses,
    "StationLoadMapForceConservationPass"->forceChecks,
    "StationLoadMapMomentConservationPass"->momentChecks,
    "StationLoadMapConservationPass"->(forceChecks&&momentChecks),
    "LocalSurfaceNormalMaximumUnitError"->normError,
    "LocalSurfaceNormalsUnitLength"->TrueQ[normError<=in["QuaternionNormalizationTolerance"]],
    "MeshAreaTolerance"->in["MeshAreaRelativeTolerance"],
    "MeshAreaPass"->TrueQ[Abs[mesh["QuadratureAreaRelativeError"]]<=in["MeshAreaRelativeTolerance"]],
    "MassLedgerPass"->TrueQ[Lookup[massFinal,"MassLedgerCloses",False]],
    "MassConservationResidual_kg"->dyn["MassConservationResidual_kg"],
    "MassDistributionConservationPass"->TrueQ[Abs[dyn["MassConservationResidual_kg"]]<=
      in["PowerLedgerRelativeTolerance"] Max[Abs[massFinal["TotalMass_kg"]],$MinMachineNumber]],
    "PerPoleOnly"->True,"OtherPoleStateReadOrModified"->False,
    "NoCombinedMechanicalEquilibrium"->True,
    "LaterElectricalNetworkNotInvoked"->True,
    "QualificationBoundary"->"Screening calculations only; structural, actuator and thin-film hardware qualification are not asserted."|>;
  stamp=DateString[{"Year","-","Month","-","Day"," ","Hour",":","Minute",":","Second"}];
  $Phase1State=Join[$Phase1State,<|"Step4CoreLastRun"-><|"Time"->stamp,
    "Pole"->$Phase1CurrentPole,"InputSnapshotHash"->core["InputSnapshotHash"]|>|>];
  phase1StoreResult["Step4EngineeringCore",core];
  phase1Audit["Step4EngineeringCoreCompleted",<|"Pole"->$Phase1CurrentPole,
    "MeshPatchCount"->mesh["PatchCount"],"StationWrenchRank"->core["StationWrenchMatrixRank"],
    "StationLoadMapConservationPass"->core["StationLoadMapConservationPass"]|>];
  core
];

(* WHAT: Integrate the pole's three-dimensional translation, quaternion attitude,
   and body angular velocity while recalculating the environmental forces and station
   control demand as the collector moves and rotates.
   WHY: Step 4 must carry the distributed geometry and ICARUS design into a time-varying
   response. The motion model resolves local solar incidence, patch radiation momentum,
   patchwise solar-wind/CME loading, gravity at every sheet/perimeter/station mass point,
   and the control wrench delivered through the four station locations. Sheet-patch
   gravity remains distributed at its physical patches; perimeter and station gravity
   is transferred from its attachment positions through a conservative patch map in both
   the static structural screen and the time-dependent membrane load map.
   HOW: Thirteen scalar NDSolveValue dependent functions represent position, velocity,
   four quaternion components and three angular-velocity components. Numeric state
   snapshots rebuild vector kinematics, patch loads, gravity gradients and controller
   commands inside each solver evaluation. Station force limits are applied before
   calculating actual control. Dynamic patch loads are combined with the station-to-sheet
   load map and screened against the configured membrane traction/deflection limits.
   This is a reduced-order rigid-body and membrane-load model, not a qualified actuator
   plant, structural finite-element simulation, or external co-simulation worker. *)
phase1IntegratedSimulationCurrent[durationS_:Automatic] := Module[
  {in=Phase1GetInputs[],core,dyn,geo,mesh,mass,inertia,capacity,wrenchMatrix,arealMass,
   wrenchCharacteristicLength,wrenchRowScale,scaledWrenchMatrix,scaledWrenchPseudoInverse,
   kp,kd,kt,kw,spinTracking,targetSpin,trackingError,rawControl,actualControl,numericStateQ,numericThreeVectorQ,numericQuaternionQ,rotationMatrix,
   disturbanceState,cachedDisturbanceState,lastDisturbanceTime,lastDisturbanceState,lastDisturbanceResult,
   sol,solutionAccessors,ts,sampleTimes,samples,maxRad,maxLat,maxAtt,maxReq,maxUsed,maxReqTorque,
   saturation,struct,results,withinQ,disturbanceEnd,postIndices,recoveryIndex,
   recoveryTime,radialTol,lateralTol,angleOf,velTol,rateTol,baseAccelerationCrossCheck,
   centeredPatches,radialDirection,peakReq,peakApplied,quatNormError,loadIndices,loadRecords,
   loadMapAtPeak,peakLoadIndex,peakLocalLoad,maxLoadMapResidual,maxLoadMapMomentResidual,
   peakPatchTraction,maxPatchTraction,peakICARUSTraction,structuralPressureLimit,structuralLoadPass,
   initialStateAcceleration,initialStateAttitude,patchForcesBody,combinedPatchForces,patchTractions,
   baseAccelerationScale,peakState,peakEnvironmentalForces,peakICARUSForces,peakCombinedPatchForces,peakPatchTractions,
   translationalAccelerationComponent,angularAccelerationComponent,environmentNow,controlNow,controlWrenchNow,
   peakReqTorque,perStationPeakForce,perStationPeakTorque,rawStationForceSamples,demandSummary,
   t,x1f,x2f,x3f,v1f,v2f,v3f,q0f,q1f,q2f,q3f,w1f,w2f,w3f,
   xFunctions,vFunctions,qFunctions,wFunctions,xVector,vVector,qVector,wVector,
   xDerivative,vDerivative,qDerivative,wDerivative,dependentFunctions,equations,stateVector},
  core=phase1BuildStep4Core[];
  If[FailureQ[core],Return[core]];
  dyn=core["DynamicInitialConditions"];
  geo=Phase1GetState[]["Derived"]["Geometry"];
  mesh=Phase1GetState[]["Derived"]["SurfaceMesh"];
  mass=dyn["TotalMass_kg"];
  inertia=dyn["InertiaTensor_kg_m2"];
  arealMass=core["MassBalance"]["TotalArealMass_kg_m2"];
  capacity=core["ICARUSCapacityPerStation_N"];
  wrenchMatrix=core["ICARUSWrenchMatrix"];
  (* Use the same invertible force/moment row scaling as the static allocator.
     Directly pseudoinverting this 6-by-12 matrix mixes N and Nm rows across
     heliocentric station lever arms and can numerically suppress force channels.
     Precompute its scaled pseudoinverse once, outside the ODE right-hand side. *)
  wrenchCharacteristicLength=Max[Norm/@dyn["StationPositionsLocal_m"]];
  If[!phase1FiniteRealNumberQ[wrenchCharacteristicLength]||!TrueQ[wrenchCharacteristicLength>0.],
    Return[Failure["DynamicICARUSWrenchCharacteristicLengthInvalid",<|
      "CharacteristicLength_m"->wrenchCharacteristicLength|>]]
  ];
  wrenchRowScale=DiagonalMatrix[Join[ConstantArray[1.,3],
    ConstantArray[1./wrenchCharacteristicLength,3]]];
  scaledWrenchMatrix=wrenchRowScale.wrenchMatrix;
  If[Dimensions[scaledWrenchMatrix]=!={6,12}||MatrixRank[scaledWrenchMatrix]=!=6,
    Return[Failure["DynamicICARUSWrenchMatrixRankInvalid",<|
      "Dimensions"->Dimensions[scaledWrenchMatrix],"Rank"->MatrixRank[scaledWrenchMatrix],
      "RequiredRank"->6,"CharacteristicLength_m"->wrenchCharacteristicLength|>]]
  ];
  scaledWrenchPseudoInverse=Quiet@Check[PseudoInverse[scaledWrenchMatrix],$Failed];
  If[scaledWrenchPseudoInverse===$Failed||!MatrixQ[scaledWrenchPseudoInverse,phase1FiniteRealNumberQ],
    Return[Failure["DynamicICARUSScaledPseudoInverseFailed",<||>]]
  ];
  kp=in["ControllerTranslationKp_perS2"];kd=in["ControllerTranslationKd_perS"];
  kt=in["ControllerAttitudeKp_perS2"];kw=in["ControllerAttitudeKd_perS"];
  spinTracking=TrueQ[Lookup[in,"SpinTrackingEnabled",False]];
  targetSpin=dyn["InitialAngularVelocity_rad_s"][[1]];
  If[spinTracking && (!phase1FiniteRealNumberQ[targetSpin] || targetSpin==0. ||
      Norm[Rest[dyn["InitialAngularVelocity_rad_s"]]]>0.),
    Return[Failure["InvalidAxialSpinReference",<|"InitialRate"->dyn["InitialAngularVelocity_rad_s"]|>]]];
  trackingError[q_,w_]:=Module[{u,b,nb,c},
    u=Transpose[rotationMatrix[q]].{1.,0.,0.};
    b=Cross[u,{1.,0.,0.}]; nb=Norm[b]; c=u[[1]];
    {If[nb==0.,If[c<0.,{0.,Pi,0.},{0.,0.,0.}],ArcTan[c,nb] b/nb],w-targetSpin u}
  ];
  radialDirection={1.,0.,0.};
  centeredPatches=Map[Function[p,Join[p,<|"Position_m"->(p["Position_m"]-dyn["CenterOfMassLocal_m"])|>]],mesh["Patches"]];
  (* NDSolve entry points accept finite real vectors with their actual physical
     dimensions: position, velocity and angular rate are three-vectors, while attitude
     is a four-component unit-quaternion state. Keeping these predicates distinct avoids
     rejecting a valid quaternion or accepting a wrongly shaped state component. *)
  numericThreeVectorQ[v_] := phase1FiniteRealVectorQ[v,3];
  (* The ODE quaternion may drift slightly from unit norm between solver steps, but it
     must remain finite and nonzero before any normalization or attitude transform. The
     configured post-integration quaternion tolerance remains the acceptance criterion. *)
  numericQuaternionQ[v_] := phase1FiniteRealVectorQ[v,4]&&
    phase1FiniteRealNumberQ[Norm[v]]&&TrueQ[Norm[v]>0.];
  numericStateQ[z_] := ListQ[z] && Length[z]===4 &&
    numericThreeVectorQ[z[[1]]]&&numericThreeVectorQ[z[[2]]]&&
    numericQuaternionQ[z[[3]]]&&numericThreeVectorQ[z[[4]]];
  rotationMatrix[qInput_] := Module[{qv=Normalize[qInput],q0,q1,q2,q3},
    {q0,q1,q2,q3}=qv;
    {{1.-2. (q2^2+q3^2),2. (q1 q2-q0 q3),2. (q1 q3+q0 q2)},
     {2. (q1 q2+q0 q3),1.-2. (q1^2+q3^2),2. (q2 q3-q0 q1)},
     {2. (q1 q3-q0 q2),2. (q2 q3+q0 q1),1.-2. (q1^2+q2^2)}}
  ];
  rawControl[state_?numericStateQ] := Module[
    {x,v,q,w,rot,xb,vb,qbody,thetaBody,forceBody,torqueBody,wrench,allocated,stationForces,
     achieved,forceResidual,momentResidual,forceScale,momentScale,reconstructionTolerance},
    {x,v,q,w}=state;rot=rotationMatrix[q];
    xb=Transpose[rot].x;vb=Transpose[rot].v;
    qbody=If[q[[1]]<0.,-q,q];
    thetaBody=If[Norm[qbody[[2;;4]]]<Sqrt[$MachineEpsilon],{0.,0.,0.},
      (2. ArcCos[Clip[qbody[[1]],{-1.,1.}]]/Norm[qbody[[2;;4]]]) qbody[[2;;4]]];
    forceBody={0.,-mass (kp xb+kd vb)[[2]],-mass (kp xb+kd vb)[[3]]};
    torqueBody=-inertia.(If[spinTracking,{kt,kw}.trackingError[q,w],kt thetaBody+kw w]);
    wrench=Join[forceBody,torqueBody];
    If[!phase1FiniteRealVectorQ[wrench,6],
      Return[Failure["DynamicICARUSDesiredWrenchInvalid",<|"DesiredWrench"->wrench|>]]
    ];
    allocated=Quiet@Check[scaledWrenchPseudoInverse.(wrenchRowScale.wrench),$Failed];
    If[allocated===$Failed||!phase1FiniteRealVectorQ[allocated,12],
      Return[Failure["DynamicICARUSWrenchAllocationFailed",<|"WrenchMatrix"->wrenchMatrix,
        "ScaledWrenchMatrix"->scaledWrenchMatrix,"DesiredWrench"->wrench|>]]
    ];
    stationForces=Partition[allocated,3];
    If[Length[stationForces]=!=4||!And@@(phase1FiniteRealVectorQ[#,3]&/@stationForces),
      Return[Failure["DynamicICARUSStationForceRecordInvalid",<|"StationForces_N"->stationForces|>]]
    ];
    (* Verify the unconstrained allocation in separate translational-force and
       rotational-moment units before a finite station-force rating is applied. The
       later capacity clip is intentionally allowed to leave a residual; that residual
       is part of the modeled saturation/recovery response rather than an allocator error. *)
    achieved=wrenchMatrix.Flatten[stationForces];
    If[!phase1FiniteRealVectorQ[achieved,6],
      Return[Failure["DynamicICARUSAchievedWrenchInvalid",<|"AchievedWrench"->achieved|>]]
    ];
    forceResidual=Norm[achieved[[1;;3]]-wrench[[1;;3]]];
    momentResidual=Norm[achieved[[4;;6]]-wrench[[4;;6]]];
    forceScale=Max[Sqrt[$MinMachineNumber],Norm[wrench[[1;;3]]],Norm[achieved[[1;;3]]],
      Norm[wrench[[4;;6]]]/wrenchCharacteristicLength,
      Norm[achieved[[4;;6]]]/wrenchCharacteristicLength];
    momentScale=wrenchCharacteristicLength forceScale;
    reconstructionTolerance=Lookup[in,"ICARUSLoadMapRelativeTolerance",Missing["WrenchToleranceUnavailable"]];
    If[!phase1FiniteRealNumberQ[reconstructionTolerance]||!TrueQ[reconstructionTolerance>0.]||
       !TrueQ[forceResidual<=reconstructionTolerance forceScale&&
         momentResidual<=reconstructionTolerance momentScale],
      Return[Failure["DynamicICARUSWrenchReconstructionFailed",<|
        "ForceResidual_N"->forceResidual,"MomentResidual_Nm"->momentResidual,
        "ForceReferenceScale_N"->forceScale,"MomentReferenceScale_Nm"->momentScale,
        "RelativeTolerance"->reconstructionTolerance|>]]
    ];
    stationForces
  ];
  (* A bad numeric state or an invalid raw allocation must terminate the dynamic solve
     rather than flow into a symbolic Part expression or a misleading force-capacity map. *)
  actualControl[state_] := Module[{raw,limited},
    If[!numericStateQ[state],
      Throw[Failure["InvalidDynamicICARUSControlState",<|"State"->state|>],"Phase1ControlCapacityFailure"]
    ];
    raw=rawControl[state];
    If[FailureQ[raw]||!ListQ[raw]||Length[raw]=!=4||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@raw),
      Throw[If[FailureQ[raw],raw,Failure["InvalidDynamicICARUSRawStationForces",<|"StationForces_N"->raw|>]],
        "Phase1ControlCapacityFailure"]
    ];
    limited=phase1ApplyStationCapacity[raw,capacity];
    If[FailureQ[limited],Throw[limited,"Phase1ControlCapacityFailure"],limited["AppliedStationForces_N"]]
  ];
  (* NDSolve requests separate scalar derivatives for translation and rotation at
     the same time/state. The environmental model includes patch-resolved radiation,
     solar-wind loading and distributed gravity, so recomputing it six times per RHS
     evaluation is wasteful and can dominate the integration. Cache only the most recent
     (time, position, quaternion) tuple: identical sibling derivative calls reuse one
     evaluation, while any changed state immediately refreshes the cache. *)
  lastDisturbanceTime=Missing["NotEvaluated"];
  lastDisturbanceState=Missing["NotEvaluated"];
  lastDisturbanceResult=Missing["NotEvaluated"];
  disturbanceState[tt_?NumericQ,xState_?numericThreeVectorQ,qState_?numericQuaternionQ,includeEvents_:True] := Module[
    {rot,localDistance,d,reflectorR,reflectorT,reflectorA,pvOptics,refOptics,opticsNow,
     timeInputs,rotatedPatches,rotatedMesh,rad,sun,radialVector,radialDirection,projectedWindArea,
     cmeForces,cmeTorque,cmeForce,acceleration,torqueBody,localPosition,heliocentricPosition,solarRotation,gravityLoad,
     gravityPatchIDs,gravityIndexMap,gravityPatchIndices,gravityPatchForces,gravityAllForces,radiationPatchForces,
     gravityAllIDs,gravityKinds,gravityPositions},
    rot=rotationMatrix[qState];
    localPosition=xState;
    heliocentricPosition={in["Distance_m"],0.,0.}+localPosition;
    If[!phase1FiniteRealVectorQ[heliocentricPosition,3],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["InvalidDynamicHeliocentricPosition",<|"Time_s"->tt|>]}]
    ];
    localDistance=Norm[heliocentricPosition];
    If[!phase1FiniteRealNumberQ[localDistance]||!TrueQ[localDistance>0.],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["InvalidDynamicHeliocentricDistance",<|"Time_s"->tt,"Distance_m"->localDistance|>]}]
    ];
    radialDirection=Normalize[heliocentricPosition];
    solarRotation={{Cos[in["IncidenceAngle_deg"] Degree],-Sin[in["IncidenceAngle_deg"] Degree],0.},
      {Sin[in["IncidenceAngle_deg"] Degree],Cos[in["IncidenceAngle_deg"] Degree],0.},{0.,0.,1.}};
    sun=Normalize[solarRotation.radialDirection];
    d=phase1Disturbance[in,tt,localDistance];
    If[!TrueQ[includeEvents],d=Join[d,<|"FlareMultiplier"->1.,"CMEWindMultiplier"->1.,"ReflectivityFactor"->1.|>]];
    reflectorT=in["ReflectorSolarTransmissivity"];
    reflectorR=Clip[in["ReflectorSolarReflectivity"] d["ReflectivityFactor"],{0.,1.-reflectorT}];
    reflectorA=1.-reflectorR-reflectorT;
    pvOptics=<|"R"->in["PVSolarReflectivity"],"T"->in["PVSolarTransmissivity"],
      "A"->1.-in["PVSolarReflectivity"]-in["PVSolarTransmissivity"]|>;
    refOptics=<|"R"->reflectorR,"T"->reflectorT,"A"->reflectorA|>;
    opticsNow=<|"PV"->pvOptics,"Reflector"->refOptics,
      "EnergyClosure"-><|"PV"->Total[Values[pvOptics]],"Reflector"->Total[Values[refOptics]]|>|>;
    timeInputs=Join[in,<|"SolarLuminosity_W"->in["SolarLuminosity_W"] d["FlareMultiplier"]|>];
    rotatedPatches=Map[Function[p,Join[p,<|"Position_m"->(rot.p["Position_m"]),
      "Normal"->Normalize[rot.p["Normal"]]|>]],centeredPatches];
    rotatedMesh=Join[mesh,<|"Patches"->rotatedPatches|>];
    rad=phase1Radiation[timeInputs,geo,rotatedMesh,opticsNow,in["PVFraction"],localDistance,in["IncidenceAngle_deg"],sun];
    If[FailureQ[rad]||!AssociationQ[rad]||!ListQ[Lookup[rad,"PatchLoads",Missing[]]],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicRadiationPatchRecordUnavailable",<|"Time_s"->tt|>]}]
    ];
    radiationPatchForces=Lookup[rad["PatchLoads"],"RadiationForceVector_N",{}];
    If[Length[rad["PatchLoads"]]=!=mesh["PatchCount"]||
        Length[radiationPatchForces]=!=mesh["PatchCount"]||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@radiationPatchForces)||
        !phase1FiniteRealVectorQ[Lookup[rad,"NetRadiationForceVector_N",{}],3]||
        !phase1FiniteRealVectorQ[Lookup[rad,"NetRadiationMoment_Nm",{}],3],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicRadiationLoadRecordInvalid",<|"Time_s"->tt,
          "PatchCount"->Length[rad["PatchLoads"]],"RadiationForceCount"->Length[radiationPatchForces]|>]}]
    ];
    projectedWindArea=Total[Map[Function[p,Max[0.,p["Normal"].radialDirection] p["SurfaceAreaWeight_m2"]],rotatedPatches]];
    cmeForce=d["BaselineSolarWindPressure_Pa"] d["CMEWindMultiplier"] projectedWindArea radialDirection;
    cmeForces=Map[Function[p,d["BaselineSolarWindPressure_Pa"]*d["CMEWindMultiplier"]*Max[0.,p["Normal"].radialDirection]*
       p["SurfaceAreaWeight_m2"]*radialDirection],rotatedPatches];
    cmeTorque=Total[MapThread[Cross[#1,#2]&,{Lookup[rotatedPatches,"Position_m"],cmeForces}]];
    gravityLoad=phase1GravityLoads[Join[in,<|"Distance_m"->localDistance|>],dyn,heliocentricPosition,qState];
    If[FailureQ[gravityLoad]||!AssociationQ[gravityLoad],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicGravityCalculationUnavailable",<|"Time_s"->tt,
          "UnderlyingResult"->gravityLoad|>]}]
    ];
    (* Resolve the gravitational body load back onto the exact sheet patches by their
       persistent identifiers. Before building that lookup, require one aligned record
       for every physical mass point. This same record carries perimeter and station
       gravity into the centre-of-mass rigid-body force/torque equations. *)
    gravityAllIDs=Lookup[gravityLoad,"MassPointIdentifiers",{}];
    gravityKinds=Lookup[gravityLoad,"MassPointKinds",{}];
    gravityAllForces=Lookup[gravityLoad,"IndividualGravityForces_N",{}];
    gravityPositions=Lookup[gravityLoad,"MassPointPositionsCOMInertial_m",{}];
    If[!ListQ[gravityAllIDs]||gravityAllIDs==={}||
        !VectorQ[gravityAllIDs,StringQ]||!DuplicateFreeQ[gravityAllIDs]||
        !ListQ[gravityKinds]||Length[gravityKinds]=!=Length[gravityAllIDs]||
        !VectorQ[gravityKinds,StringQ]||
        !And@@(MemberQ[{"SheetPatch","PerimeterHardware","ICARUSStation"},#]&/@gravityKinds)||
        !ListQ[gravityAllForces]||Length[gravityAllForces]=!=Length[gravityAllIDs]||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@gravityAllForces)||
        !ListQ[gravityPositions]||Length[gravityPositions]=!=Length[gravityAllIDs]||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@gravityPositions),
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicGravityMassPointRegisterInvalid",<|"Time_s"->tt,
          "IdentifierCount"->If[ListQ[gravityAllIDs],Length[gravityAllIDs],Missing["NotAList"]],
          "KindCount"->If[ListQ[gravityKinds],Length[gravityKinds],Missing["NotAList"]],
          "ForceCount"->If[ListQ[gravityAllForces],Length[gravityAllForces],Missing["NotAList"]],
          "PositionCount"->If[ListQ[gravityPositions],Length[gravityPositions],Missing["NotAList"]]|>]}]
    ];
    gravityPatchIDs=("SheetPatch-"<>ToString[#])&/@Lookup[rad["PatchLoads"],"PatchIndex",{}];
    gravityIndexMap=AssociationThread[gravityAllIDs,Range[Length[gravityAllIDs]]];
    gravityPatchIndices=Lookup[gravityIndexMap,gravityPatchIDs,Missing["SheetPatchMassPointNotFound"]];
    If[Length[gravityPatchIndices]=!=Length[rad["PatchLoads"]]||
        !VectorQ[gravityPatchIndices,IntegerQ],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicSheetGravityMassPointMappingInvalid",<|"Time_s"->tt,
          "ExpectedPatchCount"->Length[rad["PatchLoads"]],
          "MappedPatchCount"->Count[gravityPatchIndices,_Integer]|>]}]
    ];
    If[!And@@((gravityKinds[[#]]==="SheetPatch")&/@gravityPatchIndices),
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicSheetGravityMassPointKindMismatch",<|"Time_s"->tt,"PatchIndices"->gravityPatchIndices|>]}]
    ];
    gravityPatchForces=gravityAllForces[[gravityPatchIndices]];
    (* The continuous sheet-patch gravity forces are evaluated here because they are
       part of the patch environmental load field. The complete gravity record, including
       discrete perimeter and station point forces, is returned alongside the rigid-body
       resultants. Their more expensive force-/moment-corrected patch transfer is performed
       only at the configured post-solution load-propagation samples below, not at every
       internal differential-equation evaluation. This preserves dynamic force/torque
       fidelity while avoiding repeated reconstruction of a geometry-only attachment map. *)
    If[Length[cmeForces]=!=mesh["PatchCount"]||
        !And@@(phase1FiniteRealVectorQ[#,3]&/@cmeForces)||
        !phase1FiniteRealVectorQ[cmeForce,3]||!phase1FiniteRealVectorQ[cmeTorque,3],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicSolarWindPatchRecordInvalid",<|"Time_s"->tt|>]}]
    ];
    acceleration=(rad["NetRadiationForceVector_N"]+gravityLoad["TotalGravityForce_N"]+cmeForce)/mass;
    torqueBody=Transpose[rot].(rad["NetRadiationMoment_Nm"]+
      gravityLoad["TotalGravityTorqueInertial_Nm"]+cmeTorque);
    If[!phase1FiniteRealVectorQ[acceleration,3]||!phase1FiniteRealVectorQ[torqueBody,3],
      Return[{ConstantArray[Indeterminate,3],ConstantArray[Indeterminate,3],
        ConstantArray[{Indeterminate,Indeterminate,Indeterminate},Length[mesh["Patches"]]],
        Failure["DynamicRigidBodyEnvironmentalResultInvalid",<|"Time_s"->tt|>]}]
    ];
    patchForcesBody=Map[Transpose[rot].#&,
      MapThread[Plus,{radiationPatchForces,cmeForces,gravityPatchForces}]];
    {acceleration,torqueBody,patchForcesBody,gravityLoad}
  ];
  cachedDisturbanceState[tt_?NumericQ,xState_?numericThreeVectorQ,qState_?numericQuaternionQ] :=
    If[SameQ[lastDisturbanceTime,tt]&&SameQ[lastDisturbanceState,{xState,qState}],
      lastDisturbanceResult,
      lastDisturbanceTime=tt;
      lastDisturbanceState={xState,qState};
      lastDisturbanceResult=disturbanceState[tt,xState,qState]
    ];
  ts=If[durationS===Automatic,in["DynamicCheckDuration_s"],durationS];
  If[!phase1FiniteRealNumberQ[ts]||!TrueQ[ts>0.],
    Return[Failure["InvalidIntegratedSimulationDuration",<|"Duration_s"->ts,"Requirement"->"Finite positive real duration"|>]]
  ];
  baseAccelerationCrossCheck=Norm[disturbanceState[0.,{0.,0.,0.},dyn["InitialQuaternion"],False][[1]]-
    core["MassBalance"]["NetNaturalAccelerationVector_m_s2"]];
  initialStateAcceleration=disturbanceState[0.,dyn["InitialPositionLocal_m"],dyn["InitialQuaternion"]][[1]];
  initialStateAttitude=phase1QuaternionToRotationVector[dyn["InitialQuaternion"],Sqrt[$MachineEpsilon]];
  baseAccelerationScale=Max[Norm[core["MassBalance"]["RadiationAccelerationVector_m_s2"]],
    core["MassBalance"]["SolarGravityAcceleration_m_s2"],$MinMachineNumber];

  (* Scalar component dependent functions; vectors are reconstructed for each RHS evaluation. *)
  xFunctions={x1f,x2f,x3f};vFunctions={v1f,v2f,v3f};
  qFunctions={q0f,q1f,q2f,q3f};wFunctions={w1f,w2f,w3f};
  xVector={x1f[t],x2f[t],x3f[t]};vVector={v1f[t],v2f[t],v3f[t]};
  qVector={q0f[t],q1f[t],q2f[t],q3f[t]};wVector={w1f[t],w2f[t],w3f[t]};
  xDerivative={x1f'[t],x2f'[t],x3f'[t]};vDerivative={v1f'[t],v2f'[t],v3f'[t]};
  qDerivative={q0f'[t],q1f'[t],q2f'[t],q3f'[t]};wDerivative={w1f'[t],w2f'[t],w3f'[t]};
  dependentFunctions=Join[xFunctions,vFunctions,qFunctions,wFunctions];
  stateVector={xVector,vVector,qVector,wVector};
  (* Scalar numeric helper functions defer disturbance and controller evaluation
     until NDSolve supplies a numeric time and complete numeric state. Applying
     Part to a still-unevaluated NumericQ-gated vector function would otherwise
     leave an invalid symbolic Part expression in the differential equations. *)
  translationalAccelerationComponent[component_Integer,tt_?NumericQ,xState_?numericThreeVectorQ,
      vState_?numericThreeVectorQ,qState_?numericQuaternionQ,wState_?numericThreeVectorQ] := Module[
    {environment,stationForces,controlForce},
    environment=cachedDisturbanceState[tt,xState,qState];
    If[!ListQ[environment] || Length[environment]<1 || !phase1FiniteRealVectorQ[environment[[1]],3],Return[Indeterminate]];
    stationForces=actualControl[{xState,vState,qState,wState}];
    controlForce=rotationMatrix[qState].(wrenchMatrix[[1;;3]].Flatten[stationForces])/mass;
    environment[[1,component]]+controlForce[[component]]
  ];
  angularAccelerationComponent[component_Integer,tt_?NumericQ,xState_?numericThreeVectorQ,
      vState_?numericThreeVectorQ,qState_?numericQuaternionQ,wState_?numericThreeVectorQ] := Module[
    {environment,stationForces,controlTorque},
    environment=cachedDisturbanceState[tt,xState,qState];
    If[!ListQ[environment] || Length[environment]<2 || !phase1FiniteRealVectorQ[environment[[2]],3],Return[Indeterminate]];
    stationForces=actualControl[{xState,vState,qState,wState}];
    controlTorque=wrenchMatrix[[4;;6]].Flatten[stationForces];
    LinearSolve[inertia,environment[[2]]+controlTorque-Cross[wState,inertia.wState]][[component]]
  ];
  equations={
    x1f'[t]==v1f[t],x2f'[t]==v2f[t],x3f'[t]==v3f[t],
    v1f'[t]==translationalAccelerationComponent[1,t,xVector,vVector,qVector,wVector],
    v2f'[t]==translationalAccelerationComponent[2,t,xVector,vVector,qVector,wVector],
    v3f'[t]==translationalAccelerationComponent[3,t,xVector,vVector,qVector,wVector],
    q0f'[t]==phase1QuaternionRate[qVector,wVector][[1]],
    q1f'[t]==phase1QuaternionRate[qVector,wVector][[2]],
    q2f'[t]==phase1QuaternionRate[qVector,wVector][[3]],
    q3f'[t]==phase1QuaternionRate[qVector,wVector][[4]],
    w1f'[t]==angularAccelerationComponent[1,t,xVector,vVector,qVector,wVector],
    w2f'[t]==angularAccelerationComponent[2,t,xVector,vVector,qVector,wVector],
    w3f'[t]==angularAccelerationComponent[3,t,xVector,vVector,qVector,wVector],
    x1f[0.]==dyn["InitialPositionLocal_m"][[1]],x2f[0.]==dyn["InitialPositionLocal_m"][[2]],x3f[0.]==dyn["InitialPositionLocal_m"][[3]],
    v1f[0.]==dyn["InitialVelocityLocal_m_s"][[1]],v2f[0.]==dyn["InitialVelocityLocal_m_s"][[2]],v3f[0.]==dyn["InitialVelocityLocal_m_s"][[3]],
    q0f[0.]==dyn["InitialQuaternion"][[1]],q1f[0.]==dyn["InitialQuaternion"][[2]],
    q2f[0.]==dyn["InitialQuaternion"][[3]],q3f[0.]==dyn["InitialQuaternion"][[4]],
    w1f[0.]==dyn["InitialAngularVelocity_rad_s"][[1]],w2f[0.]==dyn["InitialAngularVelocity_rad_s"][[2]],
    w3f[0.]==dyn["InitialAngularVelocity_rad_s"][[3]]
  };
  sol=Quiet@Check[NDSolveValue[equations,dependentFunctions,{t,0.,ts},
    AccuracyGoal->in["DynamicAccuracyGoal"],PrecisionGoal->in["DynamicPrecisionGoal"],
    MaxSteps->in["DynamicMaxSteps"]],$Failed];
  If[sol===$Failed,
    results=<|"Solution"->$Failed,"SolverSucceeded"->False,"Duration_s"->ts,
      "BaseAccelerationConsistencyResidual_m_s2"->baseAccelerationCrossCheck,
      "RecoveryWithinLimit"->False,"ICARUSWithinCapacity"->False,
      "ICARUSForceDemandWithinSpecifiedCapacity"->False,"ICARUSHardwareCapacityQualified"->False,
      "Status"->"NDSolveValue failed for the thirteen scalar state components. No dynamic acceptance is claimed."|>,
    solutionAccessors=<|"PositionFunctions"->Take[sol,3],"VelocityFunctions"->Take[sol,{4,6}],
      "AttitudeFunctions"->Take[sol,{7,10}],"AngularVelocityFunctions"->Take[sol,{11,13}]|>;
    sampleTimes=Subdivide[0.,ts,in["DynamicSampleCount"]];
    samples=Table[
      {(#[tt]&/@solutionAccessors["PositionFunctions"]),
       (#[tt]&/@solutionAccessors["VelocityFunctions"]),
       (#[tt]&/@solutionAccessors["AttitudeFunctions"]),
       (#[tt]&/@solutionAccessors["AngularVelocityFunctions"])},
      {tt,sampleTimes}];
    maxRad=Max[Abs[samples[[All,1,1]]]];
    maxLat=Max[Norm/@samples[[All,1,2;;3]]];
    angleOf[qv_]:=If[spinTracking,Norm[First[trackingError[qv,{0.,0.,0.}]]],Module[{qn=Normalize[qv]},2. ArcCos[Clip[Abs[qn[[1]]],{0.,1.}]]]];
    maxAtt=Max[angleOf/@samples[[All,3]]];
    rawStationForceSamples=Table[rawControl[samples[[i]]],{i,Length[samples]}];
    demandSummary=phase1StationDemandSummary[dyn["StationPositionsLocal_m"],rawStationForceSamples,sampleTimes];
    If[FailureQ[demandSummary],Return[demandSummary]];
    peakReq=demandSummary["StationForceMagnitudesBySample_N"];
    peakReqTorque=demandSummary["StationTorqueMagnitudesBySample_Nm"];
    perStationPeakForce=demandSummary["MaximumStationForceByStation_N"];
    perStationPeakTorque=demandSummary["MaximumStationTorqueByStation_Nm"];
    peakApplied=Table[Norm/@actualControl[samples[[i]]],{i,Length[samples]}];
    maxReq=demandSummary["MaximumStationForce_N"];maxUsed=Max[Flatten[peakApplied]];
    maxReqTorque=demandSummary["MaximumStationTorque_Nm"];
    saturation=If[NumericQ[capacity]&&TrueQ[0.<capacity<Infinity],AnyTrue[Flatten[peakReq],#>capacity+0.&],False];
    loadIndices=DeleteDuplicates[Round[Subdivide[1,Length[samples],Min[in["DynamicLoadPropagationSampleCount"],Length[samples]-1]]]];
    loadRecords=Table[Module[
      {state=samples[[ii]],lm,environmentalState,environmentalForces,gravityRecord,
       massPointKinds,massPointIDs,massPointForces,massPointPositions,
       gravityAttachmentIndices,gravityAttachmentPositions,gravityAttachmentForces,gravityAttachmentIDs,
       attachmentGravityMapNow,attachmentGravityPatchForces,rotNow,icarusForces,totalPatchForces,
       areas,traction,localPressure,stationResultant},
      lm=phase1LoadMap[in,geo,mesh,dyn,actualControl[state]];
      If[FailureQ[lm],Return[lm]];
      environmentalState=disturbanceState[sampleTimes[[ii]],state[[1]],state[[3]]];
      If[!ListQ[environmentalState]||Length[environmentalState]=!=4||
          !phase1FiniteRealVectorQ[environmentalState[[1]],3]||
          !phase1FiniteRealVectorQ[environmentalState[[2]],3]||
          !ListQ[environmentalState[[3]]]||Length[environmentalState[[3]]]=!=mesh["PatchCount"]||
          !And@@(phase1FiniteRealVectorQ[#,3]&/@environmentalState[[3]]),
        Return[Failure["DynamicEnvironmentalPatchLoadRecordInvalid",<|
          "SampleIndex"->ii,"Time_s"->sampleTimes[[ii]],
          "EnvironmentalRecordShape"->If[ListQ[environmentalState],Length[environmentalState],"NotAList"]|>]]
      ];
      gravityRecord=environmentalState[[4]];
      If[!AssociationQ[gravityRecord],Return[If[FailureQ[gravityRecord],gravityRecord,
        Failure["DynamicGravityRecordUnavailable",<|"SampleIndex"->ii|>]]]];
      massPointKinds=Lookup[gravityRecord,"MassPointKinds",{}];
      massPointIDs=Lookup[gravityRecord,"MassPointIdentifiers",{}];
      massPointForces=Lookup[gravityRecord,"IndividualGravityForces_N",{}];
      massPointPositions=Lookup[dyn,"MassPointPositionsLocal_m",{}];
      If[!ListQ[massPointKinds]||!ListQ[massPointIDs]||!ListQ[massPointForces]||
          !ListQ[massPointPositions]||Length[massPointKinds]===0||
          Length[massPointIDs]=!=Length[massPointKinds]||
          Length[massPointForces]=!=Length[massPointKinds]||
          Length[massPointPositions]=!=Length[massPointKinds]||
          !VectorQ[massPointKinds,StringQ]||!VectorQ[massPointIDs,StringQ]||
          !And@@(phase1FiniteRealVectorQ[#,3]&/@massPointForces)||
          !And@@(phase1FiniteRealVectorQ[#,3]&/@massPointPositions),
        Return[Failure["DynamicGravityMassPointRecordMisaligned",<|
          "SampleIndex"->ii,"MassPointKindCount"->If[ListQ[massPointKinds],Length[massPointKinds],Missing["NotAList"]],
          "MassPointIdentifierCount"->If[ListQ[massPointIDs],Length[massPointIDs],Missing["NotAList"]],
          "GravityForceCount"->If[ListQ[massPointForces],Length[massPointForces],Missing["NotAList"]],
          "BodyPositionCount"->If[ListQ[massPointPositions],Length[massPointPositions],Missing["NotAList"]]|>]]
      ];
      gravityAttachmentIndices=Select[Range[Length[massPointKinds]],
        MemberQ[{"PerimeterHardware","ICARUSStation"},massPointKinds[[#]]]&];
      rotNow=rotationMatrix[state[[3]]];
      gravityAttachmentPositions=massPointPositions[[gravityAttachmentIndices]];
      gravityAttachmentForces=Map[Transpose[rotNow].#&,massPointForces[[gravityAttachmentIndices]]];
      gravityAttachmentIDs=massPointIDs[[gravityAttachmentIndices]];
      attachmentGravityMapNow=phase1ConcentratedGravityLoadMap[in,centeredPatches,
        gravityAttachmentPositions,gravityAttachmentForces,gravityAttachmentIDs];
      If[FailureQ[attachmentGravityMapNow],Return[attachmentGravityMapNow]];
      attachmentGravityPatchForces=attachmentGravityMapNow["PatchForces_N"];
      environmentalForces=MapThread[Plus,{environmentalState[[3]],attachmentGravityPatchForces}];
      icarusForces=Lookup[lm["Patches"],"EstimatedLocalLoadVector_N"];
      totalPatchForces=MapThread[Plus,{icarusForces,environmentalForces}];
      areas=Lookup[mesh["Patches"],"SurfaceAreaWeight_m2"];
      traction=MapThread[Norm[#1]/#2&,{totalPatchForces,areas}];
      localPressure=Max[traction];stationResultant=Max[Norm/@icarusForces];
      <|"SampleIndex"->ii,"Time_s"->sampleTimes[[ii]],
        "EnvironmentalPatchLoadsIncludeDistributedSheetGravity"->True,
        "EnvironmentalPatchLoadsIncludePerimeterAndStationGravity"->TrueQ[
          AssociationQ[attachmentGravityMapNow]&&
          TrueQ[Lookup[attachmentGravityMapNow,"ForceAndMomentConservationPass",False]]],
        "AttachmentGravityForceConservationResidual_N"->If[AssociationQ[attachmentGravityMapNow],
          Lookup[attachmentGravityMapNow,"ForceConservationResidual_N",Infinity],Infinity],
        "AttachmentGravityMomentConservationResidual_Nm"->If[AssociationQ[attachmentGravityMapNow],
          Lookup[attachmentGravityMapNow,"MomentConservationResidual_Nm",Infinity],Infinity],
        "AttachmentGravityTransferSummary"->KeyTake[attachmentGravityMapNow,
          {"AttachmentIdentifiers","TargetForceTotal_N","DistributedPatchForceTotal_N",
           "TargetMomentTotalAboutCOM_Nm","DistributedPatchMomentTotalAboutCOM_Nm",
           "ForceConservationPass","MomentConservationPass",
           "AllIndividualAttachmentTransfersConserved","PerAttachmentForceConservationPasses",
           "PerAttachmentMomentConservationPasses"}],
        "StationLoadMapForceAndMomentConserved"->TrueQ[Lookup[lm,"ForceAndMomentConservationPass",False]],
        "StationLoadMapAllIndividualTransfersConserved"->TrueQ[Lookup[lm,"AllIndividualStationTransfersConserved",False]],
        "StationLoadMapPerStationForceConservationPasses"->Lookup[lm,"PerStationForceConservationPasses",{}],
        "StationLoadMapPerStationMomentConservationPasses"->Lookup[lm,"PerStationMomentConservationPasses",{}],
        "EnvironmentalPatchForces_N"->environmentalForces,
        "EnvironmentalLoadComponents"->{"Solar radiation pressure","Solar-wind/CME ram pressure",
          "Per-sheet-patch solar gravity","Perimeter-hardware and ICARUS-station attachment gravity"},
        "PeakPatchResultantLoad_N"->Max[Norm/@totalPatchForces],
        "PeakICARUSPatchForce_N"->stationResultant,
        "PeakCombinedPatchTraction_Pa"->localPressure,"MaximumPatchTraction_Pa"->Max[traction],
        "ForceConservationResidual_N"->lm["ForceConservationResidual_N"],
        "MomentConservationResidual_Nm"->lm["MomentConservationResidual_Nm"]|>
    ],{ii,loadIndices}];
    If[AnyTrue[loadRecords,FailureQ],Return[SelectFirst[loadRecords,FailureQ]]];
    peakLoadIndex=First@Ordering[Lookup[loadRecords,"PeakCombinedPatchTraction_Pa"],-1];
    peakLocalLoad=loadRecords[[peakLoadIndex]]["PeakPatchResultantLoad_N"];
    peakPatchTraction=loadRecords[[peakLoadIndex]]["PeakCombinedPatchTraction_Pa"];
    peakICARUSTraction=loadRecords[[peakLoadIndex]]["PeakICARUSPatchForce_N"];
    maxPatchTraction=Max[Lookup[loadRecords,"PeakCombinedPatchTraction_Pa"]];
    maxLoadMapResidual=Max[Lookup[loadRecords,"ForceConservationResidual_N"]];
    maxLoadMapMomentResidual=Max[Lookup[loadRecords,"MomentConservationResidual_Nm"]];
    peakState=samples[[loadRecords[[peakLoadIndex]]["SampleIndex"]]];
    loadMapAtPeak=phase1LoadMap[in,geo,mesh,dyn,actualControl[peakState]];
    If[FailureQ[loadMapAtPeak],Return[loadMapAtPeak]];
    peakEnvironmentalForces=loadRecords[[peakLoadIndex]]["EnvironmentalPatchForces_N"];
    peakICARUSForces=Lookup[loadMapAtPeak["Patches"],"EstimatedLocalLoadVector_N"];
    peakCombinedPatchForces=MapThread[Plus,{peakICARUSForces,peakEnvironmentalForces}];
    patchTractions=MapThread[Norm[#1]/#2&,{peakCombinedPatchForces,Lookup[mesh["Patches"],"SurfaceAreaWeight_m2"]}];
    structuralPressureLimit=Min[
      in["CircularMembraneDeflectionCoefficient"] in["MembranePretension_N_m"] in["MaximumDeflectionFractionOfRadius"]/geo["PlanformEquivalentRadius_m"],
      in["CircularMembraneDeflectionCoefficient"] in["MaximumDeflectionFractionOfRadius"] core["StructuralScreen"]["AllowablePretensionFromStrength_N_m"]/geo["PlanformEquivalentRadius_m"]
    ];
    structuralLoadPass=TrueQ[maxPatchTraction<=structuralPressureLimit];
    radialTol=in["RadialDeviationToleranceFractionOfRadius"] geo["PlanformEquivalentRadius_m"];
    lateralTol=in["LateralDeviationToleranceFractionOfRadius"] geo["PlanformEquivalentRadius_m"];
    velTol=in["VelocityRecoveryTolerance_m_s"];rateTol=in["AngularRateRecoveryTolerance_rad_s"];
    disturbanceEnd=Max[phase1FlareTimeBounds[in]["EndTime_s"],in["CMEOnset_s"]+in["CMEDuration_s"]];
    postIndices=Flatten@Position[Map[#>=disturbanceEnd&,sampleTimes],True];
    withinQ[i_Integer] := Module[{sample=samples[[i]],xx,vv,qq,ww},
      {xx,vv,qq,ww}=sample;
      Abs[xx[[1]]]<=radialTol && Norm[xx[[2;;3]]]<=lateralTol &&
      Abs[vv[[1]]]<=velTol && Norm[vv[[2;;3]]]<=velTol &&
      angleOf[qq]<=in["AttitudeTolerance_rad"] && Norm[If[spinTracking,Last[trackingError[qq,ww]],ww]]<=rateTol
    ];
    recoveryIndex=SelectFirst[postIndices,
      Function[index,And@@(withinQ/@Range[index,Length[samples]])],Missing["NotRecovered"]];
    recoveryTime=If[IntegerQ[recoveryIndex],sampleTimes[[recoveryIndex]]-disturbanceEnd,Infinity];
    struct=core["StructuralScreen"];
    quatNormError=Max[Abs[(Norm/@samples[[All,3]])-1.]];
    results=<|"Solution"->solutionAccessors,"SolverSucceeded"->True,"Duration_s"->ts,
      "ScalarComponentInterpolatingFunctions"->sol,
      "SampleTimes_s"->sampleTimes,"SampleStates"->samples,
      (* A nominally successful ODE call is not sufficient by itself. Require every
         sampled position, velocity, quaternion and angular-rate component to be a
         finite real numeric value; also require strictly increasing sample times and
         the exact configured sample count. These checks prevent incomplete, complex,
         non-finite or duplicated sample records from being treated as a valid dynamic
         trajectory during the later ICARUS sizing assessment. *)
      "DynamicSamplesFinite"->TrueQ[VectorQ[Flatten[samples],
        Function[value,NumericQ[value]&&FreeQ[value,Indeterminate|ComplexInfinity|_DirectedInfinity]&&
          TrueQ[Im[N[value]]==0]]]],
      "DynamicSampleTimesStrictlyIncreasing"->TrueQ[Length[sampleTimes]>=2&&
        VectorQ[Differences[sampleTimes],Function[dt,NumericQ[dt]&&TrueQ[dt>0.]]]],
      "DynamicSampleCountMatchesConfigured"->TrueQ[Length[sampleTimes]===in["DynamicSampleCount"]+1],
      "DynamicStateSamplesCoverFullRun"->TrueQ[Length[sampleTimes]>=2&&
        Abs[First[sampleTimes]]<=10^-10 Max[1.,Abs[ts]]&&
        Abs[Last[sampleTimes]-ts]<=10^-10 Max[1.,Abs[ts]]],
      "DynamicLoadPropagationCoversFullRun"->TrueQ[Length[loadRecords]>=2&&
        Abs[First[loadRecords]["Time_s"]]<=10^-10 Max[1.,Abs[ts]]&&
        Abs[Last[loadRecords]["Time_s"]-ts]<=10^-10 Max[1.,Abs[ts]]],
      "RequiredStationForceMagnitudesBySample_N"->peakReq,
      "RequiredStationTorqueMagnitudesBySample_Nm"->peakReqTorque,
      "MaximumRequiredStationForceByStation_N"->perStationPeakForce,
      "MaximumRequiredStationTorqueByStation_Nm"->perStationPeakTorque,
      "StationForceVectorsBySample_N"->demandSummary["StationForceVectorsBySample_N"],
      "StationTorqueVectorsBySample_Nm"->demandSummary["StationTorqueVectorsBySample_Nm"],
      "PeakStationForceSampleIndices"->demandSummary["PeakStationForceSampleIndices"],
      "PeakStationForceTimes_s"->demandSummary["PeakStationForceTimes_s"],
      "PeakStationForceVectors_N"->demandSummary["PeakStationForceVectors_N"],
      "PeakStationForceUnitDirections"->demandSummary["PeakStationForceUnitDirections"],
      "PeakStationTorqueSampleIndices"->demandSummary["PeakStationTorqueSampleIndices"],
      "PeakStationTorqueTimes_s"->demandSummary["PeakStationTorqueTimes_s"],
      "PeakStationTorqueVectors_Nm"->demandSummary["PeakStationTorqueVectors_Nm"],
      "AppliedStationForceMagnitudesBySample_N"->peakApplied,
      "DynamicLoadPropagationRecords"->loadRecords,
      "DynamicEnvironmentalPatchLoadComponents"->{"Solar radiation pressure","Solar-wind/CME ram pressure",
        "Per-sheet-patch solar gravity","Perimeter-hardware and ICARUS-station attachment gravity"},
      "DistributedSheetGravityIncludedInDynamicMembraneLoadMap"->True,
      "DistributedAttachmentGravityIncludedInDynamicMembraneLoadMap"->TrueQ[
        And@@(TrueQ[Lookup[#,"EnvironmentalPatchLoadsIncludePerimeterAndStationGravity",False]]&/@loadRecords)],
      "DynamicAttachmentGravityTransferFrame"->"Pole-local COM-centred collector body frame; point positions, gravity vectors, actuator loads and patch resultants are expressed in the same body frame at each output sample.",
      "PeakLocalMembraneLoad_N"->peakLocalLoad,
      "PeakCombinedPatchTraction_Pa"->peakPatchTraction,
      "MaximumCombinedPatchTraction_Pa"->maxPatchTraction,
      "PeakICARUSPatchForce_N"->peakICARUSTraction,
      "StructuralPressureLimitForDynamicLoads_Pa"->structuralPressureLimit,
      "DynamicStructuralLoadScreenPass"->structuralLoadPass,
      "PeakLocalMembraneLoadMapPatchForces"->Map[KeyTake[#,{"Position_m","PositionCOM_m","EstimatedLocalLoadVector_N"}]&,loadMapAtPeak["Patches"]],
      "PeakCombinedDynamicPatchLoadMap"->MapThread[<|"Position_m"->#1["Position_m"],
        "PositionCOMBody_m"->(#1["Position_m"]-dyn["CenterOfMassLocal_m"]),
        "EnvironmentalPatchForce_N"->#2,"CombinedPatchForce_N"->#3,
        "CombinedPatchTraction_Pa"->#4,
        "ReferenceFrame"->"Pole-local COM-centred collector body frame"|>&,
        {mesh["Patches"],peakEnvironmentalForces,peakCombinedPatchForces,patchTractions}],
      "PeakAttachmentGravityTransferSummary"->loadRecords[[peakLoadIndex]]["AttachmentGravityTransferSummary"],
      "PeakLoadMapSampleTime_s"->loadRecords[[peakLoadIndex]]["Time_s"],
      "MaximumLoadMapForceConservationResidual_N"->maxLoadMapResidual,
      "MaximumLoadMapMomentConservationResidual_Nm"->maxLoadMapMomentResidual,
      "DynamicICARUSLoadsPropagatedToCanopy"->True,
      "BaseAccelerationConsistencyResidual_m_s2"->baseAccelerationCrossCheck,
      "BaseAccelerationConsistencyRelativeError"->baseAccelerationCrossCheck/baseAccelerationScale,
      "BaseAccelerationConsistencyScale_m_s2"->baseAccelerationScale,
      "InitialStateAccelerationVector_m_s2"->initialStateAcceleration,
      "InitialStateAttitudeRotationVector_rad"->initialStateAttitude,
      "MaximumQuaternionNormalizationError"->quatNormError,
      "MaximumRadialDeviation_m"->maxRad,"MaximumLateralDeviation_m"->maxLat,
      "MaximumAttitudeDeviation_rad"->maxAtt,
      "MaximumRequiredStationForce_N"->maxReq,"MaximumRequiredStationTorque_Nm"->maxReqTorque,"MaximumAppliedStationForce_N"->maxUsed,
      "ICARUSCapacityPerStation_N"->capacity,"ICARUSSaturationOccurred"->saturation,
      "ICARUSCapacityMode"->If[capacity===Automatic,"UnknownCapacity_UnclippedDemand",
        If[capacity===Infinity,"IdealizedUnboundedCapacity","ExplicitFinitePerStationForceLimit"]],
      "ICARUSStationForceCapacitySpecified"->TrueQ[NumericQ[capacity]&&0.<capacity<Infinity],
      "ICARUSForceDemandWithinSpecifiedCapacity"->TrueQ[NumericQ[capacity]&&0.<capacity<Infinity&&maxReq<=capacity],
      "ICARUSWithinCapacity"->TrueQ[NumericQ[capacity]&&0.<capacity<Infinity&&maxReq<=capacity],
      "ICARUSTorqueDemandCalculated"->True,
      "ICARUSHardwareCapacityQualified"->False,
      "ICARUSHardwareQualificationBlockers"->{"Only a per-station force limit is represented. Complete actuator torque/stroke/bandwidth/power ratings and qualification evidence are absent."},
      "ControlSimulationQualification"->If[capacity===Automatic,
        "Unclipped theoretical station-force demand is applied to the equations solely to expose required force and torque demand; actuator hardware is not qualified and dynamic recovery is not accepted.",
        If[capacity===Infinity,"Idealized unbounded actuation assumption; actuator hardware is not qualified.",
          "Control is clipped to the explicitly supplied per-station force limit; force-demand comparison is not complete actuator qualification. Torque/stroke/bandwidth/power limits remain unverified."]],
      "RadialDeviationWithinLimit"->TrueQ[maxRad<=radialTol],
      "LateralDeviationWithinLimit"->TrueQ[maxLat<=lateralTol],
      "AttitudeWithinLimit"->TrueQ[maxAtt<=in["AttitudeTolerance_rad"]],
      "DynamicLoadMapAllStationTransfersConserved"->TrueQ[Length[loadRecords]>0&&
        And@@(TrueQ[Lookup[#,"StationLoadMapAllIndividualTransfersConserved",False]]&/@loadRecords)],
      "DynamicLoadMapForceAndMomentConserved"->TrueQ[Length[loadRecords]>0&&
        And@@(TrueQ[Lookup[#,"StationLoadMapForceAndMomentConserved",False]]&/@loadRecords)&&
        maxLoadMapResidual<=in["ICARUSLoadMapRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Abs[maxUsed]] &&
        maxLoadMapMomentResidual<=in["ICARUSLoadMapRelativeTolerance"] Max[Sqrt[$MinMachineNumber],
          Norm[loadMapAtPeak["StationMomentTotal_Nm"]],maxUsed geo["PlanformEquivalentRadius_m"]]],
      "RecoveryDisturbanceEnd_s"->disturbanceEnd,"RecoveryTime_s"->recoveryTime,
      "RecoveryWithinLimit"->TrueQ[recoveryTime<=in["RecoveryTimeMaximum_s"]],
      "RecoveryStateIncludesPositionVelocityAttitudeAndRate"->True,"SpinTrackingEnabled"->spinTracking,
      "RecoveryTimeResolution_s"->(ts/in["DynamicSampleCount"]),
      "StructuralScreenPass"->struct["StructuralScreenPass"],
      "RadiationForceAndTorqueDependOnCurrentAttitude"->True,
      "DistributedGravityReevaluatedAtEveryDynamicState"->True,
      "GravityMassPointCount"->dyn["MassPointCount"],
      "ICARUSBodyFrameForcesRotatedToInertialTranslation"->True,
      "Status"->"Integrated 3-D translation and quaternion/Euler rigid-body dynamics solved with thirteen scalar dependent functions; radiation forces/torques use current attitude and local position; CME projected loading, flare, albedo degradation and configured-station body-frame control are connected. Flexible deformation remains a first-order surrogate.",
      "ModelLimits"->"Rigid-body dynamics with patch-distributed mass/inertia and an approximate tensioned-membrane screen; no flexible-body FEM, thermal inertia or qualified actuator dynamics."|>
  ];
  phase1StoreResult["IntegratedSimulation",results];
  phase1Audit["IntegratedSimulationCompleted",KeyDrop[results,"Solution"]];
  results
];


(* ------------------------------------------------------------------------
   ICARUS MISSION-SPECIFIC REDESIGN SIZING — CONDITIONAL PHASE 1 SCREEN

   Method: first run this pole's integrated dynamics with an unbounded/unknown
   capacity to expose raw station-force demand. Derive a common per-station
   force target from the largest individual-station demand plus the user-approved
   10% reserve. Then rerun only this same pole in a temporary state with that
   finite target and check for saturation and modeled recovery. The temporary
   capacity is never written into the live shared input register.

   The 10% reserve is a provisional synthetic screening margin selected under the user-approved
   modest-variation policy; the user approved the approach, not this specific percentage. This routine
   does NOT infer actuator-local drive torque from r x F: reported station
   moments are wrench contributions about the assembly COM. Drive torque,
   stroke, slew rate, actual actuator bandwidth/plant, duty cycle, power,
   thermal behaviour, lifetime and hardware qualification remain future design
   gates. A pass is model-based sizing evidence only, never hardware qualification.
   ------------------------------------------------------------------------ *)
phase1ICARUSRedesignSizingCurrent[] := Module[
  {in=Phase1GetInputs[],reserve,unbounded,requiredByStation,target,limited,checks,
   bandwidthHz,controllerNaturalFrequency,assumptionApproved,stationMoments,
   stationTorqueDemandCalculated,actuatorRequirementAssessment,
   result,liveSnapshot=$Phase1State,finiteState,unboundedState},
  If[!TrueQ[Lookup[in,"ICARUSRedesignFeasibilityApproved",False]],
    Return[Failure["ICARUSRedesignAssumptionNotApproved",<|"Pole"->$Phase1CurrentPole|>]]];
  reserve=Lookup[in,"ICARUSRedesignForceReserveFraction",Missing["ReserveUnavailable"]];
  (* The reserve is a pole-specific mutable engineering input. Require a finite real
     fraction before deriving any synthetic station-force target; complex or infinite
     NumericQ values are not meaningful actuator sizing inputs. *)
  If[!phase1FiniteRealNumberQ[reserve]||!TrueQ[reserve>=0.],
    Return[Failure["InvalidICARUSRedesignReserve",<|"Value"->reserve,"RequiredRange"->"Finite nonnegative reserve; no project-wide universal percentage cap is imposed."|>]]];
  (* Block-local clone forces an unbounded-demand run even if a prior user-entered
     rating exists. No live input or the other pole's operating state is changed. *)
  unboundedState=Join[liveSnapshot,<|
    "Inputs"->Join[in,<|"ICARUSStationForceCapacity_N"->Automatic|>],
    "Derived"-><||>,"Results"-><||>,"LastRun"->Missing["TemporaryUnboundedSizingRun"]|>];
  unbounded=Block[{$Phase1State=unboundedState},phase1IntegratedSimulationCurrent[]];
  If[FailureQ[unbounded],Return[unbounded]];
  requiredByStation=Lookup[unbounded,"MaximumRequiredStationForceByStation_N",Missing["StationDemandUnavailable"]];
  If[!ListQ[requiredByStation]||requiredByStation==={}||
      !phase1FiniteRealVectorQ[requiredByStation,Length[requiredByStation]]||
      !And@@(TrueQ[#>=0.]&/@requiredByStation),
    Return[Failure["InvalidICARUSStationDemand",<|"Demand"->requiredByStation,"Pole"->$Phase1CurrentPole|>]]];
  target=Max[requiredByStation](1.+reserve);
  If[!phase1FiniteRealNumberQ[target]||!TrueQ[target>0.],
    Return[Failure["InvalidDerivedICARUSForceTarget",<|"Target_N"->target|>]]];
  (* Re-run the same pole with a synthetic finite rating equal to the derived
     target. A scalar rating is applied to each station; target is sized to the
     highest per-station demand, so every station gets at least the same reserve. *)
  finiteState=Join[liveSnapshot,<|
    "Inputs"->Join[in,<|"ICARUSStationForceCapacity_N"->target|>],
    "Derived"-><||>,"Results"-><||>,"LastRun"->Missing["TemporaryFiniteCapacitySizingRun"]|>];
  limited=Block[{$Phase1State=finiteState},phase1IntegratedSimulationCurrent[]];
  If[FailureQ[limited],Return[limited]];
  controllerNaturalFrequency=Max[Sqrt[Max[0.,in["ControllerTranslationKp_perS2"]]],
    Sqrt[Max[0.,in["ControllerAttitudeKp_perS2"]]]];
  (* First-order actuator bandwidth heuristic: target at least 5x the
     closed-loop natural frequency. This is a design starting point, not a
     measurement or validated control/actuator plant model. *)
  bandwidthHz=5. controllerNaturalFrequency/(2. Pi);
  stationMoments=Lookup[limited,"MaximumRequiredStationTorqueByStation_Nm",Missing["MomentDemandUnavailable"]];
  stationTorqueDemandCalculated=TrueQ[ListQ[stationMoments]&&Length[stationMoments]===Length[requiredByStation]&&
    phase1FiniteRealVectorQ[stationMoments,Length[requiredByStation]]&&And@@(TrueQ[#>=0.]&/@stationMoments)];
  assumptionApproved=TrueQ[in["ICARUSRedesignFeasibilityApproved"]];
  (* The force/moment result below is a model-based load demand. A station r x F
     contribution about the assembly centre of mass is not the internal drive torque
     of a specific actuator; deriving that value requires its actual transmission,
     lever arm, gearing and efficiency. Keep each missing qualification item explicit. *)
  actuatorRequirementAssessment=<|
    "PerStationPeakForceRequirement_N"->requiredByStation,
    "PerStationPeakForceVector_N"->Lookup[limited,"PeakStationForceVectors_N",Missing["PeakForceVectorsUnavailable"]],
    "PerStationPeakForceDirection"->Lookup[limited,"PeakStationForceUnitDirections",Missing["PeakForceDirectionsUnavailable"]],
    "PerStationPeakForceSampleIndex"->Lookup[limited,"PeakStationForceSampleIndices",Missing["PeakForceIndicesUnavailable"]],
    "PerStationPeakForceTimes_s"->Lookup[limited,"PeakStationForceTimes_s",Missing["PeakForceTimesUnavailable"]],
    "PerStationPeakAssemblyCOMMomentContribution_Nm"->stationMoments,
    "PerStationPeakAssemblyCOMMomentVector_Nm"->Lookup[limited,"PeakStationTorqueVectors_Nm",Missing["PeakTorqueVectorsUnavailable"]],
    "PerStationPeakMomentSampleIndex"->Lookup[limited,"PeakStationTorqueSampleIndices",Missing["PeakTorqueIndicesUnavailable"]],
    "PerStationPeakMomentTimes_s"->Lookup[limited,"PeakStationTorqueTimes_s",Missing["PeakTorqueTimesUnavailable"]],
    "DemandVectorReferenceFrame"->"Active pole's COM-centred collector body frame; force and moment vectors are evaluated at the dynamic sample states.",
    "MomentReference"->"Assembly centre of mass; r x F load contribution, not actuator-local drive torque.",
    "PreliminaryBandwidthTarget_Hz"->bandwidthHz,
    "PreliminaryBandwidthStatus"->"Heuristic screening target only; it is not a measured plant bandwidth or a verified phase margin.",
    "DriveTorqueAndGearing"-><|"Status"->"External mechanism definition and qualification required","ComputedValue"->Missing["ActuatorTransmissionKinematicsRequired"],"RequiredEvidence"->"Actuator linkage geometry, effective lever arms, reduction ratio, drivetrain efficiency, friction and rated torque-speed envelope."|>,
    "StrokeAndSlewRate"-><|"Status"->"External mechanism definition and qualification required","ComputedValue"->Missing["ActuatorTravelAndManeuverEnvelopeRequired"],"RequiredEvidence"->"Attachment geometry, required travel, angular/linear maneuver envelope, acceleration profile and end-stop margins."|>,
    "BandwidthAndPhaseMargin"-><|"Status"->"External plant identification and control analysis required","ComputedValue"->Missing["MeasuredActuatorTransferFunctionRequired"],"RequiredEvidence"->"Measured or validated actuator-plus-structure transfer function, delays, controller implementation and closed-loop robustness analysis."|>,
    "DutyCycle"-><|"Status"->"Mission operations definition required","ComputedValue"->Missing["MissionDutyProfileRequired"],"RequiredEvidence"->"Mission maneuver frequency, hold intervals, disturbance occurrence rates and allowable cumulative energized time."|>,
    "PowerAndEnergy"-><|"Status"->"Drive-train and mission profile required","ComputedValue"->Missing["ActuatorTorqueSpeedAndDutyDataRequired"],"RequiredEvidence"->"Torque-speed profile, electrical efficiency, peak/average current, supply voltage, energy storage and regeneration policy."|>,
    "ThermalLimitsAndRejection"-><|"Status"->"Thermal qualification required","ComputedValue"->Missing["ActuatorLossAndThermalNetworkRequired"],"RequiredEvidence"->"Motor/drive losses, conductive interfaces, radiative view factors, thermal environment and allowable component temperatures."|>,
    "LifetimeAndRadiation"-><|"Status"->"Component-specific qualification required","ComputedValue"->Missing["ActuatorLifeAndRadiationDataRequired"],"RequiredEvidence"->"Cycle-life testing, wear data, lubrication or flexure limits, radiation dose response, shielding and end-of-life performance."|>,
    "AttachmentAndLoadTransfer"-><|"Status"->"Structural interface qualification required","ComputedValue"->Missing["FinalAttachmentAndJointModelRequired"],"RequiredEvidence"->"Final station/foil joint geometry, fastener or bonded-joint allowables, local bearing/peel/shear limits and structural load-path substantiation."|>,
    "HardwareQualification"->False|>;
  checks=<|
    "ApprovedRedesignPremise"->assumptionApproved,
    "FiniteForceTargetDerivedFromThisPoleDemand"->TrueQ[target>=Max[requiredByStation]],
    "ReserveIsFiniteAndNonnegative"->TrueQ[phase1FiniteRealNumberQ[reserve]&&reserve>=0.],
    (* IntegratedSimulation reports the applied capacity under its public result key,
       ICARUSCapacityPerStation_N (the input register key is not copied verbatim). *)
    "FiniteCapacityAppliedInTemporaryRun"->TrueQ[Lookup[limited,"ICARUSCapacityPerStation_N",Automatic]===target],
    "NoStationForceSaturation"->TrueQ[!TrueQ[Lookup[limited,"ICARUSSaturationOccurred",True]]],
    "ForceDemandWithinDerivedTarget"->TrueQ[phase1FiniteRealNumberQ[Lookup[limited,"MaximumRequiredStationForce_N",Missing[]]]&&
      Lookup[limited,"MaximumRequiredStationForce_N",Infinity]<=target],
    "PerStationTorqueDemandCalculated"->stationTorqueDemandCalculated,
    "DynamicStationDemandProfilesAlignWithStateSamples"->TrueQ[
      phase1StationDemandProfileIntegrityQ[limited,Length[requiredByStation]]],
    "PerStationPeakForceAndMomentVectorProfilesComplete"->TrueQ[
      ListQ[Lookup[limited,"PeakStationForceVectors_N",Missing[]]]&&
      Length[Lookup[limited,"PeakStationForceVectors_N",{}]]===Length[requiredByStation]&&
      And@@(phase1FiniteRealVectorQ[#,3]&/@Lookup[limited,"PeakStationForceVectors_N",{}])&&
      ListQ[Lookup[limited,"PeakStationTorqueVectors_Nm",Missing[]]]&&
      Length[Lookup[limited,"PeakStationTorqueVectors_Nm",{}]]===Length[requiredByStation]&&
      And@@(phase1FiniteRealVectorQ[#,3]&/@Lookup[limited,"PeakStationTorqueVectors_Nm",{}])&&
      Length[Lookup[limited,"PeakStationForceTimes_s",{}]]===Length[requiredByStation]&&
      phase1FiniteRealVectorQ[Lookup[limited,"PeakStationForceTimes_s",{}],Length[requiredByStation]]&&
      Length[Lookup[limited,"PeakStationTorqueTimes_s",{}]]===Length[requiredByStation]&&
      phase1FiniteRealVectorQ[Lookup[limited,"PeakStationTorqueTimes_s",{}],Length[requiredByStation]]],
    "DynamicRigidBodySolverSucceeded"->TrueQ[Lookup[limited,"SolverSucceeded",False]],
    "DynamicSamplesFinite"->TrueQ[Lookup[limited,"DynamicSamplesFinite",False]],
    "DynamicSampleTimesStrictlyIncreasing"->TrueQ[Lookup[limited,"DynamicSampleTimesStrictlyIncreasing",False]],
    "DynamicSampleCountMatchesConfigured"->TrueQ[Lookup[limited,"DynamicSampleCountMatchesConfigured",False]],
    "DynamicStateSamplesCoverFullRun"->TrueQ[Lookup[limited,"DynamicStateSamplesCoverFullRun",False]],
    "DynamicLoadPropagationSamplesCoverFullRun"->TrueQ[Lookup[limited,"DynamicLoadPropagationCoversFullRun",False]],
    "DynamicLoadMapConserved"->TrueQ[Lookup[limited,"DynamicLoadMapForceAndMomentConserved",False]],
    "DynamicLoadMapConservesEveryStationTransfer"->TrueQ[Lookup[limited,"DynamicLoadMapAllStationTransfersConserved",False]],
    "DynamicSheetGravityPropagatedToMembraneLoadMap"->TrueQ[
      Lookup[limited,"DistributedSheetGravityIncludedInDynamicMembraneLoadMap",False]&&
      ListQ[Lookup[limited,"DynamicLoadPropagationRecords",{}]]&&
      Length[Lookup[limited,"DynamicLoadPropagationRecords",{}]]>0&&
      And@@(TrueQ[Lookup[#,"EnvironmentalPatchLoadsIncludeDistributedSheetGravity",False]]&/@
        Lookup[limited,"DynamicLoadPropagationRecords",{}])],
    "DynamicAttachmentGravityPropagatedToMembraneLoadMap"->TrueQ[
      Lookup[limited,"DistributedAttachmentGravityIncludedInDynamicMembraneLoadMap",False]&&
      ListQ[Lookup[limited,"DynamicLoadPropagationRecords",{}]]&&
      Length[Lookup[limited,"DynamicLoadPropagationRecords",{}]]>0&&
      And@@(TrueQ[Lookup[#,"EnvironmentalPatchLoadsIncludePerimeterAndStationGravity",False]]&&
        phase1FiniteRealNumberQ[Lookup[#,"AttachmentGravityForceConservationResidual_N",Missing[]]]&&
        phase1FiniteRealNumberQ[Lookup[#,"AttachmentGravityMomentConservationResidual_Nm",Missing[]]]&/@
        Lookup[limited,"DynamicLoadPropagationRecords",{}])],
    "DynamicStructuralLoadScreenPass"->TrueQ[Lookup[limited,"DynamicStructuralLoadScreenPass",False]],
    "ExternalActuatorQualificationItemsExplicitlyRecorded"->TrueQ[
      AssociationQ[actuatorRequirementAssessment]&&
      And @@ (KeyExistsQ[actuatorRequirementAssessment, #] & /@ {"DriveTorqueAndGearing","StrokeAndSlewRate",
        "BandwidthAndPhaseMargin","DutyCycle","PowerAndEnergy","ThermalLimitsAndRejection",
        "LifetimeAndRadiation","AttachmentAndLoadTransfer"})],
    "QuaternionNormalizationMaintained"->TrueQ[Lookup[limited,"MaximumQuaternionNormalizationError",Infinity]<=in["QuaternionNormalizationTolerance"]],
    "RecoveryWithinConfiguredLimit"->TrueQ[Lookup[limited,"RecoveryWithinLimit",False]],
    "NoLiveInputsModified"->TrueQ[SameQ[$Phase1State,liveSnapshot]],
    "OtherPoleStateNotReadOrModified"->TrueQ[
      Keys[Lookup[$Phase1State,"PoleOperatingInputs",<||>]]==={$Phase1CurrentPole} &&
      Keys[Lookup[$Phase1State,"PoleStates",<||>]]==={$Phase1CurrentPole}]
  |>;
  result=<|
    "Pole"->$Phase1CurrentPole,
    "Status"->If[And@@(TrueQ/@Values[checks]),"ConditionalModelBasedRedesignSizingPass","RedesignTargetCalculated; one or more modeled control/recovery checks remain open"],
    "Classification"->"UserApprovedRedesignFeasibilityPremiseWithProvisionalSyntheticReserveAndDerivedPerPoleDemand; not current hardware capability or qualification",
    "ReserveNumericalValueClassification"->"The current 10% value is a provisional synthetic starting assumption, not a universal upper bound, qualified factor of safety or separately specified requirement. The reserve remains a mutable design setting subject to engineering justification.",
    "RedesignFeasibilityAssumptionApproved"->assumptionApproved,
    "ExistingHardwareCapacity_N"->in["ICARUSStationForceCapacity_N"],
    "ExistingHardwareCapabilityKnown"->TrueQ[phase1FiniteRealNumberQ[in["ICARUSStationForceCapacity_N"]]&&
      in["ICARUSStationForceCapacity_N"]>0.],
    "UnboundedRequiredStationForceByStation_N"->requiredByStation,
    "UnboundedMaximumRequiredStationForce_N"->Lookup[unbounded,"MaximumRequiredStationForce_N",Missing["Unavailable"]],
    "ApprovedForceReserveFraction"->reserve,
    "ConditionalFuturePerStationForceTarget_N"->target,
    "PerStationForceTarget_N"->ConstantArray[target,Length[requiredByStation]],
    "RequiredStationMomentContributionAboutCOMByStation_Nm"->stationMoments,
    "PerStationTorqueDemandCalculated"->stationTorqueDemandCalculated,
    "MomentDefinition"->"r x F contribution about assembly centre of mass; not actuator-local drive torque.",
    "ActuatorRequirementAssessment"->actuatorRequirementAssessment,
    "ProvisionalMinimumActuatorBandwidth_Hz"->bandwidthHz,
    "BandwidthHeuristic"->"5x controller natural frequency divided by 2 pi; preliminary target only, requiring measured/identified actuator plant and closed-loop margin analysis.",
    "LimitedDynamicSimulation"->KeyDrop[limited,{"Solution","ScalarComponentInterpolatingFunctions","SampleStates"}],
    "Checks"->checks,
    "AllSizingChecksPass"->TrueQ[And@@(TrueQ/@Values[checks])],
    "UnresolvedActuatorDesignProperties"->{"Drive-local torque and gearing","Stroke and slew rate","Measured force-frequency response and phase margin","Duty cycle","Power draw and energy storage","Thermal limits and thermal rejection","Lifetime, wear and radiation degradation","Mechanical attachment and load transfer qualification"},
    "HardwareQualification"->False,
    "LiveInputsModified"->False,
    "OtherPoleOperatingStateAccessed"->False,
    "Method"->"Independent-pole unbounded force demand, configured finite nonnegative reserve, then same-pole finite-capacity transient rerun in an isolated temporary state."|>;
  phase1StoreResult["ICARUSRedesignSizing",result];
  phase1Audit["ICARUSRedesignSizingCompleted",<|"Pole"->$Phase1CurrentPole,
    "Target_N"->target,"ReserveFraction"->reserve,"AllSizingChecksPass"->result["AllSizingChecksPass"]|>];
  result
];

(* ------------------------------------------------------------------------
   STEP 4 ACCEPTANCE ASSESSMENT — transferred ICARUS work plus geometry/load model

   This assessment is explicitly pole-local. It includes unfinished Step 3 technical
   requirements carried into Step 4 by user authorization. Modelled sizing success is
   not actuator qualification; hardware design/qualification evidence remains open.
   ------------------------------------------------------------------------ *)
phase1Step4AssessmentCurrent[] := Module[
  {in=Phase1GetInputs[],core,sizing,dynamic,freeRotation,wobble,stability,rad,mass,natural,dyn,checks,sizingChecks,
   mesh,geometry,loadMaps,stamp,result,unresolved},
  If[!TrueQ[$Phase1ExecutingPole]||!MemberQ[$Phase1PoleIDs,$Phase1CurrentPole],
    Return[Failure["Step4AssessmentRequiresIndependentPoleContext",<|"CurrentPole"->$Phase1CurrentPole|>]]
  ];
  core=phase1BuildStep4Core[];
  If[FailureQ[core],Return[core]];
  sizing=phase1ICARUSRedesignSizingCurrent[];
  sizingChecks=If[AssociationQ[sizing],Lookup[sizing,"Checks",<||>],<||>];
  dynamic=If[AssociationQ[sizing],Lookup[sizing,"LimitedDynamicSimulation",<||>],<||>];
  (* Step 4 explicitly checks the pole's torque-free quaternion rotation, nonlinear
     gravity-gradient wobble, and registered stability limits in addition to the
     controlled disturbance/recovery simulation inside ICARUS sizing. These are separate
     diagnostics: torque-free conservation does not replace controlled transient analysis,
     and the wobble model does not qualify a flexible membrane or actuator plant. *)
  freeRotation=phase1FreeRotationTrajectoryCurrent[];
  If[FailureQ[freeRotation],Return[freeRotation]];
  wobble=phase1WobbleSimulationCurrent[];
  If[FailureQ[wobble],Return[wobble]];
  stability=phase1StabilityCriteriaCurrent[];
  If[FailureQ[stability],Return[stability]];
  geometry=core["Geometry"];mesh=core["SurfaceMesh"];rad=core["LocalRadiation"];
  mass=core["MassBalance"];natural=core["NaturalEquilibrium"];dyn=core["DynamicInitialConditions"];
  loadMaps=core["ICARUSWrenchBasisLoadMaps"];
  unresolved=If[AssociationQ[sizing],Lookup[sizing,"UnresolvedActuatorDesignProperties",{
    "Drive-local torque and gearing","Stroke and slew rate","Measured force-frequency response and phase margin",
    "Duty cycle","Power draw and energy storage","Thermal limits","Lifetime and radiation degradation",
    "Mechanical attachment/load transfer qualification"}],{"ICARUS sizing run did not complete."}];
  checks=<|
    "Step4CoreAvailable"->True,
    "GeometryModelAndAreaValid"->TrueQ[phase1FiniteRealNumberQ[geometry["GrossCurvedAreaPerPole_m2"]]&&
      geometry["GrossCurvedAreaPerPole_m2"]>0.],
    "SurfaceMeshAreaWithinTolerance"->TrueQ[core["MeshAreaPass"]],
    "LocalSurfaceNormalsUnitLength"->TrueQ[core["LocalSurfaceNormalsUnitLength"]],
    "PatchResolvedRadiationForceAndMomentFinite"->TrueQ[
      phase1FiniteRealVectorQ[rad["NetRadiationForceVector_N"],3]&&
      phase1FiniteRealVectorQ[rad["NetRadiationMoment_Nm"],3]&&
      Length[rad["PatchLoads"]]===mesh["PatchCount"]&&
      Length[Lookup[rad["PatchLoads"],"RadiationMomentAboutReferencePoint_Nm",{}]]===mesh["PatchCount"]&&
      And@@(phase1FiniteRealVectorQ[#,3]&/@Lookup[rad["PatchLoads"],"RadiationMomentAboutReferencePoint_Nm",{}])&&
      TrueQ[Norm[Total[Lookup[rad["PatchLoads"],"RadiationMomentAboutReferencePoint_Nm"]]-
        rad["NetRadiationMoment_Nm"]]<=in["PowerLedgerRelativeTolerance"] Max[Sqrt[$MinMachineNumber],Norm[rad["NetRadiationMoment_Nm"]]]]],
    "PatchLocalIncidenceAnglesAvailable"->TrueQ[
      Length[Lookup[rad["PatchLoads"],"IncidenceAngle_rad",{}]]===mesh["PatchCount"]&&
      VectorQ[Lookup[rad["PatchLoads"],"IncidenceAngle_rad",{}],phase1FiniteRealNumberQ]],
    "DistributedGravityMassPointCoverageComplete"->TrueQ[
      AssociationQ[core["DistributedGravityLoads"]]&&
      Lookup[core["DistributedGravityLoads"],"MassPointCount",-1]===dyn["MassPointCount"]&&
      Count[Lookup[core["DistributedGravityLoads"],"MassPointKinds",{}],"SheetPatch"]===mesh["PatchCount"]&&
      Count[Lookup[core["DistributedGravityLoads"],"MassPointKinds",{}],"PerimeterHardware"]===dyn["PerimeterMassPointCount"]&&
      Count[Lookup[core["DistributedGravityLoads"],"MassPointKinds",{}],"ICARUSStation"]===Length[dyn["StationPositionsLocal_m"]]],
    "DistributedGravityForceAndMomentVectorsFinite"->TrueQ[
      Length[Lookup[core["DistributedGravityLoads"],"IndividualGravityForces_N",{}]]===dyn["MassPointCount"]&&
      Length[Lookup[core["DistributedGravityLoads"],"IndividualGravityTorquesAboutCOM_Nm",{}]]===dyn["MassPointCount"]&&
      And@@(phase1FiniteRealVectorQ[#,3]&/@Lookup[core["DistributedGravityLoads"],"IndividualGravityForces_N",{}])&&
      And@@(phase1FiniteRealVectorQ[#,3]&/@Lookup[core["DistributedGravityLoads"],"IndividualGravityTorquesAboutCOM_Nm",{}])],
    "PerimeterAndStationGravityTransferredToStaticMembraneLoadPath"->TrueQ[
      Lookup[core["StructuralScreen"],"PerimeterAndStationGravityTransferredToMembrane",False]&&
      Lookup[Lookup[core["StructuralScreen"],"AttachmentGravityLoadMap",<||>],"ForceAndMomentConservationPass",False]&&
      Length[Lookup[Lookup[core["StructuralScreen"],"AttachmentGravityLoadMap",<||>],"PatchForces_N",{}]]===mesh["PatchCount"]&&
      Length[Lookup[Lookup[core["StructuralScreen"],"AttachmentGravityLoadMap",<||>],"AttachmentIdentifiers",{}]]===
        dyn["PerimeterMassPointCount"]+Length[dyn["StationPositionsLocal_m"]]&&
      And@@(phase1FiniteRealVectorQ[#,3]&/@Lookup[Lookup[core["StructuralScreen"],"AttachmentGravityLoadMap",<||>],"PatchForces_N",{}])],
    "DistributedSheetGravityIncludedInStructuralLoadScreen"->TrueQ[
      Lookup[core["StructuralScreen"],"DistributedGravityIncludedInStaticStructuralLoad",False]&&
      Lookup[core["StructuralScreen"],"DistributedGravityPatchForceCount",0]===mesh["PatchCount"]&&
      Length[Lookup[core["StructuralScreen"],"PatchGravityNormalTraction_Pa",{}]]===mesh["PatchCount"]&&
      VectorQ[Lookup[core["StructuralScreen"],"PatchGravityNormalTraction_Pa",{}],phase1FiniteRealNumberQ]&&
      Length[Lookup[core["StructuralScreen"],"PatchGravityTangentialTraction_Pa",{}]]===mesh["PatchCount"]&&
      VectorQ[Lookup[core["StructuralScreen"],"PatchGravityTangentialTraction_Pa",{}],phase1FiniteRealNumberQ]],
    "MassLedgerCloses"->TrueQ[core["MassLedgerPass"]],
    "DistributedMassAndCenterOfMassValid"->TrueQ[core["MassDistributionConservationPass"]&&
      phase1FiniteRealVectorQ[dyn["CenterOfMassLocal_m"],3]&&
      MatrixQ[dyn["InertiaTensor_kg_m2"],phase1FiniteRealNumberQ]&&
      Dimensions[dyn["InertiaTensor_kg_m2"]]==={3,3}&&Min[Eigenvalues[dyn["InertiaTensor_kg_m2"]]]>0.],
    "RadiationForceExceedsInwardGravity"->TrueQ[natural["RadiationExceedsInwardGravityPass"]],
    "OutwardRadiationMarginCalculatedAndPositive"->TrueQ[phase1FiniteRealNumberQ[natural["NetNaturalRadialForce_N"]]&&
      natural["OutwardRadialBiasPass"]&&TrueQ[Lookup[mass,"MassFeasible",False]]],
    "FutureAddedMassCapacityCalculatedFromRadiationOnly"->TrueQ[
      phase1FiniteRealNumberQ[Lookup[natural,"MaximumFutureAddedMassCapacity_kg",Missing[]]]&&
      phase1FiniteRealNumberQ[Lookup[natural,"SignedFutureAddedMassCapacityBeforeRadialBalance_kg",Missing[]]]],
    "PositiveFutureAddedMassHeadroom"->TrueQ[Lookup[natural,"FutureMassGrowthTargetPass",False]],
    "TransverseNaturalForceWithinTolerance"->TrueQ[natural["TransverseForceBalancePass"]],
    "NaturalTorqueWithinTolerance"->TrueQ[natural["ExactTorqueEquilibrium"]],
    "StationWrenchMatrixSixByTwelve"->TrueQ[core["StationWrenchMatrixDimensions"]==={6,12}],
    "StationWrenchMatrixFullRank"->TrueQ[core["StationWrenchMatrixRank"]===6],
    "StationWrenchAllocatorReconstructsSixBasisWrenches"->TrueQ[core["StationWrenchReconstructionPass"]],
    "StationToMembraneForceConservation"->TrueQ[core["StationLoadMapForceConservationPass"]],
    "StationToMembraneMomentConservation"->TrueQ[core["StationLoadMapMomentConservationPass"]],
    "ICARUSRedesignSizingProduced"->TrueQ[AssociationQ[sizing]],
    "ConditionalRedesignForceTargetDerived"->TrueQ[Lookup[sizingChecks,"FiniteForceTargetDerivedFromThisPoleDemand",False]],
    "FiniteForceTargetAppliedWithoutSaturation"->TrueQ[
      Lookup[sizingChecks,"FiniteCapacityAppliedInTemporaryRun",False]&&
      Lookup[sizingChecks,"NoStationForceSaturation",False]&&
      Lookup[sizingChecks,"ForceDemandWithinDerivedTarget",False]],
    "PerStationAssemblyCOMMomentDemandCalculated"->TrueQ[Lookup[sizingChecks,"PerStationTorqueDemandCalculated",False]],
    "PerStationPeakForceAndMomentVectorProfilesComplete"->TrueQ[
      Lookup[sizingChecks,"PerStationPeakForceAndMomentVectorProfilesComplete",False]],
    "DynamicStationDemandProfilesAlignWithStateSamples"->TrueQ[Lookup[sizingChecks,"DynamicStationDemandProfilesAlignWithStateSamples",False]],
    "TorqueFreeQuaternionRotationSolverSucceeded"->TrueQ[Lookup[freeRotation,"SolverSucceeded",False]],
    "TorqueFreeQuaternionRotationTrajectoryIntegrityPass"->TrueQ[Lookup[freeRotation,"TrajectoryIntegrityPass",False]],
    "TorqueFreeQuaternionNormalizationPass"->TrueQ[Lookup[freeRotation,"QuaternionNormalizationPass",False]],
    "TorqueFreeAngularMomentumConservationPass"->TrueQ[Lookup[freeRotation,"AngularMomentumConservationPass",False]],
    "TorqueFreeRotationalEnergyConservationPass"->TrueQ[Lookup[freeRotation,"RotationalEnergyConservationPass",False]],
    "NonlinearGravityGradientWobbleSolverSucceeded"->TrueQ[Lookup[wobble,"SolverSucceeded",False]],
    "NonlinearGravityGradientWobbleTrajectoryIntegrityPass"->TrueQ[Lookup[wobble,"TrajectoryIntegrityPass",False]],
    "GravityGradientReferenceTransverseStabilityPass"->TrueQ[Lookup[wobble,"AlignedReferenceTransverseStabilityPass",False]],
    "WobbleAttitudeWithinTolerance"->TrueQ[Lookup[wobble,"AttitudeWithinTolerance",False]],
    "WobbleAngularRateWithinTolerance"->TrueQ[Lookup[wobble,"AngularRateWithinTolerance",False]],
    "WobbleQuaternionNormalizationPass"->TrueQ[Lookup[wobble,"QuaternionNormalizationPass",False]],
    "StabilityCriteriaRegistered"->TrueQ[AssociationQ[stability]&&
      Lookup[stability,"ICARUSSaturationAllowed",True]===False&&
      Lookup[stability,"ExactZeroNetForceRequirement",True]===False],
    "DynamicRigidBodySolverSucceeded"->TrueQ[Lookup[sizingChecks,"DynamicRigidBodySolverSucceeded",False]],
    "DynamicSamplesFinite"->TrueQ[Lookup[sizingChecks,"DynamicSamplesFinite",False]],
    "DynamicSampleTimesStrictlyIncreasing"->TrueQ[Lookup[sizingChecks,"DynamicSampleTimesStrictlyIncreasing",False]],
    "DynamicSampleCountMatchesConfigured"->TrueQ[Lookup[sizingChecks,"DynamicSampleCountMatchesConfigured",False]],
    "DynamicStateSamplesCoverFullRun"->TrueQ[Lookup[sizingChecks,"DynamicStateSamplesCoverFullRun",False]],
    "DynamicLoadPropagationSamplesCoverFullRun"->TrueQ[Lookup[sizingChecks,"DynamicLoadPropagationSamplesCoverFullRun",False]],
    "DynamicStationToMembraneLoadMapConserved"->TrueQ[Lookup[sizingChecks,"DynamicLoadMapConserved",False]],
    "DynamicEveryStationLoadTransferConservedAtEveryPropagationSample"->TrueQ[
      Lookup[sizingChecks,"DynamicLoadMapConservesEveryStationTransfer",False]],
    "DynamicSheetGravityPropagatedToMembraneLoadMap"->TrueQ[Lookup[sizingChecks,"DynamicSheetGravityPropagatedToMembraneLoadMap",False]],
    "DynamicAttachmentGravityPropagatedToMembraneLoadMap"->TrueQ[Lookup[sizingChecks,"DynamicAttachmentGravityPropagatedToMembraneLoadMap",False]],
    "DynamicMembraneTractionWithinStructuralScreen"->TrueQ[Lookup[sizingChecks,"DynamicStructuralLoadScreenPass",False]],
    "ExternalActuatorQualificationNeedsRecorded"->TrueQ[Lookup[sizingChecks,"ExternalActuatorQualificationItemsExplicitlyRecorded",False]],
    "DynamicQuaternionNormalizationMaintained"->TrueQ[Lookup[sizingChecks,"QuaternionNormalizationMaintained",False]],
    "DynamicRecoveryWithinConfiguredLimit"->TrueQ[Lookup[sizingChecks,"RecoveryWithinConfiguredLimit",False]],
    "PoleExecutionRemainsIsolated"->TrueQ[$Phase1ExecutingPole&&MemberQ[$Phase1PoleIDs,$Phase1CurrentPole]&&
      Keys[Lookup[$Phase1State,"PoleOperatingInputs",<||>]]==={$Phase1CurrentPole}&&
      Keys[Lookup[$Phase1State,"PoleStates",<||>]]==={$Phase1CurrentPole}],
    "NoCombinedMechanicalEquilibriumIntroduced"->True,
    "HardwareQualificationIsExplicitlyNotClaimed"->TrueQ[
      AssociationQ[sizing]&&Lookup[sizing,"HardwareQualification",True]===False&&
      ListQ[unresolved]&&Length[unresolved]>0]
  |>;
  result=<|"Pole"->$Phase1CurrentPole,"Step"->4,
    "StepName"->"Complete ICARUS Carryover, Collector Geometry, and Distributed Physical Loading",
    "Status"->If[And@@(TrueQ/@Values[checks]),
      "All modeled Step 4 checks pass; physical hardware qualification remains open.",
      "Step 4 remains incomplete; one or more modeled checks are false or unavailable."],
    "Step4ScopeComplete"->TrueQ[And@@(TrueQ/@Values[checks])],
    "Checks"->checks,"Step4Core"->core,
    "ICARUSRedesignSizing"->If[AssociationQ[sizing],KeyDrop[sizing,{"LimitedDynamicSimulation"}],sizing],
    "TorqueFreeRotationResults"->freeRotation,
    "GravityGradientWobbleResults"->wobble,
    "RegisteredStabilityCriteria"->stability,
    "ActuatorRequirementAssessment"->If[AssociationQ[sizing],Lookup[sizing,"ActuatorRequirementAssessment",Missing["Unavailable"]],Missing["SizingUnavailable"]],
    "StationDemandProfile"->If[AssociationQ[sizing],KeyTake[Lookup[sizing,"LimitedDynamicSimulation",<||>],
      {"MaximumRequiredStationForceByStation_N","MaximumRequiredStationTorqueByStation_Nm",
       "PeakStationForceSampleIndices","PeakStationForceTimes_s","PeakStationForceVectors_N",
       "PeakStationForceUnitDirections","PeakStationTorqueSampleIndices","PeakStationTorqueTimes_s",
       "PeakStationTorqueVectors_Nm","StationForceVectorsBySample_N","StationTorqueVectorsBySample_Nm"}],
      Missing["SizingUnavailable"]],
    "DynamicResults"->dynamic,
    "OutwardForceMargin"->KeyTake[natural,{"RadiationOutwardRadialForce_N","GravityInwardRadialForce_N",
      "SolarWindRadialForce_N","NetNaturalRadialForce_N","RadiationToInwardGravityRadialForceRatio",
      "RadiationEquivalentMassAtRadialBalance_kg","CurrentGravityEquivalentMass_kg",
      "SignedFutureAddedMassCapacityBeforeRadialBalance_kg","FutureMassCapacityBeforeRadialBalance_kg",
      "MaximumFutureAddedMassCapacity_kg","FutureMassTarget_kg","FutureMassTargetFractionOfCurrentMass",
      "FutureAddedMassCapacityToCurrentMassRatio","FutureMassGrowthTargetPass",
      "FutureMassTargetBasis","FutureMassCapacityAssumptions","OutwardRadialBiasObjective"}],
    "UnresolvedActuatorDesignProperties"->unresolved,
    "HardwareQualification"->False,
    "HardwareQualificationStatement"->"A force-capacity target and reduced-order dynamics do not qualify current or redesigned hardware. Torque/gearing, stroke/slew, measured bandwidth/phase margin, duty cycle, power/energy, thermal limits, life/radiation and attachments remain to be specified or qualified.",
    "PerPoleOnly"->True,"OtherPoleOperatingStateAccessed"->False,
    "CombinedMechanicalEquilibrium"->False,
    "TestExecutionStatus"->"Mathematica runtime testing is authorized; the Step 4 assessment remains pending complete independent per-pole results."|>;
  phase1StoreResult["Step4Assessment",result];
  stamp=DateString[{"Year","-","Month","-","Day"," ","Hour",":","Minute",":","Second"}];
  phase1Audit["Step4AssessmentProduced",<|"Pole"->$Phase1CurrentPole,
    "Step4ScopeComplete"->result["Step4ScopeComplete"],"Time"->stamp|>];
  result
];

(* ========================================================================
   7. VALIDATION, ACCEPTANCE, REPORT AND HANDOFF
   ======================================================================== *)

phase1ValidateCurrent[] := Module[{results=phase1EnsureCalculated[]},
  If[FailureQ[results],Return[results]];
  results["Validation"]
];

phase1RunSelfTestsCurrent[] := Module[{results=phase1EnsureCalculated[],validation,testNames,checks,failed,passed,notApplicable,feasibility,report,missingTests,approvedNotApplicable,unexpectedNonBoolean},
  If[FailureQ[results],Return[results]];
  validation=results["Validation"];
  testNames={"CentralInputSchemaComplete","AllCentralInputChecksPass","AllSelectedModelFormInputsSupported","SolarGravitationalParameterPositive",
    "SolarLuminosityNominalReferenceConsistencyCheck","PVScenarioOptionsValid","PVScenarioRecognized",
    "PVScenarioOutputIndependentRecalculation",
    "MITTemperatureAdjustedEfficiencyIndependentRecalculation",
    "IntegratedPVTemperatureAdjustedEfficiencyIndependentRecalculation",
    "ProjectTargetTemperatureAdjustedEfficiencyIndependentRecalculation",
    "PVCellArraySpecificPowerImpliedEfficiencyDoesNotExceedFreeStandingReference",
    "IntegratedSpecificPowerImpliedEfficiencyDoesNotExceedIntegratedReference",
    "PVSpecificPowerIrradianceScalingIndependentlyRecalculated",
    "ConditionedPowerIndependentRecalculation","PVTechnologyScenarioMassesIndependentlyRecalculated",
    "OpticalReflectorEnergyClosure","OpticalPVEnergyClosure",
    "WholeSurfaceOpticalEnergyConservation","PVFractionEnergyLedgerConnected","ReflectorEnergyLedgerConnected",
    "CoverageRange","DistancePositive","HeliocentricReferenceMotionModeSupported","HeliocentricStaticHoverVelocityValid",
    "GeometryMeshCurvedAreaConverges","MeshMomentumResolutionConverges",
    "NumericalVsAnalyticMomentumCoefficient","RadiationPatchForceIndependentRecalculation","RadiationTorqueIndependentRecalculation","PatchForceVsMomentumCoefficientCrossCheck","RadiationForceMassAccelerationCrossCheck",
    "ArealAndTotalForceAccelerationCrossCheck","DistributedGravityIndependentRecalculation","SolarWindForceIndependentRecalculation","SolarWindForceIncludedInEquilibrium",
    "NaturalTorqueIndependentRecalculation","NaturalForceOutwardBiasAtCurrentInputs",
    "NaturalTransverseForceBalanceAtCurrentInputs","NaturalTorqueEquilibriumAtCurrentInputs",
    "ControlledOutwardForceEnvelopeAtCurrentInputs","OutwardEnvelopeRequiresMassLedgerAndTransverseBalance",
    "FutureAddedMassCapacityPositiveAtCurrentInputs","PVTemperatureIndependentRecalculation","ReflectorTemperatureIndependentRecalculation",
    "PVThermalBalanceResidual","PVThermalCouplingConverged","ReflectorThermalBalanceResidual","PVOutputBelowAbsorbedEnergy",
    "PVSpecificPowerCapApplied","PVMassConsistentAcrossMassAndPowerLedgers",
    "TransferAndConditioningConnected","StationMassCountedOnce","StationCoordinatesWithinPlanform","MembraneSubstrateIncludedInMassLedger","PerimeterHardwareMassIncludedInMassLedger",
    "TotalMassComponentLedgerCloses","InertiaTensorPositive","DistributedMassConservation",
    "CenterOfMassFinite","QuaternionNormalized","ICARUSWrenchMatrixFullRank",
    "StructuralScreenCalculated","ICARUSStationForceCapacityInputValid","ICARUSWrenchAllocatorReconstructsDemand",
    "ICARUSLoadMapConservesStationForce","ICARUSLoadMapConservesStationMoment",
    "ICARUSPerStationLoadWeightsNormalize"};
  missingTests=Complement[testNames,Keys[validation]];
  checks=KeyTake[validation,Complement[testNames,missingTests]];
  approvedNotApplicable=<|"NumericalVsAnalyticMomentumCoefficient"->Missing["AnalyticFaceOnCheckNotApplicableAtTiltOrAttitude"]|>;
  notApplicable=Select[Keys[checks],KeyExistsQ[approvedNotApplicable,#]&&SameQ[checks[#],approvedNotApplicable[#]]&];
  unexpectedNonBoolean=Select[Keys[checks],!BooleanQ[checks[#]]&&!MemberQ[notApplicable,#]&];
  failed=Join[Select[Keys[checks],!TrueQ[checks[#]]&&!MemberQ[notApplicable,#]&],missingTests];
  passed=Select[Keys[checks],TrueQ[checks[#]]&];
  feasibility=<|"MassFeasible"->results["MassBalance"]["MassFeasible"],
    "OutwardRadialBiasPass"->results["MassBalance"]["OutwardRadialBiasPass"],
    "TransverseForceBalancePass"->results["MassBalance"]["TransverseForceBalancePass"],
    "ControlledOutwardForceEnvelopePass"->results["MassBalance"]["ControlledOutwardForceEnvelopePass"],
    "ExactVectorEquilibriumDiagnostic"->results["MassBalance"]["ExactVectorEquilibrium"],
    "NaturalTorqueEquilibrium"->results["MassBalance"]["ExactTorqueEquilibrium"],
    "ExactNaturalEquilibriumDiagnostic"->results["MassBalance"]["ExactNaturalEquilibrium"],
    "EquilibriumScope"->results["MassBalance"]["EquilibriumScope"],
    "WholeTwoPoleSystemEquilibriumEvaluated"->False,
    "ThermalLimitsWithinBounds"->results["Thermal"]["AllThermalLimitsWithinBounds"],
    "StaticStructuralScreenPass"->results["StructuralScreen"]["StructuralScreenPass"]|>;
  report=<|"TestCount"->Length[testNames],"ExpectedTestKeysPresent"->(missingTests==={}),
    "MissingTestKeys"->missingTests,"PassedCount"->Length[passed],
    "FailedCount"->Length[failed],"NotApplicableCount"->Length[notApplicable],
    "UnexpectedNonBooleanTestKeys"->unexpectedNonBoolean,
    "PassedTests"->passed,"FailedTests"->failed,"NotApplicableTests"->notApplicable,
    "NotApplicablePolicy"->"Only the face-on analytic momentum comparison may be not applicable, and only when the attitude/incidence condition explicitly returns its exact Missing reason. Every missing test key, False value, unexpected Missing, Failure or other non-Boolean result fails closed.",
    "EngineeringFeasibilityStatus"->feasibility,"Validation"->validation,
    "CodeSelfTestStatus"->If[failed==={},"All applicable calculation-integrity self-tests passed for this input snapshot.",
      "One or more calculation-integrity tests failed. Do not treat outputs as accepted until corrected."],
    "EngineeringStatus"->"Engineering feasibility is reported separately; a physically infeasible input case does not by itself indicate a software self-test failure."|>;
  phase1StoreResult["SelfTestReport",report]
];

phase1RunReportCurrent[] := Module[{results=phase1EnsureCalculated[],in=Phase1GetInputs[]},
  If[FailureQ[results],Return[results]];
  phase1StoreResult["RunReport",<|"Revision"->"v11.65 Step 4 station-demand vector frame documentation",
    "GoverningObjective"->"Maximize delivered electrical power subject to independently evaluated natural force and torque equilibrium plus quantified operating/structural limits for each pole system. Shared design/material inputs are evaluated in two separate operating contexts; no inter-pole operating coupling is present.",
    "EquilibriumScope"->"One independently operated pole system; evaluated separately for Pole1 and Pole2.",
    "WholeTwoPoleSystemEquilibriumEvaluated"->False,
    "CentralInputCount"->Length[Keys[in]],"CentralInputRegister"->in,
    "SelectedSharedDesignMaterialModelForms"->KeyTake[in,{"PVLayoutModel","GeometryProfileModel","MassDistributionModel","ICARUSLoadTransferModel","MembraneStructuralModel","ICARUSStationCountScope"}],
    "SelectedPoleSpecificEnvironmentAndReferenceMotionForms"->KeyTake[in,{"FlareTemporalProfile","CMETemporalProfile","HeliocentricReferenceMotionMode"}],
    "HeliocentricReferenceMotionScope"-><|"SelectedMode"->in["HeliocentricReferenceMotionMode"],
      "OrbitalPropagationImplemented"->False,"RotatingFrameCouplingImplemented"->False,
      "ReferenceVelocityRequirement_m_s"->{0.,0.,0.},
      "Rule"->"The explicitly selected Phase 1 mode is StaticHover. Each pole independently requires zero heliocentric reference velocity; local perturbation velocities are modeled separately. No Keplerian orbit propagation or rotating-frame coupling is implemented."|>,
    "SelectedPoleSpecificControllerSettings"->KeyTake[in,{"ControllerTranslationKp_perS2","ControllerTranslationKd_perS","ControllerAttitudeKp_perS2","ControllerAttitudeKd_perS"}],
    "OptimizerVariables"->{"Distance_m","PVFraction"},
    "OptimizerIndependentGridResolution"->{in["OptimizerGridPointCount"]+1,in["OptimizerCoverageGridPointCount"]+1},
    "DefaultInputAudit"->phase1DefaultInputAudit[],
    "ApprovedAssumptions"->Phase1ApprovedAssumptions[],
    "InputReadiness"->Phase1InputStatus[],
    "DerivedOutputs"->$Phase1State["Derived"],
    "CalculationOutputs"->results,
    "Validation"->results["Validation"],
    "CalculationManifest"->$Phase1State["LastRun"]["CalculationManifest"],
    "AuditLog"->$Phase1State["AuditLog"],
    "ExecutionStatement"->"This report is generated by Mathematica from the shared design/material assumption register and the active pole's independent operating-input assumption register. User-approved assumptions are identified in ApprovedAssumptions and are not represented as measured or qualified properties. Pole1 and Pole2 execute in separate state, cache and result contexts; only scalar reporting outputs may be summed after independent calculations.",
    "CachedValuesAreAcceptedOnlyForExactInputSnapshots"->True,
    "CentralStateInputSnapshotHash"->$Phase1State["LastRun"]["InputSnapshotHash"],
    "CentralStateSnapshotMatchesCurrentInputs"->TrueQ[$Phase1State["LastRun"]["InputSnapshot"]===in],
    "CentralStateSnapshotHashMatchesCurrentInputs"->TrueQ[$Phase1State["LastRun"]["InputSnapshotHash"]===Hash[in,"SHA256"]]|>]
];

phase1Phase2HandoffCurrent[] := phase1StoreResult["Phase2Handoff",<|
  "Phase1Outputs"->{"Central numeric input and model-form register","Stored geometry and local surface mesh","Local optical closure and radiation force/moment quadrature","Independent analytic-versus-numerical momentum coefficient check","Nominal solar-parameter consistency calculations (GM-to-mass reconstruction is algebraic; luminosity-to-irradiance comparison checks nominal-reference consistency, not independent measurements)","Mass ledger including base membrane substrate, reflective coating, PV, wiring, separately modelled perimeter hardware, deferred mass and configured stations; integrated PV cell array overlap handled by an explicit central policy","Natural vector equilibrium residual","Four PV performance scenarios and delivered power ledger","Radiative thermal boundary and thermal residual","Configured-station wrench allocator and user-supplied per-station force capacity","Force- and moment-conserving station-to-membrane actuator load mapping plus perimeter/station gravity attachment-load transfer, with dynamic patch-traction screening","Rigid-body quaternion/Euler free rotation and integrated 3-D simulation","Disturbance/degradation scenarios","Patch-pressure-driven selected membrane substrate tensioned-membrane structural screening calculation","Acceptance/validation manifest and audit history"},
  "Phase2MustReplaceOrValidate"->{"Actual deployed CAD/profile and material layup","Measured reflector/PV spectral R/A/T and diffuse reflectance","Qualified PV efficiency/temperature/radiation curve","Measured selected substrate/composite areal mass, modulus, strength, creep and fatigue","Nonlinear membrane/structural finite-element or validated reduced-order model","Measured ICARUS force/torque/stroke/bandwidth/power ratings","Distributed wiring, joints, perimeter and equipment masses","Thermal conduction, transient heat capacity, view factors and hot spots","Validated flare/CME/SEP histories","Full electrical topology, resistance, current/voltage and power electronics"},
  "DeferredByProjectInstruction"->{"Magnetron mass","Capacitor mass","Resistor/circuit mass","Detailed complete component mass distribution"},
  "HandoffStatus"->"Phase 1 performs internally connected numerical screening using user-approved assumptions and explicit unresolved qualification gates. No output is a flight qualification or accepted engineering design until Phase 2 replaces or validates the stated assumptions with measured/qualified project data."|>];

phase1StabilityCriteriaCurrent[] := Module[{in,g,core,result},
  core=phase1EnsureStep4CoreCurrent[];
  If[FailureQ[core],Return[core]];
  in=Phase1GetInputs[];g=Lookup[core,"Geometry",Missing["GeometryUnavailable"]];
  If[!AssociationQ[g],Return[Failure["GeometryUnavailable",<||>]]];
  result=<|"RadialDeviationTolerance_m"->in["RadialDeviationToleranceFractionOfRadius"] g["PlanformEquivalentRadius_m"],
    "LateralDeviationTolerance_m"->in["LateralDeviationToleranceFractionOfRadius"] g["PlanformEquivalentRadius_m"],
    "AttitudeTolerance_rad"->in["AttitudeTolerance_rad"],"PVTemperatureLimit_K"->in["PVTemperatureLimit_K"],
    "ReflectorTemperatureLimit_K"->in["ReflectorTemperatureLimit_K"],
    "MaximumDeflectionFractionOfRadius"->in["MaximumDeflectionFractionOfRadius"],
    "MaximumRecoveryTime_s"->in["RecoveryTimeMaximum_s"],"ICARUSSaturationAllowed"->False,
    "AcceptanceRequiresPositiveRadiationOnlyOutwardMarginTransverseForceToleranceAndNaturalTorqueTolerance"->True,
    "ExactZeroNetForceRequirement"->False,
    "ExactVectorEquilibriumUse"->"Diagnostic only; the governing radial objective is positive outward radiation surplus."|>;
  phase1StoreResult["StabilityCriteria",result]
];

phase1RunFullAssessmentCurrent[] := Module[
  {base,originalInputs,originalResults,eq,floor,disturbance,
   free,wobble,baselineDynamic,optimization,handoff,assessment,report,optimizedDynamic,
   stability,selfTests,rootFound=False,rootExact=False},
  base=Phase1ComputeAll[];
  If[FailureQ[base],Return[base]];
  originalInputs=Phase1GetInputs[];
  originalResults=Phase1GetResults[];
  eq=Phase1SolveExactEquilibrium[];
  If[FailureQ[eq],Return[eq]];
  rootFound=AssociationQ[eq] && KeyExistsQ[eq,"PVFraction"];
  rootExact=rootFound && TrueQ[Lookup[Lookup[eq,"MassBalance",<||>],"ExactNaturalEquilibrium",False]];
  (* Equilibrium roots are diagnostic only. The full assessment never changes PVFraction or distance. *)
  floor=Phase1DistanceThermalFloor[];If[FailureQ[floor],Return[floor]];
  disturbance=Phase1DisturbanceScenarios[];If[FailureQ[disturbance],Return[disturbance]];
  stability=Phase1StabilityCriteria[];If[FailureQ[stability],Return[stability]];
  selfTests=Phase1RunSelfTests[];If[FailureQ[selfTests],Return[selfTests]];
  free=Phase1FreeRotationTrajectory[];If[FailureQ[free],Return[free]];
  wobble=Phase1WobbleSimulation[];If[FailureQ[wobble],Return[wobble]];
  baselineDynamic=Phase1IntegratedSimulation[];If[FailureQ[baselineDynamic],Return[baselineDynamic]];
  optimization=Phase1JointOptimization[];If[FailureQ[optimization],Return[optimization]];
  optimizedDynamic=If[AssociationQ[optimization],Lookup[optimization,"DynamicSimulation",Missing["NoOptimizedDynamicRun"]],Missing["NoOptimizedDynamicRun"]];
  handoff=Phase1Phase2Handoff[];
  assessment=<|"Revision"->"v11.65 centralized full assessment",
    "OriginalInputSnapshot"->originalInputs,
    "OriginalCalculationOutputs"->originalResults,"ExactEquilibriumDiagnosticSolve"->eq,
    "ThermalDistanceFloor"->floor,"DisturbanceScenarios"->disturbance,
    "StabilityCriteria"->stability,"SelfTests"->selfTests,"FreeRotationTrajectory"->free,"WobbleSimulation"->wobble,
    "BaselineIntegratedSimulation"->baselineDynamic,
    "JointOptimization"->optimization,"OptimizedIntegratedSimulation"->optimizedDynamic,
    "Phase2Handoff"->handoff,"FinalInputSnapshot"->Phase1GetInputs[],
    "EquilibriumRootWasFound"->rootFound,"EquilibriumRootPassedExactNaturalEquilibrium"->rootExact,
    "EquilibriumDiagnosticRootAppliedToActiveInputs"->False,
    "WholeTwoPoleSystemEquilibriumEvaluated"->False,
    "WholeTwoPoleSystemEquilibriumQualification"->"Not a coupled equilibrium problem: the two pole systems are operationally independent by governing architecture. Each pole is evaluated separately; only scalar outputs are summed.",
    "OptimizerCandidateApplicationPolicy"->"Optimizer candidates are recalculated and dynamically evaluated within temporary per-pole input snapshots; no candidate is automatically applied or retained in live inputs.",
    "OptimizerCandidateAppliedToLiveInputs"->False,
    "RadialOrTorqueUnbalancedRootWasAppliedAsEquilibrium"->False,
    "CalculationDataFlow"->"All numerical outputs are generated in Wolfram Language from shared design/material inputs and this pole's independent operating-input register. Each pole has its own state, controller, disturbances, dynamics, cache and results. No operating state or force is exchanged between poles. Aggregate mass and power are arithmetic sums of the two independently calculated outputs."|>;
  phase1StoreResult["FullAssessment",assessment];
  report=Phase1RunReport[];
  <|"Assessment"->assessment,"RunReport"->report,"FinalState"->Phase1GetState[]|>
];

(* ========================================================================
   8. INTERACTIVE PANEL — UI writes to the same central input register
   ======================================================================== *)



(* ========================================================================
   9. TWO-POLE INDEPENDENT-SYSTEM ARCHITECTURE — v11.65

   Governing two-pole rule (user-specified):
     Pole1 and Pole2 are separate physical operating systems. They share only
     design and material definitions. Each has its own operating inputs,
     operating environment, initial conditions, event profiles, controller gains and state, dynamics, force/torque calculations, result cache and acceptance
     results. During an individual pole calculation, the other pole's operating
     inputs, environment, state, cache and results are inaccessible. No force,
     torque, power, control command, state or disturbance is transferred between
     poles. Immutable physical constants and mathematical/numerical-method
     definitions are common code references, not exchanged operating data.

     Both systems are computed independently. Only after both calculations finish
     may scalar mass, area and electrical power be summed for reporting. That
     reporting-only aggregation does not feed either system's operation. No
     per-pole value is multiplied by PoleCount to stand in for the other pole.
     No combined mechanical equilibrium is imposed.

   PoleCount = 2 is the fixed user-confirmed architecture. The shared and per-pole
   registers contain user-approved assumptions, reported separately by
   Phase1ApprovedAssumptions[]. These values are assumptions, not measured or qualified
   inputs. Pole1/Pole2 are neutral identifiers; no north/south orientation is inferred.
   ======================================================================== *)

(* Public API symbols and implementation helpers were initialized by the package header. *)





(* Task dependencies are an explicit execution/preflight register. Geometry,
   SurfaceMesh, and OpticalRegister are pure setup calculations and may execute
   independently when their listed inputs are complete. Every other registered
   task retains the full-core execution gate. Dependency completeness is never
   treated as evidence that a non-independent calculation has executed. *)
$Phase1TaskInputDependencies = <|
  "Geometry" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius"},
  "SurfaceMesh" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","MeshAreaRelativeTolerance"},
  "OpticalRegister" -> {"ReflectionModel","ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","OpticalClosureTolerance"},
  "InitialRadiationLoads" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","MeshAreaRelativeTolerance","ReflectionModel","ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","OpticalClosureTolerance","Distance_m","PVFraction","IncidenceAngle_deg","SolarLuminosity_W","SpeedOfLight_m_s","PowerLedgerRelativeTolerance"},
  "RadiationLoads" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","MeshAreaRelativeTolerance","ReflectionModel","ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","OpticalClosureTolerance","Distance_m","PVFraction","IncidenceAngle_deg","InitialAttitudeSmallAngles_rad","SolarLuminosity_W","SpeedOfLight_m_s"},
  "MassBalance" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","MeshAreaRelativeTolerance","ReflectionModel","ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","OpticalClosureTolerance","Distance_m","PVFraction","IncidenceAngle_deg","InitialAttitudeSmallAngles_rad","SolarLuminosity_W","SpeedOfLight_m_s","PrimaryPVScenario","PVCellArrayMassPolicy","PVArealMass_kg_m2","ReflectorArealMass_kg_m2","MembraneSubstrateMaterialClass","AluminumFoilThickness_m","AluminumDensity_kg_m3","WiringArealMass_kg_m2","OtherInstalledArealMass_kg_m2","PerimeterHardwareLinearMass_kg_m","ICARUSStationCount","ICARUSStationMass_kg","ICARUSStationPositionsLocal_m","DeferredEquipmentMass_kg","MassDistributionModel","PowerLedgerRelativeTolerance"},
  "NaturalEquilibrium" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","MeshAreaRelativeTolerance","ReflectionModel","ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","OpticalClosureTolerance","Distance_m","PVFraction","IncidenceAngle_deg","InitialAttitudeSmallAngles_rad","InitialAngularVelocity_rad_s","InitialPositionLocal_m","InitialVelocityLocal_m_s","InitialVelocityHeliocentric_m_s","HeliocentricReferenceMotionMode","SolarLuminosity_W","SpeedOfLight_m_s","SolarGravitationalParameter_m3_s2","AstronomicalUnit_m","PowerLedgerRelativeTolerance","MembraneSubstrateMaterialName","SolarWindProtonDensity_1AU_cm3","SolarWindSpeed_1AU_m_s","ProtonMass_kg","CentimetersPerMeter","MassDistributionModel","PVCellArrayMassPolicy","PVArealMass_kg_m2","ReflectorArealMass_kg_m2","MembraneSubstrateMaterialClass","AluminumFoilThickness_m","AluminumDensity_kg_m3","WiringArealMass_kg_m2","OtherInstalledArealMass_kg_m2","PerimeterHardwareLinearMass_kg_m","ICARUSStationCount","ICARUSStationMass_kg","ICARUSStationPositionsLocal_m","DeferredEquipmentMass_kg","FutureAddedMassTargetFractionOfCurrentMass","ExactEquilibriumRelativeTolerance"},
  "Thermal" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","ReflectionModel","ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","Distance_m","PVFraction","IncidenceAngle_deg","BothSidesRadiate","PVIRemissivity","ReflectorIRemissivity","PVTemperatureLimit_K","ReflectorTemperatureLimit_K","StefanBoltzmann_W_m2_K4","SolarLuminosity_W","PVThermalCouplingMaxIterations","ThermalResidualRelativeTolerance"},
  "PVPerformance" -> {"PVLayoutModel","PrimaryPVScenario","PVScenarioOptions","PVFraction","Distance_m","IncidenceAngle_deg","PVArealMass_kg_m2","PVCellArraySpecificPower_W_kg","PVSpecificPowerReferenceIrradiance_W_m2","PVReferenceTemperature_K","PVCellReferenceEfficiency","PVCellArrayEfficiencyReference","ProjectTargetEfficiency","PVEfficiencyTemperatureCoefficient_perK","PVAnnualDegradationFraction","PVDegradationPerSEPReferenceDoseFraction","SEPDoseReference_protons_cm2","SEPDose_protons_cm2","ReferenceMissionYears","Year_s","PVTemperatureLimit_K"},
  "PowerLedger" -> {"TransferEfficiency","ConditioningEfficiency","PVLayoutModel","PrimaryPVScenario","PVScenarioOptions","PVFraction","Distance_m","IncidenceAngle_deg","PVArealMass_kg_m2","PVCellArraySpecificPower_W_kg","PVSpecificPowerReferenceIrradiance_W_m2","PVReferenceTemperature_K","PVCellReferenceEfficiency","PVCellArrayEfficiencyReference","ProjectTargetEfficiency","PVEfficiencyTemperatureCoefficient_perK","PVAnnualDegradationFraction","PVDegradationPerSEPReferenceDoseFraction","SEPDoseReference_protons_cm2","SEPDose_protons_cm2","ReferenceMissionYears","Year_s","PVTemperatureLimit_K"},
  "StructuralScreen" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","ReflectionModel","ReflectorSolarReflectivity","ReflectorSolarTransmissivity","PVSolarReflectivity","PVSolarTransmissivity","Distance_m","PVFraction","IncidenceAngle_deg","SolarWindProtonDensity_1AU_cm3","SolarWindSpeed_1AU_m_s","ProtonMass_kg","CentimetersPerMeter","MembraneStructuralModel","MembraneSubstrateMaterialClass","AluminumFoilThickness_m","AluminumDensity_kg_m3","AluminumYoungsModulus_Pa","AluminumYieldStrength_Pa","AluminumTensileStrength_Pa","MembranePretension_N_m","StructuralSafetyFactor","MaximumDeflectionFractionOfRadius","CircularMembraneDeflectionCoefficient","WiringArealMass_kg_m2","PrimaryPVScenario","PVCellArrayMassPolicy"},
  "GravityGradientModes" -> {"Distance_m","SolarGravitationalParameter_m3_s2","WobbleDampingRatio","MassDistributionModel","GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","PVFraction","PVArealMass_kg_m2","PVCellArrayMassPolicy","ReflectorArealMass_kg_m2","MembraneSubstrateMaterialClass","AluminumFoilThickness_m","AluminumDensity_kg_m3","WiringArealMass_kg_m2","ICARUSStationCount","ICARUSStationMass_kg","ICARUSStationPositionsLocal_m"},
  "FreeRotationDynamicsCore" -> {"Distance_m","GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","MassDistributionModel","PVFraction","PVArealMass_kg_m2","PVCellArrayMassPolicy","ReflectorArealMass_kg_m2","MembraneSubstrateMaterialClass","AluminumFoilThickness_m","AluminumDensity_kg_m3","WiringArealMass_kg_m2","ICARUSStationCount","ICARUSStationMass_kg","ICARUSStationPositionsLocal_m","InitialAttitudeSmallAngles_rad","InitialAngularVelocity_rad_s","DynamicCheckDuration_s","DynamicAccuracyGoal","DynamicPrecisionGoal","DynamicMaxSteps","DynamicSampleCount"},
  "ICARUSLoadTransfer" -> {"GeometryProfileModel","PerPoleProjectedArea_m2","CapDepthToPlanformRadius","MeshRadialCount","MeshAzimuthCount","MassDistributionModel","ICARUSStationCount","ICARUSStationCountScope","ICARUSStationMass_kg","ICARUSStationPositionsLocal_m","ICARUSLoadTransferModel","MembraneLoadSpreadFractionOfRadius","ICARUSLoadMapRelativeTolerance"},
  "Step5StructuralArchitecture" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "Step4EngineeringCore" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "Step4Assessment" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "IntegratedSimulation" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "JointOptimization" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "ComputeAll" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "FullAssessment" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "SolveExactEquilibrium" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "FreeRotation" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "Wobble" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "Validate" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "CalculationSelfTests" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "DisturbanceScenarios" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "ThermalDistanceFloor" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "ICARUSControlLaw" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "ICARUSLoadPropagation" -> DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],$Phase1PoleOperatingKeys]],
  "SoftwareSelfTests" -> {}
|>;

(* These deterministic setup operations, together with the per-pole NaturalEquilibrium task,
   are approved for independent execution. Dynamic, optimization, thermal, structural and
   full assessment tasks remain behind their full-core execution gates. *)
$Phase1IndependentlyExecutableTasks = {"Geometry", "SurfaceMesh", "OpticalRegister", "InitialRadiationLoads", "NaturalEquilibrium"};

$Phase1OriginalDefaults = $Phase1DefaultInputs;
$Phase1PoleInputDefaults = KeyTake[$Phase1OriginalDefaults, $Phase1PoleOperatingKeys];
$Phase1DefaultInputs = KeyDrop[$Phase1DefaultInputs, $Phase1PoleOperatingKeys];

(* Move operating fields out of the shared Inputs association into separate pole maps. *)
$Phase1State = Join[$Phase1State, <|
  "SchemaVersion" -> $Phase1ModelVersion,
  "Inputs" -> KeyDrop[$Phase1State["Inputs"], $Phase1PoleOperatingKeys],
  "PoleOperatingInputs" -> AssociationThread[$Phase1PoleIDs, ConstantArray[$Phase1PoleInputDefaults, Length[$Phase1PoleIDs]]],
  "PoleStates" -> <||>,
  "TwoPoleAggregate" -> <||>,
  "PoleArchitectureRule" -> "There are two physically distinct systems, one installed at each pole. Their design and material definitions are shared; their operation is completely independent. Each pole has its own operating inputs, local environment and disturbance history, initial conditions, forces, torques, controllers, dynamics, stored state, caches, results, optimization and acceptance decisions. No operating state, force, torque, power, control command, disturbance, environment state or calculated operating output is exchanged, coupled, combined or used as an input between poles. Immutable physical constants and common mathematical/numerical algorithms are common definitions, not shared operating states. Scalar outputs may be arithmetically summed only after both calculations finish and only for reporting; aggregate results never feed either pole's operation. No combined mechanical equilibrium is imposed. Each pole uses its own local Sun-radial +x coordinate basis; no common global position/orientation is inferred.",
  "ActivePole" -> Missing["NoActivePole"]
|>];

$Phase1ExecutingPole = False;
$Phase1CurrentPole = None;
$Phase1SelectedPole = "Pole1";

(* Input readiness depends on required values only. *)
phase1ProjectInputKeys[] := DeleteDuplicates[Join[Keys[$Phase1DefaultInputs],
  If[TrueQ[$Phase1ExecutingPole], $Phase1PoleOperatingKeys, {}]]];

phase1PoleInputStatus[pole_String] := Module[{inputs, missing},
  If[!MemberQ[$Phase1PoleIDs, pole],
    Return[Failure["UnknownPoleID", <|"Pole" -> pole, "ValidPoleIDs" -> $Phase1PoleIDs|>]]
  ];
  inputs = Join[$Phase1State["Inputs"], Lookup[$Phase1State["PoleOperatingInputs"], pole, <||>]];
  missing = Select[Keys[inputs], MissingQ[Lookup[inputs, #, Missing[]]] &];
  <|"Pole" -> pole, "Ready" -> (missing === {}),
    "MissingRequiredInputKeys" -> missing,
    "InputCount" -> Length[inputs], "MissingRequiredInputCount" -> Length[missing]|>
];

Phase1MissingRequiredInputs[] := If[TrueQ[$Phase1ExecutingPole],
  Select[Keys[$Phase1State["Inputs"]], MissingQ[Lookup[$Phase1State["Inputs"], #, Missing[]]] &],
  Join[
    Select[Keys[$Phase1State["Inputs"]], MissingQ[Lookup[$Phase1State["Inputs"], #, Missing[]]] &],
    Flatten[Table[(pole <> "::" <> #) & /@
      Select[phase1PoleInputStatus[pole]["MissingRequiredInputKeys"],
        MemberQ[$Phase1PoleOperatingKeys, #] &], {pole, $Phase1PoleIDs}]]
  ]
];

Phase1InputStatus[pole_String] := If[TrueQ[$Phase1ExecutingPole] && pole =!= $Phase1CurrentPole,
  Failure["CrossPoleStatusReadBlocked", <|"ActivePole" -> $Phase1CurrentPole, "RequestedPole" -> pole|>],
  phase1PoleInputStatus[pole]];

Phase1InputStatus[] := If[TrueQ[$Phase1ExecutingPole],
  Module[{status = phase1PoleInputStatus[$Phase1CurrentPole]},
    Join[status, <|"ActivePole" -> $Phase1CurrentPole|>]],
  Module[{sharedMissing, poleStatus, allMissing},
    sharedMissing = Select[Keys[$Phase1State["Inputs"]],
      MissingQ[Lookup[$Phase1State["Inputs"], #, Missing[]]] &];
    poleStatus = AssociationMap[phase1PoleInputStatus, $Phase1PoleIDs];
    allMissing = Join[sharedMissing,
      Flatten[Table[(pole <> "::" <> #) & /@
        Select[poleStatus[pole]["MissingRequiredInputKeys"], MemberQ[$Phase1PoleOperatingKeys, #] &],
        {pole, $Phase1PoleIDs}]]];
    <|"Ready" -> (allMissing === {}), "MissingRequiredInputKeys" -> allMissing,
      "MissingRequiredInputCount" -> Length[allMissing],
      "SharedInputCount" -> Length[$Phase1State["Inputs"]],
      "PoleOperatingInputCountPerPole" -> Length[$Phase1PoleOperatingKeys],
      "PoleStatuses" -> poleStatus,
      "ApprovedAssumptionCount" -> Phase1ApprovedAssumptions[]["ApprovedAssumptionCount"],
      "ApprovedAssumptionsUsed" -> True,
      "EngineeringAcceptance" -> "NotEstablishedByInputReadiness; evaluate each pole's calculations, constraints and qualification evidence separately.",
      "InputReadinessScope" -> "All registered calculation inputs are populated by user-approved assumptions, reference/software definitions or per-pole derived values. This does not imply feasibility, stability, actuator capacity or engineering acceptance.",
      "UnresolvedEngineeringAndQualificationItems" -> Phase1ApprovedAssumptions[]["UnresolvedEngineeringAndQualificationItems"]|>
  ]
];

phase1TaskInputStatusFromInputs[inputs_Association, task_String] := Module[
  {keys, missing, unknown},
  If[!KeyExistsQ[$Phase1TaskInputDependencies,task],
    Return[Failure["UnknownTaskName",<|"Task"->task,"ValidTasks"->Keys[$Phase1TaskInputDependencies]|>]]
  ];
  keys=DeleteDuplicates[$Phase1TaskInputDependencies[task]];
  missing=Select[keys,MissingQ[Lookup[inputs,#,Missing["InputKeyNotRegistered",#]]]&];
  unknown=Complement[keys,Keys[inputs]];
  <|"Task"->task,"InputDependenciesSatisfied"->(missing==={}&&unknown==={}),
    "RequiredInputKeys"->keys,"MissingInputKeys"->missing,"UnregisteredInputKeys"->unknown,
    "PresentInputCount"->(Length[keys]-Length[missing]-Length[unknown]),
    "RequiredInputCount"->Length[keys],
    "PreflightScope"->"Checks registered task inputs only. This report does not run a calculation; only the explicitly supported independent setup tasks can execute without the full-core gate.",
    "CalculationExecuted"->False,"IndependentTaskExecutionAvailable"->MemberQ[$Phase1IndependentlyExecutableTasks,task]|>
];

phase1TaskInputStatusForPole[pole_String,task_String] := Module[
  {inputs,status,poleState,derived,manifest,taskRun,inputHash,executionFresh},
  If[TrueQ[$Phase1ExecutingPole]&&pole=!=$Phase1CurrentPole,
    Return[Failure["CrossPoleTaskStatusReadBlocked",<|"ActivePole"->$Phase1CurrentPole,"RequestedPole"->pole|>]]
  ];
  If[!MemberQ[$Phase1PoleIDs,pole],
    Return[Failure["UnknownPoleID",<|"Pole"->pole,"ValidPoleIDs"->$Phase1PoleIDs|>]]
  ];
  inputs=If[TrueQ[$Phase1ExecutingPole],Phase1GetInputs[],Phase1GetPoleInputs[pole]];
  If[FailureQ[inputs],Return[inputs]];
  status=phase1TaskInputStatusFromInputs[inputs,task];
  If[FailureQ[status],Return[status]];
  poleState=If[TrueQ[$Phase1ExecutingPole],$Phase1State,
    Lookup[Lookup[$Phase1State,"PoleStates",<||>],pole,<||>]];
  derived=If[AssociationQ[poleState],Lookup[poleState,"Derived",<||>],<||>];
  manifest=Lookup[derived,"IndependentTaskManifest",<||>];
  taskRun=Lookup[manifest,task,<||>];
  inputHash=Hash[KeyTake[inputs,status["RequiredInputKeys"]],"SHA256"];
  executionFresh=AssociationQ[taskRun]&&
    SameQ[Lookup[taskRun,"InputSnapshotHash",Missing[]],inputHash]&&
    TrueQ[Lookup[taskRun,"FullCoreCalculationExecuted",False]===False];
  Join[status,<|"Pole"->pole,
    "CalculationExecuted"->TrueQ[executionFresh],
    "IndependentTaskExecutionAvailable"->MemberQ[$Phase1IndependentlyExecutableTasks,task],
    "ExecutedOutputKeys"->If[TrueQ[executionFresh],Lookup[taskRun,"OutputKeys",{}],{}],
    "ExecutionFreshForCurrentInputs"->TrueQ[executionFresh]|>]
];

Phase1TaskInputStatus[] := Module[{pole=If[TrueQ[$Phase1ExecutingPole],$Phase1CurrentPole,$Phase1SelectedPole]},
  AssociationMap[phase1TaskInputStatusForPole[pole,#]&,Keys[$Phase1TaskInputDependencies]]
];
Phase1TaskInputStatus[task_String] := phase1TaskInputStatusForPole[
  If[TrueQ[$Phase1ExecutingPole],$Phase1CurrentPole,$Phase1SelectedPole],task];
Phase1TaskInputStatus[pole_String,task_String] := phase1TaskInputStatusForPole[pole,task];

Phase1InputRequirements[] := Module[
  {inputs = Phase1GetSharedInputs[], sharedGroups, sharedMissing, sharedCategorized,
   poleIDs, poleGroups, poleCategorized, unclassifiedShared, unclassifiedPole, ready},
  sharedGroups = Association @ KeyValueMap[Function[{name, keys},
    With[{missing = Select[keys, MissingQ[Lookup[inputs, #, Missing[]]] &]},
      name -> <|"RequiredKeys" -> keys, "MissingValues" -> missing,
        "MissingValueCount" -> Length[missing]|>
    ]
  ], $Phase1InputCategories];
  sharedMissing = Select[Keys[inputs], MissingQ[Lookup[inputs, #, Missing[]]] &];
  sharedCategorized = DeleteDuplicates[Flatten[Values[$Phase1InputCategories]]];
  poleIDs = If[TrueQ[$Phase1ExecutingPole], {$Phase1CurrentPole}, $Phase1PoleIDs];
  poleGroups = AssociationMap[Function[pole,
    Module[{poleInputs = Phase1GetPoleInputs[pole], groups, missingKeys},
      groups = Association @ KeyValueMap[Function[{name, keys},
        With[{missing = Select[keys, MissingQ[Lookup[poleInputs, #, Missing[]]] &]},
          name -> <|"RequiredKeys" -> keys, "MissingValues" -> missing,
            "MissingValueCount" -> Length[missing]|>
        ]
      ], $Phase1PoleOperatingInputCategories];
      missingKeys = Select[$Phase1PoleOperatingKeys, MissingQ[Lookup[poleInputs, #, Missing[]]] &];
      <|"Groups" -> groups, "MissingRequiredInputKeys" -> missingKeys,
        "MissingRequiredInputCount" -> Length[missingKeys]|>
    ]
  ], poleIDs];
  poleCategorized = DeleteDuplicates[Flatten[Values[$Phase1PoleOperatingInputCategories]]];
  unclassifiedShared = Complement[sharedMissing, sharedCategorized];
  unclassifiedPole = AssociationMap[
    Complement[poleGroups[#]["MissingRequiredInputKeys"], poleCategorized] &, poleIDs];
  ready = sharedMissing === {} &&
    And @@ (poleGroups[#]["MissingRequiredInputKeys"] === {} & /@ poleIDs) &&
    unclassifiedShared === {} && And @@ (unclassifiedPole[#] === {} & /@ poleIDs);
  <|"Ready" -> TrueQ[ready], "RequiredSharedInputCount" -> Length[Keys[inputs]],
    "MissingSharedInputCount" -> Length[sharedMissing], "SharedGroups" -> sharedGroups,
    "PoleOperatingRequirements" -> poleGroups,
    "UnclassifiedSharedRequiredInputs" -> unclassifiedShared,
    "UnclassifiedPoleOperatingInputs" -> unclassifiedPole,
    "SharedDesignMaterialInputCategories" -> $Phase1InputCategories,
    "PoleOperatingInputCategories" -> $Phase1PoleOperatingInputCategories,
    "MissingRequiredInputKeys" -> Join[sharedMissing,
      Flatten[Table[(pole <> "::" <> #) & /@ poleGroups[pole]["MissingRequiredInputKeys"], {pole, poleIDs}]]],
    "MissingValueCount" -> Length[sharedMissing] + Total[poleGroups[#]["MissingRequiredInputCount"] & /@ poleIDs],
    "Groups" -> sharedGroups,
    "UnclassifiedRequiredInputs" -> unclassifiedShared,
    "RequiredProjectAndNumericalInputCount" -> Total[Length /@ Values[$Phase1InputCategories]] +
      Length[poleIDs] Total[Length /@ Values[$Phase1PoleOperatingInputCategories]],
    "Rule" -> "Full model execution requires every registered value to be available. Values populated from the approved register are assumptions, not measured properties; unresolved ICARUS capacity remains demand-only and does not qualify hardware.",
    "RequiredValuesMustBeExplicit" -> False,
    "ApprovedAssumptionCount" -> Phase1ApprovedAssumptions[]["ApprovedAssumptionCount"],
    "ApprovedAssumptions" -> Phase1ApprovedAssumptions[],
    "UnresolvedEngineeringAndQualificationItems" -> Phase1ApprovedAssumptions[]["UnresolvedEngineeringAndQualificationItems"]|>
];

phase1ResolveDerivedInputs[in_Association] := Module[
  {resolved=in,area,count,radius,positions,distance,referenceFluence,au},
  (* Station coordinates are an explicit model-form assumption tied to the shared geometry,
     not an independently keyed project dimension. They refresh when area or station count changes. *)
  If[Lookup[resolved,"ICARUSStationPositionsLocal_m",Missing[]]===Automatic,
    area=Lookup[resolved,"PerPoleProjectedArea_m2",Missing[]];
    count=Lookup[resolved,"ICARUSStationCount",Missing[]];
    If[NumericQ[area]&&area>0.&&IntegerQ[count]&&count>0,
      radius=Sqrt[area/Pi];
      positions=Table[{0.,radius Cos[2. Pi (j-1)/count],radius Sin[2. Pi (j-1)/count]},{j,count}];
      resolved=Join[resolved,<|"ICARUSStationPositionsLocal_m"->positions|>]
    ]
  ];
  (* SEP fluence is derived pole-locally from that pole's current distance, so optimization
     or a distance edit cannot leave a stale 0.2 AU fluence value in either pole register. *)
  If[Lookup[resolved,"SEPDose_protons_cm2",Missing[]]===Automatic,
    distance=Lookup[resolved,"Distance_m",Missing[]];
    referenceFluence=Lookup[resolved,"SEPDoseReference_protons_cm2",Missing[]];
    au=Lookup[resolved,"AstronomicalUnit_m",Missing[]];
    If[NumericQ[distance]&&distance>0.&&NumericQ[referenceFluence]&&referenceFluence>=0.&&NumericQ[au]&&au>0.,
      resolved=Join[resolved,<|"SEPDose_protons_cm2"->referenceFluence (au/distance)^2|>]
    ]
  ];
  resolved
];

phase1AssumptionRecord[key_String,value_] := <|
  "Value"->value,
  "Classification"->If[MemberQ[{"ICARUSStationPositionsLocal_m","SEPDose_protons_cm2"},key],"DerivedFromUserApprovedAssumption","UserApprovedAssumption"],
  "Basis"->Lookup[$Phase1ApprovedAssumptionNotes,key,"User-approved screening assumption recorded in the 142-input assessment; not a measured or qualified value."]
|>;

Phase1ApprovedAssumptions[] := Module[
  {shared=phase1ResolveDerivedInputs[Phase1GetSharedInputs[]],poleMaps,numericalKeys,sharedKeys,poleKeys,poleIDs,unresolved},
  sharedKeys=Complement[DeleteDuplicates[Flatten[Values[KeyDrop[$Phase1ApprovedAssumptionGroups,{"PoleSpecificOperatingAssumptions","NumericalExecutionSettings"}]]]],{"ICARUSStationForceCapacity_N"}];
  poleKeys=$Phase1ApprovedAssumptionGroups["PoleSpecificOperatingAssumptions"];
  numericalKeys=$Phase1ApprovedAssumptionGroups["NumericalExecutionSettings"];
  poleIDs=If[TrueQ[$Phase1ExecutingPole],{$Phase1CurrentPole},$Phase1PoleIDs];
  poleMaps=AssociationMap[Function[pole,
    With[{inputs=Phase1GetPoleInputs[pole]},
      Association@Map[#->phase1AssumptionRecord[#,Lookup[inputs,#,Missing["NotAvailable"]]]&,poleKeys]
    ]],poleIDs];
  unresolved={
    <|"Item"->"ICARUS mission-specific actuator redesign feasibility","Status"->If[TrueQ[shared["ICARUSRedesignFeasibilityApproved"]],"User-approved conditional design assumption","Not approved"],"Value"->Lookup[shared,"ICARUSRedesignFeasibilityApproved",Missing["NotAvailable"]],"Reason"->"The user approves the premise that modest mission-specific reengineering can provide the required capability. This is a future design premise, not evidence that the present actuators are capable."|>,
    <|"Item"->"ICARUS current hardware ratings and complete actuator law","Status"->"Unresolved; conditional redesign force target can be calculated","Value"->Automatic,"Reason"->"Present force rating remains unknown. Local actuator torque, stroke, slew rate, bandwidth, duty cycle, power draw, thermal limits, lifetime and qualification are not specified. The 10% force reserve does not replace these checks."|>,
    <|"Item"->"External support/tether/anchor forces","Status"->"Not modelled; no support force assumed in the free-hover calculation scope","Value"->Missing["NotModelled"],"Reason"->"Any real external support mechanism must be specified and added as its own physical force/torque contribution."|>,
    <|"Item"->"Ultrathin aluminum-film process and structural qualification","Status"->"Unqualified screening properties","Value"->Missing["QualificationEvidenceRequired"],"Reason"->"Actual film thickness uniformity, grain/defect population, residual stress, yield and tensile response, fatigue, seams/joints, thermal cycling, radiation exposure, surface condition and manufacturing process must be characterized. Bulk 1060-O handbook values are not thin-film allowables."|>,
    <|"Item"->"Near-Sun PV/reflector durability","Status"->"Unqualified stress assumptions","Value"->Missing["QualificationEvidenceRequired"],"Reason"->"Exact-device radiation, UV, thermal-vacuum and lifetime degradation data are not established by these screening assumptions."|>
  };
  <|
    "ClassificationPolicy"->"Every populated design/material/operating value originating from the input register is an assumption, not a measurement or qualification. Mathematical approximations are preferred where suitable; otherwise modest synthetic values may be selected under the user-approved project policy, clearly labelled with their basis and checked upstream/downstream. The ICARUS modest-redesign feasibility premise is explicitly user-approved; the 10% force reserve and 0.55 kg station mass are provisional numerical choices under that policy, not separately user-specified values. Present actuator ratings remain unknown.",
    "SharedEngineeringAssumptions"->Association@Map[#->phase1AssumptionRecord[#,Lookup[shared,#,Missing["NotAvailable"]]]&,sharedKeys],
    "PoleSpecificOperatingAssumptions"->poleMaps,
    "NumericalExecutionSettings"->Association@Map[#-><|"Value"->Lookup[shared,#,Missing["NotAvailable"]],"Classification"->"UserApprovedNumericalSetting","Basis"->"Numerical convergence/solver setting; not a physical design or operating property."|>&,numericalKeys],
    "AlternativeMaterialComparisonPresets"->$Phase1AlternateMaterialScenarioPresets,
    "UnresolvedEngineeringAndQualificationItems"->unresolved,
    "ApprovedAssumptionCount"->(Length[sharedKeys]+Length[poleKeys]*Length[poleIDs]+Length[numericalKeys])
  |>
];

Phase1MaterialScenarioPresets[] := $Phase1AlternateMaterialScenarioPresets;

Phase1GetSharedInputs[] := KeyDrop[$Phase1State["Inputs"], $Phase1PoleOperatingKeys];
Phase1GetInputs[] := phase1ResolveDerivedInputs[$Phase1State["Inputs"]];
Phase1GetInput[name_String] := If[TrueQ[$Phase1ExecutingPole],
  Lookup[Phase1GetInputs[], name, Missing["UnknownInput", name]],
  If[MemberQ[$Phase1PoleOperatingKeys, name],
    AssociationMap[Lookup[Phase1GetPoleInputs[#], name, Missing["UnknownInput", name]] &, $Phase1PoleIDs],
    Lookup[Phase1GetSharedInputs[], name, Missing["UnknownInput", name]]]];
Phase1GetPoleInputs[pole_String] := Which[
  TrueQ[$Phase1ExecutingPole] && pole =!= $Phase1CurrentPole, Failure["CrossPoleInputReadBlocked", <|"ActivePole" -> $Phase1CurrentPole, "RequestedPole" -> pole|>],
  !MemberQ[$Phase1PoleIDs, pole], Failure["UnknownPoleID", <|"Pole" -> pole, "ValidPoleIDs" -> $Phase1PoleIDs|>],
  True, phase1ResolveDerivedInputs[Join[KeyDrop[$Phase1State["Inputs"], $Phase1PoleOperatingKeys], Lookup[$Phase1State["PoleOperatingInputs"], pole, <||>]]]];

(* Shared design/material changes invalidate both calculation caches, but do not
   modify either pole's operating inputs. PoleCount is fixed at the user-confirmed 2. *)
Phase1SetInputs[updates_Association] := Module[
  {current, unknown, changed, immutableChanges, cacheChanged},
  If[TrueQ[$Phase1ExecutingPole],
    Return[Failure["SharedInputsLockedDuringPoleExecution",
      <|"Reason" -> "A pole calculation cannot mutate shared design/material inputs."|>]]
  ];
  current = $Phase1State["Inputs"];
  unknown = Complement[Keys[updates], Keys[current]];
  If[unknown =!= {},
    Return[Failure["UnknownOrPoleSpecificInputKeys",
      <|"Keys" -> unknown, "Use" -> "Phase1SetPoleOperatingInputs[pole, values] for pole-specific values."|>]]
  ];
  If[KeyExistsQ[updates, "PoleCount"] && updates["PoleCount"] =!= 2,
    Return[Failure["PoleCountIsFixedAtTwo", <|"PoleCount" -> 2|>]]
  ];
  changed = Select[Keys[updates], !SameQ[Lookup[current, #, Missing[]], updates[#]] &];
  immutableChanges = Intersection[changed, $Phase1ImmutableInputKeys];
  If[immutableChanges =!= {},
    Return[Failure["ImmutableInputMutationBlocked",
      <|"Keys" -> immutableChanges,
        "Reason" -> "The governing project fixes fundamental physical constants, the two-sheet topology and intrinsic base-material properties. No-op assignments are permitted; changed values are not."|>]]
  ];
  cacheChanged = changed =!= {};
  $Phase1State = Join[$Phase1State, <|
    "Inputs" -> Join[current, updates],
    "PoleStates" -> If[cacheChanged, <||>, Lookup[$Phase1State, "PoleStates", <||>]],
    "TwoPoleAggregate" -> If[cacheChanged, <||>, Lookup[$Phase1State, "TwoPoleAggregate", <||>]]
  |>];
  phase1Audit["SharedDesignMaterialInputsUpdated", <|"ChangedKeys" -> changed,
    "CalculationCachesInvalidated" -> cacheChanged,
    "BothPoleCalculationCachesInvalidated" -> cacheChanged|>];
  $Phase1State["Inputs"]
];



Phase1SetPoleOperatingInputs[pole_String, updates_Association] := Module[
  {current, unknown, changed, immutableChanges, poleStates, cacheChanged},
  If[!MemberQ[$Phase1PoleIDs, pole],
    Return[Failure["UnknownPoleID", <|"Pole" -> pole, "ValidPoleIDs" -> $Phase1PoleIDs|>]]
  ];
  If[TrueQ[$Phase1ExecutingPole],
    Return[Failure["PoleInputsLockedDuringPoleExecution",
      <|"Reason" -> "Operating inputs cannot be mutated while a pole calculation is running."|>]]
  ];
  unknown = Complement[Keys[updates], $Phase1PoleOperatingKeys];
  If[unknown =!= {}, Return[Failure["NotPoleOperatingInputKeys", <|"Pole" -> pole, "Keys" -> unknown|>]]];
  current = Lookup[$Phase1State["PoleOperatingInputs"], pole, $Phase1PoleInputDefaults];
  changed = Select[Keys[updates], !SameQ[Lookup[current, #, Missing[]], updates[#]] &];
  immutableChanges = Intersection[changed, $Phase1ImmutableInputKeys];
  If[immutableChanges =!= {},
    Return[Failure["ImmutableInputMutationBlocked",
      <|"Pole" -> pole, "Keys" -> immutableChanges,
        "Reason" -> "Pole-local operating updates cannot override fundamental constants, fixed topology or intrinsic base-material properties."|>]]
  ];
  cacheChanged = changed =!= {};
  poleStates = Lookup[$Phase1State, "PoleStates", <||>];
  $Phase1State = Join[$Phase1State, <|
    "PoleOperatingInputs" -> Join[Lookup[$Phase1State, "PoleOperatingInputs", <||>],
      <|pole -> Join[current, updates]|>],
    "PoleStates" -> If[cacheChanged, KeyDrop[poleStates, {pole}], poleStates],
    "TwoPoleAggregate" -> If[cacheChanged, <||>, Lookup[$Phase1State, "TwoPoleAggregate", <||>]]
  |>];
  phase1Audit["PoleOperatingInputsUpdated", <|"Pole" -> pole, "ChangedKeys" -> changed,
    "CalculationCacheInvalidated" -> cacheChanged,
    "OtherPoleInputAndCacheUnchanged" -> True|>];
  Lookup[$Phase1State["PoleOperatingInputs"], pole]
];




phase1BuildPoleLocalState[pole_String] := Module[{parent = $Phase1State, prior, op, sharedSnapshotOK},
  op = Lookup[parent["PoleOperatingInputs"], pole, $Phase1PoleInputDefaults];
  prior = Lookup[Lookup[parent, "PoleStates", <||>], pole, <||>];
  sharedSnapshotOK = AssociationQ[prior] &&
    SameQ[Lookup[prior, "SharedInputSnapshot", Missing[]], parent["Inputs"]];
  If[!TrueQ[sharedSnapshotOK], prior = <||>];
  Join[parent, <|
    "SchemaVersion" -> "11.9",
    "Inputs" -> Join[parent["Inputs"], op],
    "PoleOperatingInputs" -> <|pole -> op|>,
    "PoleStates" -> <|pole -> prior|>,
    "TwoPoleAggregate" -> <||>,
    "Derived" -> Lookup[prior, "Derived", <||>],
    "Results" -> Lookup[prior, "Results", <||>],
    "LastRun" -> Lookup[prior, "LastRun", Missing["NotRun"]],
    "AuditLog" -> Lookup[prior, "AuditLog", {}],
    "ActivePole" -> pole,
    "PoleExecutionActive" -> True
  |>]
];

SetAttributes[phase1WithPole, HoldAll];
phase1WithPole[pole_String, expr_] := Module[{local, result = $Failed, finalLocal = <||>, parent, poleRecord, op, localIsolationQ, otherStatesBefore, otherStatesAfter},
  If[!MemberQ[$Phase1PoleIDs, pole], Return[Failure["UnknownPoleID", <|"Pole" -> pole, "ValidPoleIDs" -> $Phase1PoleIDs|>]]];
  If[TrueQ[$Phase1ExecutingPole],
    If[pole === $Phase1CurrentPole, Return[expr],
      Return[Failure["NestedCrossPoleExecutionBlocked", <|"ActivePole" -> $Phase1CurrentPole, "RequestedPole" -> pole|>]]]];
  parent = $Phase1State; local = phase1BuildPoleLocalState[pole];
  Block[{$Phase1State = local, $Phase1ExecutingPole = True, $Phase1CurrentPole = pole},
    result = expr; finalLocal = $Phase1State;
  ];
  op = Lookup[parent["PoleOperatingInputs"], pole, $Phase1PoleInputDefaults];
  localIsolationQ = TrueQ[
    Keys[Lookup[finalLocal,"PoleOperatingInputs",<||>]]==={pole} &&
    Keys[Lookup[finalLocal,"PoleStates",<||>]]==={pole} &&
    SameQ[KeyTake[Lookup[finalLocal,"Inputs",<||>],$Phase1PoleOperatingKeys],op]
  ];
  If[!localIsolationQ, Return[Failure["PoleContextIsolationCheckFailed",<|"Pole"->pole,
    "LocalPoleInputAndStateKeys"-><|"OperatingInputs"->Keys[Lookup[finalLocal,"PoleOperatingInputs",<||>]],
      "PoleStates"->Keys[Lookup[finalLocal,"PoleStates",<||>]]|>,"NoParentStateCommitted"->True|>]]];
  otherStatesBefore=KeyDrop[Lookup[parent,"PoleStates",<||>],{pole}];
  poleRecord = <|
    "Pole" -> pole, "OperatingInputs" -> op,
    "SharedInputSnapshot" -> parent["Inputs"],
    "Derived" -> Lookup[finalLocal, "Derived", <||>],
    "Results" -> Lookup[finalLocal, "Results", <||>],
    "LastRun" -> Lookup[finalLocal, "LastRun", Missing["NotRun"]],
    "AuditLog" -> Lookup[finalLocal, "AuditLog", {}],
    "InputSnapshot" -> Lookup[finalLocal, "Inputs", <||>],
    "LocalPoleIsolationPassed" -> localIsolationQ,
    "LastExecutionResult" -> If[FailureQ[result], result, "CompletedOrReturnedValue"]
  |>;
  $Phase1State = Join[parent, <|
    "PoleStates" -> Join[Lookup[parent, "PoleStates", <||>], <|pole -> poleRecord|>],
    "ActivePole" -> pole,
    "AuditLog" -> Append[Lookup[parent, "AuditLog", {}],
      <|"Action" -> "IndependentPoleContextCompleted", "Pole" -> pole,
        "ResultWasFailure" -> FailureQ[result], "LocalPoleIsolationPassed" -> localIsolationQ,
        "OtherPoleStateModified" -> !SameQ[otherStatesBefore,KeyDrop[Lookup[$Phase1State,"PoleStates",<||>],{pole}]]|>]|>];
  otherStatesAfter=KeyDrop[Lookup[$Phase1State,"PoleStates",<||>],{pole}];
  If[!SameQ[otherStatesBefore,otherStatesAfter], Return[Failure["OtherPoleStateChangedDuringExecution",<|"ActivePole"->pole,"NoIndependentResultCommitted"->False|>]]];
  result
];

Phase1GetPoleState[pole_String] := Which[
  TrueQ[$Phase1ExecutingPole] && pole =!= $Phase1CurrentPole, Failure["CrossPoleStateReadBlocked", <|"ActivePole" -> $Phase1CurrentPole, "RequestedPole" -> pole|>],
  !MemberQ[$Phase1PoleIDs, pole], Failure["UnknownPoleID", <|"Pole" -> pole|>],
  True, Lookup[Lookup[$Phase1State, "PoleStates", <||>], pole, Missing["PoleNotYetComputed", pole]]];
Phase1GetPoleResults[pole_String] := Module[{s = Phase1GetPoleState[pole]},
  If[AssociationQ[s], Lookup[s, "Results", <||>], s]];
Phase1GetPoleResult[pole_String, name_String] := Module[{r = Phase1GetPoleResults[pole]},
  If[AssociationQ[r], Lookup[r, name, Missing["PoleResultNotAvailable", {pole, name}]], r]];
Phase1GetPoleDerived[pole_String, name_String] := Module[{s = Phase1GetPoleState[pole], d},
  If[!AssociationQ[s], Return[s]]; d = Lookup[s, "Derived", <||>];
  Lookup[d, name, Missing["PoleDerivedValueNotAvailable", {pole, name}]]];

Phase1ComputePole[pole_String] := phase1WithPole[pole, phase1EnsureCalculated[]];

(* Runtime architecture audit. This uses a temporary Block-local copy of the central
   state, writes a sentinel to Pole1 only, and confirms Pole2 operating inputs/state are
   unchanged. It also probes public cross-pole read guards without changing live state. *)
Phase1PoleIndependenceAudit[] := Module[
  {stateSnapshot=$Phase1State, op1Before, op2Before, state1Before, state2Before, sharedBefore,
   sentinel1, sentinel2, setterProbe, reverseSetterProbe, pole1After, pole2After, state1After, state2After,
   sharedAfter, crossInputProbe, crossStateProbe, reverseCrossInputProbe, reverseCrossStateProbe,
   local1, local2, localIsolation, sharedKeys, aggregateProbeState, aggregateProbe, aggregateProbeUnchanged, checks},
  op1Before=Lookup[stateSnapshot["PoleOperatingInputs"],"Pole1",<||>];
  op2Before=Lookup[stateSnapshot["PoleOperatingInputs"],"Pole2",<||>];
  state1Before=Lookup[stateSnapshot["PoleStates"],"Pole1",Missing["NoPole1State"]];
  state2Before=Lookup[stateSnapshot["PoleStates"],"Pole2",Missing["NoPole2State"]];
  sharedBefore=Lookup[stateSnapshot,"Inputs",<||>];
  sentinel1=Unique["Pole1IsolationSentinel$"];sentinel2=Unique["Pole2IsolationSentinel$"];
  setterProbe=Block[{$Phase1State=stateSnapshot,$Phase1ExecutingPole=False,$Phase1CurrentPole=None},
    Phase1SetPoleOperatingInputs["Pole1",<|"Distance_m"->sentinel1|>];$Phase1State];
  pole1After=Lookup[Lookup[setterProbe,"PoleOperatingInputs",<||>],"Pole1",<||>];
  pole2After=Lookup[Lookup[setterProbe,"PoleOperatingInputs",<||>],"Pole2",<||>];
  state1After=Lookup[Lookup[setterProbe,"PoleStates",<||>],"Pole1",Missing["NoPole1State"]];
  state2After=Lookup[Lookup[setterProbe,"PoleStates",<||>],"Pole2",Missing["NoPole2State"]];
  sharedAfter=Lookup[setterProbe,"Inputs",<||>];
  reverseSetterProbe=Block[{$Phase1State=stateSnapshot,$Phase1ExecutingPole=False,$Phase1CurrentPole=None},
    Phase1SetPoleOperatingInputs["Pole2",<|"Distance_m"->sentinel2|>];$Phase1State];
  crossInputProbe=Block[{$Phase1State=stateSnapshot,$Phase1ExecutingPole=False,$Phase1CurrentPole=None},phase1WithPole["Pole1",Phase1GetPoleInputs["Pole2"]]];
  crossStateProbe=Block[{$Phase1State=stateSnapshot,$Phase1ExecutingPole=False,$Phase1CurrentPole=None},phase1WithPole["Pole1",Phase1GetPoleState["Pole2"]]];
  reverseCrossInputProbe=Block[{$Phase1State=stateSnapshot,$Phase1ExecutingPole=False,$Phase1CurrentPole=None},phase1WithPole["Pole2",Phase1GetPoleInputs["Pole1"]]];
  reverseCrossStateProbe=Block[{$Phase1State=stateSnapshot,$Phase1ExecutingPole=False,$Phase1CurrentPole=None},phase1WithPole["Pole2",Phase1GetPoleState["Pole1"]]];
  local1=phase1BuildPoleLocalState["Pole1"];local2=phase1BuildPoleLocalState["Pole2"];
  sharedKeys=Keys[KeyDrop[stateSnapshot["Inputs"],$Phase1PoleOperatingKeys]];
  {aggregateProbe,aggregateProbeUnchanged}=Block[{$Phase1State=stateSnapshot},
    aggregateProbeState=$Phase1State;
    aggregateProbe=phase1PoleAggregate[<|
      "Pole1"-><|"MassBalance"-><|"TotalMass_kg"->1.|>,"PowerLedger"-><|"ConditionedDeliveredPower_W_PerPole"->2.|>|>,
      "Pole2"-><|"MassBalance"-><|"TotalMass_kg"->3.|>,"PowerLedger"-><|"ConditionedDeliveredPower_W_PerPole"->4.|>|>|>];
    {aggregateProbe,SameQ[$Phase1State,aggregateProbeState]}];
  localIsolation=TrueQ[
    Keys[Lookup[local1,"PoleOperatingInputs",<||>]]==={"Pole1"} &&
    Keys[Lookup[local2,"PoleOperatingInputs",<||>]]==={"Pole2"} &&
    Keys[Lookup[local1,"PoleStates",<||>]]==={"Pole1"} &&
    Keys[Lookup[local2,"PoleStates",<||>]]==={"Pole2"} &&
    SameQ[KeyTake[local1["Inputs"],$Phase1PoleOperatingKeys],op1Before] &&
    SameQ[KeyTake[local2["Inputs"],$Phase1PoleOperatingKeys],op2Before] &&
    SameQ[KeyDrop[local1["Inputs"],$Phase1PoleOperatingKeys],KeyDrop[local2["Inputs"],$Phase1PoleOperatingKeys]]];
  checks=<|
    "ExactlyTwoPoleSystems"->TrueQ[$Phase1PoleIDs==={"Pole1","Pole2"} && Lookup[stateSnapshot["Inputs"],"PoleCount",Missing[]]===2],
    "SharedRegisterContainsNoPoleOperatingKeys"->TrueQ[Intersection[Keys[stateSnapshot["Inputs"]],$Phase1PoleOperatingKeys]==={}],
    "FlareAndCMEProfilesArePoleSpecific"->TrueQ[Complement[{"FlareTemporalProfile","CMETemporalProfile","FlareTailCutoffFraction"},$Phase1PoleOperatingKeys]==={}],
    "ControllerGainsArePoleSpecific"->TrueQ[Complement[{"ControllerTranslationKp_perS2","ControllerTranslationKd_perS","ControllerAttitudeKp_perS2","ControllerAttitudeKd_perS"},$Phase1PoleOperatingKeys]==={}],
    "HeliocentricReferenceMotionModeIsPoleSpecific"->TrueQ[MemberQ[$Phase1PoleOperatingKeys,"HeliocentricReferenceMotionMode"] && !MemberQ[Keys[stateSnapshot["Inputs"]],"HeliocentricReferenceMotionMode"] && KeyExistsQ[stateSnapshot["PoleOperatingInputs"]["Pole1"],"HeliocentricReferenceMotionMode"] && KeyExistsQ[stateSnapshot["PoleOperatingInputs"]["Pole2"],"HeliocentricReferenceMotionMode"]],
    "EachPoleHasItsOwnCompleteOperatingInputMap"->TrueQ[Complement[$Phase1PoleOperatingKeys,Keys[stateSnapshot["PoleOperatingInputs"]["Pole1"]]]==={} && Complement[$Phase1PoleOperatingKeys,Keys[stateSnapshot["PoleOperatingInputs"]["Pole2"]]]==={}],
    "PoleOperatingInputMapsSeparate"->TrueQ[AssociationQ[op1Before]&&AssociationQ[op2Before]],
    "UpdatingPole1ChangesOnlyRequestedPole1Field"->SameQ[pole1After,Join[op1Before,<|"Distance_m"->sentinel1|>]],
    "UpdatingPole1DoesNotChangePole2OperatingInputs"->SameQ[op2Before,pole2After],
    "UpdatingPole1DoesNotChangePole2CachedState"->SameQ[state2Before,state2After],
    "UpdatingPole1InvalidatesOnlyPole1Cache"->!KeyExistsQ[Lookup[setterProbe,"PoleStates",<||>],"Pole1"],
    "UpdatingPole2ChangesOnlyRequestedPole2Field"->SameQ[Lookup[Lookup[reverseSetterProbe,"PoleOperatingInputs",<||>],"Pole2",<||>],Join[op2Before,<|"Distance_m"->sentinel2|>]],
    "UpdatingPole2DoesNotChangePole1OperatingInputs"->SameQ[op1Before,Lookup[Lookup[reverseSetterProbe,"PoleOperatingInputs",<||>],"Pole1",<||>]],
    "UpdatingPole2DoesNotChangePole1CachedState"->SameQ[state1Before,Lookup[Lookup[reverseSetterProbe,"PoleStates",<||>],"Pole1",Missing["NoPole1State"]]],
    "UpdatingPole2InvalidatesOnlyPole2Cache"->!KeyExistsQ[Lookup[reverseSetterProbe,"PoleStates",<||>],"Pole2"],
    "UpdatingPole1DoesNotChangeSharedDesignMaterialInputs"->SameQ[sharedBefore,sharedAfter],
    "PoleContextsContainOnlyTheirOwnOperatingInputsAndState"->localIsolation,
    "Pole1ToPole2InputReadBlocked"->MatchQ[crossInputProbe,Failure["CrossPoleInputReadBlocked",_Association]],
    "Pole1ToPole2StateReadBlocked"->MatchQ[crossStateProbe,Failure["CrossPoleStateReadBlocked",_Association]],
    "Pole2ToPole1InputReadBlocked"->MatchQ[reverseCrossInputProbe,Failure["CrossPoleInputReadBlocked",_Association]],
    "Pole2ToPole1StateReadBlocked"->MatchQ[reverseCrossStateProbe,Failure["CrossPoleStateReadBlocked",_Association]],
    "SharedInputSnapshotIdenticalForBothContexts"->SameQ[KeyTake[local1["Inputs"],sharedKeys],KeyTake[local2["Inputs"],sharedKeys]],
    "AggregateCalculationDoesNotMutatePoleStateOrInputs"->TrueQ[aggregateProbeUnchanged && AssociationQ[aggregateProbe]],
    "AggregateMassAndPowerAreArithmeticSums"->TrueQ[SameQ[Lookup[aggregateProbe,"TotalMass_kg",Missing[]],4.] && SameQ[Lookup[aggregateProbe,"TotalDeliveredPower_W",Missing[]],6.]],
    "AggregateDoesNotMultiplyByPoleCount"->TrueQ[SameQ[Lookup[aggregateProbe,"TotalMass_kg",Missing[]],Total[{1.,3.}]] && SameQ[Lookup[aggregateProbe,"TotalDeliveredPower_W",Missing[]],Total[{2.,4.}]]],
    "PerPoleContextsDoNotReceiveAggregateState"->TrueQ[Lookup[local1,"TwoPoleAggregate",Missing[]]===<||> && Lookup[local2,"TwoPoleAggregate",Missing[]]===<||>],
    "NoSharedOperationalStateOrCrossPoleFeedback"->TrueQ[localIsolation && SameQ[op2Before,pole2After] && SameQ[state2Before,state2After] && SameQ[op1Before,Lookup[Lookup[reverseSetterProbe,"PoleOperatingInputs",<||>],"Pole1",<||>]] && SameQ[state1Before,Lookup[Lookup[reverseSetterProbe,"PoleStates",<||>],"Pole1",Missing["NoPole1State"]]] && SameQ[sharedBefore,sharedAfter] && MatchQ[crossInputProbe,Failure["CrossPoleInputReadBlocked",_Association]] && MatchQ[crossStateProbe,Failure["CrossPoleStateReadBlocked",_Association]] && MatchQ[reverseCrossInputProbe,Failure["CrossPoleInputReadBlocked",_Association]] && MatchQ[reverseCrossStateProbe,Failure["CrossPoleStateReadBlocked",_Association]] && aggregateProbeUnchanged]
  |>;
  <|"Rule"->"Two physically distinct systems, one at each pole; design/material definitions shared, all operation independent.",
    "Checks"->checks,"Passed"->(And@@(TrueQ/@Values[checks])),
    "PoleOperatingInputCountPerPole"->Length[$Phase1PoleOperatingKeys],
    "PoleIDs"->$Phase1PoleIDs,
    "Note"->"The sentinel test ran inside a temporary state copy. No live input, pole state, cache or result was modified."|>
];

phase1PoleAggregate[poleResults_Association] := Module[
  {massValues, powerValues, areaValues, validMass, validPower, validArea, sumOrMissing, field},
  field[value_, key_, default_] := If[AssociationQ[value], Lookup[value, key, default], default];
  sumOrMissing[values_, valid_] := If[TrueQ[valid], Total[values], Missing["BothIndependentPoleResultsRequired"]];
  massValues = Table[field[field[field[poleResults, p, <||>], "MassBalance", <||>], "TotalMass_kg", Missing[]], {p, $Phase1PoleIDs}];
  powerValues = Table[field[field[field[poleResults, p, <||>], "PowerLedger", <||>], "ConditionedDeliveredPower_W_PerPole", Missing[]], {p, $Phase1PoleIDs}];
  areaValues = Table[Module[{st, derived, geometry},
    st = field[Lookup[$Phase1State, "PoleStates", <||>], p, <||>];
    derived = field[st, "Derived", <||>];
    geometry = field[derived, "Geometry", <||>];
    field[geometry, "GrossProjectedAreaPerPole_m2", Missing[]]
  ], {p, $Phase1PoleIDs}];
  validMass = And @@ (NumericQ /@ massValues); validPower = And @@ (NumericQ /@ powerValues);
  validArea = And @@ (NumericQ /@ areaValues);
  <|"PoleIDs" -> $Phase1PoleIDs, "PoleCount" -> 2,
    "SystemsOperationallyIndependent" -> True,
    "SharedDesignAndMaterialRegister" -> True,
    "InterPoleForceTorquePowerControlOrStateCoupling" -> False,
    "AggregationFeedsBackIntoPoleOperations" -> False,
    "AggregateAvailable" -> TrueQ[validMass && validPower && validArea],
    "PerPoleMass_kg" -> AssociationThread[$Phase1PoleIDs, massValues],
    "TotalMass_kg" -> sumOrMissing[massValues, validMass],
    "PerPoleDeliveredPower_W" -> AssociationThread[$Phase1PoleIDs, powerValues],
    "TotalDeliveredPower_W" -> sumOrMissing[powerValues, validPower],
    "PerPoleProjectedArea_m2" -> AssociationThread[$Phase1PoleIDs, areaValues],
    "TotalProjectedArea_m2" -> sumOrMissing[areaValues, validArea],
    "AggregationMethod" -> "Arithmetic sum of the two actual independent Pole1 and Pole2 calculation outputs. No output is multiplied by PoleCount.",
    "CombinedMechanicalEquilibrium" -> "Not evaluated; not applicable to independent systems with no mechanical or operational coupling."|>
];

Phase1ComputeAll[] := If[TrueQ[$Phase1ExecutingPole], phase1ComputeCurrentPole[],
  Module[{poleResults, aggregate},
    poleResults = AssociationMap[Phase1ComputePole, $Phase1PoleIDs];
    aggregate = phase1PoleAggregate[poleResults];
    $Phase1State = Join[$Phase1State, <|"TwoPoleAggregate" -> aggregate|>];
    <|"Revision" -> "v11.65", "PoleResults" -> poleResults, "Aggregate" -> aggregate,
      "AllPoleCalculationsIndependent" -> True,
      "PoleIndependenceAudit" -> Phase1PoleIndependenceAudit[],
      "ReadyForBothPoles" -> And @@ (AssociationQ[phase1PoleInputStatus[#]] && TrueQ[phase1PoleInputStatus[#]["Ready"]] & /@ $Phase1PoleIDs)|>
  ]];

phase1ReconcileSharedPVCandidate[perPole_Association] := Module[
  {fractions,numericFractions,tolerance,consistent,commonFraction,perPoleReady,range,
   commonEvaluations,withinRange,accepted},
  fractions=AssociationMap[If[AssociationQ[Lookup[perPole,#,Missing[]]],
    Lookup[perPole[#],"CandidatePVFraction",Missing["NoCandidate"]],Missing["NoCandidate"]]&,$Phase1PoleIDs];
  numericFractions=Select[Values[fractions],NumericQ];
  tolerance=Lookup[$Phase1State["Inputs"],"OptimizerGridCrossCheckRelativeTolerance",Missing["NotSet"]];
  consistent=Length[numericFractions]==2&&NumericQ[tolerance]&&
    Max[numericFractions]-Min[numericFractions]<=tolerance Max[Sqrt[$MinMachineNumber],Max[Abs[numericFractions]]];
  commonFraction=If[TrueQ[consistent],Mean[numericFractions],Missing["NoConsistentSharedCandidate"]];
  perPoleReady=And@@(AssociationQ[Lookup[perPole,#,Missing[]]]&&
    TrueQ[Lookup[perPole[#],"StaticConstraintProblemFeasible",False]]&&
    TrueQ[Lookup[perPole[#],"DynamicCandidateAcceptancePassed",False]]&&
    TrueQ[Lookup[perPole[#],"FullConstraintProblemFeasible",False]]&&
    TrueQ[Lookup[perPole[#],"ModelledAcceptanceUnderAssumptions",False]]&&
    NumericQ[Lookup[perPole[#],"CandidateDistance_m",Missing[]]]&/@$Phase1PoleIDs);
  range=Lookup[$Phase1State["Inputs"],"PVSearchRange",Missing["NoSearchRange"]];
  withinRange=ListQ[range]&&Length[range]==2&&NumericQ[commonFraction]&&TrueQ[range[[1]]<=commonFraction<=range[[2]]];
  commonEvaluations=If[TrueQ[consistent]&&TrueQ[perPoleReady]&&TrueQ[withinRange],
    AssociationMap[Function[pole,
      phase1WithPole[pole,phase1EvaluateCandidateTransient[
        perPole[pole]["CandidateDistance_m"],commonFraction,
        <|"BothIndependentPoleOptimizersPassedStaticAndDynamicGates"->True,
          "CommonPVFractionWithinSharedDesignSearchRange"->True,
          "CommonCandidateUsesThisPolesOwnOptimizedDistance"->True|>]]],$Phase1PoleIDs],<||>];
  accepted=TrueQ[consistent]&&TrueQ[perPoleReady]&&TrueQ[withinRange]&&
    Length[Keys[commonEvaluations]]==Length[$Phase1PoleIDs]&&
    And@@(TrueQ[Lookup[commonEvaluations[#],"ModelledAcceptanceUnderAssumptions",False]]&&
      TrueQ[Lookup[commonEvaluations[#],"NoLivePoleStateMutation",False]]&/@$Phase1PoleIDs);
  <|"PerPolePVFractionCandidates"->fractions,
    "CommonPVFractionCandidateConsistent"->TrueQ[consistent],
    "CommonPVFractionCandidate"->commonFraction,
    "IndependentCommonCandidateEvaluations"->commonEvaluations,
    "CommonPVFractionCandidatePassedBothPoleModelGates"->accepted,
    "CommonPVFractionCandidateRecommended"->If[accepted,commonFraction,Missing["CommonCandidateNotValidatedByBothIndependentSystems"]],
    "SharedDesignPVFractionApplied"->False,
    "CandidateInputsRetained"->False,
    "Rule"->"A candidate PV fraction is shared design/material data. The exact common value is independently recalculated at each pole's own optimizer distance with that pole's own operating inputs and must pass both static and dynamic gates. No candidate is automatically applied."|>
];

Phase1JointOptimization[pole_String] := phase1WithPole[pole, phase1JointOptimizationCurrent[]];
Phase1JointOptimization[] := If[TrueQ[$Phase1ExecutingPole], phase1JointOptimizationCurrent[],
  Module[{perPole},
    perPole=AssociationMap[Phase1JointOptimization,$Phase1PoleIDs];
    Join[<|"PerPoleOptimization"->perPole|>,phase1ReconcileSharedPVCandidate[perPole]]
  ]];

Phase1Validate[pole_String] := phase1WithPole[pole, phase1ValidateCurrent[]];
Phase1Validate[] := If[TrueQ[$Phase1ExecutingPole], phase1ValidateCurrent[],
  AssociationMap[Phase1Validate, $Phase1PoleIDs]];
Phase1RunSelfTests[pole_String] := Module[{status, software},
  If[!MemberQ[$Phase1PoleIDs, pole], Return[Failure["UnknownPoleID", <|"Pole" -> pole|>]]];
  status = phase1PoleInputStatus[pole];
  software = Phase1RunSoftwareSelfTests[];
  If[!TrueQ[status["Ready"]],
    Return[<|"Pole" -> pole, "SoftwareSelfTests" -> software,
      "EngineeringCalculationIntegrityTestsExecuted" -> False,
      "EngineeringTestsNotRunReason" -> "Required project inputs are still missing.",
      "MissingRequiredInputKeys" -> status["MissingRequiredInputKeys"]|>]
  ];
  phase1WithPole[pole, phase1RunSelfTestsCurrent[]]
];
Phase1RunSelfTests[] := If[TrueQ[$Phase1ExecutingPole],
  phase1RunSelfTestsCurrent[],
  Module[{software, status, allReady, perPole, isolation},
    software = Phase1RunSoftwareSelfTests[];
    status = Phase1InputStatus[];
    isolation = Phase1PoleIndependenceAudit[];
    allReady = TrueQ[status["Ready"]];
    If[!allReady,
      Return[<|"SoftwareSelfTests" -> software,
        "EngineeringCalculationIntegrityTestsExecuted" -> False,
        "EngineeringTestsNotRunReason" -> "Required shared and/or pole-specific project inputs are still missing.",
        "InputStatus" -> status,
        "PoleIndependenceAudit" -> isolation,
        "Passed" -> TrueQ[software["Passed"] && isolation["Passed"]]|>]
    ];
    perPole = AssociationMap[Phase1RunSelfTests, $Phase1PoleIDs];
    <|"SoftwareSelfTests" -> software, "PerPoleEngineeringSelfTests" -> perPole,
      "PoleIndependenceAudit" -> isolation,
      "AllPerPoleEngineeringSelfTestsPresent" -> And @@
        (TrueQ[Lookup[perPole[#], "ExpectedTestKeysPresent", False]] & /@ $Phase1PoleIDs),
      "AllPerPoleCalculationIntegrityTestsPassed" -> And @@
        (TrueQ[Lookup[perPole[#], "FailedCount", Infinity] == 0] & /@ $Phase1PoleIDs),
      "TwoPoleIndependenceTestsPassed" -> TrueQ[Lookup[isolation, "Passed", False]]|>
  ]
];
Phase1RunReport[pole_String] := phase1WithPole[pole, phase1RunReportCurrent[]];
Phase1RunReport[] := If[TrueQ[$Phase1ExecutingPole], phase1RunReportCurrent[],
  Module[{reports, calculation},
    reports = AssociationMap[Phase1RunReport, $Phase1PoleIDs];
    calculation = Phase1ComputeAll[];
    <|"PerPoleReports" -> reports,
      "TwoPoleCalculationSummary" -> calculation,
      "TwoPoleAggregate" -> If[AssociationQ[calculation], calculation["Aggregate"], Missing["AggregateUnavailable"]],
      "AggregateIsReportingOnly" -> True,
      "PoleIndependenceAudit" -> Phase1PoleIndependenceAudit[],
      "PoleIndependenceRule" -> $Phase1State["PoleArchitectureRule"]|>]];

Phase1RunPoleAssessment[pole_String] := phase1WithPole[pole, phase1RunFullAssessmentCurrent[]];
Phase1RunBothPoleAssessments[] := If[TrueQ[$Phase1ExecutingPole],
  Failure["TwoPoleAssessmentCannotRunInsideSinglePoleContext", <|"ActivePole" -> $Phase1CurrentPole|>],
  Module[{perPole, computed, perPoleOptimizations, sharedPVReconciliation},
  perPole = AssociationMap[Phase1RunPoleAssessment, $Phase1PoleIDs];
  (* Extract the actual independent optimizer result associations from each completed assessment. *)
  perPoleOptimizations = AssociationMap[Function[pole,
    Module[{poleAssessment = Lookup[perPole, pole, Missing["PoleAssessmentUnavailable"]],
        assessmentData},
      If[!AssociationQ[poleAssessment], Return[Missing["PoleAssessmentFailed", pole]]];
      assessmentData = Lookup[poleAssessment, "Assessment", Missing["AssessmentUnavailable"]];
      If[AssociationQ[assessmentData],
        Lookup[assessmentData, "JointOptimization", Missing["OptimizationUnavailable"]],
        Missing["AssessmentFailed", pole]]
    ]], $Phase1PoleIDs];
  sharedPVReconciliation=phase1ReconcileSharedPVCandidate[perPoleOptimizations];
  computed = Phase1ComputeAll[];
  <|"PerPoleAssessments" -> perPole, "SharedDesignPVReconciliation"->sharedPVReconciliation,
    "TwoPoleCalculationSummary" -> computed,
    "TwoPoleAggregate" -> Lookup[$Phase1State, "TwoPoleAggregate", <||>],
    "SystemsOperationallyIndependent" -> True,
    "NoCrossPoleOperationalDataExchange" -> True,
    "PoleIndependenceAudit" -> Phase1PoleIndependenceAudit[]|>]];
Phase1RunFullAssessment[] := If[TrueQ[$Phase1ExecutingPole], phase1RunFullAssessmentCurrent[], Phase1RunBothPoleAssessments[]];
Phase1RunFullAssessment[pole_String] := Phase1RunPoleAssessment[pole];

phase1RunIndependentPoleTaskCurrent[task_String] := Module[
  {in=Phase1GetInputs[],status,missing,geo,mesh,result,derived,manifest,outputs,inputHash,closure,
   optics,sun,illum,rad,force,moment,energyScale,rad0,mass0,dyn0,attitudeMesh,mass,dyn,natural,massFinal,stationPositions},
  If[!TrueQ[$Phase1ExecutingPole]||!MemberQ[$Phase1PoleIDs,$Phase1CurrentPole],
    Return[Failure["IndependentTaskRequiresPoleContext",<|"Task"->task|>]]
  ];
  If[!MemberQ[$Phase1IndependentlyExecutableTasks,task],
    Return[Failure["IndependentTaskNotSupported",<|"Task"->task,
      "SupportedTasks"->$Phase1IndependentlyExecutableTasks|>]]
  ];
  status=phase1TaskInputStatusFromInputs[in,task];
  If[FailureQ[status],Return[status]];
  missing=status["MissingInputKeys"];
  If[missing=!={},
    Return[Failure["TaskInputsMissing",<|"Task"->task,"Pole"->$Phase1CurrentPole,
      "MissingInputKeys"->missing,"RequiredInputKeys"->status["RequiredInputKeys"]|>]]
  ];
  derived=Lookup[$Phase1State,"Derived",<||>];
  Switch[task,
    "Geometry",
      If[!TrueQ[in["GeometryProfileModel"]==="SphericalCapSurrogate"&&
          NumericQ[in["PerPoleProjectedArea_m2"]]&&in["PerPoleProjectedArea_m2"]>0.&&
          NumericQ[in["CapDepthToPlanformRadius"]]&&0.<in["CapDepthToPlanformRadius"]<1.],
        Return[Failure["InvalidTaskInputs",<|"Task"->task,
          "Reason"->"The selected geometry model, projected area and cap-depth ratio must be valid."|>]]
      ];
      result=phase1Geometry[in];
      If[FailureQ[result],Return[result]];
      outputs={"Geometry"};
      derived=Join[derived,<|"Geometry"->result|>],
    "SurfaceMesh",
      If[!TrueQ[in["GeometryProfileModel"]==="SphericalCapSurrogate"&&
          NumericQ[in["PerPoleProjectedArea_m2"]]&&in["PerPoleProjectedArea_m2"]>0.&&
          NumericQ[in["CapDepthToPlanformRadius"]]&&0.<in["CapDepthToPlanformRadius"]<1.&&
          IntegerQ[in["MeshRadialCount"]]&&in["MeshRadialCount"]>0&&
          IntegerQ[in["MeshAzimuthCount"]]&&in["MeshAzimuthCount"]>0&&
          NumericQ[in["MeshAreaRelativeTolerance"]]&&in["MeshAreaRelativeTolerance"]>0.],
        Return[Failure["InvalidTaskInputs",<|"Task"->task,
          "Reason"->"Geometry and mesh resolution inputs must be valid positive values."|>]]
      ];
      geo=phase1Geometry[in];
      If[FailureQ[geo],Return[geo]];
      mesh=phase1Mesh[in,geo];
      If[!AssociationQ[mesh]||!IntegerQ[Lookup[mesh,"PatchCount",Missing[]]]||mesh["PatchCount"]<=0,
        Return[Failure["IndependentTaskCalculationFailed",<|"Task"->task,"Result"->mesh|>]]
      ];
      If[!NumericQ[mesh["QuadratureAreaRelativeError"]],
        Return[Failure["IndependentTaskCalculationFailed",<|"Task"->task,"Reason"->"Mesh area check was not numeric."|>]]
      ];
      If[!TrueQ[Abs[mesh["QuadratureAreaRelativeError"]]<=in["MeshAreaRelativeTolerance"]],
        Return[Failure["MeshAreaToleranceNotMet",<|"Task"->task,
          "RelativeAreaError"->mesh["QuadratureAreaRelativeError"],
          "AllowedRelativeError"->in["MeshAreaRelativeTolerance"]|>]]
      ];
      outputs={"Geometry","SurfaceMesh"};
      result=mesh;
      derived=Join[derived,<|"Geometry"->geo,"SurfaceMesh"->mesh|>],
    "OpticalRegister",
      If[!TrueQ[in["ReflectionModel"]==="Specular"&&
          And@@((NumericQ[#]&&0.<=#<=1.)&/@{
            in["ReflectorSolarReflectivity"],in["ReflectorSolarTransmissivity"],
            in["PVSolarReflectivity"],in["PVSolarTransmissivity"]})&&
          in["ReflectorSolarReflectivity"]+in["ReflectorSolarTransmissivity"]<=1.&&
          in["PVSolarReflectivity"]+in["PVSolarTransmissivity"]<=1.&&
          NumericQ[in["OpticalClosureTolerance"]]&&in["OpticalClosureTolerance"]>=0.],
        Return[Failure["InvalidTaskInputs",<|"Task"->task,
          "Reason"->"Reflection model, optical energy fractions and closure tolerance must be valid."|>]]
      ];
      result=phase1Optics[in];
      If[FailureQ[result],Return[result]];
      closure=Lookup[result,"EnergyClosure",<||>];
      If[!And@@((NumericQ[Lookup[closure,#,Missing[]]]&&
          Abs[Lookup[closure,#,Infinity]-1.]<=in["OpticalClosureTolerance"])&/@{"Reflector","PV"}),
        Return[Failure["OpticalEnergyClosureFailed",<|"Task"->task,"EnergyClosure"->closure,
          "Tolerance"->in["OpticalClosureTolerance"]|>]]
      ];
      outputs={"OpticalRegister"};
      derived=Join[derived,<|"OpticalRegister"->result|>],
    "InitialRadiationLoads",
      If[!TrueQ[
          NumericQ[in["PVFraction"]]&&0.<=in["PVFraction"]<=1.&&
          NumericQ[in["Distance_m"]]&&in["Distance_m"]>0.&&
          NumericQ[in["IncidenceAngle_deg"]]&&
          NumericQ[in["SolarLuminosity_W"]]&&in["SolarLuminosity_W"]>0.&&
          NumericQ[in["SpeedOfLight_m_s"]]&&in["SpeedOfLight_m_s"]>0.&&
          NumericQ[in["PowerLedgerRelativeTolerance"]]&&in["PowerLedgerRelativeTolerance"]>0.],
        Return[Failure["InvalidTaskInputs",<|"Task"->task,
          "Reason"->"PV fraction, pole distance, incidence, solar luminosity, light speed and energy-ledger tolerance must be valid."|>]]
      ];
      geo=phase1Geometry[in];
      If[FailureQ[geo],Return[geo]];
      mesh=phase1Mesh[in,geo];
      If[!AssociationQ[mesh]||!IntegerQ[Lookup[mesh,"PatchCount",Missing[]]]||
          mesh["PatchCount"]<=0||!NumericQ[mesh["QuadratureAreaRelativeError"]],
        Return[Failure["IndependentTaskCalculationFailed",<|"Task"->task,"Result"->mesh|>]]
      ];
      If[!TrueQ[Abs[mesh["QuadratureAreaRelativeError"]]<=in["MeshAreaRelativeTolerance"]],
        Return[Failure["MeshAreaToleranceNotMet",<|"Task"->task,
          "RelativeAreaError"->mesh["QuadratureAreaRelativeError"],
          "AllowedRelativeError"->in["MeshAreaRelativeTolerance"]|>]]
      ];
      optics=phase1Optics[in];
      If[!AssociationQ[optics]||
          !And@@((NumericQ[Lookup[Lookup[optics,"EnergyClosure",<||>],#,Missing[]]]&&
            Abs[Lookup[Lookup[optics,"EnergyClosure",<||>],#,-Infinity]-1.]<=in["OpticalClosureTolerance"])&/@{"Reflector","PV"}),
        Return[Failure["OpticalEnergyClosureFailed",<|"Task"->task,"EnergyClosure"->Lookup[optics,"EnergyClosure",<||>]|>]]
      ];
      sun=phase1SunVector[in["IncidenceAngle_deg"]];
      illum=phase1Illumination[mesh,sun];
      rad=phase1Radiation[in,geo,mesh,optics,in["PVFraction"],in["Distance_m"],in["IncidenceAngle_deg"],sun];
      If[FailureQ[rad],Return[rad]];
      force=Lookup[rad,"NetRadiationForceVector_N",Missing[]];
      moment=Lookup[rad,"NetRadiationMoment_Nm",Missing[]];
      If[!VectorQ[force,NumericQ]||Length[force]=!=3||
          !VectorQ[moment,NumericQ]||Length[moment]=!=3,
        Return[Failure["IndependentRadiationResultInvalid",<|"Task"->task,
          "ForceVector"->force,"MomentVector"->moment|>]]
      ];
      energyScale=Max[Abs[Lookup[rad,"TotalIncidentOpticalPower_W",0.]],$MinMachineNumber];
      If[!TrueQ[Abs[Lookup[rad,"OpticalEnergyClosureResidual_W",Infinity]]<=
          in["PowerLedgerRelativeTolerance"] energyScale],
        Return[Failure["RadiationOpticalEnergyLedgerFailed",<|"Task"->task,
          "Residual_W"->Lookup[rad,"OpticalEnergyClosureResidual_W",Missing[]],
          "IncidentPower_W"->energyScale,
          "RelativeTolerance"->in["PowerLedgerRelativeTolerance"]|>]]
      ];
      result=Join[rad,<|
        "CalculationScope"->"Independent initial-reference-frame radiation-load estimate",
        "ForceTorqueReferenceFrame"->"Pole-local geometry origin before centre-of-mass and initial-attitude correction",
        "FinalCOMAndInitialAttitudeCorrectionApplied"->False,
        "FullCoreCalculationExecuted"->False,
        "GeometryModelQualification"->geo["GeometryModelQualification"],
        "MeshAreaRelativeError"->mesh["QuadratureAreaRelativeError"],
        "MeshAreaRelativeTolerance"->in["MeshAreaRelativeTolerance"],
        "OpticalEnergyLedgerRelativeResidual"->If[energyScale>0.,Abs[rad["OpticalEnergyClosureResidual_W"]]/energyScale,0.],
        "InitialReferenceFrameIllumination"->illum,
        "Pole"->$Phase1CurrentPole
      |>];
      outputs={"Geometry","SurfaceMesh","OpticalRegister","InitialReferenceFrameIllumination","InitialRadiationLoads"};
      derived=Join[derived,<|"Geometry"->geo,"SurfaceMesh"->mesh,
        "OpticalRegister"->optics,"InitialReferenceFrameIllumination"->illum,
        "InitialRadiationLoads"->result|>],
    "NaturalEquilibrium",
      stationPositions=in["ICARUSStationPositionsLocal_m"];
      If[!TrueQ[
          in["GeometryProfileModel"]==="SphericalCapSurrogate"&&
          in["MassDistributionModel"]==="UniformSheetMassWithPerimeterLineMassAndStationPointMasses"&&
          NumericQ[in["PVFraction"]]&&0.<=in["PVFraction"]<=1.&&
          NumericQ[in["Distance_m"]]&&in["Distance_m"]>0.&&
          NumericQ[in["IncidenceAngle_deg"]]&&
          NumericQ[in["ExactEquilibriumRelativeTolerance"]]&&in["ExactEquilibriumRelativeTolerance"]>0.&&
          NumericQ[in["PowerLedgerRelativeTolerance"]]&&in["PowerLedgerRelativeTolerance"]>0.&&
          NumericQ[in["SolarWindProtonDensity_1AU_cm3"]]&&in["SolarWindProtonDensity_1AU_cm3"]>=0.&&
          NumericQ[in["SolarWindSpeed_1AU_m_s"]]&&in["SolarWindSpeed_1AU_m_s"]>=0.&&
          NumericQ[in["AstronomicalUnit_m"]]&&in["AstronomicalUnit_m"]>0.&&
          VectorQ[in["InitialAttitudeSmallAngles_rad"],NumericQ]&&Length[in["InitialAttitudeSmallAngles_rad"]]===3&&
          VectorQ[in["InitialAngularVelocity_rad_s"],NumericQ]&&Length[in["InitialAngularVelocity_rad_s"]]===3&&
          VectorQ[in["InitialPositionLocal_m"],NumericQ]&&Length[in["InitialPositionLocal_m"]]===3&&
          VectorQ[in["InitialVelocityLocal_m_s"],NumericQ]&&Length[in["InitialVelocityLocal_m_s"]]===3&&
          VectorQ[in["InitialVelocityHeliocentric_m_s"],NumericQ]&&Length[in["InitialVelocityHeliocentric_m_s"]]===3&&
          in["HeliocentricReferenceMotionMode"]==="StaticHover"&&Norm[in["InitialVelocityHeliocentric_m_s"]]===0.&&
          StringQ[in["MembraneSubstrateMaterialName"]]&&StringTrim[in["MembraneSubstrateMaterialName"]]=!=""&&
          ListQ[stationPositions]&&Length[stationPositions]===in["ICARUSStationCount"]&&
          And@@(VectorQ[#,NumericQ]&&Length[#]===3&/@stationPositions)],
        Return[Failure["InvalidTaskInputs",<|"Task"->task,
          "Reason"->"Natural-equilibrium inputs must include the selected geometry and mass models, all pole-specific initial conditions and solar-wind inputs, and valid shared station geometry."|>]]
      ];
      geo=phase1Geometry[in];
      If[FailureQ[geo],Return[geo]];
      mesh=phase1Mesh[in,geo];
      If[!AssociationQ[mesh]||!IntegerQ[Lookup[mesh,"PatchCount",Missing[]]]||
          mesh["PatchCount"]<=0||!NumericQ[Lookup[mesh,"QuadratureAreaRelativeError",Missing[]]],
        Return[Failure["InitialMeshFailed",<|"Task"->task,"Result"->mesh|>]]
      ];
      If[!TrueQ[Abs[mesh["QuadratureAreaRelativeError"]]<=in["MeshAreaRelativeTolerance"]],
        Return[Failure["MeshAreaToleranceNotMet",<|"Task"->task,
          "RelativeAreaError"->mesh["QuadratureAreaRelativeError"],
          "AllowedRelativeError"->in["MeshAreaRelativeTolerance"]|>]]
      ];
      optics=phase1Optics[in];
      If[!AssociationQ[optics],Return[Failure["OpticalRegisterFailed",<|"Task"->task|>]]];
      closure=Lookup[optics,"EnergyClosure",<||>];
      If[!And@@((NumericQ[Lookup[closure,#,Missing[]]]&&
          Abs[Lookup[closure,#,Infinity]-1.]<=in["OpticalClosureTolerance"])&/@{"Reflector","PV"}),
        Return[Failure["OpticalEnergyClosureFailed",<|"Task"->task,"EnergyClosure"->closure,
          "Tolerance"->in["OpticalClosureTolerance"]|>]]
      ];
      sun=phase1SunVector[in["IncidenceAngle_deg"]];
      illum=phase1Illumination[mesh,sun];
      rad0=phase1Radiation[in,geo,mesh,optics,in["PVFraction"],in["Distance_m"],in["IncidenceAngle_deg"],sun];
      If[FailureQ[rad0],Return[rad0]];
      mass0=phase1Mass[in,geo,rad0,in["PVFraction"],in["Distance_m"]];
      If[FailureQ[mass0]||!AssociationQ[mass0],Return[Failure["InitialMassCalculationFailed",<|"Task"->task,"Result"->mass0|>]]];
      If[!TrueQ[Lookup[mass0,"MassLedgerCloses",False]]||
          !TrueQ[Lookup[mass0,"StationMassCountedOnce",False]],
        Return[Failure["InitialMassLedgerFailed",<|"Task"->task,
          "MassLedgerCloses"->Lookup[mass0,"MassLedgerCloses",False],
          "StationMassCountedOnce"->Lookup[mass0,"StationMassCountedOnce",False]|>]]
      ];
      dyn0=phase1DynamicsInitial[in,geo,mass0,mesh];
      If[FailureQ[dyn0]||!AssociationQ[dyn0],Return[Failure["InitialDynamicsFailed",<|"Task"->task,"Result"->dyn0|>]]];
      If[!NumericQ[Lookup[dyn0,"MassConservationResidual_kg",Missing[]]]||
          Abs[dyn0["MassConservationResidual_kg"]]>
            in["PowerLedgerRelativeTolerance"] Max[Abs[mass0["TotalMass_kg"]],$MinMachineNumber],
        Return[Failure["InitialMassConservationFailed",<|"Task"->task,
          "Residual_kg"->Lookup[dyn0,"MassConservationResidual_kg",Missing[]],
          "TotalMass_kg"->mass0["TotalMass_kg"]|>]]
      ];
      attitudeMesh=phase1RotateMeshToCOM[mesh,dyn0["CenterOfMassLocal_m"],dyn0["InitialQuaternion"]];
      If[!AssociationQ[attitudeMesh],Return[Failure["COMAttitudeMeshConstructionFailed",<|"Task"->task|>]]];
      rad=phase1Radiation[in,geo,attitudeMesh,optics,in["PVFraction"],in["Distance_m"],in["IncidenceAngle_deg"],sun];
      If[FailureQ[rad],Return[rad]];
      force=Lookup[rad,"NetRadiationForceVector_N",Missing[]];
      moment=Lookup[rad,"NetRadiationMoment_Nm",Missing[]];
      If[!VectorQ[force,NumericQ]||Length[force]=!=3||
          !VectorQ[moment,NumericQ]||Length[moment]=!=3,
        Return[Failure["COMCorrectedRadiationResultInvalid",<|"Task"->task,
          "Force"->force,"Moment"->moment|>]]
      ];
      energyScale=Max[Abs[Lookup[rad,"TotalIncidentOpticalPower_W",0.]],$MinMachineNumber];
      If[!TrueQ[Abs[Lookup[rad,"OpticalEnergyClosureResidual_W",Infinity]]<=
          in["PowerLedgerRelativeTolerance"] energyScale],
        Return[Failure["CorrectedRadiationEnergyLedgerFailed",<|"Task"->task,
          "Residual_W"->Lookup[rad,"OpticalEnergyClosureResidual_W",Missing[]],
          "IncidentPower_W"->energyScale|>]]
      ];
      mass=phase1Mass[in,geo,rad,in["PVFraction"],in["Distance_m"]];
      If[FailureQ[mass]||!AssociationQ[mass],Return[Failure["CorrectedMassCalculationFailed",<|"Task"->task,"Result"->mass|>]]];
      dyn=phase1DynamicsInitial[in,geo,mass,mesh];
      If[FailureQ[dyn]||!AssociationQ[dyn],Return[Failure["CorrectedDynamicsFailed",<|"Task"->task,"Result"->dyn|>]]];
      natural=phase1NaturalEquilibrium[in,rad,mass,dyn];
      If[FailureQ[natural]||!AssociationQ[natural],Return[Failure["NaturalEquilibriumFailed",<|"Task"->task,"Result"->natural|>]]];
      massFinal=phase1MergeNaturalEquilibrium[mass,natural];
      If[!TrueQ[Lookup[massFinal,"MassLedgerCloses",False]]||
          !VectorQ[Lookup[natural,"NetNaturalForceVector_N",{}],NumericQ]||
          Length[natural["NetNaturalForceVector_N"]]=!=3||
          !VectorQ[Lookup[natural,"NetNaturalTorqueAboutCOM_Nm",{}],NumericQ]||
          Length[natural["NetNaturalTorqueAboutCOM_Nm"]]=!=3||
          !MemberQ[{True,False},Lookup[natural,"ExactNaturalEquilibrium",Missing[]]],
        Return[Failure["PerPoleNaturalEquilibriumResultInvalid",<|"Task"->task,"Mass"->massFinal,"Natural"->natural|>]]
      ];
      result=<|
        "Pole"->$Phase1CurrentPole,
        "MassBalance"->massFinal,
        "InitialMassBalance"->mass0,
        "Dynamics"->dyn,
        "InitialDynamics"->dyn0,
        "InitialReferenceFrameRadiationLoads"->rad0,
        "COMCorrectedRadiationLoads"->rad,
        "COMCorrectedSurfaceMesh"->attitudeMesh,
        "NaturalEquilibrium"->natural,
        "NaturalEquilibriumPass"->TrueQ[natural["ControlledOutwardForceEnvelopePass"]&&natural["ExactTorqueEquilibrium"]],
        "NaturalForceResidualMagnitude_m_s2"->natural["NaturalForceResidualMagnitude_m_s2"],
        "NaturalTorqueResidualMagnitude_Nm"->natural["NaturalTorqueResidualMagnitude_Nm"],
        "RadiationExceedsInwardGravityPass"->TrueQ[natural["RadiationExceedsInwardGravityPass"]],
        "TransverseForceBalancePass"->TrueQ[natural["TransverseForceBalancePass"]],
        "ControlledOutwardForceAndTorqueEnvelopePassIndependentlyPerPole"->TrueQ[natural["ControlledOutwardForceEnvelopePass"]&&natural["ExactTorqueEquilibrium"]],
        "RadiationCOMAndInitialAttitudeCorrectionApplied"->True,
        "FullCoreCalculationExecuted"->False,
        "EngineeringAcceptance"->"NotDeterminedByThisTask",
        "TaskScope"->"Independent single-pole natural-load calculation; acceptance means radiation exceeds inward gravity, net radial force is outward, transverse force and natural torque remain within tolerance. Exact zero-net-force equilibrium is diagnostic only. This partial task does not execute thermal, electrical power, disturbance/recovery, actuator qualification, optimization or whole-project acceptance."
      |>;
      outputs={"Geometry","SurfaceMesh","OpticalRegister","InitialReferenceFrameIllumination",
        "InitialRadiationLoads","InitialMassBalance","InitialDynamics","COMCorrectedSurfaceMesh",
        "COMCorrectedRadiationLoads","MassBalance","Dynamics","NaturalEquilibrium"};
      derived=Join[derived,<|"Geometry"->geo,"SurfaceMesh"->mesh,"OpticalRegister"->optics,
        "InitialReferenceFrameIllumination"->illum,"InitialRadiationLoads"->rad0,
        "InitialMassBalance"->mass0,"InitialDynamics"->dyn0,"COMCorrectedSurfaceMesh"->attitudeMesh,
        "COMCorrectedRadiationLoads"->rad,"MassBalance"->massFinal,"Dynamics"->dyn,
        "NaturalEquilibrium"->natural|>]
  ];
  inputHash=Hash[KeyTake[in,status["RequiredInputKeys"]],"SHA256"];
  manifest=Lookup[derived,"IndependentTaskManifest",<||>];
  manifest=Join[manifest,<|task-><|"InputSnapshotHash"->inputHash,
    "RequiredInputKeys"->status["RequiredInputKeys"],"OutputKeys"->outputs,
    "ExecutionMode"->"IndependentPartialTask","FullCoreCalculationExecuted"->False|>|>];
  derived=Join[derived,<|"IndependentTaskManifest"->manifest|>];
  $Phase1State=Join[$Phase1State,<|"Derived"->derived|>];
  phase1Audit["IndependentTaskExecuted",<|"Pole"->$Phase1CurrentPole,"Task"->task,
    "OutputKeys"->outputs,"FullCoreCalculationExecuted"->False|>];
  <|"Pole"->$Phase1CurrentPole,"Task"->task,"Executed"->True,
    "ExecutionMode"->"IndependentPartialTask","OutputKeys"->outputs,
    "Result"->result,"FullCoreCalculationExecuted"->False,
    "FullCalculationStatus"->"NotRunByIndependentTask"|>
];

Phase1RunPoleTask[pole_String, task_String] := phase1WithPole[pole, Switch[task,
  "Geometry"|"SurfaceMesh"|"OpticalRegister"|"InitialRadiationLoads"|"NaturalEquilibrium", phase1RunIndependentPoleTaskCurrent[task],
  "ComputeAll", phase1EnsureCalculated[],
  "FullAssessment", phase1RunFullAssessmentCurrent[],
  "JointOptimization", phase1JointOptimizationCurrent[],
  "SolveExactEquilibrium", phase1SolveExactEquilibriumCurrent[],
  "IntegratedSimulation", phase1IntegratedSimulationCurrent[],
  "Step4EngineeringCore", phase1BuildStep4Core[],
  "Step4Assessment", phase1Step4AssessmentCurrent[],
  "ICARUSRedesignSizing", phase1ICARUSRedesignSizingCurrent[],
  "FreeRotation", phase1FreeRotationTrajectoryCurrent[],
  "Wobble", phase1WobbleSimulationCurrent[],
  "Validate", phase1ValidateCurrent[],
  "SelfTests", phase1RunSelfTestsCurrent[],
  "DisturbanceScenarios", phase1DisturbanceScenariosCurrent[],
  "ThermalDistanceFloor", phase1DistanceThermalFloorCurrent[],
  _, Failure["UnknownPoleTask", <|"Task" -> task,
    "ValidTasks" -> Join[$Phase1IndependentlyExecutableTasks,
      {"ComputeAll","FullAssessment","JointOptimization","SolveExactEquilibrium","IntegratedSimulation",
       "Step4EngineeringCore","Step4Assessment","ICARUSRedesignSizing","FreeRotation","Wobble","Validate","SelfTests","DisturbanceScenarios","ThermalDistanceFloor"}]|>]
]];

(* Pole-specific overloads for the principal stateful solvers. *)
(* All scalar operational APIs resolve to exactly one pole context. The no-argument
   form uses the selected pole; a pole_String first argument is explicit. The global
   bulk APIs Phase1ComputeAll, Phase1JointOptimization, and Phase1RunFullAssessment
   are the only ordinary entry points that intentionally visit both poles. *)
Phase1SolveExactEquilibrium[] := If[TrueQ[$Phase1ExecutingPole],phase1SolveExactEquilibriumCurrent[],Phase1SolveExactEquilibrium[$Phase1SelectedPole]];
Phase1SolveExactEquilibrium[pole_String] := phase1WithPole[pole,phase1SolveExactEquilibriumCurrent[]];

Phase1DistanceThermalFloor[coverage_:Automatic] := If[TrueQ[$Phase1ExecutingPole],phase1DistanceThermalFloorCurrent[coverage],Phase1DistanceThermalFloor[$Phase1SelectedPole,coverage]];
Phase1DistanceThermalFloor[pole_String,coverage_:Automatic] := phase1WithPole[pole,phase1DistanceThermalFloorCurrent[coverage]];

Phase1IntegratedSimulation[durationS_:Automatic] := If[TrueQ[$Phase1ExecutingPole],phase1IntegratedSimulationCurrent[durationS],Phase1IntegratedSimulation[$Phase1SelectedPole,durationS]];
Phase1IntegratedSimulation[pole_String,durationS_:Automatic] := phase1WithPole[pole,phase1IntegratedSimulationCurrent[durationS]];

Phase1RunStep4Assessment[pole_String] := phase1WithPole[pole,phase1Step4AssessmentCurrent[]];
(* The supplied Step 4 record must belong to the named pole. This wrapper never
   executes Step 4 dynamics: it consumes an already available same-pole assessment
   and returns preliminary Step 5 design requirements inside that pole's state context. *)
Phase1RunStep5StructuralArchitecture[pole_String,step4Assessment_Association,ribSpacing_:Automatic,
    ribRunSpan_:Automatic,intraNodeConnectorInput_:Automatic,interNodeRibInput_:Automatic] := phase1WithPole[pole,
      phase1Step5StructuralArchitectureCurrent[step4Assessment,ribSpacing,ribRunSpan,intraNodeConnectorInput,interNodeRibInput]];
Phase1RunStep4Assessment[] := Module[{perPole,scopeChecks,allPass},
  perPole=AssociationMap[Function[pole,Phase1RunStep4Assessment[pole]],$Phase1PoleIDs];
  scopeChecks=AssociationMap[Function[pole,
    If[AssociationQ[Lookup[perPole,pole,Missing[]]],
      TrueQ[Lookup[perPole[pole],"Step4ScopeComplete",False]],False]],$Phase1PoleIDs];
  allPass=And@@Values[scopeChecks];
  <|"Step"->4,"StepName"->"Complete ICARUS Carryover, Collector Geometry, and Distributed Physical Loading",
    "Status"->If[allPass,"Both independent pole assessments pass their modeled Step 4 checks; hardware qualification remains open.",
      "Step 4 remains incomplete for one or both independent poles."],
    "PerPoleResults"->perPole,"PerPoleModeledScopeChecks"->scopeChecks,
    "BothIndependentPoleChecksPass"->allPass,
    "NoCombinedMechanicalEquilibrium"->True,
    "AggregateUse"->"Only the boolean completion summary above is combined. Force, torque, dynamics, controller state and operating data remain pole-local."|>
];

Phase1ICARUSRedesignSizing[] := If[TrueQ[$Phase1ExecutingPole],phase1ICARUSRedesignSizingCurrent[],Phase1ICARUSRedesignSizing[$Phase1SelectedPole]];
Phase1ICARUSRedesignSizing[pole_String] := phase1WithPole[pole,phase1ICARUSRedesignSizingCurrent[]];

Phase1FreeRotationTrajectory[durationS_:Automatic] := If[TrueQ[$Phase1ExecutingPole],phase1FreeRotationTrajectoryCurrent[durationS],Phase1FreeRotationTrajectory[$Phase1SelectedPole,durationS]];
Phase1FreeRotationTrajectory[pole_String,durationS_:Automatic] := phase1WithPole[pole,phase1FreeRotationTrajectoryCurrent[durationS]];

Phase1WobbleSimulation[durationS_:Automatic] := If[TrueQ[$Phase1ExecutingPole],phase1WobbleSimulationCurrent[durationS],Phase1WobbleSimulation[$Phase1SelectedPole,durationS]];
Phase1WobbleSimulation[pole_String,durationS_:Automatic] := phase1WithPole[pole,phase1WobbleSimulationCurrent[durationS]];

Phase1DisturbanceScenarios[] := If[TrueQ[$Phase1ExecutingPole],phase1DisturbanceScenariosCurrent[],Phase1DisturbanceScenarios[$Phase1SelectedPole]];
Phase1DisturbanceScenarios[pole_String] := phase1WithPole[pole,phase1DisturbanceScenariosCurrent[]];


Phase1TimeDependentPower[timeS_?NumericQ] := If[TrueQ[$Phase1ExecutingPole],phase1TimeDependentPowerCurrent[timeS],Phase1TimeDependentPower[$Phase1SelectedPole,timeS]];
Phase1TimeDependentPower[pole_String,timeS_?NumericQ] := phase1WithPole[pole,phase1TimeDependentPowerCurrent[timeS]];

Phase1ICARUSControlLaw[desiredWrench_List,capacityN_:Automatic] := If[TrueQ[$Phase1ExecutingPole],phase1ICARUSControlLawCurrent[desiredWrench,capacityN],Phase1ICARUSControlLaw[$Phase1SelectedPole,desiredWrench,capacityN]];
Phase1ICARUSControlLaw[pole_String,desiredWrench_List,capacityN_:Automatic] := phase1WithPole[pole,phase1ICARUSControlLawCurrent[desiredWrench,capacityN]];

Phase1ICARUSLoadPropagation[localPosition_List,localVelocity_List,attitudeQuaternion_List,angularVelocity_List] :=
  If[TrueQ[$Phase1ExecutingPole],phase1ICARUSLoadPropagationCurrent[localPosition,localVelocity,attitudeQuaternion,angularVelocity],
    Phase1ICARUSLoadPropagation[$Phase1SelectedPole,localPosition,localVelocity,attitudeQuaternion,angularVelocity]];
Phase1ICARUSLoadPropagation[pole_String,localPosition_List,localVelocity_List,attitudeQuaternion_List,angularVelocity_List] :=
  phase1WithPole[pole,phase1ICARUSLoadPropagationCurrent[localPosition,localVelocity,attitudeQuaternion,angularVelocity]];

Phase1Phase2Handoff[] := If[TrueQ[$Phase1ExecutingPole],phase1Phase2HandoffCurrent[],Phase1Phase2Handoff[$Phase1SelectedPole]];
Phase1Phase2Handoff[pole_String] := phase1WithPole[pole,phase1Phase2HandoffCurrent[]];

Phase1StabilityCriteria[] := If[TrueQ[$Phase1ExecutingPole],phase1StabilityCriteriaCurrent[],Phase1StabilityCriteria[$Phase1SelectedPole]];
Phase1StabilityCriteria[pole_String] := phase1WithPole[pole,phase1StabilityCriteriaCurrent[]];

Phase1LocalSurfaceMesh[] := If[TrueQ[$Phase1ExecutingPole],
  Module[{computed=phase1EnsureCalculated[]},If[FailureQ[computed],computed,Lookup[$Phase1State["Derived"],"SurfaceMesh",Missing["SurfaceMeshUnavailable"]]]],
  Phase1LocalSurfaceMesh[$Phase1SelectedPole]];
Phase1LocalSurfaceMesh[pole_String] := Module[{computed=Phase1ComputePole[pole]},
  If[FailureQ[computed],computed,Phase1GetPoleDerived[pole,"SurfaceMesh"]]];

Phase1LocalRadiationLoads[] := If[TrueQ[$Phase1ExecutingPole],Phase1GetResult["LocalRadiation"],Phase1LocalRadiationLoads[$Phase1SelectedPole]];
Phase1LocalRadiationLoads[pole_String] := Module[{computed=Phase1ComputePole[pole]},If[FailureQ[computed],computed,Phase1GetPoleResult[pole,"LocalRadiation"]]];
Phase1MassBalance[] := If[TrueQ[$Phase1ExecutingPole],Phase1GetResult["MassBalance"],Phase1MassBalance[$Phase1SelectedPole]];
Phase1MassBalance[pole_String] := Module[{computed=Phase1ComputePole[pole]},If[FailureQ[computed],computed,Phase1GetPoleResult[pole,"MassBalance"]]];
Phase1ThermalScreen[] := If[TrueQ[$Phase1ExecutingPole],Phase1GetResult["Thermal"],Phase1ThermalScreen[$Phase1SelectedPole]];
Phase1ThermalScreen[pole_String] := Module[{computed=Phase1ComputePole[pole]},If[FailureQ[computed],computed,Phase1GetPoleResult[pole,"Thermal"]]];
Phase1PowerLedger[] := If[TrueQ[$Phase1ExecutingPole],Phase1GetResult["PowerLedger"],Phase1PowerLedger[$Phase1SelectedPole]];
Phase1PowerLedger[pole_String] := Module[{computed=Phase1ComputePole[pole]},If[FailureQ[computed],computed,Phase1GetPoleResult[pole,"PowerLedger"]]];
Phase1DynamicInitialConditions[] := If[TrueQ[$Phase1ExecutingPole],Phase1GetResult["DynamicInitialConditions"],Phase1DynamicInitialConditions[$Phase1SelectedPole]];
Phase1DynamicInitialConditions[pole_String] := Module[{computed=Phase1ComputePole[pole]},If[FailureQ[computed],computed,Phase1GetPoleResult[pole,"DynamicInitialConditions"]]];

(* WHAT: Select which pole the no-argument read/view accessors display.
   WHY: A convenient view selector is useful when inspecting independently calculated
   outputs, but it must not become an operating-state coupling mechanism.
   HOW: This changes only the view-selection symbol. It does not edit either operating
   register, invoke a calculation, exchange data, or merge runtime states. During an
   active pole calculation, cross-pole selection is rejected. *)
Phase1SelectPole[pole_String] := Which[
  TrueQ[$Phase1ExecutingPole] && pole =!= $Phase1CurrentPole, Failure["CrossPoleSelectionBlocked", <|"ActivePole" -> $Phase1CurrentPole, "RequestedPole" -> pole|>],
  !MemberQ[$Phase1PoleIDs, pole], Failure["UnknownPoleID", <|"Pole" -> pole, "ValidPoleIDs" -> $Phase1PoleIDs|>],
  True, $Phase1SelectedPole = pole; pole];
Phase1GetResults[] := If[TrueQ[$Phase1ExecutingPole], phase1EnsureCalculated[], Phase1GetPoleResults[$Phase1SelectedPole]];
Phase1GetResult[name_String] := If[TrueQ[$Phase1ExecutingPole],
  Module[{r = phase1EnsureCalculated[]}, If[FailureQ[r], r, Lookup[$Phase1State["Results"], name, Missing["ResultNotAvailable", name]]]],
  Phase1GetPoleResult[$Phase1SelectedPole, name]];
Phase1GetDerived[name_String] := If[TrueQ[$Phase1ExecutingPole],
  Module[{r = phase1EnsureCalculated[]}, If[FailureQ[r], r, Lookup[$Phase1State["Derived"], name, Missing["DerivedValueNotAvailable", name]]]],
  Phase1GetPoleDerived[$Phase1SelectedPole, name]];

(* A single-pole candidate may not alter the shared design. Reconciliation across
   both pole operating envelopes is a separate design decision. *)
Phase1ApplyOptimizationCandidate[] := Failure["SinglePoleCandidateCannotChangeSharedDesign", <|
  "Reason" -> "A candidate calculated for one pole cannot modify common design/material inputs. Reconcile both independent pole optimization results against the shared design register first.",
  "NoInputsChanged" -> True|>];

(* WHAT: Provide an interactive editor for the shared design/material register.
   WHY: Geometric, optical and common material definitions are common model inputs,
   whereas the two poles' environments, disturbances and initial conditions remain
   separate. The editor must not expose pole-specific operating keys.
   HOW: Each InputField edits a local working association. Apply commits only the
   registered shared keys through Phase1SetInputs; Reload discards local edits and
   reloads the active shared register. This panel uses editable fields, not sliders;
   no calculation is implied until the user invokes a calculation command. *)
Phase1InteractivePanel[] := DynamicModule[
  {working = Phase1GetSharedInputs[], result = Missing["NotRun"], keys},
  keys = Keys[$Phase1State["Inputs"]];
  Column[{
    Style["PHASE 1 — SHARED DESIGN & MATERIAL INPUTS / v11.142", Bold],
    Style["These inputs are common to both pole systems. Pole-specific operating values are entered separately."],
    Pane[Dynamic@Grid[Prepend[Table[{k,
      (* This field edits a local draft value only; it does not mutate the live model
         until the shared Apply control validates and commits the complete key set. *)
      InputField[Dynamic[working[k]]]}, {k, keys}],
      {"Shared input key", "Value"}], Alignment -> Left], Scrollbars -> {False, True}],
    Row[{
      (* Commit shared design/material values through the immutable-input gate. A
         successful shared update invalidates both pole result caches for recalculation. *)
      Button["Apply shared inputs", result = Phase1SetInputs[Association@KeyTake[working, keys]], Method -> "Queued"],
      (* Restore the current shared register and discard uncommitted local edits. *)
      Button["Reload", working = Phase1GetSharedInputs[], Method -> "Queued"]
    }],
    Dynamic[If[FailureQ[result], Style[ToString[result, InputForm], Red], ToString[Phase1InputStatus[], InputForm]]]
  }]
];

(* WHAT: Provide a separate operating-input editor for exactly one named pole.
   WHY: Pole 1 and Pole 2 may share immutable physical constants and common design
   definitions, but their orbital/operating values and result caches must never cross.
   HOW: The panel captures the requested pole's operating register only. Apply writes
   that pole's keys; Reload refreshes that pole's editor; Calculate this pole explicitly
   invokes the single-pole calculation. Cross-pole access is rejected while a pole run
   is active. The visible controls are InputFields and buttons, not automatic sliders. *)
Phase1PoleOperatingInputPanel[pole_String] := Which[
  TrueQ[$Phase1ExecutingPole] && pole =!= $Phase1CurrentPole, Failure["CrossPoleUIReadBlocked", <|"ActivePole" -> $Phase1CurrentPole, "RequestedPole" -> pole|>],
  !MemberQ[$Phase1PoleIDs, pole], Failure["UnknownPoleID", <|"Pole" -> pole|>],
  True,
  DynamicModule[{working = Lookup[$Phase1State["PoleOperatingInputs"], pole], result = Missing["NotRun"]},
    Column[{
      Style["PHASE 1 — " <> pole <> " OPERATING INPUTS", Bold],
      Style["These operating values belong only to " <> pole <> ". Changes here do not alter the other pole's operating register or result cache."],
      Grid[Prepend[Table[{k,
        (* This field edits only the local draft for the explicitly named pole. *)
        InputField[Dynamic[working[k]]]}, {k, $Phase1PoleOperatingKeys}],
        {"Operating input key", "Value"}], Alignment -> Left],
      Row[{
        (* Commit only this pole's operating keys; the other pole's operating state
           and result cache remain isolated and are neither read nor overwritten. *)
        Button["Apply " <> pole <> " operating inputs",
          result = Phase1SetPoleOperatingInputs[pole, Association@KeyTake[working, $Phase1PoleOperatingKeys]], Method -> "Queued"],
        (* Reload only the named pole's active operating register. *)
        Button["Reload", working = Lookup[$Phase1State["PoleOperatingInputs"], pole], Method -> "Queued"],
        (* Explicitly invoke one pole's calculation path; this is not a combined run. *)
        Button["Calculate this pole", result = Phase1ComputePole[pole], Method -> "Queued"]
      }],
      Dynamic[If[FailureQ[result], Style[ToString[result, InputForm], Red], ToString[Phase1InputStatus[pole], InputForm]]]
    }]
  ]
];

Phase1Reset[] := If[TrueQ[$Phase1ExecutingPole],
  Failure["ResetBlockedInsidePoleExecution", <|"ActivePole" -> $Phase1CurrentPole|>],
  Module[{shared = $Phase1DefaultInputs, op = $Phase1PoleInputDefaults},
    $Phase1State = <|"SchemaVersion" -> $Phase1ModelVersion, "Inputs" -> shared,
      "PoleOperatingInputs" -> AssociationThread[$Phase1PoleIDs, ConstantArray[op, Length[$Phase1PoleIDs]]],
      "PoleStates" -> <||>, "TwoPoleAggregate" -> <||>,
      "Derived" -> <||>, "Results" -> <||>, "AuditLog" -> {},
      "LastRun" -> Missing["NotRun"], "ActivePole" -> Missing["NoActivePole"],
      "PoleArchitectureRule" -> "Two physically distinct systems, one installed at each pole. Their design and material definitions are shared; their operation is completely independent. Each pole has its own operating inputs, local environment and disturbance history, initial conditions, forces, torques, controllers, dynamics, stored state, caches, results, optimization and acceptance decisions. No operating state, force, torque, power, control command, disturbance, environment state or calculated operating output is exchanged, coupled, combined or used as an input between poles. Immutable physical constants and common mathematical/numerical algorithms are common definitions, not shared operating states. Scalar outputs may be arithmetically summed only after both calculations finish and only for reporting; aggregate results never feed either pole's operation. No combined mechanical equilibrium is imposed. Each pole uses its own local Sun-radial +x coordinate basis; no common global position/orientation is inferred."|>;
    phase1Audit["ResetTwoIndependentPoleSystems", <|"PoleCount" -> 2, "OtherProjectDefaults" -> 0|>];
    $Phase1State
  ]
];

Phase1SaveState[path_String] := If[TrueQ[$Phase1ExecutingPole],
  Failure["SaveStateBlockedInsidePoleExecution", <|"ActivePole" -> $Phase1CurrentPole|>],
  Put[$Phase1State, path]
];
Phase1LoadState[path_String] := If[TrueQ[$Phase1ExecutingPole],
  Failure["LoadStateBlockedInsidePoleExecution", <|"ActivePole" -> $Phase1CurrentPole|>],
  Module[{loaded, schema, shared, opInputs, unknownShared, unknownOps, loadedSchema},
    loaded = Quiet@Check[Get[path], $Failed];
    If[!AssociationQ[loaded], Return[Failure["InvalidIndependentPoleStateFile", <|"Path" -> path|>]]];
    schema = Lookup[loaded, "SchemaVersion", ""];
    If[!MemberQ[{"11.33", "11.92", "11.93", "11.94", "11.109", "11.110", "11.111", "11.112", "11.113", "11.114", "11.115", "11.116", "11.117", "11.118", "11.119", "11.120", "11.121", "11.122", "11.123", "11.124", "11.125", "11.126", "11.127", "11.128", "11.129", "11.130", "11.131", "11.132", "11.133", "11.134", "11.135", "11.136", "11.137", "11.138", "11.139", $Phase1ModelVersion}, schema],
      Return[Failure["InvalidOrUnsupportedIndependentPoleStateFile",
        <|"Path" -> path, "SupportedSchemas" -> {"11.33", "11.92", "11.93", "11.94", "11.109", "11.110", "11.111", "11.112", "11.113", "11.114", "11.115", "11.116", "11.117", "11.118", "11.119", "11.120", "11.121", "11.122", "11.123", "11.124", "11.125", "11.126", "11.127", "11.128", "11.129", "11.130", "11.131", "11.132", "11.133", "11.134", "11.135", $Phase1ModelVersion}|>]]];
    shared = Lookup[loaded, "Inputs", <||>];
    If[!AssociationQ[shared], Return[Failure["InvalidSharedInputRegisterInSavedState", <|"Path" -> path|>]]];
    loadedSchema = schema;
    shared = KeyDrop[shared, $Phase1PoleOperatingKeys];
    (* KeyTake enforces the current shared-input contract. Any unknown field is
       deliberately discarded rather than evaluated or carried into the model. *)
    unknownShared = Complement[Keys[shared], Keys[$Phase1DefaultInputs]];
    shared = KeyTake[shared, Keys[$Phase1DefaultInputs]];
    opInputs = Lookup[loaded, "PoleOperatingInputs", <||>];
    If[!AssociationQ[opInputs], Return[Failure["InvalidPoleOperatingInputRegistersInSavedState", <|"Path" -> path|>]]];
    If[!And @@ (KeyExistsQ[opInputs, #] && AssociationQ[Lookup[opInputs, #, <||>]] & /@ $Phase1PoleIDs),
      Return[Failure["MissingOrInvalidPoleOperatingInputRegisterInSavedState", <|"Path" -> path|>]]];
    unknownOps = Flatten[Table[Complement[Keys[opInputs[id]], $Phase1PoleOperatingKeys], {id, $Phase1PoleIDs}]];
    opInputs = AssociationMap[KeyTake[opInputs[#], $Phase1PoleOperatingKeys] &, $Phase1PoleIDs];
    If[Lookup[shared, "PoleCount", $Phase1DefaultInputs["PoleCount"]] =!= 2,
      Return[Failure["InvalidPoleCountInSavedState", <|"RequiredPoleCount" -> 2|>]]];
    $Phase1State = <|
      "SchemaVersion" -> $Phase1ModelVersion,
      "Inputs" -> Join[$Phase1DefaultInputs, shared],
      "PoleOperatingInputs" -> AssociationMap[
        Join[$Phase1PoleInputDefaults, Lookup[opInputs, #, <||>]] &, $Phase1PoleIDs],
      "PoleStates" -> <||>, "TwoPoleAggregate" -> <||>,
      "Derived" -> <||>, "Results" -> <||>, "AuditLog" -> {},
      "LastRun" -> Missing["LoadedStateRequiresPerPoleRecalculation"],
      "ActivePole" -> Missing["NoActivePole"],
      "PoleArchitectureRule" -> $Phase1State["PoleArchitectureRule"]
    |>;
    phase1Audit["IndependentPoleStateLoaded", <|"Path" -> path,
      "LoadedSchemaVersion" -> loadedSchema,
      "UnknownSharedInputCountDiscarded" -> Length[unknownShared],
      "UnknownPoleInputCountDiscarded" -> Length[unknownOps],
      "AllPoleCachesInvalidated" -> True|>];
    $Phase1State
  ]
];

(* The only numerical operation common to the poles is evaluation of shared design/material
   properties. Each pole's complete calculation uses a merged read-only snapshot that combines
   those common values with exactly one pole's operating inputs. *)

End[];
EndPackage[];

(* ========================================================================
   SOURCE REVISION STATUS — 2026-11-22
   Revision v11.140 makes force and moment reconstruction tolerances scale-aware for
   pure-force and pure-moment requests. A shared characteristic-length-equivalent force
   reference is converted into separate force and moment scales, preventing roundoff in
   a nominally zero wrench channel from being judged against a near-zero-only reference.
   Revision v11.139 scales the six-axis ICARUS wrench equations by an invertible
   characteristic-length row transformation before the minimum-norm pseudoinverse solve.
   This removes the numerical conditioning imbalance between newton force rows and
   newton-metre moment rows for heliocentric-scale station lever arms without changing
   the exact wrench constraint set. A large-scale six-basis allocator regression test
   is added to the software suite. Runtime verification is pending; no acceptance is
   asserted. Saved-state compatibility retains v11.138.

   Revision v11.138 vectorizes the Gaussian attachment-weight evaluation and expresses
   the moment-correction covariance as Tr[Q] I - Q, where Q is the weighted patch-offset
   second-moment matrix. This preserves the v11.137 transfer equations and per-attachment
   force/moment checks while removing interpreted nested patch loops from the 68-point
   gravity-attachment path. Runtime verification is pending; no acceptance is asserted.
   Saved-state compatibility retains v11.137.

   Revision v11.137 removes repeated full attachment/station patch-array extraction
   from the membrane load-transfer aggregation. Both maps now reduce their complete
   station/attachment-by-patch force arrays once, preserving the original per-point
   force and moment correction equations while reducing aggregation work from
   quadratic patch-count data movement to linear movement in the stored arrays.
   The revision is intended to make the configured 1,280-patch, 68-attachment static
   gravity transfer executable within the Mathematica runtime. Runtime verification
   of the revised source remains pending; no Step 4 pass is asserted by this edit.
   Saved-state compatibility retains v11.136.

   Revision v11.136 records the bounded Mathematica runtime verification performed
   against v11.135 and advances the saved-state schema without changing calculation
   equations. The package loaded through sequential Get[StringToStream] with model
   version v11.135; the input-readiness report showed 112 shared inputs and 27 operating
   inputs per pole, with zero missing required keys. The software-only suite passed
   48/48 tests. The pole-independence audit passed all 27 checks. For each pole, the
   independent Geometry, SurfaceMesh, OpticalRegister, InitialRadiationLoads and
   NaturalEquilibrium tasks executed and returned associations; the mass ledger closed,
   the NaturalEquilibriumPass and radiation-over-inward-gravity checks were True, and
   transverse natural-force balance passed. The Pole2 NaturalEquilibrium record also
   explicitly returned ExactTorqueEquilibrium=True. These results verify those bounded
   model paths only; they do not establish complete Step 4 acceptance.

   Full Step 4 assessment, ICARUS transient sizing, and torque-free/wobble trajectory
   calls were attempted after v11.135 separated the Step 4 core from the Step 7-gated
   full calculation accessor. The Wolfram evaluator returned an internal tool error for
   these longer calls without a structured model result. This is an execution-service
   limitation in the recorded attempts, not a model-level Failure result and not a pass.
   Those routines remain unverified at their configured seven-day operating duration.
   Step 4 therefore remains resumed, incomplete and unaccepted. Hardware/actuator,
   attachment and flexible-structure qualification remains external and is not claimed.
   Saved-state compatibility retains v11.135.

   Revision v11.135 isolates the Step 4 quaternion-rotation, gravity-gradient wobble and
   stability routines from the complete calculation accessor that requires the deferred
   Step 7 electrical network. These routines retrieve a current-input-hash-matched Step 4
   engineering core, rebuilding that core directly when necessary. This keeps Step 4
   dynamics inside their authorized calculation scope and does not invoke the Step 7
   electrical network. Bounded runtime verification is recorded above; complete Step 4
   solver/assessment verification remains open. Saved-state compatibility retains v11.134.
   Revision v11.134 corrects package initialization order. The fixed Pole1/Pole2 IDs
   and the pole-operating-input key list are now initialized before the mutability
   inventory derives immutable, mutable and runtime-control key sets from them.
   This prevents the package from evaluating those inventories against an undefined
   operating-key symbol during sequential Get loading. The input values and key
   membership are unchanged. Saved-state compatibility retains v11.133. The current
   roadmap position is Step 4, resumed under the user's latest directive; Mathematica
   testing is authorized. No model test result or Step 4 acceptance is asserted by
   this source-order correction alone.
   Revision v11.133 adds the conductor-and-insulation self-mass/inertial line-load term to
   each inter-node rib run. Each run must supply an evidenced maximum effective transverse
   acceleration across the complete same-pole operating envelope. Physical conductor count,
   per-strand area and density plus supplied insulation linear mass determine cable linear
   mass; that mass times the acceleration bound is added to the Step 4 surface-load envelope.
   Design tension and the operating-sag estimate use the combined load when evidence is
   complete. Otherwise, only a clearly labelled surface-load partial screen is returned and
   the run is blocked. Static source review only; no Mathematica parsing, execution, tests
   or simulations. The saved-state whitelist retains v11.132.
   The current saved-state schema is v11.142.
   Revision v11.132 adds an evidence-backed per-run operating-sag check for inter-node
   structural ribs. Each run must provide a positive lower bound on horizontal cable
   tension across its complete same-pole operating envelope, an explicit passed-evidence
   flag and a traceable evidence reference. The source calculates the small-sag parabolic
   upper bound q L^2/(8 H_min) from the run's conservative equivalent normal-plus-
   tangential line-load envelope and compares it with the permitted run sag. This is a
   model screening check; supplied tension evidence is not derived or authenticated here.
   The aggregate result distinguishes missing/unsubstantiated horizontal-tension evidence
   from an actual derived sag-limit exceedance; either condition blocks the run structural
   screen and Step 5 acceptance. The existing permitted-sag envelope remains the conservative
   foil-plus-support displacement bound. The saved-state whitelist retains v11.131.
   Static source review only; no Mathematica parsing, execution, tests or simulations.
   The current saved-state schema is v11.132.
   Revision v11.131 adds a conservative combined out-of-plane deflection envelope for the
   foil bay and its supporting inter-node cable ribs. The largest global/patchwise panel
   deflection relative to supports is added to the maximum allowed rib sag and compared
   against the existing `MaximumDeflectionFractionOfRadius` allowance times planform radius.
   The combined envelope is added to the Step 5 spacing pass and an explicit acceptance
   blocker is emitted when it fails. This scalar sum does not resolve directional, spatial,
   or nonlinear foil/cable coupling. The saved-state whitelist retains v11.130. Static
   review only; no Mathematica parsing, execution, tests or simulations. The current
   saved-state schema is v11.131.
   Revision v11.130 makes the intra-node joint qualification blocker actionable by including
   the supplied overall pass flag, missing/failed evidence keys and missing/invalid report
   reference keys in the Step 5 acceptance blocker text. The connector result also exposes
   a single evidence-acceptance gate field while retaining all itemized evidence lists.
   Revision v11.129 documents the intra-node connector screen's What/Why/How contract,
   its per-connection demand basis, equal sharing assumption across supplied tabs, tab
   mass formula and separately supplied solder-volume mass formula. The result explicitly
   states that electrical resistance and I2R loss are not calculated by this mechanical
   connector screen. Revision v11.128 adds an itemized evidence and traceable-reference
   register for intra-node tab/solder joint qualification. The overall JointQualificationPassed flag
   is insufficient alone: the tab-material allowable, lap-shear, peel, thermal-cycling,
   vacuum/outgassing, radiation, electrical-resistance and process-repeatability items
   must each be marked passed and have a corresponding non-empty report reference.
   Missing/invalid references and failed/missing flags are returned separately and block
   the connector qualification gate. References are user-supplied pointers, not
   authenticated reports. The saved-state whitelist retains v11.127. Static review only;
   no Mathematica parsing, execution, tests or simulations were performed. The current
   saved-state schema is v11.131.
   Revision v11.127 adds a per-requirement traceable-reference register for backside-film
   bond qualification. Each of the required lap-shear, peel, thermal-vacuum, outgassing,
   radiation, ageing, process-repeatability and environmental-compatibility test flags
   must pass and have a corresponding non-empty report reference before the evidence
   record is complete. The references are user-supplied pointers, not authenticated reports.
   The existing overall qualification flag remains necessary but is not sufficient alone.
   The saved-state whitelist retains v11.126. Static review only; no Mathematica parsing,
   execution, tests or simulations were performed. The current saved-state schema is
   v11.127.
   Revision v11.126 exposes the exact per-run InsulationLinearMass_kg_per_m input beside
   the calculated insulation mass and run subtotal, and records separate conductor-metal
   and insulation mass-basis descriptions so both contributions can be audited from each
   returned run record.
   Revision v11.125 clarifies that physical strand count, per-strand section/density and
   actual run length determine conductor-metal mass, while insulation mass is computed
   from the separately supplied per-run insulation linear-mass input. Effective load-bearing
   strand count changes mechanical capacity and axial-rigidity credit only; it does not
   replace physical conductor count in conductor-metal mass accounting.
   Revision v11.124 aligns the Step 5 What/Why/How narrative with the active structural
   equations. It now documents that same-pole uniform membrane pretension contributes to
   direct foil tensile stress and tension-plus-bending strip deflection, while two-way
   shell action, directional membrane-network redistribution and rib bending stiffness
   remain excluded. It documents the global pressure-plus-tangential-traction envelope,
   co-located patchwise loads, and the small-sag parabolic cable approximation used for
   rib tension/end reactions. No catenary, cable-net, or direction-resolved load solution
   is claimed. The saved-state whitelist retains v11.123. Static review only; no
   Mathematica parsing, execution, tests or simulations were performed. The current
   saved-state schema is v11.128.
   Revision v11.123 requires the effective load-bearing conductor count to be an integer
   physical strand count in the range one through the supplied physical conductor count.
   The default remains one load-bearing strand. Fractional effective strand counts cannot
   be supplied. The v11.122 evidence gate remains: additional strands receive capacity/EA
   credit only with a passing per-run evidence flag and non-empty reference. Physical
   conductor count continues to determine conductor-metal mass; insulation mass is calculated separately from the supplied per-run insulation linear-mass input. The saved-state
   whitelist retains v11.122. Static review only; no Mathematica parsing, execution, tests
   or simulations were performed. The current saved-state schema is v11.123.
   Revision v11.122 changes the inter-node rib's mechanical-capacity assumption. Physical
   conductor count continues to determine conductor-metal mass; insulation mass is calculated separately from the supplied per-run insulation linear-mass input, but tensile capacity
   and axial rigidity default to a single credited strand. A per-run effective load-bearing
   strand count above one is credited only with a passing load-sharing evidence flag and
   a non-empty reference; without that evidence the source uses one-strand capacity/EA and
   adds a Step 5 acceptance blocker when multi-strand credit was requested. The evidence
   reference is user-supplied and not independently qualified by this routine. The saved-
   state whitelist retains v11.121. Static review only; no Mathematica parsing, execution,
   tests or simulations were performed. The current saved-state schema is v11.122.
   Revision v11.121 adds same-pole Step 4 patch tangential-traction magnitude to the
   inter-node rib tributary load path. The same supplied patch-area shares now integrate
   normal pressure and tangential traction independently, with separate conservation
   checks; the cable demand uses a conservative sum of their line-load magnitudes because
   rib-local directional projection is not yet resolved. The peak-envelope fallback also
   includes the peak tangential-traction magnitude and remains provisional. Step 5 records
   the new tangential load path in its structural-stability and rib-interface outputs.
   The saved-state whitelist retains v11.120. Static review only; no Mathematica parsing,
   execution, tests or simulations were performed. The current saved-state schema is v11.121.
   Revision v11.120 separates the inter-node cable run's tensile/axial-rigidity gate from
   its operating-envelope tautness gate in the aggregate result and structural-stability
   record. The tautness evidence flag and reference are explicitly user-supplied claims,
   not evidence independently inspected by this source routine. Missing or failed records
   continue to block the run; compressive foil wrinkling/buckling and two-way shell stability
   remain explicit unresolved Step 5 acceptance items. The saved-state whitelist retains
   v11.119. Static review only; no Mathematica parsing, execution, tests or simulations.
   The current saved-state schema is v11.120.
   Revision v11.119 adds an explicit Step 5 structural-stability coverage record and
   makes the tension-only inter-node cable rib's tautness a per-run acceptance gate.
   Each run must supply a positive minimum operating cable tension across its same-pole
   operating load envelope plus a passing evidence flag and non-empty evidence reference;
   the source does not infer reverse-load/slack stability from its single peak normal-load
   cable calculation. The Step 5 result now records foil stress/deflection, rib tensile/EA,
   cable tautness and anchor capacity coverage, while explicitly identifying compressive
   foil wrinkling/buckling, two-way plate/shell instability, and temperature-dependent
   residual-stress stability as unresolved. Step 5 acceptance is blocked until directional
   in-plane stress resultants and final support boundaries are resolved. Static review only;
   no Mathematica parsing, execution, tests or simulations were performed.
   At v11.119 the saved-state schema was v11.119; v11.120 retains it as an
   explicitly supported previous schema.
   Revision v11.118 makes the Step 5 tangential-traction interpretation explicit. The
   source assigns the full magnitude of each patch's in-plane tangential surface traction
   to one scalar shear component for a reduced-order plane-stress von Mises screening
   surrogate. Result fields now identify this as a surrogate and explicitly state that
   the in-plane stress tensor, traction direction relative to ribs, membrane load
   redistribution and two-way shell response are not resolved. The original equivalent-
   stress field names remain as compatibility aliases, with additional fields naming
   the reported values as stress surrogates. The explicit saved-state whitelist now
   retains schema v11.117 as well as v11.115 and v11.116 and the earlier supported
   schemas. Static review only; no Mathematica parsing, execution, tests or simulations.
   At v11.118 the saved-state schema was v11.118; v11.119 retains it as an
   explicitly supported previous schema.
   Revision v11.117 completes the static review of the Step 5 tangential-traction
   interaction. The panel description and equations now identify the shear-reduced
   normal stress allowance, distinguish the intentionally conservative global envelope
   (which may combine pressure and shear maxima from different patches) from the
   co-located patchwise checks, and expose the resulting normal stress budget and
   thickness-interaction flags in the result. The explicit saved-state whitelist now
   preserves both v11.115 and v11.116 saved schemas as well as the earlier supported
   schemas when advancing to v11.117. This remains static source inspection only; no
   Mathematica parsing, execution, tests or simulations were performed.
   At v11.117 the saved-state schema was v11.117; v11.118 retains it as an
   explicitly supported previous schema.
   Revision v11.116 carries the Step 4 patchwise tangential traction into the Step 5
   aluminum foil stress assessment. The Step 5 input join now requires finite,
   nonnegative, mesh-aligned total tangential traction, gravity normal/tangential
   traction, and perimeter/station attachment-gravity normal/tangential traction arrays.
   The global stress bound reduces the available normal stress using the maximum
   tangential traction; patchwise stress uses each patch's own traction. The interaction
   is reported as a plane-stress von Mises equivalent for normal pretension/bending
   stress plus tangential traction. Missing distributed-gravity or attachment-gravity
   transfer flags now appear as explicit Step 5 acceptance blockers. This remains a
   one-way reduced-order screen, not a directional membrane-network or shell solution.
   Static review only; no Mathematica parsing, execution, tests or simulations were run.
   Revision v11.115 extends the explicit saved-state load whitelist to include schemas
   v11.112, v11.113 and v11.114, in addition to the already supported prior schemas.
   Older states are normalized into the current shared-input and two-pole operating-input
   defaults during load; unknown legacy keys continue to be dropped rather than retained.
   At v11.115 the saved-state schema was v11.115. v11.117 explicitly retains that
   schema alongside v11.116 and the earlier supported versions while preserving the
   strict independent Pole 1/Pole 2 register contract.
   Static review only; no Mathematica parsing, execution, tests or simulations were run.
   Revision v11.114 makes the coupled minimum-thickness helper return one traceable
   association for both baseline-passing and bisection branches. The Step 5 global
   thickness result, maximum-span result, and every patchwise thickness result preserve
   the requested relative interval tolerance, iteration count, lower/upper bracket role,
   and whether the baseline foil already passes. The source output now exposes these
   records rather than discarding search metadata after scalar extraction. Static review
   only; no Mathematica parsing, execution, tests or simulations were performed.
   Revision v11.113 makes the maximum tensioned-strip span helper return one stable
   association schema on every successful path. The zero-pressure degenerate path and
   the branch where the whole planform diameter satisfies the deflection criterion now
   return MaximumPassingSpan_m, iteration/tolerance metadata and an explicit indication
   that the planform bound is active. The bisection-limited path returns the same schema
   with PlanformBoundActive=False. This corrects a branch-dependent return type that the
   Step 5 caller's Lookup operation could not safely consume. Static review only; no
   Mathematica parsing, execution, tests or simulations were performed.
   Revision v11.112 replaces the bending-only deflection sizing bound with monotone,
   tolerance-controlled searches using the coupled tension-plus-bending strip response.
   The largest baseline-thickness rib spacing is found by bisection against the
   deflection-fraction limit, and global/patchwise minimum foil thickness is found by
   bisection from the current aluminum baseline to a conservative bending-only upper
   bracket. The bending-only expression is no longer treated as the selected thickness;
   it only bounds the search. Static review only; no Mathematica parsing, execution,
   tests or simulations were performed.
   Revision v11.111 adds membrane-pretension coupling to the Step 5 one-way foil-panel screen. The applied same-pole MembranePretension_N_m is included as direct in-plane tensile stress in the foil allowable-stress check and as axial tension in the simply supported tension-plus-bending strip deflection solution. The bending-only deflection thickness/span bound remains explicitly conservative; actual global and patchwise deflection use the combined model. The calculation uses a stable small-parameter series near zero pretension and the centered closed-form solution elsewhere. This does not qualify installed pretension, two-way plate/shell action, or nonlinear membrane behavior. Static review only; no Mathematica parsing, execution, tests or simulations were performed.
   Revision v11.110 exposes the selected and baseline aluminum foil areal mass,
   membrane extensional stiffness per unit width, and Euler-Bernoulli flexural rigidity
   per unit width in the Step 5 structural result and mass ledger. The panel-deflection
   calculation now uses the same reported flexural-rigidity quantity directly, making
   the thickness/spacing/mass/stiffness trade-off explicit. The section properties are
   guarded against non-finite or non-positive results. The beam-strip assumption remains
   explicit and no two-way plate/shell stiffness is claimed. Static review only; no
   Mathematica parsing, execution, tests or simulations were performed.
   Revision v11.109 adds a finite-real and nonnegative-domain guard to the Step 5 known
   structural mass subtotal after combining aluminium foil, selected backside-film,
   supplied intra-node connector and supplied inter-node rib/anchor masses. The output
   explicitly states that this subtotal includes only available validated components;
   missing connector or routing records are retained as Missing in the component ledger
   and are not interpreted as a zero-mass final design. Static review only; no Mathematica
   parsing, execution, tests or simulations were performed.
   Revision v11.108 fixes tributary-geometry evidence propagation. The per-run
   structural result now carries each supplied TributaryGeometryMappingEvidencePassed
   flag and TributaryGeometryEvidenceReference into the Step 5 aggregate evidence gate;
   previously the aggregate gate could only see missing output fields and therefore
   could never clear even when a valid run-level evidence record was supplied. No
   geometry evidence is inferred or upgraded by this propagation. Static review only;
   no Mathematica parsing, execution, tests or simulations were performed.
   Revision v11.107 replaces per-run duplicated anchor capacities with a unique physical
   AnchorRecords register referenced by each run's StartAnchorID and EndAnchorID. Demand
   magnitudes from all connected rib ends are aggregated at each shared anchor before its
   capacity check; each unique anchor's mass is counted once and added to the inter-node
   structural mass subtotal. Anchor qualification now requires a passing flag and an
   evidence reference. Summed force magnitudes are deliberately conservative because
   anchor-local force directions and cable-network interaction are not yet modelled.
   Revision v11.106 makes each inter-node tributary-geometry evidence flag traceable:
   each run must now provide both TributaryGeometryMappingEvidencePassed=True and a
   non-empty TributaryGeometryEvidenceReference. A complete area-share ledger by itself
   does not establish that the shares correspond to physical rib geometry. Revision
   v11.105 distinguishes a closed supplied patch-area-share ledger from proof that the
   share map matches the physical rib geometry. Every run needs an explicit geometry
   evidence flag in addition to complete patch shares, per-patch share closure and global
   pressure-load conservation. The helper reports that it does not derive or independently
   qualify tributary geometry. It also documents that the integrated normal load is
   represented as an equivalent uniform line load over the unsupported span; local
   along-run load variation, cable-net interaction and tangential/shear transfer remain
   outside this reduced-order model. Connector and inter-node blocker lists now retain
   every independent missing/failed condition instead of returning only the first. Static review only; no execution or tests.
   Revision v11.104 adds explicit per-run TributaryPatchShares records for spatial load
   mapping. The optional inter-node rib screen now consumes the same pole's Step 4 patch
   pressures, curved patch areas and unit normals; each run integrates its assigned
   normal load and converts that total to a line load over its unsupported span. Every
   patch's area share must close to unity across the full run set, and summed run loads
   must conserve the complete Step 4 normal-pressure integral. Missing patch shares retain
   the conservative peak-pressure-width fallback but explicitly block Step 5 acceptance.
   This mapping does not yet model cable-net interaction or tangential/shear transfer.
   Static review only; no Mathematica execution, tests or simulations were performed.
   Revision v11.103 clarifies and tightens the optional per-run inter-node rib screen:
   it requires a non-empty conductor material name, a safety factor of at least one,
   explicit unsupported-span/run-length ordering, and finite derived run and total-mass
   values; it reports both unfactored and safety-factored elastic extension while
   enforcing the latter against the configured extension limit. The Step 5 public API
   usage string now documents its optional same-pole intra-node and inter-node records.
   Static review only; no Mathematica execution, tests or simulations were performed.
   Revision v11.102 adds an optional same-pole, per-run inter-node conductor screen.
   It consumes supplied Step 7 conductor material/section, parallel-conductor count,
   actual route length, unsupported span, tributary width and individual start/end
   anchor capacities. For each run it derives a safety-factored tension demand from
   the Step 4 peak-pressure envelope, checks conductor tensile capacity, actual EA,
   elastic extension and both anchors, and calculates conductor-metal plus supplied
   insulation mass. A missing run record remains a blocker; no AWG, current capability,
   electrical topology or I2R loss is selected. Anchor qualification remains a separate
   evidence flag and a passing capacity calculation is not hardware qualification.
   Revision v11.101 permits a tab-only intra-node connector record to omit solder
   density when solder volume is explicitly zero; solder density remains mandatory
   and positive whenever nonzero solder volume is supplied. The reported complete bond
   evidence field now includes constitutive/mass/section evidence, all qualification
   evidence items and the overall qualification flag rather than only mechanical-data
   completeness.
   Revision v11.100 corrects the patchwise panel-screen local-variable scope and
   requires the pressure, patch, index, position, normal and area-weight arrays to
   have exactly matching lengths. Patch indices must be a complete unique sequence,
   and local normals must be finite-real unit vectors before any per-patch demand is
   derived. The bond-evidence missing/failed report also handles a malformed evidence
   container safely by treating all required items as unavailable.
   Revision v11.99 joins the Step 5 panel screen to the exact supplied Step 4 curved
   mesh: patch pressure, patch index, local position, unit normal and curved-area weight
   must align, and the quadrature area must close to the analytic curved area within the
   configured mesh tolerance. Each patch now receives its own local panel stress,
   deflection and minimum-thickness screen using the common provisional rib spacing;
   the global peak pressure still sets the conservative common candidate thickness.
   Results identify the uniform trial-grid assumption and retain the requirement for
   the final routed support bays to be defined in Step 7. This is still reduced-order
   screening, not a shell model, FEA or structural qualification.
   Revision v11.98 replaces the optional-backing single bond-qualification Boolean as
   the sole acceptance evidence with a required evidence register for lap shear, peel
   resistance, thermal-vacuum cycling, vacuum/outgassing, radiation compatibility,
   long-term ageing, process repeatability and environmental compatibility. Every
   item must be explicitly passed, in addition to the overall qualification flag,
   before a bonded anti-sunward film can be selected. Missing evidence remains visible
   in the result record and blocks selection; the current Kapton candidate remains
   unselected. This is a source-level evidence gate, not a qualification test.
   Revision v11.97 adds an optional same-pole intra-node tab/solder connector screen.
   With an explicit Step 7 connector record it calculates tab tension, nominal joint
   overlap shear/peel stress, elastic extension, tab mass and solder mass, and adds
   those local connector masses to the Step 5 known structural subtotal. Missing
   connector data remains a named blocker; no dimensions, alloy, topology, solder
   quantity or qualification is inferred. The public Step 5 API remains backwards
   compatible through optional defaults.
   Revision v11.96 corrects the optional-backing comparison so any characterized
   bonding-layer areal mass is included in the mass-equivalent aluminum comparator.
   Film selection now additionally requires measured/defensible bond mechanical
   properties, explicit inclusion of the bond section in laminate bending mechanics,
   known bond mass and passed bond qualification; these are unavailable for the current
   candidate, so it remains unselected. The Step 5 task dependency entry now captures
   the full same-pole upstream input set required by the supplied Step 4 assessment.
   Revision v11.93 begins Step 5 through a pole-specific structural architecture
   interface driven by the supplied same-pole Step 4 pressure/geometry assessment. It
   introduces mutable panel-deflection, rib-sag and cable-extension screening inputs;
   registers a manufacturer-data Kapton HN candidate without selecting or adding film
   mass; derives foil minimum thickness and maximum structural bus-run spacing from a
   simply supported strip screen; calculates tributary rib line load, tension, end
   anchor capacity and EA; and records a partial mass ledger with local connector and
   inter-node bus mass deferred to Step 7. The routine does not run Step 4, mutate the
   active material/mass inputs, or claim Step 4/Step 5 acceptance. Step 4 remains
   deferred and must be resumed and accepted before Step 5 acceptance or Step 6.
   Revision v11.92 adds a shared finite-real, strictly positive quaternion-norm predicate to the torque-free rotation and nonlinear gravity-gradient wobble paths. Both initial quaternions are rejected before ODE construction if malformed or zero-norm; every sampled quaternion is checked by the shared trajectory-integrity gate before attitude-angle or normalization-dependent post-processing; numeric gravity-gradient RHS evaluations also reject invalid quaternions before rotation-matrix normalization. The existing configured unit-norm tolerance remains a separate post-integration acceptance check. Revision v11.91 verifies the unconstrained station-force solution reconstructed through the physical 6-by-12 wrench matrix before finite per-station force clipping. Translational force residual and rotational moment residual are scaled and compared separately using the configured relative tolerance. Capacity-induced residual after clipping remains a modeled saturation response and is not confused with an allocator reconstruction error. Revision v11.90 hardens the integrated dynamic controller allocation boundary: the six-component demand wrench and 12-component unconstrained allocation must be finite real; the result must partition into exactly four finite-real station force vectors; invalid states, raw allocations or finite-capacity results fail the dynamic control path explicitly instead of flowing into symbolic or malformed records. Revision v11.89 requires every numeric quaternion entering the integrated rigid-body RHS/controller path to be a finite-real four-vector with a finite, strictly positive norm before rotation/normalization. Small solver norm drift is still assessed against the configured post-integration quaternion tolerance; the guard only prevents a zero/invalid quaternion from reaching attitude transforms. Revision v11.88 hardens the time-dependent power entry point before any trajectory-driven mesh rotation: requested time and simulation duration must be finite real values; interpolated/initial positions and quaternions must have finite-real three-/four-component shapes; quaternion norm must satisfy the configured normalization tolerance; the centre of mass and mesh-rotation result are validated; and failed integrated trajectories are not replaced with initial conditions. Revision v11.87 hardens the per-station demand-summary producer: station positions and every station force sample must be finite-real three-vectors; supplied sample times must be finite-real, align one-to-one with the samples, and increase strictly before per-station force/moment peaks are derived. The helper retains a generic positive station count for isolated diagnostics while the physical controller enforces four stations. Revision v11.86 connects the allocator's separately scaled force and moment reconstruction result to both the six-basis Step 4 geometry/controller assessment and the initial zero-command allocation; invalid allocator/load-map results now fail explicitly before downstream indexing, and the Step 4 core records the six per-basis reconstruction booleans. Revision v11.85 hardens the common ICARUS allocator and force-capacity boundary: only four finite-real station force vectors, a finite-real six-component desired wrench, four valid station positions and a full-rank finite-real 6-by-12 wrench matrix are accepted; achieved force and moment residuals are reported and scaled separately, without mixing newtons and newton-metres. Revision v11.84 makes the standalone ICARUS load-propagation path use the exact principal axis-angle rotation vector already used by the integrated rigid-body controller, rather than the small-angle twice-quaternion-vector approximation; the adjacent frame note records that position/velocity are transformed from the pole-local inertial frame while angular velocity is a body-frame state. Revision v11.83 aligns the standalone ICARUS load-propagation entry point with the integrated rigid-body controller: it validates all pole-local state vectors and model mass properties, checks quaternion normalization, canonicalizes the quaternion sign, rotates position and velocity into the collector body frame before building translation demand, checks station allocation and geometry/mesh availability, and refuses to store a load map unless aggregate and every individual station force/moment transfer conserve. Revision v11.82 aligns ICARUS sizing with the shared finite-real domain checks: the per-pole reserve, station-force demands, derived capacity target, station assembly-COM moment demands, peak force/moment vectors and times, existing-capability classification, and dynamic attachment-conservation residuals must be finite real values of the expected shape before a sizing pass can be recorded. Revision v11.81 applies finite-real time, pole-local position, quaternion, heliocentric position and positive heliocentric-distance guards to the time-dependent power evaluator before direction normalization and inverse-square illumination are evaluated. Revision v11.80 requires the integrated dynamic heliocentric position and resulting solar distance to be finite real values before normalization or inverse-square gravity evaluation; the controlled rigid-body, torque-free rotation and gravity-gradient wobble runs also require finite positive real integration durations. Revision v11.79 aligns the Step 4 acceptance checklist with the shared finite-real predicates for geometry area, radiation resultants and patch moments, incidence angles, distributed gravity vectors, attachment patch forces, gravity traction arrays, centre of mass, inertia tensor and future-mass scalar outputs. Revision v11.78 corrects the dynamic radiation-record failure-detail association identified during static review of v11.77; the force-count and patch-count diagnostics now have separate, properly closed values. Revision v11.77 requires every dynamic radiation patch force, radiation resultant, solar-wind patch/resultant, and final environmental acceleration/torque vector to be finite and real before entering the rigid-body equations; the scalar ODE callbacks apply matching checks to returned acceleration and torque vectors. Revision v11.76 separates the dynamic ODE state predicates by physical dimension: position, velocity and angular-rate inputs are finite-real three-vectors, and attitude is a finite-real four-component quaternion. The explicit state shape gate now preserves the quaternion dimension while rejecting malformed or non-finite state components. Revision v11.75 added fail-closed radiation/gravity record checks during each dynamic disturbance evaluation and finite-real checks on the state-vector inputs. The complete dynamic gravity mass-point register must have unique identifiers, recognized categories, aligned force/position arrays and finite-real three-vectors before stable-ID patch routing. Revision v11.74 validates the complete static gravity mass-point register before identifier-based sheet-patch routing, including unique IDs, recognized point categories, aligned force/position arrays and finite-real three-vectors; station-capacity input now uses the same finite-real vector predicate. Revision v11.73 adds shared finite-real scalar/vector validation to station, attachment, patch and dynamic environmental load inputs, and verifies that dynamic gravity mass-point kinds, identifiers, forces and body positions have aligned counts and finite-real three-vector data before attachment selection. Revision v11.72 adds explicit failure propagation for invalid dynamic station load maps and malformed environment/patch-load records, records each station's conservation result at every propagated sample, and requires all individual station transfers to pass for dynamic ICARUS acceptance. Revision v11.71 scales individual and aggregate moment-conservation residuals using both the actual target moment and a force-times-characteristic-radius reference, avoiding near-zero-only tolerances for nominally zero-moment loads. Revision v11.70 adds a positive finite load-spread-width guard to the concentrated perimeter/station gravity transfer and makes both actuator-station and attachment-gravity load-map conservation acceptance require each individual force and moment transfer as well as the aggregate resultant. Revision v11.69 retains the shared finite-real, state-shape, strict-time, configured-count and full-duration trajectory integrity gate for torque-free quaternion rotation and nonlinear gravity-gradient wobble. Revision v11.68 station-to-membrane transfer input validation and the v11.67 station-demand profile alignment checks remain active on top of the dynamic state integrity gates while retaining the pole-local COM-centred body frame for complete per-station force and assembly-COM moment vector profiles, peak directions and peak sample times; scale-aware solver and output-sample coverage gates remain active while retaining distributed gravity from every modeled mass category through
   the static and dynamic Step 4 membrane-load paths. Sheet-patch gravity remains attached
   to its physical surface patches; perimeter-hardware and ICARUS-station gravity loads are
   distributed from their instantaneous COM-referenced attachment positions with explicit
   per-attachment and global force/moment conservation residuals. These maps are included
   in the static structural traction screen, the time-dependent membrane traction map, the
   ICARUS sizing checks and Step 4 acceptance checklist. The complete gravity force and
   gravity-gradient torque remain independently included in the rigid-body equations.
   The attachment map is a reduced-order transfer surrogate, not a detailed attachment,
   seam or finite-element model. Step 4 assessment also invokes torque-free quaternion
   rotation, nonlinear gravity-gradient wobble and the registered stability criteria;
   those outputs are checked separately from the controlled disturbance/recovery run.
   Dynamic trajectory integrity requires finite real sampled state values, strictly increasing sample times and exact agreement with the configured sample count. Every station's force/moment history, peak vector, peak index and peak time must also align with the same trajectory samples; these gates feed ICARUS sizing and Step 4 acceptance. Runtime execution and tests are user-authorized; results must be recorded before modeled completion is claimed. Fundamental constants and intrinsic base-material properties are immutable
   through the input setters. The continuous aluminum-film base is the current provisional
   substrate definition; areal mass is derived from active thickness and intrinsic density.
   The radiation-only outward-force surplus and per-pole future added-mass capacity are
   explicitly calculated; solar-wind pressure is not credited toward that capacity.
   The coupled optimizer uses positive added-mass headroom, transverse-force tolerance,
   and torque tolerance; exact zero-net-force roots remain diagnostics only.
   Step 4 is the resumed current step and remains incomplete until its ICARUS sizing/dynamics work, geometry,
   distributed radiation/gravity loads, station wrench allocation, membrane load-map
   conservation, and independent Pole1/Pole2 assessments are executed and verified in Mathematica.
   The user has now explicitly authorized kernel execution and Step 4 verification.
   Step 4 remains unaccepted until its modeled checks pass for both independent poles
   and all documented scope requirements are satisfied. External actuator, attachment
   and flexible-structure qualifications remain separate. Step 5 remains preliminary
   and unaccepted; Step 6 remains blocked until Step 4 acceptance.
   ======================================================================== *)


(* v11.141 change record: the continuous integrated-simulation controller now uses
   the same scale-aware station wrench allocator as the static six-axis controller.
   Its scaled pseudoinverse is precomputed once per simulation, then reused inside
   the ODE right-hand side. Independent force and moment residuals are referenced
   to a common characteristic-length wrench scale, avoiding false zero-channel
   failures and preventing unscaled N/Nm conditioning from corrupting dynamic sizing.
   Runtime verification remains required for both independent poles. *)


(* v11.142 change record: the dynamic ODE shares a one-entry cache for the full
   patch-resolved environmental evaluation across sibling scalar derivative requests
   at an identical (time, position, quaternion) state. This avoids repeated radiation,
   solar-wind and distributed-gravity assembly within one right-hand-side evaluation.
   The cache is state-keyed and refreshes on any changed state; no trajectory values
   or physical inputs are approximated or skipped. Runtime verification remains required. *)
