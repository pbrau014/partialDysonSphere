# Step 4 moving-reference trajectory study

Completed independent native force grids and seven-day nominal radial trajectories for both poles. Use the 0.6% reserve-preserving design (8.18745e14 kg each, 10.056% initial future mass reserve). Start face-on and at rest at 0.2 AU. Interpolate the native pole-local radial force over 11 distances from 0.20 to 0.30 AU, after scaling out the dominant inverse-square factor. The first force sample matches the previously saved native check.

Both results: day seven distance 0.2177344735 AU, outward displacement 2.65304e9 m, radial speed 8530.71 m/s, irradiance 28711.56 W/m^2, compared with 34029.16 W/m^2 initially. The final irradiance loss is 15.63% and mean loss over the window is 5.54%. The proposed reference therefore requires at least this much excursion and flux variation to accommodate even the nominal case. No allowed mission envelope is specified in these checkpoints.

Do not treat a change of reference as a verified recovery result. This case holds attitude face-on in a radial calculation without disturbances or actuator commands. It has no return leg and no station-load or attachment verification. Acceptance remains open pending a mission envelope and integrated pole-local tracking and structural checks against the selected reference.

Saved evidence: 29_Run_Moving_Reference.wl, separate pole force grids and trajectories. The loaded static balance remains a separate diagnostic.
