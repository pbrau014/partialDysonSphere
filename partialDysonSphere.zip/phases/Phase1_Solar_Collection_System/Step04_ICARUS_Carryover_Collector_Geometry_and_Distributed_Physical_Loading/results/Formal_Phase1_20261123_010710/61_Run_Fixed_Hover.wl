(* Phase 1 Step 4: pole-local static balance of a separate loaded operating case. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"];
d=Get["01_Reference_Architecture.wl"]; area=N[4 Pi 695700000^2/10]; a=Sqrt[area/Pi-10000.^2]; sh=Join[d["SharedNativeInputs"],<|"PerPoleProjectedArea_m2"->Pi a^2,"CapDepthToPlanformRadius"->10000./a|>];
op=Phase1SetPoleOperatingInputs[pole,d["PoleOperatingInputs"]];
If[FailureQ[op],Print[op];Exit[2]];
key="OtherInstalledArealMass_kg_m2"; x0=sh[key];
eval[x_?NumericQ]:=Module[{set,n},
 set=Phase1SetInputs[Join[sh,<|key->x|>]];
 If[FailureQ[set],Print[set];Exit[2]];
 n=Phase1RunPoleTask[pole,"NaturalEquilibrium"];
 If[!AssociationQ[n],Print[n];Exit[2]];
 n=Lookup[n,"Result",n]; If[AssociationQ[Lookup[n,"NaturalEquilibrium",None]],n["NaturalEquilibrium"],n]];
a=eval[x0]; b=eval[x0+.0001]; force="NetNaturalRadialForce_N";
If[!AllTrue[{a[force],b[force]},NumberQ],Print[Keys[a]];Exit[2]];
x=x0-.0001 a[force]/(b[force]-a[force]); c=eval[x];
out=<|"Pole"->pole,"BaseNaturalRadial_N"->a[force],"BaseMass_kg"->a["CurrentPoleMass_kg"],
 "LoadedForce_N"->c[force],"LoadedMass_kg"->c["CurrentPoleMass_kg"],
 "AddedUniformMass_kg"->(c["CurrentPoleMass_kg"]-a["CurrentPoleMass_kg"]),
 "LoadedOtherInstalledArealMass_kg_m2"->x,"ExactNaturalEquilibrium"->c["ExactNaturalEquilibrium"],
 "OutwardRadialBiasPass"->c["OutwardRadialBiasPass"],"RemainingGrowthReserve_kg"->c["SignedFutureAddedMassCapacityBeforeRadialBalance_kg"],
 "LoadedSharedInputs"->Join[sh,<|key->x|>],"LoadedPoleInputs"->d["PoleOperatingInputs"]|>;
Put[out,"61_"<>pole<>".wl"];Print[out];


