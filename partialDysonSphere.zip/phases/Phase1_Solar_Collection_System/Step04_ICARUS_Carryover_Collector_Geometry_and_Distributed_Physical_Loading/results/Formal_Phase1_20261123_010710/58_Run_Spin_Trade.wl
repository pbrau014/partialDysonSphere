(* Phase 1 Step 4: spin trade on 10 km geometry, independent pole screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
n=Get["29_"<>p<>"_Moving_Reference.wl"]; d=Get["32_"<>p<>"_CME_RideThrough.wl"];
sh=Get["56_"<>p<>".wl"]; area=N[4 Pi 695700000^2/10];m=n["Mass_kg"];
h=10000.;a=Sqrt[area/Pi-h^2];rc=area/(2 Pi h);r0=n["ForceGrid_N"][[1,1]];
mu=1.3271244*^20; r7=r0 d["Day7Distance_AU"]/.2;
den[u_?NumericQ]:=Sqrt[1-(a u/rc)^2];
ax[u_?NumericQ]:=h-((a u)^2/rc)/(1+den[u]);
avg[rr_,w_]:=m a^2/area NIntegrate[u^2 (w^2-mu/((rr-ax[u])^2+(a u)^2)^(3/2))/den[u],{u,0,1}];
bal[rr_]:=Sqrt[-avg[rr,0.]/avg[rr,1.]];
rows=Table[With[{w=If[days==Infinity,0.,2 Pi/(86400 days)]},
 {days,a w,avg[r0,w],avg[r7,w],2705. a^2 (w^2-mu/(r0^2+a^2)^(3/2))}],
 {days,{Infinity,7.,1.,2 Pi/(86400 bal[r0])}}];
o=<|"Pole"->p,"Columns"->{"SpinDays","RimSpeed_m_s","InitialNetCut_N_m","Day7NetCut_N_m","InitialIdealRingHoopStress_Pa"},
 "Rows"->rows,"AdaptiveCutBalancePeriods_days"->{2 Pi/(86400 bal[r0]),2 Pi/(86400 bal[r7])},
 "CMEOnlyMassScreen"->First[sh["Rows"]],
 "Scope"->"Axisymmetric shallow cap with uniform mass. Signed cut resultant from transverse gravity and centrifugal inertia only. Ring stress includes ideal rim gravity but no sheet traction. Cut balance is not patchwise, and the model excludes photon steering, rim/foil interaction, and stability."|>;
Put[o,"58_"<>p<>".wl"];Print[o];
