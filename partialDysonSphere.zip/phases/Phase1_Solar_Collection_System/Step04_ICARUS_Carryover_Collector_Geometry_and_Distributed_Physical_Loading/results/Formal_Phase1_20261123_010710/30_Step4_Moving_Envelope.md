# Step 4 provisional moving mission envelope

Using the existing 1%-radius radial tracking tolerance as a provisional tube, the seven-day trajectory requires 0.1999707 to 0.2177637 AU and at least 28,703.85 W/m^2 at the outer edge. This is a required operating range for this design case, not evidence that later mission systems tolerate the excursion.

Native pole-local wrench allocation reconstructs a unit radial command. Reserving 447.925 GN per station for the prior attitude disturbance leaves 208.30 GN of ideal radial authority per pole at the 500 GN trial station cap. The ideal isolated 24-hour correction scales are 21.98 m/s for a velocity change and 474.8 km for a rest-to-rest position change. They cannot be achieved simultaneously from these separate calculations. The position scale is about 11% of the 4378 km tube half-width, so being inside the tube alone cannot guarantee full recentring. Disturbance magnitude and time history need to be specified and evaluated in the coupled trajectory.

The existing 20 m panel screen uses a coarse-map station bound that covers any station force directions within the trial caps, with static environmental normal pressure. It provides no resolved stresses at the attachments and excludes transient environmental pressure. Verification needs a force path from station through the support network into the rim/sheet and a structural mass ledger. Step 4 stays open.

Saved native envelope runner and two independent outputs are in this directory.
