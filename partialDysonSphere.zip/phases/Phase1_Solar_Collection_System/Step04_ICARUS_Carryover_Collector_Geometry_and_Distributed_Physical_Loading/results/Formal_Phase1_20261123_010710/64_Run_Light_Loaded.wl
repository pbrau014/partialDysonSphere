(* Phase 1 Step 4: verify loaded equilibrium for the lightweight planning case. *)
src=Environment["POLAR_ACCEPT_SOURCE"]; If[Get[src]===$Failed,Exit[3]];
p=Environment["POLAR_ACCEPT_POLE"]; d=Get["01_Reference_Architecture.wl"];
fixed=Get["61_"<>p<>".wl"]; trade=Get["63_"<>p<>".wl"];
pick=SelectFirst[trade["Cases"],#["ReserveFraction"]==.1&];
f=pick["PV_pct"]/100; area=N[4 Pi 695700000^2/10];
base=(1.526698109072746*^14 .2705+4.694880877436852*^13/4) f/.006;
sh=Join[fixed["LoadedSharedInputs"],<|"PVFraction"->f|>];
op=Phase1SetPoleOperatingInputs[p,d["PoleOperatingInputs"]];If[FailureQ[op],Exit[2]];
eval[m_]:=Module[{set,n},
 set=Phase1SetInputs[Join[sh,<|"OtherInstalledArealMass_kg_m2"->((base+m)/area)|>]];
 If[FailureQ[set],Print[set];Exit[2]];
 n=Phase1RunPoleTask[p,"NaturalEquilibrium"]; If[!AssociationQ[n],Print[n];Exit[2]];
 n=Lookup[n,"Result",n];Lookup[n,"NaturalEquilibrium",n]];
force="NetNaturalRadialForce_N";
m0=pick["ModelReportedMassReserve_kg"]; a=eval[m0]; b=eval[m0+10^12];
mass=m0-10^12 a[force]/(b[force]-a[force]); c=eval[mass];
out=<|"Pole"->p,"PV_pct"->100 f,"ConditionalPower_W"->pick["ConditionalPower_W"],
 "LaterUniformHardwareMassToBalance_kg"->mass,"LoadedMass_kg"->c["CurrentPoleMass_kg"],
 "LoadedRadialResidual_N"->c[force],"ExactNaturalEquilibrium"->c["ExactNaturalEquilibrium"],
 "Scope"->"Uniform effective loading, fixed 0.2 AU, 10 km cap. Conditional cooling, short copper routes, and future hardware mass target, not an installed design."|>;
Put[out,"64_"<>p<>".wl"];Print[out];
If[!TrueQ[out["ExactNaturalEquilibrium"]],Exit[1]];
