$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$source = (Get-ChildItem -LiteralPath '.\00_Prework\source' -Filter '*cached_dynamic_environment.wl' -File | Select-Object -First 1).FullName
$stage = Join-Path $env:TEMP ('polar_'+[guid]::NewGuid()+'.wl')
Copy-Item -LiteralPath $source -Destination $stage
if ((Get-FileHash -LiteralPath $source).Hash -ne (Get-FileHash -LiteralPath $stage).Hash) { throw 'Source staging hash mismatch' }
$env:POLAR_ACCEPT_SOURCE = $stage
foreach ($pole in 'Pole1','Pole2') {
  $env:POLAR_ACCEPT_POLE = $pole
  $log = "07_${pole}_Kernel.log"
  & wolframscript -file '06_Run_Step4_Acceptance.wl' *> $log
  $code = $LASTEXITCODE
  Add-Content -LiteralPath $log -Value "WolframScript exit code: $code"
}
