<|"Pole" -> "Pole1", "Cap_N" -> 500000000000, 
 "Bound_Pa" -> 0.0007839806855332916, "HalfSpanAtPointOnePretension_m" -> 
  25.510832561385474|>
