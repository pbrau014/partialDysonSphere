<|"Pole" -> "Pole1", "NormalPressureBoundPerStationCap_PaPerN" -> 
  1.4944558787815347*^-15, "StaticPeak_Pa" -> 0.0000367527461425242, 
 "EnvelopeAt1p5TN_Pa" -> 0.002278436564314826, 
 "HalfSpanAt1p5TN_m" -> 8.777949016989385|>
