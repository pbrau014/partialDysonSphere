# Step 4 depth comparison extension

Add 50 km and 70 km to the shallow-cap trade alongside 10 km, 20 km, and 30 km. This does not replace the documented 100 km primary and 250 km alternative. The 56 Wolfram runner uses each pole's saved CME bypass, pressure, and mass budget. For the 70 km case it also integrates ideal aligned hoop fiber needed above the 1.4 N/m foil allowable using the shallow-cap linear hoop profile.

At 50 km the bypass is about 6.81e11 kg, and peak hoop demand is 1.05 N/m. At 70 km the corresponding values are 9.53e11 kg and 1.47 N/m, with about 3.32e8 kg ideal hoop fiber. Against the existing 4.12e11 kg allowance, both added cases are over budget before any solar tide, bond, buckling or installed structure costs. Retain as trade points; prioritize 10 km and 20 km for the combined-load comparison. Step 4 stays open.
