(* Phase 1 Step 4: smooth distributed optical wrench substitution. *)
p=Environment["POLAR_ACCEPT_POLE"]; If[!MemberQ[{"Pole1","Pole2"},p],Exit[2]];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
d=Get["66_"<>p<>".wl"]; e=Get["67_"<>p<>".wl"]; h=Get["70_"<>p<>".wl"];
a=N[4 Pi 695700000^2/10]; rad=Sqrt[a/Pi-10000.^2];
ar=a (1-d["PV_pct"]/100); w=c["ICARUSWrenchMatrix"];
peakReturn=Max[First[e["Cases"]]["RequiredReflectivityRange"]];
head=(.999-peakReturn) 2 34029.16163521439/299792458.;
run[case_]:=Module[{wr,coeff,peak},
 wr=(w.Flatten[#]& /@ case["AppliedStationForces_N"]);
 (* Full-disk affine field; pressure map per steerable non-PV area. *)
 coeff=({#[[1]],-4 #[[6]]/rad,4 #[[5]]/rad}/ar& /@ wr);
 peak=Max[(Abs[First[#]]+Norm[Rest[#]])& /@ coeff];
 <|"CMEExcessFractionError"->case["CMEExcessFractionError"],"PeakAffineAxialPressureAdjustment_Pa"->peak,
 "CalmPositiveHeadroom_Pa"->head,"FractionOfCalmPositiveHeadroom"->peak/head,
 "RemainingMaximumTransverseForce_N"->Max[Norm /@ wr[[All,2;;3]]],
 "RemainingMaximumRollTorque_Nm"->Max[Abs[wr[[All,4]]]],
 "PressureColumns"->{"Constant_Pa","yOverR_Pa","zOverR_Pa"},"PressureCoefficients"->coeff|>];
out=<|"Pole"->p,"Cases"->(run /@ h["Cases"]),
 "Scope"->"Ideal axial affine pressure variation. Assumes independently addressable spread, uniform PV coverage, on-axis ray budget and unchanged force histories. Does not demonstrate optical precision, bandwidth, remaining six-axis recovery, or realized deformation."|>;
Put[out,"74_"<>p<>".wl"];Print[{p,KeyDrop[#,"PressureCoefficients"]& /@ out["Cases"]}];
