(* Phase 1 Step 4: ideal freely rotating ring material screen. *)
p=Environment["POLAR_ACCEPT_POLE"];
d=Get["21_Step4_Candidate_Inputs.wl"];
c=Get["02_"<>p<>"_Static.wl"]["Results"]["Step4EngineeringCore"];
a=c["Geometry"]["PlanformEquivalentRadius_m"];
rho=2705.; allow=14.*^6; period=d["AxialSpinPeriod_s"];
v=2 Pi a/period;
(* Ring-only self stress excludes sheet load and all radial reactions. *)
o=<|"Pole"->p,"RingRadius_m"->a,"RimSpeed_m_s"->v,
 "MinAllowableSpecificStrength_m2_s2"->v^2,"AluminumAllowableSpecificStrength_m2_s2"->allow/rho,
 "IdealAluminumRingSelfStress_Pa"->rho v^2,
 "IdealMinimumAluminumRingPeriod_days"->2 Pi a Sqrt[rho/allow]/86400,
 "Scope"->"Uniform self-supporting tension-only ring in free spin; excludes all sheet forces, gravity, propulsion and alternate load paths."|>;
Put[o,"37_"<>p<>"_Rim_Material_Screen.wl"];Print[o];
