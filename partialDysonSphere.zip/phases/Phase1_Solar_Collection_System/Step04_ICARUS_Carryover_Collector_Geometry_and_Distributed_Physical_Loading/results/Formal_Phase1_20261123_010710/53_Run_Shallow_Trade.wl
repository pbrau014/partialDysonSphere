(* Phase 1 Step 4: shallow cap CME mass sensitivity and solar tide cut scale. *)
p=Environment["POLAR_ACCEPT_POLE"];
s=Get["52_"<>p<>".wl"];
n=Get["29_"<>p<>"_Moving_Reference.wl"];
a=N[4 Pi 695700000^2/10]; m=n["Mass_kg"]; r=n["ForceGrid_N"][[1,1]];
b=Get["48_"<>p<>"_Unstiffened_Area.wl"]["RemainingReservePreservingMass_kg"];
m100=First[s["Rows"]][[3]];
rp=Sqrt[a/Pi];
(* Flat disk, uniform mass: x integral over one half-disk is 2 R^3/3.
   Divide the inward half-disk solar tide force by the cut length 2 R. *)
f=(m/a) (1.3271244*^20/r^3) 2 rp^3/3;
out=<|"Pole"->p,"Columns"->{"Depth_km","CMEOnlyIdealBypass_kg","MassLeftBeforeOtherLoads_kg"},
 "DepthSweep"->Table[{h,m100 h/100,b-m100 h/100},{h,{10.,15.,20.,25.,30.}}],
 "FlatDiskSolarTransverseTideHalfCutForce_N"->f,"AverageSolarTideCutResultant_N_m"->f/(2 rp),
 "Scope"->"CME-only shallow scaling plus an independent face-on flat-disk gravity load scale. No cancellation by radiation, rotation or edge reaction is modeled; no installed mass or acceptance."|>;
Put[out,"53_"<>p<>".wl"];Print[out];
