<|"Pole" -> "Pole2", "RequiredPretension_N_m" -> 0.07839806855332916, 
 "MarginFactor" -> 1.2755416280692735, "PureAxialSectionAt14MPa_m2" -> 
  35714.28571428571|>
