<|"Pole" -> "Pole1", "Duration_s" -> 604800, 
 "OutwardDrift_m" -> 1.122259444945632*^10, 
 "FinalSpeed_m_s" -> 33527.782833873884, "FinalFluxFraction" -> 
  0.528854807323981|>
