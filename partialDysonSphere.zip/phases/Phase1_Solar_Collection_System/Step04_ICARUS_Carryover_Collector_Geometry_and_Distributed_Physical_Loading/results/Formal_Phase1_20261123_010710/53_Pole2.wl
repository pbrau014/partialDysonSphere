<|"Pole" -> "Pole2", "Columns" -> {"Depth_km", "CMEOnlyIdealBypass_kg", 
   "MassLeftBeforeOtherLoads_kg"}, "DepthSweep" -> 
  {{10., 1.3611021665462373*^11, 2.759185331894963*^11}, 
   {15., 2.0416532498193558*^11, 2.0786342486218442*^11}, 
   {20., 2.7222043330924747*^11, 1.3980831653487253*^11}, 
   {25., 3.402755416365593*^11, 7.175320820756067*^10}, 
   {30., 4.0833064996387115*^11, 3.6980998802488403*^9}}, 
 "FlatDiskSolarTransverseTideHalfCutForce_N" -> 3.7879543209453644*^11, 
 "AverageSolarTideCutResultant_N_m" -> 430.4500261198724, 
 "Scope" -> "CME-only shallow scaling plus an independent face-on flat-disk \
gravity load scale. No cancellation by radiation, rotation or edge reaction \
is modeled; no installed mass or acceptance."|>
