(* Phase 1 Step 4: short integrated spin-mode wiring check; no acceptance claim. *)
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
p=Environment["POLAR_ACCEPT_POLE"];
ref=Get["01_Reference_Architecture.wl"]; d=Get["21_Step4_Candidate_Inputs.wl"];
shared=Join[ref["SharedNativeInputs"],<|"SpinTrackingEnabled"->True,
 "ICARUSStationForceCapacity_N"->d["TrialStationCap_N"],"DynamicSampleCount"->16,"MeshRadialCount"->6,"MeshAzimuthCount"->16|>];
op=Join[ref["PoleOperatingInputs"],<|"DynamicCheckDuration_s"->604800.,
 "InitialAngularVelocity_rad_s"->{N[2 Pi/d["AxialSpinPeriod_s"]],0.,0.},
 "InitialAttitudeSmallAngles_rad"->{0.,N[Degree/4],0.},
 "ControllerAttitudeKp_perS2"->d["AttitudeKp_per_s2"],
 "ControllerAttitudeKd_perS"->d["AttitudeKd_per_s"]|>];
errors=Select[{Phase1SetInputs[shared],Phase1SetPoleOperatingInputs[p,op]},FailureQ];
If[errors=!={},Print[errors];Exit[1]];
Print[{p,"SpinTrackingEnabled",Phase1GetInputs[]["SpinTrackingEnabled"]}];
x=TimeConstrained[Phase1RunPoleTask[p,"IntegratedSimulation"],150,Failure["SmokeTimeLimit",<||>]];
s=If[AssociationQ[x],KeyTake[x,{"SolverSucceeded","Duration_s","SpinTrackingEnabled",
 "ICARUSSaturationOccurred","MaximumRequiredStationForce_N","MaximumQuaternionNormalizationError","RecoveryWithinLimit","RecoveryTime_s","StructuralScreenPass","FinalRecoveryErrors","RadialDeviationWithinLimit","LateralDeviationWithinLimit","AttitudeWithinLimit"}],x];
Put[<|"Pole"->p,"Summary"->s,"SourceHash"->FileHash[src,"SHA256","HexString"]|>,"24_"<>p<>"_Integrated_Smoke.wl"];
Print[{p,s}];


