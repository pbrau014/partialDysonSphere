<|"Pole" -> "Pole2", "StaticPeakNormalPressure_Pa" -> 0.0000367527461425242, 
 "LegacyFullRadiusPass" -> False, "TrialHalfSpan_m" -> 
  {100, 300, 500, 1000, 5000, 10000}, "RequiredPretension_N_m" -> 
  {0.018376373071262102, 0.0551291192137863, 0.0918818653563105, 
   0.183763730712621, 0.918818653563105, 1.83763730712621}, 
 "MaxHalfSpanAtConfiguredPretension_m" -> 544.1770234649026, 
 "MaxHalfSpanAtStrengthLimit_m" -> 7618.478328508635|>
