<|"Pole" -> "Pole1", "Cases" -> {<|"Cap_N" -> 6.*^10, "GainFactor" -> 1., 
    "SolverSucceeded" -> True, "Recovery_s" -> 260999.99999999997, 
    "PeakDemand_N" -> 7.465422194780493*^10, "Saturated" -> True, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.000018769469052401536, "QuaternionNormError" -> 
     3.7784824935549466*^-8|>, <|"Cap_N" -> 1.2*^11, "GainFactor" -> 1., 
    "SolverSucceeded" -> True, "Recovery_s" -> 256200., 
    "PeakDemand_N" -> 7.465422194780493*^10, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00001942203374322879, "QuaternionNormError" -> 
     3.3354434214594164*^-8|>, <|"Cap_N" -> 1.2*^11, "GainFactor" -> 2., 
    "SolverSucceeded" -> True, "Recovery_s" -> 182700., 
    "PeakDemand_N" -> 1.4930844389560986*^11, "Saturated" -> True, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.000027581482128723655, "QuaternionNormError" -> 
     1.339512513132135*^-7|>, <|"Cap_N" -> 2.4*^11, "GainFactor" -> 2., 
    "SolverSucceeded" -> True, "Recovery_s" -> 181200., 
    "PeakDemand_N" -> 1.4930844389560986*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00003826271599382839, "QuaternionNormError" -> 
     1.3379657193279826*^-7|>}|>
