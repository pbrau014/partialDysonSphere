<|"Pole" -> "Pole1", "Cases" -> {<|"Cap_N" -> 6.*^11, "GainFactor" -> 6., 
    "SolverSucceeded" -> True, "Recovery_s" -> 75000., 
    "PeakDemand_N" -> 4.479253316868296*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00009437045662283592, "QuaternionNormError" -> 
     3.6382641344090416*^-10|>, <|"Cap_N" -> 9.*^11, "GainFactor" -> 10., 
    "SolverSucceeded" -> True, "Recovery_s" -> 57300., 
    "PeakDemand_N" -> 7.465422194780493*^11, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.00016796782343051124, "QuaternionNormError" -> 
     1.9068913115205532*^-10|>, <|"Cap_N" -> 1.5*^12, "GainFactor" -> 16., 
    "SolverSucceeded" -> True, "Recovery_s" -> 56099.99999999999, 
    "PeakDemand_N" -> 1.194467551164879*^12, "Saturated" -> False, 
    "PeakTilt_deg" -> 1.2499999999998945, "PeakNetStationForce_N" -> 
     0.000307597858358457, "QuaternionNormError" -> 
     3.1769475938858704*^-11|>}|>
