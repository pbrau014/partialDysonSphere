(* Phase 1 Step 4: antisunward backing candidate, optimistic tensile-only sensitivity. *)
p=Environment["POLAR_ACCEPT_POLE"];
area=N[4 Pi 695700000^2/10];
normal=Get["40_"<>p<>"_Membrane_Cut.wl"]["ApexMeridionalIncrementMagnitude_N_m"];
ideal=Get["41_"<>p<>"_Rim_Thrust_Limit.wl"]["BestPeakCMEMembraneIncrement_N_m"];
budget=Get["27_"<>p<>"_Reserve_Trade.wl"]["MaximumAddedMassPreservingReserve_kg"];
data={{"Toray T1100G carbon fiber",1790.,7.*^9},{"Toyobo Zylon AS PBO fiber",1540.,5.8*^9},
 {"Kuraray Vectran HT yarn",1400.,3.402*^9},{"DuPont Kapton HN film at 23 C",1420.,231.*^6}};
rows=Map[Function[d,With[{rho=d[[2]],allow=d[[3]]/2},
 {d[[1]],d[[3]]/rho, Max[0,normal-1.4]/allow, area rho Max[0,normal-1.4]/allow,
 area rho Max[0,ideal-1.4]/allow}]],data];
o=<|"Pole"->p,"Scope"->"Uniform backing; perfectly aligned tension and full load transfer; illustrative factor two on ultimate. No load sharing, compression, bonding, radiation, thermal or shell qualification.",
 "ReservePreservingAddedMassCeiling_kg"->budget,"Rows"->rows,
 "Columns"->{"Material","UltimateSpecificStrength_m2_s2","PassiveEquivalentThickness_m","PassiveUniformBackingMass_kg","IdealTrimUniformBackingMass_kg"}|>;
Put[o,"43_"<>p<>"_Backing_Screen.wl"];Print[o];
