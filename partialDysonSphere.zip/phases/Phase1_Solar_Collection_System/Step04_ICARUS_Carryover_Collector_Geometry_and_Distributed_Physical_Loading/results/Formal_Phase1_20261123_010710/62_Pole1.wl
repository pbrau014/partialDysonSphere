<|"Pole" -> "Pole1", "Cases" -> {<|"CoolingDensity_g_m2" -> 1., 
    "ReserveFraction" -> 0., "PV_pct" -> 0.8307264755373335, 
    "ConditionalPower_W" -> 4.68704857396045*^18, 
    "RadialForce_N" -> -1.640625, "MassBeforeLaterLoading_kg" -> 
     9.273087724283534*^14, "ModelReportedMassReserve_kg" -> 
     -1.3724003911031924*^11, "StaticBalancePass" -> True, 
    "InterpolationResidual" -> -1.640625|>, <|"CoolingDensity_g_m2" -> 1., 
    "ReserveFraction" -> 0.1, "PV_pct" -> 0.701131828703936, 
    "ConditionalPower_W" -> 3.955861567743401*^18, 
    "RadialForce_N" -> 1.252420775521775*^13, "MassBeforeLaterLoading_kg" -> 
     8.434189228258798*^14, "ModelReportedMassReserve_kg" -> 
     8.434189228259186*^13, "StaticBalancePass" -> False, 
    "InterpolationResidual" -> 3.875|>, <|"CoolingDensity_g_m2" -> 0.2705, 
    "ReserveFraction" -> 0., "PV_pct" -> 1.1613752973226101, 
    "ConditionalPower_W" -> 6.552604968594386*^18, 
    "RadialForce_N" -> -2.21875, "MassBeforeLaterLoading_kg" -> 
     9.257703113916452*^14, "ModelReportedMassReserve_kg" -> 
     -1.3724003911421886*^11, "StaticBalancePass" -> True, 
    "InterpolationResidual" -> -2.21875|>, <|"CoolingDensity_g_m2" -> 0.2705, 
    "ReserveFraction" -> 0.1, "PV_pct" -> 0.9804522919865077, 
    "ConditionalPower_W" -> 5.531817815267276*^18, 
    "RadialForce_N" -> 1.2506692196080438*^13, "MassBeforeLaterLoading_kg" -> 
     8.422374514968804*^14, "ModelReportedMassReserve_kg" -> 
     8.422374514969772*^13, "StaticBalancePass" -> False, 
    "InterpolationResidual" -> 9.671875|>}, "Scope" -> "Native static force \
at 10 km cap and 0.2 AU. Earlier linear PV power, cooling and copper laws. \
Installed hardware, radiator optical forces and CME stationkeeping \
unverified."|>
