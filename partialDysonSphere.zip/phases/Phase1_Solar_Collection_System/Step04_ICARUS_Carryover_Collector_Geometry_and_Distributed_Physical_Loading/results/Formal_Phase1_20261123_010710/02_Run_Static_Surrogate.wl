(* Phase 1 Step 4. Independent static surrogate for the 0.6% reference. *)
root=DirectoryName[$InputFileName];
src=Environment["POLAR_ACCEPT_SOURCE"];
If[Get[src]===$Failed,Exit[3]];
pole=Environment["POLAR_ACCEPT_POLE"];
If[!MemberQ[{"Pole1","Pole2"},pole],Exit[2]];
design=Get["01_Reference_Architecture.wl"];
change=Phase1SetInputs[design["SharedNativeInputs"]];
op=Phase1SetPoleOperatingInputs[pole,design["PoleOperatingInputs"]];
If[FailureQ[change]||FailureQ[op],Print[Select[{change,op},FailureQ]];Exit[1]];
tasks={"Geometry","SurfaceMesh","Step4EngineeringCore","NaturalEquilibrium"};
res=AssociationMap[Phase1RunPoleTask[pole,#]&,tasks];
path="02_"<>pole<>"_Static.wl";
Put[<|"Pole"->pole,"SourceHash"->FileHash[src,"SHA256","HexString"],"Results"->res|>,path];
Print[{pole,Map[AssociationQ,res],Cases[res,_Failure,1],KeyTake[res["NaturalEquilibrium"],{"NetNaturalRadialForce_N","NaturalEquilibriumPass"}]}];
If[!And@@(AssociationQ /@ Values[res]),Exit[1]];




