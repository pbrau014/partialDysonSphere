# Step 1 - Establish the Governing Inputs and Assumptions Baseline

**Roadmap status:** Complete.

Keep step-specific inputs, source, scripts, reports, tests, and results in the corresponding folders. The governing roadmap defines scope and acceptance.

## Current recalculation plan

Carry the selected and alternative coverage, fixed geometry, uniform mass, and the complete coverage range. Record hardware allowances as provisional.
