# Step 2 - Establish Natural Force and Torque Equilibrium

**Roadmap status:** Complete.

Keep step-specific inputs, source, scripts, reports, tests, and results in the corresponding folders. The governing roadmap defines scope and acceptance.

## Current recalculation plan

Verify the full pole-local force and torque balance with installed mass and optical effects. The outward radial surplus is a design reserve.
