# Phase 0 - Master Parameters

Reserved for Phase 0 project materials. This directory does not define internal steps; follow the governing roadmap and existing project authorization.


=== ALL-PHASE TENTATIVE PLANNING BASELINE ===
Planning basis: 10 km cap for provisional downstream sizing; compare 20 km for shape retention. Retain 100 km and 250 km as documented reference cases. The 0.6% PV design, 1.1% alternative and 0.5%-3.0% coverage range remain in the trade record. Use conditional interfaces and explicit TBDs. Step 4 remains technically open; planning proceeds without representing any failed or unverified gate as passed. Keep pole results independent; aggregation is reporting only. Revisit the coupled design after the all-phase plan.
Master register: tag each value as verified screen, provisional target, or TBD. Track source, geometry, units, per-pole applicability and revision. Keep 10% future mass reserve in the ledger. Demand installed mass, heat and power data back from every phase.

CURRENT OPERATING REFERENCE: By user direction, plan for the loaded collector to remain at a fixed heliocentric location at 0.2 AU after future mass is installed. The outward moving reference and its day-seven power derating are historical studies. Use stationary-reference disturbance rejection for further acceptance work. Static balance is a design target and does not qualify CME stationkeeping, attitude stability or shape retention. Treat future mass reserve as prior to loading, and reconcile once actual hardware mass is known.
