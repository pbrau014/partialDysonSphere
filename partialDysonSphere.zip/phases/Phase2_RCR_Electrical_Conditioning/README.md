# Phase 2 - RCR Electrical Conditioning

Reserved under the fixed six-phase project structure. Do not create internal steps before the authorized Phase 1 completion and handoff planning point.


=== ALL-PHASE TENTATIVE PLANNING BASELINE ===
Planning basis: 10 km cap for provisional downstream sizing; compare 20 km for shape retention. Retain 100 km and 250 km as documented reference cases. The 0.6% PV design, 1.1% alternative and 0.5%-3.0% coverage range remain in the trade record. Use conditional interfaces and explicit TBDs. Step 4 remains technically open; planning proceeds without representing any failed or unverified gate as passed. Keep pole results independent; aggregation is reporting only. Revisit the coupled design after the all-phase plan.
RCR interface: 3.39 EW at 0.2 AU and 2.54 EW on day seven per pole are historical conditional conditioned-side estimates for planning. Identify the raw PV and bus boundary, allocate cooling/collection/conditioning losses once, and return input/output voltage, current, efficiency map, heat, installed mass and fault limits. Do not apply the historical conditioning loss a second time.

CURRENT OPERATING REFERENCE: By user direction, plan for the loaded collector to remain at a fixed heliocentric location at 0.2 AU after future mass is installed. The outward moving reference and its day-seven power derating are historical studies. Use stationary-reference disturbance rejection for further acceptance work. Static balance is a design target and does not qualify CME stationkeeping, attitude stability or shape retention. Treat future mass reserve as prior to loading, and reconcile once actual hardware mass is known.
