# Operations Review and Handoff Notes

## Source and roadmap reconciliation

The latest project source located in the Library is v11.142, named `Phase1_Polar_Collector_v11.142_step4_cached_dynamic_environment.wl`. Its SHA-256 is recorded in the manifest. The governing roadmap supplied with this package is version 1.2 and still contains an older current-position paragraph naming v11.136 and its older bounded tests. The source is newer than that paragraph. This handoff records v11.142 as the source baseline without silently rewriting the supplied roadmap; a roadmap progress-marker update should be made after the next verified source/test checkpoint.

## Recent source changes

- **v11.141:** changes the continuous integrated-simulation controller to use the same scale-aware station wrench allocator as the static six-axis controller. A scaled pseudoinverse is precomputed once per simulation and reused inside the ODE right-hand side to improve the conditioning of mixed force (N) and moment (N m) channels.
- **v11.142:** adds a one-entry cache for the full patch-resolved environmental evaluation across sibling scalar derivative requests at the same `(time, position, quaternion)` state. It avoids repeated radiation, solar-wind and distributed-gravity assembly within one ODE RHS evaluation. The cache refreshes when the state changes; the source says it does not approximate or skip physical inputs. Both source change records explicitly state runtime verification remains required.

## Correct evaluator loading discipline

The Wolfram Language evaluator is stateless between calls. For each independent evaluation:

1. Transfer the **entire exact** source file in ordered chunks and confirm the expected byte/content length and revision sentinel.
2. Load the source using `Get[StringToStream[completeSourceText]]` (or, in local Mathematica, `Get[fullSourcePath]`).
3. Invoke only package-qualified public names, such as `Phase1PolarCollector`Phase1InputStatus[]` and `Phase1PolarCollector`Phase1RunStep4Assessment["Pole1"]`.
4. Do not concatenate unqualified calls after the package text and assume the parser will resolve those symbols in the package context. The earlier attempt caused Global/package shadowing warnings.
5. Do not invoke package-private helper names by guessing their context. The earlier manual `phase1Structural` / `phase1LoadMap` probes were context-mismatched and are not valid verification.

## Proper next execution sequence

The supplied checkpointed runbook performs:

1. Exact source load and revision assertion.
2. Input-readiness check.
3. Software self-tests.
4. Pole-independence audit.
5. Save checkpoint `00_Readiness_Software_Isolation.wl`.
6. Run `Phase1RunStep4Assessment["Pole1"]` in its isolated context; save its result immediately as `01_Pole1_Step4_Assessment.wl`.
7. Run `Phase1RunStep4Assessment["Pole2"]` independently; save its result immediately as `02_Pole2_Step4_Assessment.wl`.
8. Build and save `03_Step4_Acceptance_Summary.wl` from the two saved results. Only `Step4ScopeComplete -> True` for both poles permits the modeled Step 4 scope to be called complete.

The assessment entry point itself builds the Step 4 core, runs conditional ICARUS redesign sizing, torque-free rotation, nonlinear wobble, and registered stability checks. It is the authoritative end-to-end Step 4 assessment. Use the specific `Step4EngineeringCore` task as a diagnostic only if a full assessment returns a structured model `Failure`; do not claim acceptance from a subset.

## Scope guard

Do not run the full electrical or power calculation to work around a Step 4 problem. Step 7 owns the two-tier PV interconnect and electrical network. The Step 4 core explicitly records `LaterElectricalNetworkNotInvoked -> True`. Keep the Pole 1 and Pole 2 operating states, loads, torques, trajectories, and controls separate.

## Change / save / retest discipline

No source edits were completed in the preceding evaluator operations. The work completed was testing and evidence capture only. The exact v11.142 source and roadmap are preserved in this package. If a future structured model failure identifies a code defect:

- inspect the actual failing function and its inputs/consumers;
- make the smallest justified edit;
- save the full source as a new checkpoint before continuing;
- record the version/hash and static review;
- reload that exact saved checkpoint into a fresh Wolfram kernel;
- rerun readiness, software regressions, pole isolation, the affected calculation, and all dependent Step 4 checks;
- preserve every checkpoint/result rather than overwriting the original v11.142 source.
