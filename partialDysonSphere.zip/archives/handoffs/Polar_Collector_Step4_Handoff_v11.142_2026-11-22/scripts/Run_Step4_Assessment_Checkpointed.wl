(* ========================================================================
   POLAR COLLECTOR — STEP 4 CHECKPOINTED ACCEPTANCE RUNBOOK
   Handoff baseline: v11.142 — 2026-11-22

   Governing project phases (the only project-level phase structure):
     Phase 0 — Master Parameters
     Phase 1 — Solar Collection System
     Phase 2 — RCR Electrical Conditioning
     Phase 3 — Microwave Generation, Transmission and Orbital Distribution
     Phase 4 — Terrestrial Reception and Grid Integration
     Phase 5 — Integrated System Simulation

   This runbook does not edit the source. It saves a checkpoint after readiness,
   software/isolation tests, each independent pole assessment, and final summary.
   Run from a fresh Mathematica kernel. Do not substitute Phase1ComputeAll or the
   full Phase1RunFullAssessment; Step 7 owns the electrical-network calculation.
   ======================================================================== *)

$HandoffRoot = DirectoryName[$InputFileName];
$SourcePath = FileNameJoin[{$HandoffRoot, "..", "source",
  "Phase1_Polar_Collector_v11.142_step4_cached_dynamic_environment.wl"}];
$ResultsPath = FileNameJoin[{$HandoffRoot, "..", "results"}];
If[!DirectoryQ[$ResultsPath], CreateDirectory[$ResultsPath, CreateIntermediateDirectories -> True]];

If[!FileExistsQ[$SourcePath],
  Print["SOURCE FILE NOT FOUND: ", $SourcePath]; Abort[]
];

(* Load the exact saved package file. Keep all subsequent calls package-qualified. *)
Get[$SourcePath];
If[Phase1PolarCollector`Private`$Phase1ModelVersion =!= "11.142",
  Print["Unexpected source revision: ", Phase1PolarCollector`Private`$Phase1ModelVersion]; Abort[]
];

$StartedAt = DateString["ISODateTime"];
$Smoke = <|
  "HandoffBaseline" -> "v11.142",
  "StartedAt" -> $StartedAt,
  "SourcePath" -> $SourcePath,
  "SourceRevision" -> Phase1PolarCollector`Private`$Phase1ModelVersion,
  "InputReadiness" -> Phase1PolarCollector`Phase1InputStatus[],
  "SoftwareSelfTests" -> Phase1PolarCollector`Phase1RunSoftwareSelfTests[],
  "PoleIndependenceAudit" -> Phase1PolarCollector`Phase1PoleIndependenceAudit[]
|>;

$ReadinessPass = AssociationQ[$Smoke["InputReadiness"]] &&
  TrueQ[Lookup[$Smoke["InputReadiness"], "Ready", False]] &&
  Lookup[$Smoke["InputReadiness"], "MissingRequiredInputCount", Infinity] === 0;
$SoftwarePass = AssociationQ[$Smoke["SoftwareSelfTests"]] &&
  TrueQ[Lookup[$Smoke["SoftwareSelfTests"], "Passed", False]] &&
  Lookup[$Smoke["SoftwareSelfTests"], "FailedChecks", <|"Unexpected" -> True|>] === <||>;
$IsolationPass = AssociationQ[$Smoke["PoleIndependenceAudit"]] &&
  TrueQ[Lookup[$Smoke["PoleIndependenceAudit"], "Passed", False]];
$Smoke = Join[$Smoke, <|
  "ReadinessPass" -> $ReadinessPass,
  "SoftwarePass" -> $SoftwarePass,
  "IsolationPass" -> $IsolationPass
|>];
Put[$Smoke, FileNameJoin[{$ResultsPath, "00_Readiness_Software_Isolation.wl"}]];
Print["Saved checkpoint 00_Readiness_Software_Isolation.wl"];

If[!($ReadinessPass && $SoftwarePass && $IsolationPass),
  Print["Smoke/readiness gate did not pass. Stop; do not run Step 4 acceptance."];
  Abort[]
];

(* One hour is a wall-clock ceiling for an individual pole assessment. A timeout
   is recorded as incomplete, never as a pass or model-level solver failure. *)
$AssessmentWallClockLimitSeconds = 3600;
$TimeoutToken = Unique["AssessmentTimedOut"];

$Pole1Result = TimeConstrained[
  Phase1PolarCollector`Phase1RunStep4Assessment["Pole1"],
  $AssessmentWallClockLimitSeconds,
  $TimeoutToken
];
$Pole1Checkpoint = <|
  "Pole" -> "Pole1",
  "CompletedAt" -> DateString["ISODateTime"],
  "Result" -> $Pole1Result,
  "ReturnedAssociation" -> AssociationQ[$Pole1Result],
  "ModelFailure" -> FailureQ[$Pole1Result],
  "TimedOut" -> SameQ[$Pole1Result, $TimeoutToken],
  "Step4ScopeComplete" -> (AssociationQ[$Pole1Result] &&
    TrueQ[Lookup[$Pole1Result, "Step4ScopeComplete", False]])
|>;
Put[$Pole1Checkpoint, FileNameJoin[{$ResultsPath, "01_Pole1_Step4_Assessment.wl"}]];
Print["Saved checkpoint 01_Pole1_Step4_Assessment.wl"];

$Pole2Result = TimeConstrained[
  Phase1PolarCollector`Phase1RunStep4Assessment["Pole2"],
  $AssessmentWallClockLimitSeconds,
  $TimeoutToken
];
$Pole2Checkpoint = <|
  "Pole" -> "Pole2",
  "CompletedAt" -> DateString["ISODateTime"],
  "Result" -> $Pole2Result,
  "ReturnedAssociation" -> AssociationQ[$Pole2Result],
  "ModelFailure" -> FailureQ[$Pole2Result],
  "TimedOut" -> SameQ[$Pole2Result, $TimeoutToken],
  "Step4ScopeComplete" -> (AssociationQ[$Pole2Result] &&
    TrueQ[Lookup[$Pole2Result, "Step4ScopeComplete", False]])
|>;
Put[$Pole2Checkpoint, FileNameJoin[{$ResultsPath, "02_Pole2_Step4_Assessment.wl"}]];
Print["Saved checkpoint 02_Pole2_Step4_Assessment.wl"];

$PoleScopeChecks = <|
  "Pole1" -> TrueQ[$Pole1Checkpoint["Step4ScopeComplete"]],
  "Pole2" -> TrueQ[$Pole2Checkpoint["Step4ScopeComplete"]]
|>;
$BothPolesPass = And @@ Values[$PoleScopeChecks];
$FinalSummary = <|
  "HandoffBaseline" -> "v11.142",
  "CompletedAt" -> DateString["ISODateTime"],
  "SmokeChecks" -> <|
    "ReadinessPass" -> $ReadinessPass,
    "SoftwarePass" -> $SoftwarePass,
    "IsolationPass" -> $IsolationPass
  |>,
  "PerPoleModeledScopeChecks" -> $PoleScopeChecks,
  "BothIndependentPoleChecksPass" -> $BothPolesPass,
  "Step4Disposition" -> If[$BothPolesPass,
    "MODELED STEP 4 SCOPE COMPLETE — physical hardware qualification remains separate and open.",
    "STEP 4 NOT ACCEPTED — one or both independent pole assessments are incomplete, failed, timed out, or missing."],
  "Pole1CheckpointFile" -> "01_Pole1_Step4_Assessment.wl",
  "Pole2CheckpointFile" -> "02_Pole2_Step4_Assessment.wl",
  "NoCombinedMechanicalEquilibrium" -> True,
  "ElectricalNetworkDeferredToStep7" -> True,
  "HardwareQualificationAsserted" -> False
|>;
Put[$FinalSummary, FileNameJoin[{$ResultsPath, "03_Step4_Acceptance_Summary.wl"}]];
Print["Saved checkpoint 03_Step4_Acceptance_Summary.wl"];
Print[$FinalSummary["Step4Disposition"]];
