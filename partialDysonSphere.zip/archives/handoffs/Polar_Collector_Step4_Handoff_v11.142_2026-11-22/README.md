# Polar Collector — Step 4 Engineering Handoff

**Handoff date:** 2026-11-22  
**Governing project phase:** Phase 1 — Solar Collection System  
**Current step:** Step 4 — Complete ICARUS Carryover, Collector Geometry, and Distributed Physical Loading  
**Source baseline:** v11.142 — cached dynamic environmental RHS evaluation  
**Step 4 disposition:** **OPEN / NOT ACCEPTED**

## Purpose

This package preserves the exact v11.142 Wolfram Language source and the latest supplied governing roadmap, records the verified engineering/software evidence obtained in this session, documents failed or unverified attempts without misclassifying them, and provides a checkpointed Wolfram Language runbook for resuming Step 4.

No change was made to the v11.142 source or the governing roadmap while preparing this handoff. No new engineering result is claimed by packaging alone.

## Package contents

- `source/` — exact v11.142 source file used for this handoff.
- `roadmap/` — exact current roadmap file retrieved from the project Library; preserved as supplied.
- `reports/ENGINEERING_VERIFICATION_STATUS.md` — confirmed results, blockers, and acceptance disposition.
- `reports/OPERATIONS_REVIEW_AND_HANDOFF.md` — review of the preceding evaluator operations and corrections to the testing method.
- `scripts/Run_Step4_Assessment_Checkpointed.wl` — local Mathematica runbook. It loads the source, runs readiness/software/isolation checks, runs Pole 1 and Pole 2 Step 4 assessments independently, and saves a checkpoint after each major result.
- `manifests/SHA256SUMS.txt` — SHA-256 integrity manifest for the included source and roadmap (and package documents/scripts).
- `results/` — initially empty destination for locally generated run checkpoints.

## Important acceptance boundary

The source's Step 4 assessment is pole-local. Run Pole 1 and Pole 2 separately and preserve each result. The combined summary may combine only the boolean modeled-scope completion result; do not combine mechanical equilibrium, forces, torques, operating states, controller states, disturbances, or dynamic trajectories.

Do **not** run `Phase1ComputeAll[]`, `Phase1RunFullAssessment[]`, full joint optimization, or a full electrical/power pipeline as a shortcut for Step 4. The two-tier PV/electrical network belongs to Step 7. The Step 4 source explicitly records that the later electrical network must not be invoked.

A modeled Step 4 pass is not hardware qualification. Actuator torque/gearing, stroke/slew rate, measured bandwidth/phase margin, duty cycle, power/energy, thermal limits, lifetime/radiation effects, attachments, and thin-film manufacturing/structural allowables remain external evidence or qualification items.

## Resume

1. Extract the package to a writable local directory.
2. Open a fresh Wolfram Mathematica kernel.
3. Evaluate `scripts/Run_Step4_Assessment_Checkpointed.wl` (or read it and run its sections individually).
4. Inspect each saved result in `results/`. A result marked `Failure`, `TimedOut`, `$Failed`, or lacking `Step4ScopeComplete -> True` is not a pass.
5. Correct any source defect only after a structured model-level result identifies it. Save a new full source checkpoint before the next modification, reload that exact checkpoint, and rerun the relevant and dependent tests.
6. Update the roadmap's current source revision/hash and acceptance marker only after the relevant work is complete and verified. Preserve the supplied roadmap as the original handoff baseline.

The runbook uses an intentionally long local timeout for each pole assessment because the configured Step 4 dynamic horizon is seven days (`DynamicCheckDuration_s = 604800` seconds). A wall-clock timeout does not mean the modeled seven-day simulation itself failed; it means that execution did not return within the runbook's allotted wall-clock window.
