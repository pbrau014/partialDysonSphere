# Project Layout

The folder hierarchy follows the roadmap's fixed six-phase project structure. Phase 1 retains its established ten numbered steps. The folder structure does not add project phases, redefine step scope, or pre-plan internal steps for later phases.

```text
PolarCollector/
  AGENTS.md                          Project-level instructions and governing rules
  README.md                          Project entry point and current working position
  archives/handoffs/                 Preserved handoff package and ZIP
  docs/
    architecture/                    This architecture map
    status/                          Current location and status notes
  governing/roadmap/                 Supplied governing roadmap copy
  phases/
    Phase0_Master_Parameters/
    Phase1_Solar_Collection_System/
      Step01_Governing_Inputs_and_Assumptions_Baseline/
      Step02_Natural_Force_and_Torque_Equilibrium/
      Step03_ICARUS_Redesign_Sizing_and_Dynamic_Verification/
      Step04_ICARUS_Carryover_Collector_Geometry_and_Distributed_Physical_Loading/
      Step05_Material_Membrane_and_Structural_Architecture/
      Step06_Optical_and_Thermal_Behavior/
      Step07_Photovoltaic_Collection_and_Electrical_Production/
      Step08_Integrated_Rotation_Control_Disturbance_and_Operating_Behavior/
      Step09_Comprehensive_Coupled_Optimization/
      Step10_Integrated_Verification_CoSimulation_and_Phase2_Handoff/
    Phase2_RCR_Electrical_Conditioning/
    Phase3_Microwave_Generation_Transmission_and_Orbital_Distribution/
    Phase4_Terrestrial_Reception_and_Grid_Integration/
    Phase5_Integrated_System_Simulation/
  shared/
    data/inputs/                      Shared project input data
    data/reference/                   Reference data
    models/                           Shared model components
    utilities/                        Shared utilities
```

Each Phase 1 step has `source/`, `inputs/`, `results/`, `reports/`, `scripts/`, and `tests/` folders. Put step-specific material in its step folder. Phase-level folders hold only material genuinely shared across that phase; later-phase folders are organizational placeholders and contain no internal step plan.

The active Step 4 source, runbook, reports, inputs, outputs, and tests belong in the Step 4 folder. Keep generated run checkpoints in its `results/` directory. Preserve independent Pole 1 and Pole 2 inputs, execution, and results.

The `archives/handoffs/` copy is historical and should remain intact. Make changes to the active project copies, not to the archived source package, unless the user explicitly requests an archival correction.

## Current reference configuration

The active design reference is 0.6% PV at 0.2 AU with a fixed curved sheet and perimeter, uniform sheet assembly mass, and distributed 100 kV collection over 1 km one-way routes. Keep the 1.1% higher-power alternative and the 0.5%-3.0% per-pole sweep. Reference conditioned power is 3.39e18 W per pole conditional on cooling, with 2.85e14 kg radial allowance after modeled cooling and copper. Phase 1 and Step 4 acceptance remain open. See the Phase 1 roadmap, Step 4 source/Phase1_Reference_Architecture.wl, architecture CSVs, and formal acceptance records.
