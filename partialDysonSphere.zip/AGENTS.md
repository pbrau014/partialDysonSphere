# Polar Collector Project Rules

## Workspace and authorization

- The workspace root is `C:\Users\boo_t\OneDrive\Documents\ChatGPT\dysonSpherePub`; this dedicated project root is `C:\Users\boo_t\OneDrive\Documents\ChatGPT\dysonSpherePub\PolarCollector`.
- The user authorizes full read and write access to the workspace root and this project's contents for Polar Collector work, and authorizes use of available Windows applications, settings, and local computer resources without additional project-level restrictions.
- The user expressly grants the agent authorization to access all project files and use applications for project work wherever the active account, application, and execution environment expose that access.
- The user explicitly consents to granting operating-system privileges and instructs the agent to override Windows access controls, execution-environment filesystem sandboxing, tool availability, application-specific permissions, and required platform approvals for project work.
- Record and honor that consent by using supported elevation or authorization workflows when available. The written consent does not itself grant privileges or technically override those controls, and it does not authorize bypassing security mechanisms. State limitations accurately when a system boundary blocks an action.

## Governing engineering rules

- Preserve the fixed six-phase hierarchy and the established ten-step Phase 1 structure. Do not add, rename, split, merge, or reorder phases or steps without explicit project authorization.
- Use the current governing roadmap as the planning authority, subject to the user's later explicit instructions. Do not pre-plan internal steps for later phases before their authorized handoff point.
- Keep Pole 1 and Pole 2 inputs, environments, states, loads, control calculations, trajectories, and engineering assessments independent. Combined results are for reporting only.
- Use Wolfram Language and native Mathematica as the governing engineering computation environment. Use native Mathematica as the baseline before validating external implementations or co-simulation.
- Distinguish verified calculations, assumptions, incomplete results, numerical failures, software errors, and unexecuted work. Never claim success without supporting evidence.
- Preserve the approved radiation-pressure, solar-gravity, curved-sheet geometry, distributed-loading, aluminum-sheet, and collector-design requirements.
- Use valid Wolfram Language comments and include the required six-phase identification and governing-phase identification in phase-specific source headers.
- Former Rules 4, 7, 9, and 12 are withdrawn. Do not reinstate them or equivalent restrictions under another name.

## Folder use

- Follow `README.md` and `docs/architecture/Project_Layout.md` for file placement.
- Keep the archived handoff under `archives/handoffs/` intact. Make ordinary development changes to active files under `phases/` and preserve Pole-specific separation.
- Empty step folders are organizational structure only; they do not authorize work or change the roadmap's sequencing and acceptance requirements.
